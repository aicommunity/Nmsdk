set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-solo-threshold-visual-asan-a1"
work="$base/source-solo-threshold-visual-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$base/source-threshold-contract-asan-isolated-a1" -c fetch.recurseSubmodules=false fetch origin 2ced776d0 > "$out/checkout.log" 2>&1
revision=$(git -C "$base/source-threshold-contract-asan-isolated-a1" rev-parse FETCH_HEAD)
git -C "$base/source-threshold-contract-asan-isolated-a1" worktree add --no-checkout --detach "$work" "$revision" >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export BASE="$base"
export TIMELEARNER_SOLO_THRESHOLD_NATIVE="$base/readbacks/s08-native-solo-threshold-trace-asan-a1/native"
export TIMELEARNER_SOLO_THRESHOLD_REPORTS="$base/cache/s08-native-solo-threshold-trace-asan-a1"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/render.log" 2>&1
from pathlib import Path
import hashlib,json,os,time,unittest
from Scripts.StructTrain.TimeLearner.solo_threshold_reports import render_solo_threshold_trace
base=Path(os.environ['BASE']);native=Path(os.environ['TIMELEARNER_SOLO_THRESHOLD_NATIVE']);output=Path(os.environ['TIMELEARNER_SOLO_THRESHOLD_REPORTS'])
sources=sorted(native.glob('*_solo_threshold_*.json'));assert len(sources)==8
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
begin=time.monotonic()
results={}
for p in sources:
 results[p.stem]=render_solo_threshold_trace(p,output/p.stem)
 print('rendered',p.name,flush=True)
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_solo_threshold_reports')
result=unittest.TextTestRunner(verbosity=2).run(suite)
after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
assert before==after
validation={'kind':'native_solo_threshold_visual_gate','schema_version':1,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-begin,'reports':len(results),'channel_trace_pairs':sum(len(r['figures']) for r in results.values()),'source_before':before,'source_after':after,'visual_acceptance_complete':False,'scientific_verdict':None}
(base/'readbacks/s08-native-solo-threshold-visual-asan-a1/validation.json').write_text(json.dumps(validation,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==2 and not result.skipped
assert validation['channel_trace_pairs']==20
print(json.dumps(validation),flush=True)
PY
