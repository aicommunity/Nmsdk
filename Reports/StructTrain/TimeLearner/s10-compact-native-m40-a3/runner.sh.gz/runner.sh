set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out=$base/readbacks/s10-compact-bundle-m40-a3
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
cd "$base/source-compact-bundle-a3"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_BUNDLE_ARTIFACTS=$base/source-repeat-boundary-full-visual-a1/Reports/StructTrain/TimeLearner/s05-repeat-boundary-m40-a3/native-run-a3
export TIMELEARNER_BUNDLE_SELECTED_REPORT=$base/readbacks/s05-repeat-boundary-full-visual-m40-a1
OUT="$out" "$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/python.log" 2>&1
import os,json,unittest,subprocess
from pathlib import Path
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName("Scripts.StructTrain.TimeLearner.tests.test_artifact_bundle"))
record={"kind":"timelearner_compact_bundle_gate","schema_version":1,"root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"tests":r.testsRun,"skips":len(r.skipped),"failures":len(r.failures),"errors":len(r.errors),"scientific_verdict":None}
Path(os.environ["OUT"],"validation.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
PY
"$base/plot-venv-a1/bin/python" -m Scripts.StructTrain.TimeLearner bundle pack-native-tests Scripts/StructTrain/TimeLearner/specs/repeat-boundary-native-v1.json --artifacts "$TIMELEARNER_BUNDLE_ARTIFACTS" --selected-report "$TIMELEARNER_BUNDLE_SELECTED_REPORT" --output "$out/primary-bundle" > "$out/pack.json" 2> "$out/pack.log"
"$base/plot-venv-a1/bin/python" -m Scripts.StructTrain.TimeLearner bundle verify "$out/primary-bundle" > "$out/verify.json" 2> "$out/verify.log"
"$base/plot-venv-a1/bin/python" -m Scripts.StructTrain.TimeLearner bundle extract "$out/primary-bundle" --output "$out/extracted" > "$out/extract.json" 2> "$out/extract.log"
export TIMELEARNER_REPEAT_BOUNDARY_DIR="$out/extracted/native"
OUT="$out" "$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/extracted-evidence.log" 2>&1
import os,json,unittest
from pathlib import Path
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName("Scripts.StructTrain.TimeLearner.tests.test_repeat_boundary_evidence"))
Path(os.environ["OUT"],"extracted-evidence.json").write_text(json.dumps({"tests":r.testsRun,"skips":len(r.skipped),"errors":len(r.errors),"failures":len(r.failures),"scientific_verdict":None},indent=2)+"\n")
raise SystemExit(0 if r.wasSuccessful() and not r.skipped and r.testsRun==5 else 1)
PY
set +e
"$base/plot-venv-a1/bin/python" -m Scripts.StructTrain.TimeLearner bundle pack-native-tests Scripts/StructTrain/TimeLearner/specs/repeat-boundary-native-v1.json --artifacts "$TIMELEARNER_BUNDLE_ARTIFACTS" --selected-report "$TIMELEARNER_BUNDLE_SELECTED_REPORT" --output "$out/rejected-budget" --maximum-bytes 1 > "$out/budget-control.stdout" 2> "$out/budget-control.json"
budget_status=$?
set -e
test "$budget_status" = 2
test ! -e "$out/rejected-budget"
OUT="$out" python3 - <<'PY'
import json,os
from pathlib import Path
out=Path(os.environ["OUT"])
r=json.loads((out/"budget-control.json").read_text())
assert r["status"]=="invalid" and r["reason"]=="primary_bundle_exceeds_extraction_budget" and r["scientific_verdict"] is None
new=json.loads((out/"primary-bundle/manifest.json").read_text())
old=json.loads((out.with_name(out.name[:-2]+"a1")/"primary-bundle/manifest.json").read_text())
assert new["archive"]["sha256"]==old["archive"]["sha256"]
(out/"archive-identity.json").write_text(json.dumps({"same_primary_archive_as_a1":True,"archive_sha256":new["archive"]["sha256"],"cli_budget_exit":2,"no_rejected_output_created":True},indent=2)+"\n")
PY
cat "$out/validation.json"
cat "$out/pack.json"
