import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/home/user/timelearner-refactor/source-worker-dependency-normal-a2')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations,ReservationError
r=Reservations('/tmp/timelearner-contained-3cwmd0id/leases.sqlite3')
values=[]
for i in range(1):
 try:
  values.append(r.reserve("actual-dependency",[{"path":'/tmp/timelearner-contained-3cwmd0id'+"/scratch-"+str(i),"access":"write"}],ttl_seconds=.001))
 except ReservationError as error:
  Path('/tmp/timelearner-contained-3cwmd0id/duplicate-rejection.json').write_text(json.dumps({"reason":str(error)}))
  break
Path('/tmp/timelearner-contained-3cwmd0id/leases.json').write_text(json.dumps(values))
subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
