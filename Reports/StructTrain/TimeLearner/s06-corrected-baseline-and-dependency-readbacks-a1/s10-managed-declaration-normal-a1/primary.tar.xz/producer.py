from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil,time
base=Path('/home/user/timelearner-refactor');label='managed-declaration-normal-a1';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False)
source=base/'source-managed-declaration-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='427a5f2ef28b90a76c458951cad8ef70bb118c95';container=Path(str(out)+'-container')
predecessor=base/'readbacks/s10-managed-reconciliation-normal-a1-container';primary=base/'readbacks/s10-managed-pipeline-coordinator-normal-a1'
stop=threading.Event();thread=None;errors=[];passed=False;token=None
capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 started=time.monotonic()
 while True:
  state=inspect_contained(predecessor)
  if state['all_processes_closed']:
   assert (predecessor/'recovery-event.json').is_file() or (predecessor/'lease-not-created.json').is_file(),'metadata predecessor operational lease status missing'
   assert json.loads((primary/'terminal.json').read_text())['tests_passed'], 'actual coordinator corpus did not pass'
   tests=json.loads((primary/'tests.json').read_text());assert tests['tests']==8 and tests['failures']==tests['errors']==tests['skipped']==0
   write('queue-prerequisite.json',{'predecessor':str(predecessor),'closure':state,'recovery':json.loads((predecessor/('recovery-event.json' if (predecessor/'recovery-event.json').is_file() else 'lease-not-created.json')).read_text()),'actual_coordinator_tests':tests});break
  assert time.monotonic()-started<64800,'coordinator wait budget exhausted'
  write('queue.json',{'reason':'wait_for_reconciliation_metadata_group_closure_and_release_then_actual_coordinator8_corpus','waited_seconds':time.monotonic()-started,'native_models_started':False})
  time.sleep(15)
 assert shutil.disk_usage(base).free>=1024**3
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 reserved=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'},{'path':str(bootstrap),'access':'read'},{'path':str(primary),'access':'read'}],demands={'slots':1,'memory_bytes':512*1024**2,'disk_bytes':256*1024**2},ttl_seconds=120)
 token=reserved['token'];write('reservation.json',reserved)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_MANAGED_COORDINATOR_PRIMARY']=str(primary/'actual-controls')
 os.environ['TMPDIR']=str(out/'temporary');(out/'temporary').mkdir()
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_managed_declaration');assert suite.countTestCases()==11
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':11})
 assert result.testsRun==11 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'new_native_units':0,'source_commit':root,'actual_primary':str(primary),'effective_native_validation_and_full_coordinator_rerun_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
  write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    entry=tarfile.TarInfo(name);entry.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(entry,f)
  write('bundle.json',{'kind':'managed_actual_downstream_declaration_checks','source_commit':root,'passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'new_native_units':0})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
