set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-console-calibration-provenance-normal-a3"
gate="$base/readbacks/s08-native-posttune-console-normal-a2"
source="$base/readbacks/s08-native-posttune-console-latest-reader-normal-a2/analysis-source"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$gate/process-exit-status.txt")" = 0
test -d "$source/Scripts"
cd "$source"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_NATIVE_CALIBRATION_RUN_DIR="$gate/calibration-cli-regressions"
unset QT_QPA_PLATFORM
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_calibration_worker.NativeCalibrationRunProvenanceTest -v > "$out/reader.log" 2>&1

