set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-console-normal-a2"
src="$base/source-order-fixed-a1";analysis="$out/analysis-source"
buildOut="$base/readbacks/s08-native-posttune-console-build-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$buildOut/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
mkdir "$analysis"
git -C "$src" -c fetch.recurseSubmodules=false fetch origin 74f49a5f08f46a16a3bd5e98b589d6dc63025417 > "$out/checkout.log" 2>&1
git -C "$src" archive 74f49a5f08f46a16a3bd5e98b589d6dc63025417 Scripts | tar -x -C "$analysis"
cd "$analysis"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1
unset QT_QPA_PLATFORM
python3 -u - <<'PY' > "$out/jobs.log" 2>&1
import contextlib,copy,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.__main__ import main
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_calibration_worker import audit_execution,audit_run_manifest,POST_TUNE_FIELDS
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
p=Path(os.environ['OUT']);base=Path(os.environ['BASE'])
raw=base/'readbacks/s08-native-posttune-controller-normal-a2/native'
runtimePath=base/'readbacks/s08-native-posttune-console-build-normal-a1/runtime-before.json'
runtime=load(runtimePath);exe=verify_runtime(runtime)
sources={load(v)['sha256']:v for v in raw.glob('*_learned_state.json')};assert len(sources)==2
records=[(v,load(v)) for v in sorted(raw.glob('*_post_tune_*.json')) if load(v).get('kind')=='native_post_tune_transaction']
selected=[(v,r) for v,r in records if any(v.stem.endswith('_'+s) for s in
 ['off','keep','canon','flat','synthetic','auto_metric','soma_metric','silent','recording_budget'])]
assert len(selected)==18
runs=p/'runs';runs.mkdir();jobs=p/'jobs';jobs.mkdir();controls=[]
def signed(v):
 v.pop('sha256',None);v['sha256']=sha(v);return v
def save(path,v):
 path.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def jobFor(record,name,calibration=False):
 source=record['source_recognition']
 model=source['source_solo']['configuration']['model']
 spec=copy.deepcopy(record['confirmation_specification']);spec['attempt_id']='console-posttune/'+name
 d={'kind':'timelearner_native_calibration_job' if calibration else 'timelearner_native_post_tune_job',
 'schema_version':1,'owner_class':'NNeuronTimeLearner'+('Branch' if model['branch'] else ''),
 'implementation_id':source['implementation_id'],'frequency_hz':model['frequency_hz'],'maximum_model_ticks':500000,
 'source_recognition':source,'thresholds':record['thresholds'],
 'maximum_candidates':record['maximum_calibration_candidates'],'specification':spec,'trials':record['trials']}
 if not calibration:d['post_tune']={k:record[k] for k in POST_TUNE_FIELDS}
 return signed(d)
for i,(path,record) in enumerate(selected):
 model=record['source_recognition']['source_solo']['configuration']['model']
 top='Branch' if model['branch'] else 'Classic';name=top+'-'+path.stem.split('_post_tune_')[1]
 job=jobFor(record,name);jobPath=jobs/(name+'.json');save(jobPath,job)
 source=sources[record['source_recognition']['source_solo']['sha256']]
 print('BEGIN',i,name,flush=True)
 with (p/(name+'-cli.log')).open('w') as log,contextlib.redirect_stdout(log):
  code=main(['posttune',str(jobPath),'--source-solo',str(source),'--runtime-manifest',str(runtimePath),
    '--wall-seconds','900','--output',str(runs/name)])
 assert code==0,(name,code)
 proof=audit_run_manifest(runs/name/'run-manifest.json',post_tune=True)
 actual=load(runs/name/'native/transaction.json')
 assert actual['status']==record['status'],(name,actual['status'],record['status'])
 controls.append({'name':name,'expected_status':record['status'],'source_transaction_sha256':record['sha256'],
 'source_path':str(source),'mode':record['mode'],'metric':record['metric']})
 print('DONE',name,actual['status'],flush=True)
save(runs/'controls.json',{'records':controls,'scientific_verdict':None})
# Exercise the unchanged calibration protocol against the newly linked Console.
legacy=p/'calibration-regressions';legacy.mkdir()
(legacy/'runtime-before.json').write_bytes(runtimePath.read_bytes())
for top in ('Classic','Branch'):
 record=next(r for v,r in records if v.stem.startswith(top+'_') and v.stem.endswith('_post_tune_keep'))
 source=sources[record['source_recognition']['source_solo']['sha256']]
 for case,status in [('success','calibrated'),('nonseparable','nonseparable'),('budget','budget_exhausted')]:
  job=jobFor(record,top+'-'+case,calibration=True)
  if case=='nonseparable':job['thresholds']=[1e9];job['maximum_candidates']=1
  if case=='budget':job['thresholds']=[1e9,5e8];job['maximum_candidates']=1
  signed(job);path=legacy/(top+'-'+case+'-job.json');save(path,job)
  directory=legacy/(top+'-'+case)
  result=execute(runtime,['--app-ini',runtime['app_ini']['path'],'--timelearner-calibrate',str(path),
   '--timelearner-output',str(directory)],exe.parent,legacy/(top+'-'+case+'-process'),900)
  assert result['execution']=='completed',(top,case,result)
  audit_execution(directory,job,load_case(source))
  assert load(directory/'transaction.json')['status']==status,(top,case)
  print('CALIBRATION DONE',top,case,flush=True)
verify_runtime(runtime)
save(p/'validation.json',{'binary_source_root':'ffd5b15a264f6d66e131230ddd301ef8ae754ea3',
 'analysis_source_root':'74f49a5f08f46a16a3bd5e98b589d6dc63025417','post_tune_runs':18,
 'calibration_regression_runs':6,'scientific_verdict':None,'full_stage_8_accepted':False})
PY
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$out/runs"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_controller_worker -v > "$out/posttune-reader.log" 2>&1
export TIMELEARNER_NATIVE_CALIBRATION_WORKER_DIR="$out/calibration-regressions"
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$base/readbacks/s08-native-posttune-controller-normal-a2/native"
export TIMELEARNER_NATIVE_CALIBRATION_CLI_OUTPUT="$out/calibration-cli-regressions"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_calibration_worker -v > "$out/calibration-reader.log" 2>&1
df -h "$base" > "$out/disk-after.txt"

