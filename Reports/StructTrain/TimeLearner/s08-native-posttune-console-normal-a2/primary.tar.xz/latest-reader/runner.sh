set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-console-latest-reader-normal-a2"
gate="$base/readbacks/s08-native-posttune-console-normal-a2"
src="$base/source-order-fixed-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$gate/process-exit-status.txt"; do sleep 10; done
test "$(cat "$gate/process-exit-status.txt")" = 0
mkdir "$out/analysis-source"
git -C "$src" -c fetch.recurseSubmodules=false fetch origin b884691c402a469aea948eb0237ec24715560184 > "$out/checkout.log" 2>&1
git -C "$src" archive b884691c402a469aea948eb0237ec24715560184 Scripts | tar -x -C "$out/analysis-source"
cd "$out/analysis-source"
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$gate/runs"
unset QT_QPA_PLATFORM
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_controller_worker -v > "$out/reader.log" 2>&1

