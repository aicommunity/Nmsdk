
from pathlib import Path
import sys,os,json,subprocess,hashlib,threading,traceback,shutil,tarfile,io
base=Path('/home/user/timelearner-refactor');root='9f92a40b97b5868b84b156e38b91903e6b0d8176'
out=base/'readbacks/s07-csearch-threshold-joint-normal-a3';out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-normal-a2';build=base/'build-csearch-threshold-joint-normal-a3';runtime=base/'runtime-csearch-threshold-joint-normal-a3'
relay=source;donor=base/'source-initial-threshold-normal-a4';framework=base/'framework-initial-threshold-normal-a4'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def run(args,name):
 if token:registry.validate_paths(token)
 assert not errors,errors
 with (out/name).open('xb') as log:
  p=subprocess.Popen(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
  write('owned-'+name+'.json',{'pid':p.pid,'start_ticks':ticks(p.pid),'arguments':list(map(str,args))});status=p.wait()
 assert status==0,(name,status)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source),'build':str(build),'runtime':str(runtime),'contained_supervisor':str(base/'readbacks/s07-csearch-threshold-joint-normal-a3-container')})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert source.is_dir() and not any(p.exists() for p in [build,runtime])
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 disk=shutil.disk_usage(base);assert disk.free>=14*1024**3 and memory>=10*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'compiler_parallelism':1,'worker_memory_max_bytes':8*1024**3,'worker_tasks_max':128,'maximum_wall_seconds':21600})
 bootstrap=base/'source-closed-worker-recovery-a3';sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 reservation=registry.reserve('s07-csearch-threshold-joint-normal-a3',
  [{'path':str(p),'access':'write'} for p in [out,source,build,runtime]]+
  [{'path':str(p),'access':'read'} for p in [donor,framework,base/'build-initial-threshold-normal-a4/_deps/llama_cpp-src',base/'source-closed-worker-recovery-a3']],
  demands={'slots':1,'memory_bytes':8*1024**3,'disk_bytes':12*1024**3},ttl_seconds=120)
 token=reservation['token'];write('reservation.json',dict(reservation,capacity=capacity,scope='declared directories and resources; entire worker is separately contained by user-systemd'))
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert git(source,'rev-parse','HEAD')==root and not (source/'.git/objects/info/alternates').exists()
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  key,path=line.split(None,1);destination=source/path;destination.parent.mkdir(parents=True,exist_ok=True)
  wanted=git(source,'rev-parse','HEAD:'+path)
  if path=='Libraries/Nmsdk-PulseLib':
   assert git(destination,'rev-parse','HEAD')==wanted and not (destination/'.git/objects/info/alternates').exists()
  else:
   # Local Git transport copies a shallow object closure without alternates.
   # Existing checkout may have created an empty gitlink directory.
   assert not any(destination.iterdir()) if destination.exists() else True
   run(['git','clone','--depth','1','--no-checkout','--no-recurse-submodules','file://'+str(donor/path),destination],'clone-'+path.replace('/','_')+'.log')
   run(['git','-C',destination,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+path.replace('/','_')+'.log')
   assert not (destination/'.git/objects/info/alternates').exists()
  assert git(destination,'rev-parse','HEAD')==wanted and not git(destination,'status','--porcelain','--untracked-files=no')
  children[path]=wanted
 run(['git','-C',source,'submodule','init'],'init-submodules.log')
 assert not git(source,'status','--porcelain','--untracked-files=no') and len(children)==7
 assert children['Libraries/Nmsdk-PulseLib']=='cc97149c90ce98ff24ca688452f4a40d54e0e63d'
 write('source-closure.json',{'root':root,'children':children,'clean':True,'root_nonruntime_blobs_promised':True,'omitted_paths':['Docs','Reports'],'source_code_delivered_through_native_git':True})
 vendor=base/'build-initial-threshold-normal-a4/_deps/llama_cpp-src'
 write('offline-vendor.json',{'path':str(vendor),'commit':git(vendor,'rev-parse','HEAD'),'tracked_clean':not git(vendor,'status','--porcelain','--untracked-files=no')})
 assert not git(vendor,'status','--porcelain','--untracked-files=no')
 assert git(framework,'rev-parse','HEAD')=='58d77fa8070e8cec2dc1ed015d66b454c8d78850'
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON','-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DRDK_LLM_LLAMA_CPP_DIR='+str(vendor),'-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':list(map(str,args))});run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes());write('build-terminal.json',{'execution':'completed','root':root})
 # Drop only the bootstrap package imports. The production gate uses this exact joint SDK code.
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 write('native-runtime.json',snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 specification=json.loads((source/'Scripts/StructTrain/TimeLearner/specs/native-csearch-threshold-joint-v1.json').read_text());assert len(specification['expected_test_ids'])==42
 specification.update(source_root=str(source),runtime_manifest=str(out/'native-runtime.json'),asan_options='');write('native-specification.json',specification)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed'
 assert result['inventory']['expected']==result['inventory']['observed']==42
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 # Release only with fresh own-group membership proving no descendants remain.
 if token and not errors:
  try:
   group=Path('/sys/fs/cgroup')/Path('/proc/self/cgroup').read_text().strip().split('0::',1)[1].lstrip('/')
   members=set()
   for entry in group.rglob('cgroup.procs'):members.update(map(int,entry.read_text().split()))
   write('reservation-release-membership.json',{'control_group':str(group),'members':sorted(members),'current_worker':os.getpid()})
   assert members=={os.getpid()},('descendants_remain',members)
   registry.release(token,note='All synchronous operations returned and fresh whole-worker cgroup membership contains only this finalizing owner; subsequent group closure recorded separately.')
   write('reservation-final.json',registry.inspect())
  except BaseException as error:write('reservation-release-refused.json',{'reason':str(error)});passed=False
 write('terminal.json',{'execution':'completed','native42_passed':passed,'primary_reader_validation_pending':True,'full304_executed':False,'whole_plan_complete':False,'scientific_verdict':None})
 hashes={}
 if source.exists():
  for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
   for p in (source/prefix).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for name,raw in files.items():info=tarfile.TarInfo(name);info.size=len(raw);archive.addfile(info,io.BytesIO(raw))
 raw=(out/'primary.tar.xz').read_bytes();write('bundle.json',{'kind':'joint_csearch_threshold_native_controls','schema_version':1,'root':root,'pulselib':'cc97149c90ce98ff24ca688452f4a40d54e0e63d','acceptance_status':'native_checks_passed_readers_pending' if passed else 'not_accepted','members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in files.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
