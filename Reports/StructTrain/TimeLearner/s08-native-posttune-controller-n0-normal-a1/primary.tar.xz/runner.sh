set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-controller-n0-normal-a1"
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-posttune-controller-n0-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test ! -e "$runtime"
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
test -z "$(git -C "$src" status --porcelain)"
BUILD="$build" python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
base=Path('/home/user/timelearner-refactor');active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(str(base)+'/runtime-') or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch origin fe45166a132a97aefcd62318125604bb066b57ff > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach fe45166a132a97aefcd62318125604bb066b57ff >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
git -C "$src" rev-parse HEAD >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativePostTuneTransaction.ClassicN0_2000:NativePostTuneTransaction.BranchN0_2000' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
export TIMELEARNER_POSTTUNE_TRANSACTION_DIR="$out/native"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_evidence -v > "$out/reader.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.json"
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
p=Path(os.environ['OUT']);r=ET.parse(p/'native.xml').getroot()
assert int(r.attrib['tests'])==2 and all(int(r.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled'])
assert not r.findall('.//skipped')
s=(p/'reader.log').read_text();assert 'Ran 12 tests' in s and s.rstrip().endswith('OK')
print(json.dumps({'native_cases':2,'reader_checks':12,'full_stage_8_accepted':False,'scientific_verdict':None}))
PY

