from pathlib import Path,PurePosixPath
import os,sys,json,hashlib,subprocess,sqlite3,socket,shutil,tarfile,io,traceback,threading,re
base=Path('/media/user/Data/TimeLearnerRefactor');tool=base/'source-stopped-final-diagnostics-a2';data_repo=base/'source-stopped-final-diagnostics-a1';out=base/'readbacks/s07-stopped-final-reader-m40-a2';cache=base/'ReportsCache/stopped-final-native-elder-a1-reader-a2';source=cache/'source';out.mkdir(exist_ok=False)
root='297bcbb42105396d83c3eecf52ad98613afaef0f';data_commit='d080310f241c994bca1231cbb38a3cb290ca2f36';prefix='Reports/StructTrain/TimeLearner/s07-stopped-final-native-elder-a1/';stop=threading.Event();thread=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(name):return subprocess.check_output(['git','-C',str(data_repo),'show',data_commit+':'+prefix+name])
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'reader_root':root,'data_commit':data_commit,'models_executed':0});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True;sys.path.insert(0,str(tool));os.chdir(tool)
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'stopped-final-metadata-reservations.sqlite3')
try:
 assert shutil.disk_usage(base).free>=1024**3+128*1024**2
 connection=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True)
 try:
  connection.execute('PRAGMA query_only=ON');connection.execute('BEGIN');metadata=dict(connection.execute('SELECT key,value FROM metadata'));assert metadata['schema_version'] in ('1','2') and metadata['worker_host']==socket.gethostname()
  held=[r for row in connection.execute("SELECT resources FROM leases WHERE state='held'") for r in json.loads(row[0])]
 finally:connection.close()
 for p in [tool,data_repo,out,cache]:
  for resource in held:
   q=Path(resource['canonical_path']);assert not p.is_relative_to(q) and not q.is_relative_to(p),str(q)
 write('global-isolation.json',{'read_only_metadata':metadata,'no_overlap_with_held_resources':True,'global_policy_modified':False,'native_models_executed':0})
 lease=registry.reserve(out.name,[{'path':str(p),'access':'read'} for p in [tool,data_repo]]+[{'path':str(p),'access':'write'} for p in [out,cache]],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(tool),'rev-parse','HEAD'],text=True).strip()==root
 bundle=json.loads(blob('bundle.json'));archive=blob('primary.tar.xz');assert len(archive)==bundle['archive_bytes'] and hashlib.sha256(archive).hexdigest()==bundle['archive_sha256']=='57376dd62371cea089d2714cba24bca7ae8dc762d7b12d7a8dd636afbfd225f4'
 assert bundle['native4_passed'] and not bundle['readers_passed'] and bundle['native_root']=='2e0618110a9abb48b94f6edc6b63c51f829ec810'
 cache.mkdir(parents=True,exist_ok=False);source.mkdir();seen=set()
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:xz') as tf:
  for member in tf:
   name=member.name;assert member.isfile() and name not in seen and not PurePosixPath(name).is_absolute() and all(x not in ('','..','.') for x in name.split('/'));seen.add(name);value=tf.extractfile(member).read();assert bundle['members'][name]=={'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}
   path=source/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(value)
 assert seen==set(bundle['members']) and len(seen)==116
 write('restoration.json',{'data_commit':data_commit,'archive_sha256':bundle['archive_sha256'],'members_verified':len(seen),'source':str(source),'native_models_executed':0,'previous_failed_reader_result_preserved':True})
 previous=json.loads((source/'native-verdict.json').read_text());assert previous['inventory']['expected']==previous['inventory']['observed']==4 and previous['validity']=='valid' and previous['assertion_status']=='passed'
 (out/'tmp').mkdir();env=dict(os.environ,TIMELEARNER_STOPPED_FINAL_PRIMARY=str(source/'native-result'),TMPDIR=str(out/'tmp'))
 tests=subprocess.run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_stopped_final_pass','-v'],cwd=tool,env=env,capture_output=True,timeout=300)
 (out/'checks-stdout.log').write_bytes(tests.stdout);(out/'checks-stderr.log').write_bytes(tests.stderr);matched=re.search(rb'Ran (\d+) tests',tests.stderr);n=int(matched.group(1)) if matched else None;write('checks.json',{'returncode':tests.returncode,'tests':n,'expected':13,'skips_allowed':False});assert tests.returncode==0 and n==13 and tests.stderr.rstrip().endswith(b'OK'),tests.stderr.decode()
 for topology in ['Classic','Branch']:
  for mode in [0,1]:
   name=topology+f'-N{mode}';destination=out/('diagnostics/'+name+'.json');destination.parent.mkdir(exist_ok=True)
   run=subprocess.run([sys.executable,'-m','Scripts.StructTrain.TimeLearner','analyze',str(source/'native-result'/(name+'.inputs.json')),'--format','stopped-final-pass','--output',str(destination)],cwd=tool,env=env,capture_output=True,timeout=120);assert run.returncode==0,run.stderr.decode();envelope=json.loads(destination.read_text());v=envelope['analysis'];assert envelope['kind']=='timelearner_analysis' and envelope['evaluation_verdict'] is None and v['complete_measured_final_pass'] and not v['certificate_present'] and not v['training_completed'] and v['evaluation_verdict'] is None
 for name,record in bundle['members'].items():assert sha(source/name)==record['sha256'] and (source/name).stat().st_size==record['bytes'],name
 write('source-unchanged.json',{'all_116_primary_files_rehashed':True,'data_commit':data_commit,'cpp_rerun':False});registry.validate_paths(token);assert not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'readers13_and_cli4_passed':passed,'native_models_executed':0,'source_native_cases':4,'whole_plan_complete':False,'scientific_verdict':None})
  write('reader-source-hashes.json',{p.relative_to(tool).as_posix():sha(p) for p in (tool/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  members={}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as tf:
   for p in sorted(out.rglob('*')):
    if p.is_file() and p.name not in ['primary.tar.xz','bundle.json']:
     assert p.resolve().is_relative_to(out.resolve());name=p.relative_to(out).as_posix();members[name]={'bytes':p.stat().st_size,'sha256':sha(p)};info=tarfile.TarInfo(name);info.size=p.stat().st_size
     with p.open('rb') as stream:tf.addfile(info,stream)
  write('bundle.json',{'kind':'timelearner_stopped_final_reader_gate','reader_root':root,'data_commit':data_commit,'checks_passed':passed,'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'native_models_executed':0,'scientific_verdict':None})
 except BaseException as error:write('archive-exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
 stop.set()
 if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
