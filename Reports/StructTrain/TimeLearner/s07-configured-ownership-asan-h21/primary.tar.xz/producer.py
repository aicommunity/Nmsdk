
from pathlib import Path
import os,sys,subprocess,json,hashlib,tarfile,lzma,traceback
base=Path('/media/user/Data/TimeLearnerRefactor');source=base/'source-configured-probe-ownership-asan-h14'
run=base/'readbacks/s07-configured-probe-ownership-asan-h21';out=base/'readbacks/s07-configured-ownership-h21-compact-a1';out.mkdir(exist_ok=False)
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def closed(p):
 owner=json.loads((p/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 closed(run);r=json.loads((run/'native-result/result.json').read_text())
 assert r['assertion_status']=='passed' and len(json.loads((run/'native-specification.json').read_text())['expected_test_ids'])==213
 assert json.loads((run/'targeted-result/result.json').read_text())['assertion_status']=='passed'
 for label in ['original87','corrected88']:
  p=base/('readbacks/s07-configured-ownership-h21-'+label+'-readers-a1');closed(p)
  value=json.loads((p/'reader-verdict.json').read_text());assert not value['errors'] and not value['skipped']
  if label=='original87':assert value['executed_tests']==87 and value['failures']==['Scripts.StructTrain.TimeLearner.tests.test_capacitance_boundary_evidence.CapacitanceBoundaryEvidenceTest.test_missing_capture_witness_is_rejected']
  else:assert value['executed_tests']==88 and not value['failures'] and value['assertion_status']=='passed'
  b=json.loads((p/'bundle.json').read_text());assert hashlib.sha256((p/'primary.tar.xz').read_bytes()).hexdigest()==b['archive_sha256']
  for old,new in [('primary.tar.xz',label+'-primary.tar.xz'),('bundle.json',label+'-bundle.json')]:
   target=out/'readers'/new;target.parent.mkdir(exist_ok=True);target.write_bytes((p/old).read_bytes())
  write(label+'-verdict.json',value)
 root=git(source,'rev-parse','HEAD');assert root=='5c9b92350ee48d130d954bf10bf9521251f99e4e'
 assert not git(source,'status','--porcelain','--untracked-files=no')
 closure={'root':root};hashes={}
 for repo,prefix,paths in [(source,'',['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','CMakeLists.txt','cmake']),
                          (source/'Libraries/Nmsdk-PulseLib','Libraries/Nmsdk-PulseLib/',['Core','CMakeLists.txt']),
                          (source/'Rdk','Rdk/',['Core','CMakeLists.txt'])]:
  sha=git(repo,'rev-parse','HEAD');closure[prefix or 'root']=sha
  assert not git(repo,'status','--porcelain','--untracked-files=no')
  for relative in git(repo,'ls-files','--',*paths).splitlines():
   p=repo/relative
   if p.is_file():hashes[prefix+relative]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-closure.json',closure);write('source-hashes.json',hashes)
 write('acceptance.json',{'native_tests':213,'native_failed':0,'standalone_original_failing_case':1,'original_readers87':'one retained diagnostic-expectation failure','corrected_readers88':'passed','native_source_mutated':False,'same_full_test_inventory_and_order':True,'inner_child_timeout_ms':120000,'detect_leaks':False,'scientific_verdict':None})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 files={('run/'+p.relative_to(run).as_posix()):p for p in run.rglob('*') if p.is_file() and not p.is_symlink()}
 files.update({p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()})
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with lzma.open(out/'primary.tar.xz','wb',filters=[{'id':lzma.FILTER_LZMA2,'preset':3,'dict_size':64*1024**2}]) as stream:
  with tarfile.open(fileobj=stream,mode='w') as archive:
   for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 p=out/'primary.tar.xz';write('bundle.json',{'kind':'configured_ownership_h21_asan_primary_validation','root':'5c9b92350ee48d130d954bf10bf9521251f99e4e','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_bytes':p.stat().st_size,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
