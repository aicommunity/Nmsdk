from pathlib import Path
import os,sys,json,subprocess,time,traceback,threading,hashlib
base=Path('/media/user/Data/TimeLearnerRefactor');prior=base/'readbacks/s07-configured-probe-ownership-asan-h14'
out=base/'readbacks/s07-configured-probe-ownership-asan-h21';out.mkdir(exist_ok=False)
source=base/'source-configured-probe-ownership-asan-h14'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':'5c9b92350ee48d130d954bf10bf9521251f99e4e'})
stop=threading.Event();thread=None
try:
 assert not live(json.loads((prior/'owned-supervisor.json').read_text()))
 original=json.loads((prior/'native-result/result.json').read_text())
 write('original-native-result.json',original)
 write('original-publication.json',json.loads((base/'readbacks/s07-configured-probe-ownership-publication-asan-h14/publication.json').read_text()))
 assert original['assertion_status']!='passed'
 spec=json.loads((prior/'native-specification.json').read_text())
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 runtime=json.loads(Path(spec['runtime_manifest']).read_text());exe=verify_runtime(runtime).resolve()
 owners=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if (p/'exe').resolve()==exe:owners.append({'pid':int(p.name),'start_ticks':ticks(int(p.name))})
  except (FileNotFoundError,PermissionError):pass
 assert not owners,owners
 def memory():return {r.split(':')[0]:int(r.split()[1])*1024 for r in Path('/proc/meminfo').read_text().splitlines() if r.startswith(('MemAvailable:','SwapFree:'))}
 m=memory();write('resource-preflight.json',{'memory':m,'required_available_bytes':32*1024**3,'other_native_owners':owners,'inner_child_timeout_ms_unchanged':120000,'runtime_mutated':False})
 assert m['MemAvailable']>=32*1024**3,'not enough free memory for diagnostic plus same-order full suite'
 def sample():
  with (out/'memory-samples.jsonl').open('x') as log:
   while not stop.is_set():
    processes=[]
    for p in Path('/proc').iterdir():
     if not p.name.isdigit():continue
     try:
      if (p/'exe').resolve()==exe:processes.append({'pid':int(p.name),'start_ticks':ticks(int(p.name)),'resident_bytes':int((p/'statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')})
     except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    log.write(json.dumps({'unix_time':time.time(),'memory':memory(),'owned_runtime_processes':processes})+'\n');log.flush();stop.wait(30)
 thread=threading.Thread(target=sample,daemon=True);thread.start()
 target=dict(spec,expected_test_ids=['NativeCapacitanceHistoryBoundary/ClassicN1StoppedBeforeFirstTick'],maximum_wall_seconds=1800.)
 write('targeted-specification.json',target)
 result=run_native_gate(out/'targeted-specification.json',out/'targeted-result');write('targeted-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed','standalone original failing case did not pass; full rerun refused'
 assert memory()['MemAvailable']>=32*1024**3,'memory budget changed after standalone case'
 full=dict(spec,maximum_wall_seconds=43200.)
 write('native-specification.json',full)
 write('full-phase.json',{'execution':'starting','same_native_root':True,'same_executable':True,'same_test_order_and_inventory':True,'expected_native_tests':213,'inner_child_timeout_ms_unchanged':120000,'original_failure_preserved':True})
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 write('terminal.json',{'execution':'completed','native_assertion_status':result['assertion_status'],'reader_validation_pending':True,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 stop.set()
 if thread:thread.join(timeout=35)
 try:verify_runtime(runtime)
 except BaseException as e:write('final-runtime-error.json',{'reason':str(e)})
 print('CLOSED',flush=True)
