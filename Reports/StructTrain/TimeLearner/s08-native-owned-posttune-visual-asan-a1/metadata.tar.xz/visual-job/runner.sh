set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-owned-posttune-visual-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
repo="$base/source-owned-posttune-reader-asan-a3"
work="$base/source-owned-posttune-visual-asan-a2"
git -C "$repo" -c fetch.recurseSubmodules=false fetch origin fffc871279a1de5d4857f2a9ec0a7f09d2851c29 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" fffc871279a1de5d4857f2a9ec0a7f09d2851c29 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
reader="$base/readbacks/s08-native-owned-posttune-reader-asan-a3"
while test ! -f "$reader/process-exit-status.txt"; do kill -0 4081129; sleep 10; done
test "$(cat "$reader/process-exit-status.txt")" = 0
cd "$work"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_OWNED_POSTTUNE_NATIVE="$base/readbacks/s08-native-owned-posttune-asan-a3/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
export TIMELEARNER_OWNED_POSTTUNE_REPORTS="$base/cache/s08-native-owned-posttune-asan-a2"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import hashlib,json,os,time,unittest
from Scripts.StructTrain.TimeLearner.finalization_ownership_reports import render_owned_posttune
native=Path(os.environ['TIMELEARNER_OWNED_POSTTUNE_NATIVE'])
fixtures=Path(os.environ['TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES'])
cache=Path(os.environ['TIMELEARNER_OWNED_POSTTUNE_REPORTS'])
assert not cache.exists();cache.mkdir(parents=True)
def inventory():
 return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for folder in (native,fixtures) for p in sorted(folder.rglob('*')) if p.is_file()}
before=inventory();start=time.monotonic();reports={}
paths=sorted(native.glob('*_managed_finalization_*_owned_*.json'));assert len(paths)==10
for p in paths:
 root=fixtures/('Classic-auto_metric' if p.name.startswith('Classic') else 'Branch-synthetic')/'input/source'
 reports[p.stem]=render_owned_posttune(p,next(root.glob('*_learned_state.json')),cache/p.stem)
 print('rendered',p.name,flush=True)
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_owned_posttune_reports'))
assert inventory()==before
summary={'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'seconds':time.monotonic()-start,'cache':str(cache),'reports':reports,'source_files_unchanged':len(before),'cache_files':sum(p.is_file() for p in cache.rglob('*')),'cache_bytes':sum(p.stat().st_size for p in cache.rglob('*') if p.is_file()),'visual_acceptance_complete':False,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==2 and not result.skipped
print(json.dumps({'tests':result.testsRun,'seconds':summary['seconds'],'cache_files':summary['cache_files'],'cache_bytes':summary['cache_bytes']}),flush=True)
PY
