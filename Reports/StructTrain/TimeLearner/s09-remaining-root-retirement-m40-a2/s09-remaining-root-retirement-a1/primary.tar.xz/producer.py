if __name__ == '__main__':
 from pathlib import Path
 import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,shutil,time,io
 base=Path('/media/user/Data/TimeLearnerRefactor');label='remaining-root-retirement-a1';out=base/('readbacks/s09-'+label);out.mkdir(exist_ok=False);source=base/'source-remaining-root-retirement-a1';child_store=base/'source-theory-retirement-a1';root='0cd87e45ecf350301483ff4371994ced688931ef';before='cb0bb0c322736406d9e73a0b5542b3b3a5ba33ec';controller=base/('readbacks/s09-'+label+'-container');bootstrap=base/'source-closed-worker-recovery-a3'
 def write(n,v):
  q=out/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
 def git(*args,data=None):return subprocess.check_output(['git','-C',str(source),*args],input=data).decode().strip()
 def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
 write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'root':root,'source':str(source),'metadata_only':True});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
 stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False
 try:
  sys.path.insert(0,str(bootstrap))
  from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
  memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
  assert memory>=2*1024**3 and shutil.disk_usage(base).free>=2*1024**3
  write('isolation-preflight.json',{'metadata_only':True,'native_models_executed':0,'historical_scripts_executed':False,'memory_available_bytes':memory,'disk_free_bytes':shutil.disk_usage(base).free,'bounded_memory_bytes':512*1024**2,'concurrent_native_runtime_modified':False})
  assert shutil.disk_usage(base).free>=1024**3;assert git('rev-parse','HEAD')==root
  sys.path.insert(0,str(bootstrap));from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
  registry=Reservations(base/'resource-reservations.sqlite3')
  write('preceding-resource-state.json',registry.inspect())
  resources=[{'path':str(out),'access':'write'},{'path':str(source),'access':'write'}]+[{'path':str(child_store/x),'access':'read'} for x in ['Bin','Libraries/Nmsdk-PulseLib']]
  lease=registry.reserve('s09-'+label,resources,ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
  def heartbeat():
   while not stop.wait(20):
    try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
    except BaseException as e:errors.append(str(e));return
  thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
  manifest=json.loads(git('show',root+':Docs/StructTrain/TimeLearner/script_migration.json'));retired=[r for r in manifest['retired_files'] if r['repository']=='root' and r['archive_commit']==before];assert len(retired)==9
  mapping=out/'revision-map.json';mapping.write_text(git('show',root+':Docs/StructTrain/TimeLearner/History/RootRevisionMap-2026-10-30.json')+'\n')
  children={name:git('rev-parse',root+':'+relative) for name,relative in [('Bin','Bin'),('PulseLib','Libraries/Nmsdk-PulseLib')]}
  for name,relative in [('Bin','Bin'),('PulseLib','Libraries/Nmsdk-PulseLib')]:
   assert subprocess.check_output(['git','-C',str(child_store/relative),'cat-file','-t',children[name]]).strip()==b'commit'
  write('delivery-closure.json',{'root':root,'children':children,'metadata_object_handles_only':True,'native_sdk_checkout':False})
  args=['python3','-m','Scripts.StructTrain.TimeLearner','history','verify-migration',root,'--root',str(source),'--bin-repository',str(child_store/'Bin'),'--pulselib-repository',str(child_store/'Libraries/Nmsdk-PulseLib'),'--map',str(mapping),'--output',str(out/'positive.json')]
  for label2,a in [('positive',args)]:
   process=subprocess.run(a,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300);(out/(label2+'-stdout.log')).write_bytes(process.stdout);(out/(label2+'-stderr.log')).write_bytes(process.stderr);assert process.returncode==0,(process.returncode,process.stderr.decode())
  positive=json.loads((out/'positive.json').read_text());assert positive['source_records_verified']==150 and not positive['whole_migration_attested'] and not positive['runtime_equivalence_attested']
  allowed={'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/run_iti.py', 'Scripts/audit_timelearner.py', 'Docs/StructTrain/TimeLearner/ScriptMigration.ru.md', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/e05_e0_kernel_probe.py', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/c1_dose_response_console.py', 'Docs/StructTrain/TimeLearner/RemainingRootToolsRetirement.ru.md', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/e05_job.py', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/be_prep.py', 'Scripts/audit-probes/README.md', 'Docs/StructTrain/TimeLearner/script_migration.json', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/timelearner_margin_model.py', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/tools/e05_e0_compare.py', 'Docs/Audit/TimeLearner-2026-09-26-review/evidence/metrics/sample_host_metrics.py'}
  changed=set(git('diff','--no-renames','--name-only',before,root).splitlines());assert changed==allowed
  for path in ['Scripts/StructTrain/TimeLearner','Tests','App','CMakeLists.txt','Bin','Libraries/Nmsdk-PulseLib','Rdk']:assert git('rev-parse',before+':'+path)==git('rev-parse',root+':'+path),path
  write('scope-verification.json',{'base':before,'candidate':root,'retired':9,'changed_paths':sorted(changed),'unchanged_code_and_child_gitlinks':True,'scientific_verdict':None})
  repo=source
  def tree(base_tree,changes):
   entries={}
   if base_tree:
    raw=subprocess.check_output(['git','-C',str(repo),'ls-tree','-z',base_tree])
    for item in raw.split(b'\0'):
     if not item:continue
     header,name=item.split(b'\t',1);mode,kind,sha=header.decode().split();entries[name.decode()]=(mode,kind,sha)
   groups={}
   for path,value in changes.items():
    head,sep,tail=path.partition('/')
    if sep:groups.setdefault(head,{})[tail]=value
    else:entries[head]=value
   for name,sub in groups.items():
    previous=entries.get(name);assert previous is None or previous[1]=='tree'
    entries[name]=('040000','tree',tree(previous[2] if previous else None,sub))
   content=b''.join((entries[n][0].lstrip('0')+' '+n).encode()+b'\0'+bytes.fromhex(entries[n][2]) for n in sorted(entries,key=lambda n:n+('/' if entries[n][1]=='tree' else '')))
   return git('hash-object','-w','-t','tree','--stdin',data=content)
  record=retired[0];new_tree=tree(git('rev-parse',root+'^{tree}'),{record['old_path']:('100644','blob',record['blob_sha1'])})
  negative=git('-c','user.name=TimeLearner Agent','-c','user.email=timelearner@localhost','commit-tree',new_tree,'-p',root,data=b'Negative metadata fixture: restored historical E05/ITI root script\n')
  args[5]=negative;args[-1]=str(out/'negative-must-not-exist.json');bad=subprocess.run(args,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300);(out/'negative-stdout.log').write_bytes(bad.stdout);(out/'negative-stderr.log').write_bytes(bad.stderr)
  assert bad.returncode==2 and b'migration_old_path_still_present' in bad.stderr and not (out/'negative-must-not-exist.json').exists()
  write('negative.json',{'revision':negative,'restored_path':record['old_path'],'returncode':bad.returncode,'reason':'migration_old_path_still_present','positive_receipt_absent':True,'archived_script_executed_or_materialized':False})
  hashes={q.relative_to(source).as_posix():sha(q) for q in sorted((source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))};write('source-hashes.json',hashes);assert not errors;passed=True
 except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
 finally:
  try:
   write('terminal.json',{'checks_passed':passed,'source_records_verified':150 if passed else None,'historical_scripts_executed':False,'native_models_executed':0,'whole_migration_complete':False,'scientific_verdict':None})
   members={}
   with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
    for q in sorted(out.rglob('*')):
     if q.is_file() and not q.is_symlink() and q.name not in ['primary.tar.xz','bundle.json']:
      name=q.relative_to(out).as_posix();members[name]={'bytes':q.stat().st_size,'sha256':sha(q)};archive.add(q,arcname=name,recursive=False)
   write('bundle.json',{'kind':'remaining_root_tools_retirement_metadata_gate','root':root,'checks_passed':passed,'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
  finally:
   stop.set()
   if thread:thread.join(timeout=30)
