set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-console-report-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-fixed-console-asan-a1/process-exit-status.txt")" = 0
test "$(git -C "$src" rev-parse HEAD)" = 2d6ab1a059005af30bc3d55a78c2192e6cbd9813
cd "$src"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.__main__ import main
out=Path(os.environ['OUT']);base=Path(os.environ['BASE'])
runs=base/'readbacks/s08-native-posttune-fixed-console-asan-a1/runs'
rows=[]
for row in load(runs/'controls.json')['records']:
 name=row['name'];target=out/'reports'/name
 target.parent.mkdir(exist_ok=True)
 print('BEGIN',name,flush=True)
 assert main(['report',str(runs/name/'run-manifest.json'),'--format','posttune-run','--output',str(target)])==0
 m=load(target/'manifest.json');binding=load(target/'run-binding.json')
 assert m['run_manifest_sha256']==binding['run_manifest_sha256']==load(runs/name/'run-manifest.json')['sha256']
 assert m['trial_soma_pairs']>0
 rows.append({'name':name,'phase':row['phase'],'status':row['expected_status'],'trial_soma_pairs':m['trial_soma_pairs']})
 print('END',name,rows[-1],flush=True)
assert len(rows)==6
(out/'validation.json').write_text(json.dumps({'source_root':'2d6ab1a059005af30bc3d55a78c2192e6cbd9813',
 'source_bundle':'0c91982450dc143233c4b05e1e746a3330aa86f5','reports':6,
 'trial_soma_pairs':sum(r['trial_soma_pairs'] for r in rows),'rows':rows,
 'full_visual_acceptance':False,'scientific_verdict':None},indent=2)+'\n')
PY
