
from pathlib import Path
import sys,os,json,hashlib,tarfile,subprocess,traceback,sqlite3
base=Path('/media/user/Data/TimeLearnerRefactor');label='m40';root='ecc384214bd3a9be4bbbfc6aba102f98d1069c89'
out=base/('readbacks/s10-contained-process-'+label+'-a2');out.mkdir(exist_ok=False)
def write(n,v):
 (out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 donor=base/('source-initial-threshold-asan-a2' if label=='m40' else 'source-initial-threshold-normal-a4')
 repo=out/'objects.git';subprocess.run(['git','clone','--shared','--bare',str(donor),str(repo)],check=True)
 remote='https://github.com/aicommunity/Nmsdk.git' if label=='m40' else str(base/'git-relay-contained-process-a2.git')
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules',remote,root],check=True)
 source=out/'source';source.mkdir();p=subprocess.Popen(['git','-C',str(repo),'archive',root,'Scripts'],stdout=subprocess.PIPE)
 subprocess.run(['tar','-xf','-','-C',str(source)],stdin=p.stdout,check=True);p.stdout.close();assert p.wait()==0
 write('source-hashes.json',{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts').rglob('*') if p.is_file()})
 write('runtime.json',{'python':sys.version,'executable':str(Path(sys.executable).resolve()),'executable_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),'sqlite':sqlite3.sqlite_version,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'neural_runs':0})
 os.environ['TIMELEARNER_CONTAINED_EVIDENCE_DIR']=str(out/'native')
 runner=out/'runner.py'
 runner.write_text("import sys,json,unittest\nfrom pathlib import Path\nif __name__=='__main__':\n sys.path.insert(0,"+repr(str(source))+ ")\n suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_contained_process.ContainedProcessTest')\n with Path("+repr(str(out/'tests.log'))+").open('w') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)\n value={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped)}\n Path("+repr(str(out/'tests.json'))+").write_text(json.dumps(value,indent=2)+'\\n')\n sys.exit(0 if r.wasSuccessful() and r.testsRun==13 and not r.skipped else 2)\n")
 with (out/'runner.log').open('xb') as log:
  p=subprocess.Popen([sys.executable,str(runner)],cwd=source,stdout=log,stderr=subprocess.STDOUT)
  write('owned-tests.json',{'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().rsplit(') ',1)[1].split()[19]});rc=p.wait(timeout=180)
 assert rc==0,('test runner failed',rc)
 assert json.loads((out/'tests.json').read_text())=={'tests':13,'failures':0,'errors':0,'skipped':0}
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'complete_queue_attested':False,'scientific_verdict':None})
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.relative_to(out).parts[0] not in ('source','objects.git')};records={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 p=out/'primary.tar.xz';write('bundle.json',{'kind':'worker_contained_process_controls','root':root,'acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_bytes':p.stat().st_size,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
