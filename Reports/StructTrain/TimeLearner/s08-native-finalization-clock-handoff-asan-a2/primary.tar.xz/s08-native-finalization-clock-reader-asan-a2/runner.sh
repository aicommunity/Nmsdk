#!/bin/bash
set -e
trap 'printf "%s\n" "$?" > "/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-finalization-clock-reader-asan-a2/process-exit-status.txt"' EXIT
cd "/media/user/Data/TimeLearnerRefactor/source-clock-reader-asan-a2"
export TIMELEARNER_FINALIZATION_CLOCK_NATIVE="/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-finalization-clock-handoff-asan-a2/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
export PYTHONDONTWRITEBYTECODE=1
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_finalization_clock_evidence -v > "/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-finalization-clock-reader-asan-a2/test.log" 2>&1
