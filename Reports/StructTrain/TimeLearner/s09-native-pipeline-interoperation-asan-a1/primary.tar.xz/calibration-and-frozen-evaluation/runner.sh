set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s09-native-pipeline-calibrated-asan-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-native-pipeline-cli-asan-a1
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_calibration_worker import run_job as calibrate,audit_run_manifest as audit_calibration
from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job as evaluate,audit_run_manifest as audit_evaluation
base=Path('/media/user/Data/TimeLearnerRefactor/readbacks');out=Path(os.environ['OUT'])
pipeline=base/'s09-native-pipeline-cli-asan-a1';runtime=pipeline/'Classic-N1-train/process/runtime.json'
results=[]
for top in ('Classic','Branch'):
 case=top+'-N1';source=pipeline/(case+'-train/native/train_learned_state.json')
 job=load(base/'s08-calibration-worker-asan-a1'/(top+'-success-job.json'))
 job['source_recognition']=load(pipeline/(case+'-export/native/model.json'))
 job['implementation_id']=job['source_recognition']['implementation_id']
 job['specification']['attempt_id']=case+'/cold-calibration'
 job.pop('sha256');job['sha256']=sha(job)
 path=out/(case+'-calibration-job.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
 calibrated=out/(case+'-calibrate')
 report=calibrate(path,source,runtime,calibrated,600)
 assert report['execution']=='completed' and report['validity']=='valid'
 assert audit_calibration(calibrated/'run-manifest.json')['run_evidence_consistent'] is True
 status=load(calibrated/'native/transaction.json')['status']
 frozen=load(pipeline/(case+'-evaluate/input/job.json'))
 frozen['source_recognition']=load(calibrated/'native/model.json')
 frozen['run_id']=case+'/post-calibration-frozen'
 for trial in frozen['trials']:trial['run_id']=frozen['run_id']
 frozen.pop('sha256');frozen['sha256']=sha(frozen)
 path=out/(case+'-evaluation-job.json');path.write_text(json.dumps(frozen,allow_nan=False)+'\n')
 final=out/(case+'-evaluate')
 scored=evaluate('evaluate',path,source,runtime,final,600)
 assert scored['execution']=='completed' and scored['validity']=='valid'
 assert audit_evaluation(final/'run-manifest.json')['run_evidence_consistent'] is True
 results.append({'case':case,'calibration_status':status,'training_outcome':load(source)['training_outcome'],
                 'frozen_metrics':scored['analysis']['metrics']})
 print(case,status,'fresh full-grid audit and frozen evaluation passed',flush=True)
(out/'validation.json').write_text(json.dumps({'reader_root':'b839e87952a0f3e04e30fd13474567371e8a1aab','native_root':'d5ef1fa18221f2ffb3e8efdeb32cccff059226e0',
 'owned_native_phases':4,'portable_audits':4,'source_cold_cases':2,'results':results,'independent_partition_verified':False,'scientific_verdict':None},indent=2)+'\n')
PY
