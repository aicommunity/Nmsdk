set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out=$base/readbacks/s05-repeat-boundary-full-visual-readback-a1
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
src=$base/source-native-catalog-a2
cd "$src"
test "$(git rev-parse HEAD)" = fb01871cf2158ece735ab45e148fc20fc33594cd
export PYTHONDONTWRITEBYTECODE=1
for producer in elder1 m40; do
 render=$base/readbacks/s05-repeat-boundary-full-visual-$producer-a1
 while ! test -f "$render/process-exit-status.txt"; do
  pid=$(cat "$render/supervisor.pid")
  kill -0 "$pid"
  ps -p "$pid" -o args= | grep -F "$render/runner.sh" >/dev/null
  sleep 10
 done
 test "$(cat "$render/process-exit-status.txt")" = 0
 mkdir "$render/readback"
 export TIMELEARNER_NATIVE_TEST_REPORT_DIR=$base/source-repeat-boundary-full-visual-a1/Reports/StructTrain/TimeLearner/s05-repeat-boundary-$producer-a3/native-run-a3
 export TIMELEARNER_NATIVE_TEST_VISUAL_DIR=$render/report
 RENDER="$render" PRODUCER="$producer" "$base/plot-venv-a1/bin/python" -u - <<'PY' > "$render/readback/python.log" 2>&1
import json,os,subprocess,unittest,hashlib,csv
from pathlib import Path
root=Path(os.environ["RENDER"]);report=root/"report"
mods=["test_native_test_reports","test_native_test_visual_evidence"]
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(["Scripts.StructTrain.TimeLearner.tests."+m for m in mods]))
record={"kind":"timelearner_full_native_visual_readback","schema_version":1,"reader_root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"renderer_root":"b2f357bcc75264a233524bfb30153b5d95816d6c","producer":os.environ["PRODUCER"],"tests":r.testsRun,"skips":len(r.skipped),"failures":len(r.failures),"errors":len(r.errors),"scientific_verdict":None}
(root/"readback/validation.json").write_text(json.dumps(record,indent=2)+"\n")
if not r.wasSuccessful() or r.skipped:raise SystemExit(1)
manifest=json.loads((report/"manifest.json").read_text());groups=manifest["groups"]
def first_probe(group):
 folder=report/Path(group["report"]).parent
 row=json.loads((folder/"manifest.json").read_text())["reports"][0]
 return folder/row["folder"]
classic=first_probe(groups[0]);branch=first_probe(groups[13])
fresh=first_probe(next(g for g in groups if g["identity"].endswith("_fresh_process.json/probe")))
warm=first_probe(next(g for g in groups if g["identity"].endswith("_warm_summary.json")))
partial=None
for group in groups:
 folder=report/Path(group["report"]).parent
 for item in json.loads((folder/"manifest.json").read_text())["reports"]:
  probe=folder/item["folder"];value=json.loads((probe/"manifest.json").read_text())
  q=value["trace_quality"]
  if not q["recorded_window_complete"] and q["sample_count"]>0:
   partial=probe;break
 if partial is not None:break
assert partial is not None
with (classic/"primary/trace.csv").open() as stream:
 samples=list(csv.DictReader(stream))
peak=float(max(samples,key=lambda s:float(s["soma0"]))["time"])
classic_manifest=json.loads((classic/"manifest.json").read_text())
zooms=[v for v in classic_manifest["figures"][0]["views"] if v["time_view"]!="overview" and v["y_scale"]=="shared" and v["begin"]<=peak<=v["end"]]
assert zooms
pdf=next(p for p in zooms[0]["files"] if p.endswith(".pdf"))
sources={"classic-overview":classic/"soma-001/overview.pdf","classic-peak-zoom":classic/pdf,
 "branch-overview":branch/"soma-001/overview.pdf","partial-overview":partial/"soma-001/overview.pdf",
 "fresh-process-overview":fresh/"soma-001/overview.pdf","warm-overview":warm/"soma-001/overview.pdf"}
qa=root/"pdf-qa";qa.mkdir()
records=[]
for name,path in sources.items():
 sha=hashlib.sha256(path.read_bytes()).hexdigest()
 subprocess.run(["pdftoppm","-singlefile","-r","160","-png",str(path),str(qa/name)],check=True)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
 (qa/(name+".pdfinfo.txt")).write_text(subprocess.check_output(["pdfinfo",str(path)],text=True))
 records.append({"source_relative":str(path.relative_to(root)),"source_sha256":sha,"preview":name+".png","dpi":160,"preview_sha256":hashlib.sha256((qa/(name+".png")).read_bytes()).hexdigest()})
(qa/"manifest.json").write_text(json.dumps({"kind":"timelearner_full_native_visual_pdf_qa","schema_version":1,"records":records,"agent_visual_review_complete":False,"human_visual_review_complete":False,"global_visual_acceptance":False,"scientific_verdict":None},indent=2)+"\n")
PY
done
