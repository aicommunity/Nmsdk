set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
src=$base/source-repeat-boundary-full-visual-a1
producer=elder1
out=$base/readbacks/s05-repeat-boundary-full-visual-$producer-a1
bundle=$src/Reports/StructTrain/TimeLearner/s05-repeat-boundary-$producer-a3
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
BUNDLE="$bundle" OUT="$out" PRODUCER="$producer" "$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/input-verification.log" 2>&1
import json,os,hashlib,subprocess
from pathlib import Path
root=Path(os.environ["BUNDLE"]);out=Path(os.environ["OUT"])
hashes=json.loads((root/"SHA256SUMS.json").read_text())
for rel,expected in hashes.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==expected,rel
record={"kind":"timelearner_visual_input_verification","schema_version":1,"producer":os.environ["PRODUCER"],"renderer_root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"render_host":"m40","source_bundle_commit":"e5d97b47325fb871584ce61e46d402b3df7c2562" if os.environ["PRODUCER"]=="elder1" else "fb73b3e5bcdef4612640631f8060310e44e08749","source_bundle_manifest_sha256":hashlib.sha256((root/"SHA256SUMS.json").read_bytes()).hexdigest(),"stored_hashes_verified":len(hashes),"scientific_verdict":None}
(out/"input-verification.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
PY
"$base/plot-venv-a1/bin/python" -u -m Scripts.StructTrain.TimeLearner report Scripts/StructTrain/TimeLearner/specs/repeat-boundary-native-v1.json --format native-test-run --artifacts "$bundle/native-run-a3" --output "$out/report" > "$out/render.log" 2>&1
OUT="$out" "$base/plot-venv-a1/bin/python" - <<'PY'
import json,os,hashlib
from pathlib import Path
out=Path(os.environ["OUT"]);root=out/"report"
manifest=json.loads((root/"manifest.json").read_text())
assert manifest["tests"]==51 and manifest["trials"]==338 and len(manifest["groups"])==78
hashes=json.loads((root/"SHA256SUMS.json").read_text())
for rel,expected in hashes.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==expected,rel
record={k:v for k,v in manifest.items() if k!="groups"}
record.update(stored_hashes_verified=len(hashes),render_process_completed=True)
(out/"validation.json").write_text(json.dumps(record,indent=2)+"\n")
PY
