from pathlib import Path
import os,sys,subprocess,json,traceback,hashlib,tarfile,unittest
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-stock-fixed-geometry-normal-a2';out.mkdir(exist_ok=False)
sdk=base/'analysis-stock-fixed-geometry-normal-a2';donor=base/'analysis-stock-fixed-geometry-normal-a1';original=base/'readbacks/s07-stock-fixed-geometry-normal-a1';source=base/'readbacks/s07-stock-threshold-pair-normal-a3/study';root='07517bcf8cf9436fa3b0161ab7102b83ebf8053d'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/');git(sdk,'fetch','--no-recurse-submodules',str(base/'git-relay-threshold-archive-normal-a1.git'),root);git(sdk,'checkout','--detach',root)
 sys.path.insert(0,str(sdk))
 from Scripts.StructTrain.TimeLearner.fixed_geometry_resistance import prepare,validate_prepared
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 before=_inventory(source);plan=prepare(source,out/'prepared');assert validate_prepared(out/'prepared')==plan
 new=_inventory(out/'prepared');old=_inventory(original/'prepared')
 assert {k:v for k,v in new.items() if k!='plan.json'}=={k:v for k,v in old.items() if k!='plan.json'}
 write('prepared-primary-reuse.json',{'equal_files':len(new)-1,'prior_plan_schema':1,'current_plan_schema':2,'prior_readback':str(original),'native_rerun':False})
 os.environ['TIMELEARNER_FIXED_GEOMETRY_CORPUS']=str(original);os.environ['TIMELEARNER_FIXED_GEOMETRY_PREPARED']=str(out/'prepared')
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_fixed_geometry_resistance.FixedGeometryResistanceTest')
 with (out/'readers.log').open('w') as log:tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('readers.json',{'tests':tests.testsRun,'errors':len(tests.errors),'failures':len(tests.failures),'skipped':len(tests.skipped)});assert tests.wasSuccessful() and not tests.skipped
 assert before==_inventory(source);passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (sdk/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'stock_fixed_geometry_input_binding_readers','orchestration_root':root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
