from pathlib import Path
import os,sys,subprocess,json,traceback,hashlib,tarfile
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-stock-fixed-geometry-normal-a1';out.mkdir(exist_ok=False)
sdk=base/'analysis-stock-fixed-geometry-normal-a1';donor=base/'source-initial-threshold-normal-a4';source=base/'readbacks/s07-stock-threshold-pair-normal-a3/study';root='61b1f3fcc40b8d050445efaeff3a9c8a0a1284aa'
runtime_manifest=base/'readbacks/s03-native-probe-interruptions-normal-a1/runtime.json'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/')
 git(sdk,'fetch','--no-recurse-submodules',str(base/'git-relay-threshold-archive-normal-a1.git'),root)
 git(sdk,'checkout','--detach',root);assert not git(sdk,'status','--porcelain','--untracked-files=no')
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.fixed_geometry_resistance import prepare,run
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 before=_inventory(source);write('source-proof.json',{'root':'74369ef343ec577e301c63f4c9ad6b0dabd2b935','published_proof':'e5fa71d745119af0d818059f497dd226f4c7c25d'})
 plan=prepare(source,out/'prepared');write('prepared-summary.json',{'rows':plan['rows'],'sha256':plan['sha256']});print('PREPARED',plan['rows'],flush=True)
 result=run(out/'prepared',runtime_manifest,out/'runs');write('summary.json',{'rows':[{'name':r['name'],'source_graph_reproduced':r['source_graph_reproduced'],'probes_executed':r['probes_executed'],'graph_delta_count':len(r['baseline_difference'])} for r in result['rows']],'scientific_verdict':None});assert before==_inventory(source)
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (sdk/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'stock_fixed_geometry_controls','orchestration_root':root,'native_root':'07ff1081f88dd020eafa345c3dc0cf4594a0941c','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
