set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-legacy-reader-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 38cd68a022814782eff667bedd60bdfe9a6950bc > "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$repo" archive 38cd68a022814782eff667bedd60bdfe9a6950bc Scripts | tar -x -C "$out/source"
cd "$out/source"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_POSTTUNE_TRANSACTION_DIR="$base/readbacks/s08-native-posttune-controller-report-normal-a1/data/controller-fixed-a2/native"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_evidence -v > "$out/reader.log" 2>&1

