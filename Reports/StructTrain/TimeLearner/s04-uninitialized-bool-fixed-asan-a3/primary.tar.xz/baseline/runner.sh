set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s04-uninitialized-bool-baseline-asan-a2"
src="$base/source-threshold-contract-asan-isolated-a1";build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s04-uninitialized-bool-baseline-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s04-uninitialized-bool-fixed-asan-a3/process-exit-status.txt")" = 0
test ! -e "$runtime"
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git f34067c64f8f4ab99b1ff7bfb6c7cc7f7d2a3b8c > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
result=execute(runtime,['--gtest_filter=RdkLifecycleBoolean.*','--gtest_output=xml:'+str(out/'native.xml')],
 Path(runtime['executable']['path']).parent,out/'process',180)
x=ET.parse(out/'native.xml').getroot()
assert int(x.attrib['tests'])==1 and int(x.attrib['failures'])==1 and int(x.attrib.get('errors','0'))==0 and not x.findall('.//skipped')
failures=x.findall('.//failure')
assert len(failures)==1 and 'Value of: uninitialized' in failures[0].attrib['message']
assert 'Actual: false' in failures[0].attrib['message'] and 'Expected: true' in failures[0].attrib['message']
assert result['returncode']==1 and result['execution']=='process_error'
r=load(out/'native/uninitialized-container.json')
assert r['uninitialized_return'] is False and r['inactive_return'] is True and r['uninitialized_children_skipped'] is True
assert r['initialized_return'] is True and r['parent_calculate_calls']==r['child_calculate_calls']==1 and r['global_clock_unchanged'] is True
report={'kind':'rdk_uninitialized_boolean_baseline','schema_version':1,'expected_failed_tests':1,
 'failure':'only boolean return before Init; children remain skipped; initialized scheduler calls both nodes once',
 'control':r,'owned_process_returncode':result['returncode'],'runtime_provenance':result['runtime_provenance'],
 'native_execution_attested':False,'scientific_verdict':None}
(out/'baseline-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
