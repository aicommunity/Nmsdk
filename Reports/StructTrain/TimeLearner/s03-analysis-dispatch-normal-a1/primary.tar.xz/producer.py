from pathlib import Path
import sys,os,json,subprocess,hashlib,threading,traceback,shutil,tarfile,time
base=Path('/home/user/timelearner-refactor');root='8021301e894368aefd045f9d77274fcce9f60245';label='analysis-dispatch-normal-a1'
out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-normal-a2';build=base/'build-csearch-threshold-joint-normal-a3';runtime=base/'runtime-csearch-threshold-joint-normal-a4';bootstrap=base/'source-closed-worker-recovery-a3';reader_source=base/'source-cli-analysis-dispatch-a1';reader_root='7a98295005762c11a9937e5c8f63e6628564d6d6'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source),'build':str(build),'runtime':str(runtime),'contained_supervisor':str(base/('readbacks/s07-'+label+'-container'))})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;disk=shutil.disk_usage(base)
 assert disk.free>=2*1024**3 and memory>=10*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'worker_memory_max_bytes':4*1024**3,'worker_tasks_max':128,'maximum_wall_seconds':86400,'compilation_disabled':True})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3};registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 reservation=registry.reserve('s07-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,build,runtime,bootstrap,reader_source,base/'readbacks/s07-csearch-threshold-joint-normal-a4']],demands={'slots':1,'memory_bytes':4*1024**3,'disk_bytes':512*1024**2},ttl_seconds=120)
 token=reservation['token'];write('reservation.json',dict(reservation,capacity=capacity,release_policy='Hold through archive creation and worker exit; outside controller recovers only after fresh kernel closure and exact owner binding.'))
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 previous=inspect_contained(base/'readbacks/s07-csearch-threshold-joint-normal-a4-container');assert previous['all_processes_closed'];write('previous-worker-closure.json',previous)
 assert git(source,'rev-parse','HEAD')==root and not git(source,'status','--porcelain','--untracked-files=no')
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  _,path=line.split(None,1);wanted=git(source,'rev-parse','HEAD:'+path);assert git(source/path,'rev-parse','HEAD')==wanted and not git(source/path,'status','--porcelain','--untracked-files=no');assert not (source/path/'.git/objects/info/alternates').exists();children[path]=wanted
 assert len(children)==7 and children['Libraries/Nmsdk-PulseLib']=='cc97149c90ce98ff24ca688452f4a40d54e0e63d' and not (source/'.git/objects/info/alternates').exists()
 write('source-closure.json',{'root':root,'children':children,'clean':True,'read_only_reuse':True,'new_checkout_build_or_runtime_update':False})
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 current=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');previous_runtime=json.loads((base/'readbacks/s07-csearch-threshold-joint-normal-a4/native-runtime.json').read_text());assert current==previous_runtime
 write('native-runtime.json',current);write('runtime-identity-readback.json',{'unchanged_against_normal44':True,'runtime_fingerprint':current['runtime_fingerprint']})
 assert git(reader_source,'rev-parse','HEAD')==reader_root
 specification={'kind':'timelearner_native_test_gate','schema_version':2,'cooperative_runtime_capture':True,'runtime_manifest':str(out/'native-runtime.json'),'source_root':str(source),'expected_test_ids':['NativeResistanceDomains/ClassicReadonlyPreview','NativeResistanceDomains/BranchReadonlyPreview'],'maximum_wall_seconds':600,'asan_options':''};write('native-specification.json',specification)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed' and result['inventory']['observed']==2
 prepare=r"""from pathlib import Path
import json
from Scripts.StructTrain.TimeLearner.validation import package_fingerprint,fixture_fingerprint
out=Path('/home/user/timelearner-refactor/readbacks/s07-analysis-dispatch-normal-a1');fixture=out/'native-result/native';count,digest=fixture_fingerprint(fixture,'*.json')
prefix='Scripts.StructTrain.TimeLearner.tests.test_analysis_cli.AnalysisCliTest.'
methods=['test_actual_domain','test_unknown_schema_fails_without_positive_output','test_output_collision_preserves_existing_file','test_probe_cannot_omit_primary_trace','test_legacy_adapter_does_not_invent_physical_proof']
spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'analysis-dispatch-actual-domain5','package_fingerprint':package_fingerprint(),'modules':['Scripts.StructTrain.TimeLearner.tests.test_analysis_cli'],'expected_test_ids':[prefix+m for m in methods],'fixtures':{'TIMELEARNER_DOMAIN_EVIDENCE_DIR':{'pattern':'*.json','files':count,'fingerprint':digest}}}
(out/'reader-suite.json').write_text(json.dumps(spec,indent=2)+'\n')
"""
 with (out/'prepare-readers.log').open('xb') as log:subprocess.run(['python3','-c',prepare],cwd=reader_source,stdout=log,stderr=subprocess.STDOUT,check=True)
 args=['python3','-m','Scripts.StructTrain.TimeLearner.validation',str(out/'reader-suite.json'),'--fixture','TIMELEARNER_DOMAIN_EVIDENCE_DIR='+str(out/'native-result/native'),'--output',str(out/'structured-readers')]
 with (out/'reader-cli.log').open('xb') as log:
  process=subprocess.Popen(args,cwd=reader_source,stdout=log,stderr=subprocess.STDOUT);write('owned-reader.json',{'pid':process.pid,'start_ticks':ticks(process.pid),'arguments':args});status=process.wait(timeout=300)
 readers=json.loads((out/'structured-readers/result.json').read_text());assert status==0 and readers['executed_tests']==5 and readers['assertion_status']=='passed' and not any(readers[k] for k in ['failures','errors','skipped'])
 write('reader-source-hashes.json',{q.relative_to(reader_source).as_posix():sha(q) for q in sorted((reader_source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))})
 assert not errors,errors
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'execution':'completed','native_readonly2_and_cli5_passed':passed,'additional_readers_pending':False,'asan_joint_native_pending':True,'whole_plan_complete':False,'scientific_verdict':None})
  hashes={}
  for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
   for p in (source/prefix).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=sha(p)
  write('source-hashes.json',hashes)
  files={}
  for p in sorted(out.rglob('*')):
   if not p.is_file():continue
   assert p.resolve().is_relative_to(out.resolve()),str(p)
   files[p.relative_to(out).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,record in files.items():
    p=out/name;assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'];info=tarfile.TarInfo(name);info.size=record['bytes']
    with p.open('rb') as f:archive.addfile(info,f)
  write('bundle.json',{'kind':'actual_analysis_dispatch_regression_gate','schema_version':1,'root':root,'reader_root':reader_root,'pulselib':children.get('Libraries/Nmsdk-PulseLib') if 'children' in globals() else None,'acceptance_status':'readonly2_and_cli5_passed' if passed else 'not_accepted','members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
