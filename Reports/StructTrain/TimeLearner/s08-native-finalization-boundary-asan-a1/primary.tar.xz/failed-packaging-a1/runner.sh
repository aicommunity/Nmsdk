set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out=/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-finalization-boundary-publish-asan-a1
repo="$base/source-rdk-bool-evidence-asan-a2"
work="$base/source-finalization-boundary-proof-asan-a1"
branch=codex/finalization-boundary-proof-asan-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-finalization-boundary-asan-a4/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git e50af3eef91b2da932b086b8d9cab2f81fac1969 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout -b "$branch" "$work" FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export BASE="$base" OUT="$out" WORK="$work" VARIANT=asan PYTHONDONTWRITEBYTECODE=1
python3 -u - <<'PY' > "$out/package.log" 2>&1
from pathlib import Path
import copy,hashlib,io,json,os,tarfile,time
from Scripts.StructTrain.TimeLearner.finalization_boundary_evidence import audit_boundary,audit_capture,audit_replay
from Scripts.StructTrain.TimeLearner.native_evidence import load,EvidenceError
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256
from Scripts.StructTrain.TimeLearner.artifact_bundle import verify_packaged_run_closure
from Scripts.StructTrain.TimeLearner.publisher import stage_artifact_set
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);work=Path(os.environ['WORK']);variant=os.environ['VARIANT']
native=base/('readbacks/s08-native-finalization-boundary-'+variant+'-a4')
assert (native/'process-exit-status.txt').read_text().strip()=='0'
corpus=base/('readbacks/s08-native-posttune-fixed-'+variant+('-a2' if variant=='normal' else '-a1')+'/baseline-source')
start=time.monotonic();checks=[];negative=[]
for topology,source in [('Classic','Classic-auto_metric'),('Branch','Branch-synthetic')]:
 job=load(corpus/source/'input/job.json')
 for scenario in (0,1,3):
  name=f'{topology}_finalization_boundary_{scenario}'
  boundary=load(native/'native'/(name+'.json'));checks.append(audit_boundary(boundary))
  if scenario==3:continue
  comparison=load(native/'native'/(name+'_capture-comparison.json'));checks.append(audit_capture(comparison,boundary))
  replay=load(native/'native'/(name+'_replay.json'));checks.append(audit_replay(replay,job,name))
  # Derivative corruption is re-signed; the semantic audit must still reject it.
  bad=copy.deepcopy(comparison);bad['after']['dataset']['native_xml']+=' '
  bad['after']['dataset']['native_xml_sha256']=hashlib.sha256(bad['after']['dataset']['native_xml'].encode()).hexdigest()
  del bad['after']['sha256'];bad['after']['sha256']=canonical_model_sha256(bad['after'])
  probes=[('changed_xml',lambda:audit_capture(bad,boundary)),
          ('wrong_source',lambda:audit_replay(replay,{**job,'implementation_id':'wrong'},name)),
          ('wrong_run',lambda:audit_replay(replay,job,name+'-wrong')),
          ('missing_trial',lambda:audit_replay({**replay,'observations':replay['observations'][:-1]},job,name))]
  for reason,probe in probes:
   try:probe()
   except EvidenceError as error:negative.append({'case':name,'control':reason,'rejected':str(error)})
   else:raise AssertionError('Accepted corrupted boundary '+name+' '+reason)
reader={'kind':'native_finalization_boundary_reader_gate','schema_version':1,'checks':checks,
 'negative_controls':negative,'seconds':time.monotonic()-start,'execution_attestation':False,
 'training_evidence_checked':False,'scientific_verdict':None}
assert len(checks)==14 and len(negative)==16
(out/'reader-validation.json').write_text(json.dumps(reader,indent=2)+'\n')
files={}
def include(folder,prefix):
 assert folder.is_dir()
 for p in sorted(folder.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();files[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for attempt in range(1,5):
 include(base/f'readbacks/s08-native-finalization-boundary-{variant}-a{attempt}',f'attempt-a{attempt}')
for source in ('Classic-auto_metric','Branch-synthetic'):include(corpus/source,'original-fixtures/'+source)
files['reader-validation.json']=(out/'reader-validation.json').read_bytes()
closure=verify_packaged_run_closure(files);assert closure['run_snapshots_verified']==2
target=work/f'Reports/StructTrain/TimeLearner/s08-native-finalization-boundary-{variant}-a1'
target.mkdir(parents=True);archive=target/'primary.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw))
expected={n:hashlib.sha256(r).hexdigest() for n,r in files.items()}
with tarfile.open(archive) as tar:
 for m in tar:
  assert m.isfile() and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==expected.pop(m.name)
assert not expected
def write(p,value):p.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
write(target/'manifest.json',{'kind':'native_finalization_boundary_proof','schema_version':1,'build':variant,
 'native_source_root':'a282fe9a56cd49c09bc81da128b2f1e4c8283417','reader_source_root':'e50af3eef91b2da932b086b8d9cab2f81fac1969',
 'native_gate':load(native/'native-validation.json'),'reader_gate':reader,'source_closure':closure,
 'configured_phase_dispatch_implemented':False,'full_stage_8_accepted':False,'scientific_verdict':None,
 'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'files':[{'path':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in sorted(files.items())]})
(target/'README.md').write_bytes(b'# Immutable native finalization boundary\n\nActual Classic/Branch capture, connected request, queued probe rejection, and external-stop diagnostic controls. Four replay records contain both declared target/foil observations. The independent reader checks source equality, declared complete trials, raw XML with only the measured zero feedback cache representation normalized, and sixteen corrupt controls. It does not attest training evidence or scientific classification.\n\nAll four native attempts are preserved: a1 compile fixture failure, a2 broad full-package equality failure, a3 semantic comparison, a4 strict complete-XML comparison. The sole observed a3 XML change was NPMembraneBio InputFeedbackSignal 0x0 to zero 1x1 in two image snapshots; physics/graph identities and all other fields matched. The cause inside native allocation/reuse has not been proven. No controller hooks or configured optional modes are enabled. Full stage 8 remains open. Plot report for these new replay records remains pending.\n')
write(target/'SHA256SUMS.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.iterdir()) if p.is_file()})
inventory=target/'SHA256SUMS.json'
print(stage_artifact_set(work,inventory.relative_to(work).as_posix(),hashlib.sha256(inventory.read_bytes()).hexdigest()))
print(json.dumps({'members':len(files),'archive_bytes':archive.stat().st_size,'closure':closure,'negative_controls':len(negative)}))

PY
git diff --cached --check
git -c user.name=Codex -c user.email=codex@openai.com commit -m "Preserve asan native finalization boundary raw evidence and independent audit" > "$out/commit.log" 2>&1
git -c push.recurseSubmodules=no push git@github.com:aicommunity/Nmsdk.git "HEAD:refs/heads/$branch" > "$out/push.log" 2>&1
test "$(git ls-remote git@github.com:aicommunity/Nmsdk.git "refs/heads/$branch" | cut -f1)" = "$(git rev-parse HEAD)"
git rev-parse HEAD > "$out/commit.txt"
