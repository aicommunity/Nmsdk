set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-finalization-clock-handoff-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
previous="$base/readbacks/s08-native-finalization-clock-handoff-normal-a1"
while test ! -f "$previous/process-exit-status.txt"; do kill -0 2155827; sleep 10; done
test "$(cat "$previous/process-exit-status.txt")" = 1
test "$(cat "$base/readbacks/s08-native-owned-posttune-worker-reader-normal-a2/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 250000000
test -z "$(git -C "$src" status --porcelain)"
export BASE="$base" SRC="$src" BUILD="$build" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
from pathlib import Path
import json,os
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch origin 62d6bf77e47897401a5709924fd960b59f62303a > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src";export PYTHONDONTWRITEBYTECODE=1
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
result=execute(runtime,['--gtest_filter=NativeFinalizationClockHandoff.*:NativeFinalizationBoundary.*:TimeLearnerNativeLifecycle.*','--gtest_output=xml:'+str(out/'native.xml')],Path(runtime['executable']['path']).parent,out/'process',900)
tree=ET.parse(out/'native.xml').getroot()
assert result['execution']=='completed' and result['returncode']==0 and result['runtime_provenance']=='loaded_files_captured'
assert int(tree.attrib['tests'])==24 and not any(int(tree.attrib.get(k,0)) for k in ('failures','errors','disabled')) and not tree.findall('.//skipped')
rows=[p.name for p in (out/'native').glob('*_clock_gap.json')];assert len(rows)==4
summary={'kind':'native_finalization_clock_handoff_gate','schema_version':1,'tests':24,'seconds':float(tree.attrib['time']),'clock_gap_records':rows,'native_execution_attested':False,'live_train_handoff_implemented':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
