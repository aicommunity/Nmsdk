#!/bin/bash
set -e
trap 'printf "%s\n" "$?" > "/home/user/timelearner-refactor/readbacks/s08-native-finalization-clock-reader-normal-a2/process-exit-status.txt"' EXIT
cd "/home/user/timelearner-refactor/source-clock-reader-normal-a2"
export TIMELEARNER_FINALIZATION_CLOCK_NATIVE="/home/user/timelearner-refactor/readbacks/s08-native-finalization-clock-handoff-normal-a2/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="/home/user/timelearner-refactor/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
export PYTHONDONTWRITEBYTECODE=1
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_finalization_clock_evidence -v > "/home/user/timelearner-refactor/readbacks/s08-native-finalization-clock-reader-normal-a2/test.log" 2>&1
