from pathlib import Path
import os,sys,json,hashlib,subprocess,threading,traceback,tarfile,shutil
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s02-closed-build-objects-retirement-a2';out.mkdir(exist_ok=False);stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False
sys.path.insert(0,str(base/'source-closed-worker-recovery-a3'))
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations

def write(n,v):(out/n).write_bytes((json.dumps(v,indent=2,allow_nan=False)+chr(10)).encode())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def runtime_inventory(root):
 v={}
 for p in root.rglob('*'):
  if p.is_symlink():v[str(p.relative_to(root))]={'symlink':os.readlink(p)}
  elif p.is_file():v[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return v
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'role':'Remove only generated objects/static compiler archives from closed agent build caches; no model execution'})
try:
 global_registry=Reservations(base/'resource-reservations.sqlite3',capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3});held=[v for l in global_registry.inspect()['leases'] if l['state']=='held' for v in l['resources']]
 roots={'build-recognition-owner-burst-normal-a1':'2cb855677f3e7160cd01837f62c649b18803ebf0','build-live-cold-fixture-baseline-normal-a1':'33fc48278cff860d20c570cb703198847f028065','build-csearch-threshold-joint-normal-a3':'8021301e894368aefd045f9d77274fcce9f60245'}
 candidates={};bindings={};before_runtime={};caches={}
 for name,commit in roots.items():
  root=base/name;assert root.resolve()==root and root.is_dir() and root.is_relative_to(base)
  assert root!=base/'build-integrated-acceptance-normal-a1'
  for v in held:
   q=Path(v['canonical_path']);assert not root.is_relative_to(q) and not q.is_relative_to(root),'build_cache_overlaps_active_resource:'+str(q)
  cache=root/'CMakeCache.txt';caches[str(cache)]=sha(cache);settings={}
  for line in cache.read_text().splitlines():
   if line.startswith(('NMSDK_DEPLOY_ROOT:','CMAKE_HOME_DIRECTORY:')):key,value=line.split('=',1);settings[key.split(':',1)[0]]=value
  source=Path(settings['CMAKE_HOME_DIRECTORY']);runtime=Path(settings['NMSDK_DEPLOY_ROOT']);assert source.resolve().is_relative_to(base) and runtime.resolve().is_relative_to(base) and runtime!=root
  assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==commit
  assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
  bindings[name]={'source':str(source),'source_commit':commit,'runtime':str(runtime),'CMakeCache_sha256':caches[str(cache)]}
  before_runtime[str(runtime)]=runtime_inventory(runtime)
  assert before_runtime[str(runtime)]
  for f in root.rglob('*'):
   if not f.is_file() or f.is_symlink() or f.suffix not in ['.o','.a'] or not ('CMakeFiles' in f.parts or f.parent.name=='lib'):continue
   assert f.resolve().is_relative_to(root) and not f.is_relative_to(source) and not f.is_relative_to(runtime)
   with f.open('rb') as stream:header=stream.read(20)
   if f.suffix=='.o':assert header[:4]==b'\x7fELF' and int.from_bytes(header[16:18],'little' if header[5]==1 else 'big')==1, str(f)
   else:assert header[:8]==b'!<arch>\n',str(f)
   candidates[str(f)]={'bytes':f.stat().st_size,'sha256':sha(f),'kind':'compiler_relocatable_object' if f.suffix=='.o' else 'compiler_static_archive'}
 assert len(candidates)==1392 and sum(v['bytes'] for v in candidates.values())==365257328
 # A runtime symlink is a live dependency even if its extension looks disposable.
 for root,records in before_runtime.items():
  for name,record in records.items():
   if 'symlink' in record:assert str((Path(root)/name).resolve()) not in candidates
 # Reject any generated object/archive currently mapped by any readable process.
 selected=set(candidates);mapped=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   for line in (proc/'maps').read_text().splitlines():
    parts=line.split(None,5)
    if len(parts)==6 and parts[5].removesuffix(' (deleted)') in selected:mapped.append({'pid':int(proc.name),'path':parts[5]})
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 assert not mapped
 registry=Reservations(base/'closed-build-object-retirement-reservations.sqlite3');lease=registry.reserve(out.name,[{'path':str(out),'access':'write'}]+[{'path':str(base/name),'access':'write'} for name in roots],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 before=shutil.disk_usage(base).free;write('predelete.json',{'bindings':bindings,'candidate_files':candidates,'runtime_inventories_before':before_runtime,'active_resource_overlaps':False,'selected_files_mapped_by_process':mapped,'disk_free_before':before,'unique_primary_or_runtime_selected':False})
 for name,rec in candidates.items():
  f=Path(name);assert f.is_file() and not f.is_symlink() and f.stat().st_size==rec['bytes'] and sha(f)==rec['sha256'];registry.validate_paths(token);f.unlink()
 after_runtime={name:runtime_inventory(Path(name)) for name in before_runtime};assert after_runtime==before_runtime
 assert all(Path(name).is_file() and sha(Path(name))==digest for name,digest in caches.items())
 assert not errors;write('result.json',{'deleted_files':len(candidates),'deleted_logical_bytes':sum(v['bytes'] for v in candidates.values()),'disk_free_before':before,'disk_free_after':shutil.disk_usage(base).free,'runtime_byte_inventories_unchanged':True,'CMakeCache_files_unchanged':True,'source_SDKs_retained':True,'all_executables_shared_libraries_configs_results_retained':True,'current_build_and_runtime_untouched':True,'native_models_executed':0,'whole_plan_complete':False});passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 write('terminal.json',{'cleanup_completed':passed,'numerical_tests_executed':False,'whole_plan_complete':False})
 files={str(f.relative_to(out)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.rglob('*') if f.is_file()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as a:
  for name,rec in files.items():
   info=tarfile.TarInfo(name);info.size=rec['bytes']
   with (out/name).open('rb') as f:a.addfile(info,f)
 write('bundle.json',{'kind':'closed_build_generated_object_retirement','cleanup_completed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'whole_plan_complete':False});print('CLOSED',passed,flush=True)
