from pathlib import Path
import os,sys,json,time,hashlib,subprocess,threading,traceback,tarfile,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');label='csearch-threshold-joint-asan-gate-a2';out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-asan-build-a1';build=base/'build-csearch-threshold-joint-asan-build-a1';runtime=base/'runtime-csearch-threshold-joint-asan-build-a2';bootstrap=base/'source-closed-worker-recovery-a3';previous=base/'readbacks/s07-capacitance-full-asan-k1';checkpoint=base/'readbacks/s07-csearch-threshold-joint-asan-build-a2'
root='8021301e894368aefd045f9d77274fcce9f60245';stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 path=out/name;path.parent.mkdir(parents=True,exist_ok=True);temporary=path.with_name(path.name+'.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def identity(pid):
 try:
  f=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split();return {'start_ticks':f[19],'state':f[0]}
 except FileNotFoundError:return None
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':identity(os.getpid())['start_ticks'],'root':root,'waits_for':{'pid':3649813,'start_ticks':'284056538'}})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 deadline=time.monotonic()+14*3600
 while True:
  owner=identity(3649813)
  if owner and owner['start_ticks']=='284056538' and owner['state'] not in ('Z','X'):
   write('queue.json',{'state':'waiting_for_exact_live_predecessor','pid':3649813,'start_ticks':'284056538','observed_monotonic':time.monotonic(),'native_models_started':False})
   assert time.monotonic()<deadline,'predecessor_wait_budget_exhausted';time.sleep(30);continue
  assert (previous/'terminal.json').is_file(),'predecessor_terminal_missing_no_restart'
  terminal=json.loads((previous/'terminal.json').read_text());assert terminal['acceptance_status']=='passed',('predecessor_not_passed',terminal)
  handles=[]
  for path in previous.rglob('owned-*.json'):
   record=json.loads(path.read_text())
   if 'pid' not in record or 'start_ticks' not in record:continue
   state=identity(record['pid']);live=bool(state and state['start_ticks']==str(record['start_ticks']) and state['state'] not in ('Z','X'));handles.append({'file':str(path),'pid':record['pid'],'start_ticks':record['start_ticks'],'same_handle_live':live});assert not live,('predecessor_owned_handle_still_live',record)
  assert handles
  reserved=json.loads((previous/'reservation.json').read_text());released=json.loads((previous/'reservation-final.json').read_text());lease=next(v for v in released['leases'] if v['token']==reserved['token']);assert lease['state']=='released' and not released['remaining_direct_children'] and not released['heartbeat_errors']
  write('predecessor-terminal-and-handles.json',{'terminal':terminal,'handles':handles,'reservation_released':True,'source_root':terminal['root']});break
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 registry=Reservations(base/'resource-reservations.sqlite3')
 oldleases=registry.inspect();assert next(v for v in oldleases['leases'] if v['token']==reserved['token'])['state']=='released'
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;disk=shutil.disk_usage(base);assert memory>=24*1024**3 and disk.free>=20*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'compilation_disabled':True,'runtime_immutable':True,'worker_memory_max_bytes':8*1024**3,'worker_tasks_max':128,'native_budget_seconds':21600,'global_ledger_schema_migration':False})
 reservation=registry.reserve('s07-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,build,runtime,bootstrap,checkpoint,previous]],ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 buildclosure=inspect_contained(Path(str(checkpoint)+'-container'));assert buildclosure['all_processes_closed'];write('build-group-closure.json',buildclosure)
 assert json.loads((checkpoint/'terminal.json').read_text())['build_passed']
 assert git(source,'rev-parse','HEAD')==root and not git(source,'status','--porcelain','--untracked-files=no') and not (source/'.git/objects/info/alternates').exists()
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  _,path=line.split(None,1);wanted=git(source,'rev-parse','HEAD:'+path);assert git(source/path,'rev-parse','HEAD')==wanted and not git(source/path,'status','--porcelain','--untracked-files=no') and not (source/path/'.git/objects/info/alternates').exists();children[path]=wanted
 assert len(children)==7 and children['Libraries/Nmsdk-PulseLib']=='cc97149c90ce98ff24ca688452f4a40d54e0e63d';write('source-closure.json',{'root':root,'children':children,'clean':True,'read_only_reuse':True})
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 current=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');assert current==json.loads((checkpoint/'native-runtime.json').read_text());write('native-runtime.json',current)
 spec=json.loads((source/'Scripts/StructTrain/TimeLearner/specs/native-csearch-threshold-joint-v1.json').read_text());assert len(spec['expected_test_ids'])==44;spec.update(source_root=str(source),runtime_manifest=str(out/'native-runtime.json'),asan_options='detect_leaks=0',maximum_wall_seconds=21600);write('native-specification.json',spec)
 registry.validate_paths(token);assert not errors
 write('queue.json',{'state':'running_native44','root':root,'native_models_started':True})
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed' and result['inventory']['observed']==result['inventory']['expected']==44
 maps=json.loads((out/'native-result/process/loaded-files.json').read_text());assert any(Path(r['path']).name.startswith('libasan.so') for r in maps)
 registry.validate_paths(token);assert not errors;passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'execution':'completed','native44_passed':passed,'full304_executed':False,'whole_plan_complete':False,'scientific_verdict':None})
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  for path in (source/prefix).rglob('*'):
   if path.is_file() and '__pycache__' not in path.parts:hashes[path.relative_to(source).as_posix()]=digest(path)
 write('source-hashes.json',hashes)
 files={path.relative_to(out).as_posix():{'bytes':path.stat().st_size,'sha256':digest(path)} for path in out.rglob('*') if path.is_file()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for name,record in files.items():
   path=out/name;assert digest(path)==record['sha256'];info=tarfile.TarInfo(name);info.size=record['bytes']
   with path.open('rb') as stream:archive.addfile(info,stream)
 write('bundle.json',{'kind':'joint_csearch_threshold_asan_native_controls','root':root,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':digest(out/'primary.tar.xz'),'native44_passed':passed,'scientific_verdict':None})
 stop.set()
 if thread:thread.join(timeout=30)
 if token and not errors:
  try:
   group=Path('/sys/fs/cgroup')/Path('/proc/self/cgroup').read_text().strip().split('0::',1)[1].lstrip('/');members=set()
   for path in group.rglob('cgroup.procs'):members.update(map(int,path.read_text().split()))
   assert members=={os.getpid()},('descendants_remain',members);registry.release(token,note='Native44 worker finalized its archive; fresh entire cgroup membership contains only the finalizing owner. Kernel group closure follows separately.');write('reservation-final.json',registry.inspect())
  except BaseException as e:write('reservation-release-refused.json',{'reason':str(e)})
 print('CLOSED',passed,flush=True)
