from pathlib import Path,PurePosixPath
import os,sys,subprocess,json,hashlib,io,tarfile,time,traceback,signal,shutil
ROOT='ddfe1f39d40373daab1d4e2894a9c822c90a288f';base=Path('/media/user/Data/TimeLearnerRefactor');out=base/'readbacks/s04-initial-threshold-asan-a2';out.mkdir(exist_ok=False)
source=base/'source-initial-threshold-asan-a2';build=base/'build-initial-threshold-asan-a2';runtime=base/'runtime-initial-threshold-asan-a2';framework=base/'framework-initial-threshold-asan-a2'
donor=base/'source-configured-probe-ownership-asan-h14'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def run(args,name,timeout=1800):
 args=[str(a) for a in args]
 with (out/name).open('xb') as log:
  q=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r={'pid':q.pid,'start_ticks':ticks(q.pid),'arguments':args,'process_group':q.pid};write('owned-'+name+'.json',r)
  try:rc=q.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   if live(r) and os.getpgid(q.pid)==q.pid:
    os.killpg(q.pid,signal.SIGTERM)
    try:q.wait(timeout=10)
    except subprocess.TimeoutExpired:
     if live(r) and os.getpgid(q.pid)==q.pid:os.killpg(q.pid,signal.SIGKILL);q.wait(timeout=10)
   raise
  assert rc==0,(name,rc)
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
try:
 prior=base/'readbacks/s07-configured-probe-ownership-asan-h21';owner=json.loads((prior/'owned-supervisor.json').read_text())
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 assert memory>=32*1024**3 and len(os.sched_getaffinity(0))>=8 and shutil.disk_usage(base).free>=20*1024**3,'insufficient measured resources for separate single-thread SDK'
 superseded=json.loads((base/'readbacks/s04-initial-threshold-asan-a1/superseded.json').read_text());assert not live(superseded['owner'])
 write('prior-waiter-supersession.json',superseded)
 write('resource-preflight.json',{'available_memory_bytes':memory,'required_memory_bytes':32*1024**3,'available_disk_bytes':shutil.disk_usage(base).free,'cpu_count':len(os.sched_getaffinity(0)),'compile_parallelism':1,'coexisting_native_owner':owner,'coexisting_native_owner_live':live(owner),'active_source_runtime_mutated':False})
 run(['git','clone','--shared','--no-checkout',donor,source],'clone-root.log')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],'fetch-root.log')
 run(['git','-C',source,'sparse-checkout','set','--no-cone','/*','!/Docs/','!/Reports/'],'sparse-root.log')
 run(['git','-C',source,'checkout','--detach',ROOT],'checkout-root.log')
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.publisher import _module_urls
 urls=_module_urls(source,ROOT);children={}
 for path,url in urls.items():
  sha=git(source,'rev-parse',ROOT+':'+path);label=path.replace('/','_');destination=source/path
  if destination.is_dir() and not any(destination.iterdir()):destination.rmdir()
  run(['git','clone','--shared','--no-checkout',donor/path,destination],'clone-'+label+'.log')
  transport='https://github.com/'+url[len('git@github.com:'):] if url.startswith('git@github.com:') else url
  run(['git','-C',destination,'fetch','--no-recurse-submodules',transport,sha],'fetch-'+label+'.log')
  run(['git','-C',destination,'checkout','--detach',sha],'checkout-'+label+'.log')
  assert git(destination,'rev-parse','HEAD')==sha and not git(destination,'status','--porcelain','--untracked-files=no')
  children[path]=sha
 run(['git','-C',source,'submodule','init'],'init-submodules.log')
 assert not git(source,'status','--porcelain','--untracked-files=no')
 write('source-closure.json',{'root':ROOT,'children':children,'clean':True,'read_only_git_object_donor':str(donor),'preserve_donors_until_dissociated':True})
 old_framework=json.loads((base/'readbacks/s07-configured-probe-ownership-asan-h14/framework.json').read_text())
 framework_sha='58d77fa8070e8cec2dc1ed015d66b454c8d78850';assert old_framework['commit']==framework_sha
 run(['git','clone','--shared','--no-checkout',old_framework['source'],framework],'clone-framework.log')
 run(['git','-C',framework,'checkout','--detach',framework_sha],'checkout-framework.log')
 assert git(framework,'rev-parse','HEAD')==framework_sha and not git(framework,'status','--porcelain','--untracked-files=no')
 write('framework.json',{'commit':framework_sha,'source':str(framework),'read_only_donor':old_framework['source'],'system_gtest_disabled':True})
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DBUILD_TESTING=ON','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON','-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':[str(a) for a in args]});run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log',10800)
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes());write('build-terminal.json',{'execution':'completed','root':ROOT})
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 from Scripts.StructTrain.TimeLearner.stock_phasea_preflight import run_stock_preflight
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 appini=runtime/'NeuroModelerConsole.ini'
 for name,exe in [('native-runtime.json','Test_PulseLib_StorageComponents'),('console-runtime.json','NeuroModelerConsole')]:write(name,snapshot(source,runtime/exe,appini,build/'CMakeCache.txt'))
 spec=load(source/'Scripts/StructTrain/TimeLearner/specs/native-initial-threshold-v1.json');assert len(spec['expected_test_ids'])==14
 spec.update(source_root=str(source),runtime_manifest=str(out/'native-runtime.json'),asan_options='detect_leaks=0');write('native-specification.json',spec)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed'
 loaded=load(out/'native-result/process/loaded-files.json')
 def strings(v):
  if isinstance(v,str):yield v
  elif isinstance(v,dict):
   for z in v.values():yield from strings(z)
  elif isinstance(v,list):
   for z in v:yield from strings(z)
 mappings=sorted({s for s in strings(loaded) if 'libasan.so' in s});assert mappings,'actual libasan mapping missing'
 write('actual-libasan-mappings.json',{'paths':mappings,'detect_leaks':False})
 bundle=out/'source-calibration';bundle.mkdir();calibration='27c5120e06d61be2244fd92111a4b062774880a8';prefix='Reports/StructTrain/TimeLearner/s08-positive-n1-calibration-normal-a1/'
 for name in ['README.md','manifest.json','SHA256SUMS.json','primary.tar.xz']:(bundle/name).write_bytes(subprocess.check_output(['git','-C',str(source),'show',calibration+':'+prefix+name]))
 run_stock_preflight(bundle,out/'console-runtime.json',out/'preflight100',initial_threshold=100.)
 normal='d7471b10d2ea744fb75034f72c871793a38c9893';prefix='Reports/StructTrain/TimeLearner/s04-initial-threshold-normal-a5/'
 raw=subprocess.check_output(['git','-C',str(source),'show',normal+':'+prefix+'primary.tar.xz']);normal_manifest=json.loads(subprocess.check_output(['git','-C',str(source),'show',normal+':'+prefix+'manifest.json']));assert hashlib.sha256(raw).hexdigest()==normal_manifest['archive_sha256']
 compared=[]
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:
  for topology in ['Classic','Branch']:
   name=topology+'-stock-nspneurongen-inputs4';member='preflight100/runs/'+name+'/native/initial-state.json';reference=json.load(t.extractfile(member));actual=load(out/'preflight100/runs'/name/'native/initial-state.json');assert actual==reference,'cross-worker zero-tick effective model changed';compared.append({'name':name,'model_revision':actual['identity']['sha256']})
 write('cross-normal-model-identities.json',{'normal_evidence':normal,'identical':compared})
 count,digest=fixture_fingerprint(out/'preflight100','**/*.*');module='Scripts.StructTrain.TimeLearner.tests.test_native_model_spec.NativeModelSpecTest'
 names=['test_both_actual_native_construction_values_and_full_physics_are_bound','test_schema_downgrade_unknown_factor_and_invalid_scalar_cannot_be_ignored','test_rehashed_effective_threshold_mismatch_is_rejected']
 suite={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'initial-threshold-asan-preflight3','package_fingerprint':package_fingerprint(),'modules':[module],'expected_test_ids':[module+'.'+n for n in names],'fixtures':{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':{'pattern':'**/*.*','files':count,'fingerprint':digest}}}
 result=run_suite(suite,{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':str(out/'preflight100')},out/'reader-result');assert result['executed_tests']==3 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 write('terminal.json',{'execution':'completed','native_tests':14,'native_preflights':2,'reader_tests':3,'actual_asan_mappings':True,'cross_worker_initial_models_identical':True,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:print('CLOSED',flush=True)
