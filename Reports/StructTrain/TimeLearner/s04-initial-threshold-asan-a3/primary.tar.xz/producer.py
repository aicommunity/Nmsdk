from pathlib import Path
import os,sys,json,hashlib,subprocess,tarfile,io,traceback
base=Path('/media/user/Data/TimeLearnerRefactor');prior=base/'readbacks/s04-initial-threshold-asan-a2';out=base/'readbacks/s04-initial-threshold-asan-a3';out.mkdir(exist_ok=False)
ROOT='ddfe1f39d40373daab1d4e2894a9c822c90a288f';sdk=base/'source-initial-threshold-asan-a2'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def digest_tree(path):return {p.relative_to(path).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file()}
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False;before=digest_tree(prior)
try:
 assert not live(json.loads((prior/'owned-supervisor.json').read_text()))
 native=json.loads((prior/'native-verdict.json').read_text());assert native['execution']=='completed' and native['validity']=='valid' and native['assertion_status']=='passed' and native['inventory']['observed']==14
 assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()==ROOT
 write('native-prerequisite.json',{'original_result':native,'original_exception':json.loads((prior/'exception.json').read_text()),'native_rerun':False,'source_runtime_unchanged':True})
 sys.path.insert(0,str(sdk));os.chdir(sdk)
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 from Scripts.StructTrain.TimeLearner.stock_phasea_preflight import run_stock_preflight
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 verify_runtime(load(prior/'native-runtime.json'));verify_runtime(load(prior/'console-runtime.json'))
 loaded=json.loads((prior/'native-result/process/loaded-files.json').read_text());assert isinstance(loaded,list) and loaded
 mappings=[r for r in loaded if isinstance(r,dict) and 'libasan.so' in r.get('path','')];assert mappings
 for row in mappings:
  p=Path(row['path']);assert p.stat().st_size==row['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 write('actual-libasan-mappings.json',{'records':mappings,'source':'original native14 loaded-files.json array','source_file_sha256':hashlib.sha256((prior/'native-result/process/loaded-files.json').read_bytes()).hexdigest(),'detect_leaks':False})
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 bundle=out/'source-calibration';bundle.mkdir();calibration='27c5120e06d61be2244fd92111a4b062774880a8';prefix='Reports/StructTrain/TimeLearner/s08-positive-n1-calibration-normal-a1/'
 for name in ['README.md','manifest.json','SHA256SUMS.json','primary.tar.xz']:(bundle/name).write_bytes(subprocess.check_output(['git','-C',str(sdk),'show',calibration+':'+prefix+name]))
 run_stock_preflight(bundle,prior/'console-runtime.json',out/'preflight100',initial_threshold=100.)
 normal='d7471b10d2ea744fb75034f72c871793a38c9893';prefix='Reports/StructTrain/TimeLearner/s04-initial-threshold-normal-a5/'
 raw=subprocess.check_output(['git','-C',str(sdk),'show',normal+':'+prefix+'primary.tar.xz']);m=json.loads(subprocess.check_output(['git','-C',str(sdk),'show',normal+':'+prefix+'manifest.json']));assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
 compared=[]
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:
  for topology in ['Classic','Branch']:
   name=topology+'-stock-nspneurongen-inputs4';reference=json.load(t.extractfile('preflight100/runs/'+name+'/native/initial-state.json'));actual=load(out/'preflight100/runs'/name/'native/initial-state.json');assert actual==reference,'cross-worker initial state differs';compared.append({'name':name,'model_revision':actual['identity']['sha256']})
 write('cross-normal-model-identities.json',{'normal_evidence':normal,'identical':compared})
 count,fingerprint=fixture_fingerprint(out/'preflight100','**/*.*');module='Scripts.StructTrain.TimeLearner.tests.test_native_model_spec.NativeModelSpecTest'
 names=['test_both_actual_native_construction_values_and_full_physics_are_bound','test_schema_downgrade_unknown_factor_and_invalid_scalar_cannot_be_ignored','test_rehashed_effective_threshold_mismatch_is_rejected']
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'initial-threshold-asan-completed-boundary-preflight3','package_fingerprint':package_fingerprint(),'modules':[module],'expected_test_ids':[module+'.'+n for n in names],'fixtures':{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':{'pattern':'**/*.*','files':count,'fingerprint':fingerprint}}}
 result=run_suite(spec,{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':str(out/'preflight100')},out/'reader-result');assert result['executed_tests']==3 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 assert before==digest_tree(prior),'original native14 attempt was modified'
 write('original-primary-byte-guard.json',{'unchanged':True,'sha256_by_path':before})
 passed=True;write('terminal.json',{'execution':'completed','original_native_tests':14,'native_rerun':False,'new_native_preflights':2,'reader_tests':3,'actual_asan_mappings':True,'original_overall_exception_preserved':True,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 from Scripts.StructTrain.TimeLearner.publisher import _module_urls
 reach=[];probe=out/'child-reachability.git';subprocess.run(['git','init','--bare',str(probe)],check=True,stdout=subprocess.DEVNULL)
 for path,url in _module_urls(sdk,ROOT).items():
  sha=subprocess.check_output(['git','-C',str(sdk),'rev-parse',ROOT+':'+path],text=True).strip()
  subprocess.run(['git','-C',str(probe),'fetch','--no-recurse-submodules','--filter=tree:0','--depth=1',url,sha],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  reach.append({'path':path,'commit':sha,'url':url,'remote_fetch_verified':True})
 write('child-remote-reachability.json',reach)
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  for p in (sdk/prefix).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(sdk).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={'original-native14/'+p.relative_to(prior).as_posix():p for p in prior.rglob('*') if p.is_file()}
 files.update({p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and 'child-reachability.git' not in p.relative_to(out).parts})
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes();bundle={'kind':'native_initial_threshold_asan_completed_boundary_validation','schema_version':1,'root':ROOT,'pulselib':'541bf89b9966f63ca5131fa57a31a9ae3f5820ea','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(bundle,indent=2)+'\n').encode()};payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(sdk),*a],input=raw,env=env).decode().strip()
 git('config','user.name','TimeLearner Evidence');git('config','user.email','timelearner@localhost');git('read-tree',ROOT)
 report='Reports/StructTrain/TimeLearner/s04-initial-threshold-asan-a3'
 for n,b in payload.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=git('commit-tree',git('write-tree'),'-p',ROOT,raw=b'evidence: actual ASan14 retained unchanged and explicit continuation2 zero-tick stock preflights plus3 readers\n')
 branch='refs/heads/codex/evidence-s04-initial-threshold-asan-a3';remote='git@github.com:aicommunity/Nmsdk.git';git('update-ref',branch,commit,'0'*40);git('push','--recurse-submodules=no',remote,branch+':'+branch)
 assert git('ls-remote',remote,branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':bundle['acceptance_status'],'members':len(records),'archive_bytes':len(raw),'original_native14_rerun':False})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
print('CLOSED',passed,flush=True)
