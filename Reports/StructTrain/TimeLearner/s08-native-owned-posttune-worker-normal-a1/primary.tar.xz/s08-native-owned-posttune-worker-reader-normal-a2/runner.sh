set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-owned-posttune-worker-reader-normal-a2"
prior="$base/readbacks/s08-native-owned-posttune-worker-normal-a1"
repo="$base/source-training-intent-binding-reader-normal-a1"
work="$base/source-owned-posttune-worker-reader-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch origin e6eb2a76aa09c7498495893b8fa99014d278f916 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" e6eb2a76aa09c7498495893b8fa99014d278f916 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
while test ! -f "$prior/process-exit-status.txt"; do kill -0 2096495; sleep 10; done
case "$(cat "$prior/process-exit-status.txt")" in 0|1) ;; *) exit 2;; esac
test -f "$prior/corpus/corpus-summary.json"
cd "$work"
export PYTHONDONTWRITEBYTECODE=1
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
python3 -u -m Scripts.StructTrain.TimeLearner.tests.owned_posttune_worker_checks --corpus "$prior/corpus" --output "$out/checks" > "$out/test.log" 2>&1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$prior/runtime-before.json" "$out/runtime-after.json"
df -h "$base" > "$out/disk-after.txt"
