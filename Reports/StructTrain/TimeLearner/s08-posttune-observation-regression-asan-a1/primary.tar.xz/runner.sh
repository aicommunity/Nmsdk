set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-posttune-observation-regression-asan-a1";runtime="$base/runtime-s08-posttune-observation-fixed-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cp "$base/readbacks/s08-posttune-observation-fixed-asan-a2/runtime-before.json" "$out/runtime-before.json"
cd "$base/source-threshold-contract-asan-isolated-a1"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-preflight.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
mkdir "$out/native"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='PostTuneTransientStimulus.*:NativePostTuneGraphBoundary.*:NativePostTuneOwnerPolicy.*:NativePostTuneBoundaryGuards.*:NativePostTuneReconstruction.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);xml=E.parse(p/'native.xml').getroot();cases=list(xml.iter('testcase'))
v={'native_root':'e3fe53408b861b49c0e0ddc6c3de9acc548a9e54','pulse':'39810a760103d2e5d5a5b9e6ae6575290522b20c',
 'tests':len(cases),'failures':len(list(xml.iter('failure'))),'errors':len(list(xml.iter('error'))),'skips':len(list(xml.iter('skipped'))),'scientific_verdict':None}
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
assert (v['tests'],v['failures'],v['errors'],v['skips'])==(37,0,0,0),v
PY
cd "$base/source-threshold-contract-asan-isolated-a1"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
