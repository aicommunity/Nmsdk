set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s08-posttune-observation-reader-normal-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /home/user/timelearner-refactor/source-posttune-baseline-evidence-normal-a1
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_LEGACY_POSTTUNE_FREERUN_DIR=/home/user/timelearner-refactor/readbacks/s08-posttune-observation-fixed-normal-a2/native
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,subprocess,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.tests.test_legacy_posttune_evidence import LegacyPostTunePhysicalEvidenceTest as Case
names=['test_four_actual_traces_remain_diagnostics','test_missing_native_sample_is_rejected','test_unknown_foil_state_cannot_reuse_valid_summary','test_changed_actual_onset_list_is_rejected','test_selected_metric_must_match_actual_somas']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Case(name) for name in names))
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
 'tests':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skips':len(r.skipped),'rendering_in_this_gate':False,'scientific_verdict':None},indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==5 and not r.skipped
PY
