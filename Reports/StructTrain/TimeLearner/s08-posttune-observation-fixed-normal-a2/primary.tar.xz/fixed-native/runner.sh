set -euo pipefail
base=/home/user/timelearner-refactor
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
out="$base/readbacks/s08-posttune-observation-fixed-normal-a2";runtime="$base/runtime-s08-posttune-observation-fixed-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s09-native-pipeline-normal-a1/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s02-runtime-duplicate-cleanup-a3/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s08-posttune-observation-baseline-normal-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git e3fe53408b861b49c0e0ddc6c3de9acc548a9e54 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach e3fe53408b861b49c0e0ddc6c3de9acc548a9e54 >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native"
set +e
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='LegacyPostTuneInferenceObservation.*:LegacyPostTunePhysicalFreeRun.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
native_rc=$?
set -e
echo "$native_rc" > "$out/native-exit-status.txt"
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);xml=E.parse(p/'native.xml').getroot();cases=list(xml.iter('testcase'))
v={'root':'e3fe53408b861b49c0e0ddc6c3de9acc548a9e54','pulse':'39810a760103d2e5d5a5b9e6ae6575290522b20c','tests':len(cases),'failed':[q.attrib['name'] for q in cases if q.find('failure') is not None],'native_returncode':int((p/'native-exit-status.txt').read_text()),'scientific_verdict':None}
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
assert len(cases)==12 and not v['failed'] and v['native_returncode']==0,v
assert not list(xml.iter('error')) and not list(xml.iter('skipped'))
print(json.dumps(v))
PY
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
