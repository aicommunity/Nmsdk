set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-training-threshold-reference-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s04-uninitialized-bool-fixed-normal-a3/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
test "$(cat "$base/readbacks/s08-native-training-threshold-reference-normal-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b922aaa20119c559367d12b50c6185543890014d > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
export TIMELEARNER_POSTTUNE_CONFIG_SOURCE="$TIMELEARNER_POSTTUNE_FIXED_SOURCE"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
filter='NativeSoloThresholdTrace.*'
result=execute(runtime,['--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'native.xml')],
 Path(runtime['executable']['path']).parent,out/'process',1800)
x=ET.parse(out/'native.xml').getroot()
assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
assert result['returncode']==0 and result['execution']=='completed' and result['runtime_provenance']=='loaded_files_captured'
names={(s.attrib['name'],t.attrib['name']) for s in x.findall('testsuite') for t in s.findall('testcase')}
assert len(names)==int(x.attrib['tests'])==8
assert sum(a=='NativeSoloThresholdTrace' for a,b in names)==8
report={'kind':'native_training_threshold_reference_gate','schema_version':1,'native_tests':8,
 'native_seconds':float(x.attrib['time']),'test_names':[list(n) for n in sorted(names)],
 'runtime_provenance':result['runtime_provenance'],'native_execution_attested':False,'scientific_verdict':None}
(out/'native-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"

mkdir "$out/reader"
export TIMELEARNER_SOLO_THRESHOLD_NATIVE="$out/native"
export TIMELEARNER_TRAINING_THRESHOLD_NATIVE="$out/native"
python3 -u - <<'PY' > "$out/reader/test.log" 2>&1
from pathlib import Path
import json,os,time,unittest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.training_threshold_reference import audit_training_threshold_reference,audit_solo_threshold_confirmation
begin=time.monotonic()
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in ['Scripts.StructTrain.TimeLearner.tests.test_solo_threshold_evidence','Scripts.StructTrain.TimeLearner.tests.test_training_threshold_reference'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
root=Path(os.environ['TIMELEARNER_TRAINING_THRESHOLD_NATIVE']);cases={}
if result.wasSuccessful():
 for p in sorted((root/'threshold-references').glob('*-proposals.json')):
  name=p.name.removesuffix('-proposals.json');source=load(root/(name+'.json'));batch=load(p)
  row={'proposals':[audit_training_threshold_reference(q,source) for q in batch['proposals']]}
  if name.endswith('_0'):row['solo_confirmation']=audit_solo_threshold_confirmation(batch['proposals'][0],source,load(p.with_name(name+'-confirmation.json')))
  cases[name]=row
validation={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-begin,'cases':cases,'scientific_verdict':None}
(Path(os.environ['BASE'])/'readbacks/s08-native-training-threshold-reference-normal-a2/reader/validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation),flush=True)
assert result.wasSuccessful() and result.testsRun==4 and not result.skipped
PY

