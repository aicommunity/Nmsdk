ASAN=False
from pathlib import Path
import os,sys,subprocess,json,traceback,time,hashlib,tarfile,unittest,threading
root='a42ff9a0aa8cf1641f87fec1524a272b5430aa5f'
base=Path('/media/user/Data/TimeLearnerRefactor' if ASAN else '/home/user/timelearner-refactor')
sdk=base/('source-initial-threshold-asan-a2' if ASAN else 'source-initial-threshold-normal-a4')
build=base/('build-initial-threshold-asan-a2' if ASAN else 'build-initial-threshold-normal-a4')
label='asan' if ASAN else 'normal';out=base/('readbacks/s03-native-probe-stopped-'+label+'-a3');out.mkdir(exist_ok=False)
runtime=base/('runtime-native-probe-stopped-'+label+'-a3')
prior=base/('readbacks/s03-native-characterization-asan-a3' if ASAN else 'readbacks/s03-native-characterization-normal-a6')
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(*a):return subprocess.check_output(['git','-C',str(sdk),*a],text=True).strip()
def run(args,name):
 with (out/name).open('xb') as log:
  p=subprocess.Popen([str(a) for a in args],stdout=log,stderr=subprocess.STDOUT)
  write('owned-'+name+'.json',{'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().rsplit(') ',1)[1].split()[19]})
  assert p.wait()==0,(name,p.returncode)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 assert not runtime.exists() and not git('status','--porcelain','--untracked-files=no')
 owner=json.loads((prior/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
 users=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:
   refs=[str((proc/'cwd').resolve()),str((proc/'exe').resolve())]+(proc/'maps').read_text().splitlines()
   if any(str(sdk) in s or str(build) in s for s in refs):users.append(proc.name)
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 assert not users,users
 write('closed-source-lease.json',{'active_users':users,'initial_root':git('rev-parse','HEAD')})
 remote='https://github.com/aicommunity/Nmsdk.git' if ASAN else str(base/'git-relay-threshold-archive-normal-a1.git')
 run(['git','-C',sdk,'fetch','--no-recurse-submodules',remote,root],'fetch.log')
 run(['git','-C',sdk,'checkout','--detach',root],'checkout.log');assert not git('status','--porcelain','--untracked-files=no')
 run(['cmake','-S',sdk,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 run(['cmake','--build',build,'--target','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_characterization import audit_execution
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 manifest=snapshot(sdk,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 before=_inventory(runtime);(out/'jobs').mkdir();(out/'runs').mkdir();rows=[]
 from Scripts.StructTrain.TimeLearner.stopped_evidence import load_case as load_stopped
 from Scripts.StructTrain.TimeLearner.native_characterization import prepare_stopped_job
 study=base/'readbacks/s07-stock-threshold-pair-normal-a3/study'
 for topology in ['Classic','Branch']:
  name=topology+'-threshold-training100';source=study/'runs'/name/'native/train_stopped_state.json'
  case=load_stopped(source);index=2 if topology=='Branch' else 0
  for variant in ['baseline','resistance']:
   label=name+'-'+variant
   owners=[0,1,2] if topology=='Branch' else [0]
   changes=[{'input_index':i,'resistance':69551260.1240013} for i in owners] if variant=='resistance' else []
   job=prepare_stopped_job(case,index,label,resistance_intervention=changes);write('jobs/'+label+'.json',job)
   destination=out/'runs'/label
   result=run_job('probe',out/'jobs'/(label+'.json'),source,out/'runtime.json',destination,960)
   assert result['validity']=='valid',(result['execution'],result['validity'])
   assert audit_run_manifest(destination/'run-manifest.json')['run_evidence_consistent']
   checked=audit_execution(destination/'native');assert checked['execution']=='completed'
   packet=load(destination/'native/probe_trial_1.json')
   rows.append({'name':label,'branch':topology=='Branch','variant':variant,'source_package_sha256':case[0]['sha256'],
                'input_index':index,'physical_bank_owners':owners,'observation_valid':checked['observation_valid'],
                'waves':[{'channel':a['channel'],'count':len(a['waves']),'validity':a['validity']} for a in packet['observation']['burst_assignments']]})
   write('index.json',{'rows':rows});print('PROBE',label,rows[-1],flush=True)
 assert before==_inventory(runtime);write('runtime-unchanged.json',{'same':True,'files':len(before)})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['App/NeuroModelerConsole','Scripts/StructTrain/TimeLearner'] for p in (sdk/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'native_stopped_probe_validation','root':root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
