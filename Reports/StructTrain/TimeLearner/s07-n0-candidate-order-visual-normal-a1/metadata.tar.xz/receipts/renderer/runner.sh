set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-visual-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-n0-candidate-order-visual-normal-a1"
export BASE="$base" OUT="$out" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,hashlib,io,tarfile,subprocess,shutil,time
from Scripts.StructTrain.TimeLearner.native_test_reports import inventory_native_test_run
from Scripts.StructTrain.TimeLearner.__main__ import main as cli
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);start=time.monotonic()
prefix='Reports/StructTrain/TimeLearner/s07-n0-candidate-order-normal-a2/';commit='c9c65de9b12989b0ddcb51da5924f1854a56f88e'
checks=json.loads(subprocess.check_output(['git','show',commit+':'+prefix+'SHA256SUMS.json']))
manifest_raw=subprocess.check_output(['git','show',commit+':'+prefix+'manifest.json'])
assert hashlib.sha256(manifest_raw).hexdigest()==checks['manifest.json'];manifest=json.loads(manifest_raw)
archive=subprocess.check_output(['git','show',commit+':'+prefix+'primary.tar.xz'])
assert hashlib.sha256(archive).hexdigest()==checks['primary.tar.xz']
expected=dict(manifest['members']);primary=out/'primary';primary.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  row=expected.pop(member.name);raw=tar.extractfile(member).read()
  assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  p=primary/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert not expected and manifest['native_cases']==31 and manifest['reader']['tests']==4
spec=Path('Scripts/StructTrain/TimeLearner/specs/n0-candidate-order-native-v1.json').resolve();declared=json.loads(spec.read_text())
job=primary/'s07-n0-candidate-order-fixed-normal-a2'
root=out/'data';(root/'native').mkdir(parents=True);shutil.copyfile(job/'native.xml',root/'native.xml')
for phase in declared['phases']:
 summary=job/'native-evidence'/phase['summary'];shutil.copyfile(summary,root/'native'/summary.name)
 count=json.loads(summary.read_text());total=count['reference_probes']+count.get('search_probes',0);assert total>0
 for i in range(1,total+1):
  for ext in ('.json','.csv'):
   name=phase['probe_prefix']+str(i)+ext;shutil.copyfile(job/'native-evidence'/name,root/'native'/name)
def hashes():return {p.relative_to(primary).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(primary.rglob('*')) if p.is_file()}
before=hashes();inventory=inventory_native_test_run(spec,root)
cache=base/'cache/s07-n0-candidate-order-normal-a2'
assert cli(['report',str(spec),'--format','native-test-run','--artifacts',str(root),'--output',str(cache)])==0
assert hashes()==before
report=json.loads((cache/'manifest.json').read_text());assert report['rendered_trial_soma_pairs']==inventory['plottable_trial_soma_pairs']
v={'kind':'n0_native_training_visual','schema_version':1,'source_proof':commit,'reader_root':'71878cb5435f75a413e979be5fba3071fdbd847d','seconds':time.monotonic()-start,'tests':inventory['tests'],'phases':len(inventory['groups']),'trials':inventory['trials'],'rendered_trial_soma_pairs':report['rendered_trial_soma_pairs'],'source_files_unchanged':len(before),'report_scope':'all four actual native N0 training phases; editor-only probes excluded explicitly','scientific_verdict':None,'visual_acceptance_complete':False}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
