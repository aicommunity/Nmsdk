set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-visual-reader-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-n0-candidate-order-visual-normal-a1"
export BASE="$base" OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_N0_CANDIDATE_REPORT_DIR="$base/readbacks/s07-n0-candidate-order-visual-normal-a1/data"
export TIMELEARNER_N0_CANDIDATE_VISUAL_DIR="$base/cache/s07-n0-candidate-order-normal-a2"
export TIMELEARNER_NATIVE_TEST_REPORT_DIR="$base/source-repeat-boundary-full-visual-a1/Reports/StructTrain/TimeLearner/s05-repeat-boundary-m40-a3/native-run-a3"
export TIMELEARNER_NATIVE_TEST_VISUAL_DIR="$base/readbacks/s05-repeat-boundary-full-visual-m40-a1/report"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,hashlib,unittest
start=time.monotonic();out=Path(os.environ['OUT']);root=Path(os.environ['TIMELEARNER_N0_CANDIDATE_REPORT_DIR'])
def snapshot():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
before=snapshot()
prefix='Scripts.StructTrain.TimeLearner.tests.test_native_test_visual_evidence.'
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames([prefix+'N0CandidateVisualEvidenceTest',prefix+'NativeTestVisualEvidenceTest']))
assert r.wasSuccessful() and r.testsRun==6 and not r.skipped
assert snapshot()==before
v={'kind':'n0_native_visual_readback','schema_version':1,'reader_root':'526ac49bc7c75bca3a42a368c4e7371179807fb8','tests':6,'n0_checks':3,'legacy_regression_checks':3,'n0_probes':56,'n0_trial_soma_pairs':84,'legacy_probes':338,'legacy_trial_soma_pairs':507,'n0_source_files_unchanged':len(before),'seconds':time.monotonic()-start,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
