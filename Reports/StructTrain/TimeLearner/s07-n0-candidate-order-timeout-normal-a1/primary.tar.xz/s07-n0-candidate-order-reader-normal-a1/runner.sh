set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s07-n0-candidate-order-reader-normal-a1"
job="$base/readbacks/s07-n0-candidate-order-fixed-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$job/process-exit-status.txt";do
 kill -0 "$(cat "$job/supervisor.pid")";sleep 10
done
test "$(cat "$job/process-exit-status.txt")" = 0
cd "$base/source-n0-candidate-order-reader-normal-a1"
export OUT="$out" TIMELEARNER_N0_CANDIDATE_RUN="$job" PYTHONDONTWRITEBYTECODE=1
python3 -u - <<'PY' > "$out/test.log" 2>&1
import os,json,hashlib,time,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.tests import test_n0_candidate_regression_evidence as module
out=Path(os.environ['OUT']);root=Path(os.environ['TIMELEARNER_N0_CANDIDATE_RUN']);start=time.monotonic()
def snapshot():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
before=snapshot()
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
assert r.wasSuccessful() and r.testsRun==4 and not r.skipped
assert snapshot()==before
v={'kind':'n0_candidate_order_complete_reader','schema_version':1,'reader_root':'a86f96ee5d015b304c63e7070b733477ed69891b','tests':r.testsRun,'native_cases_verified':31,'training_phases_verified':len(module.N0CandidateRegressionEvidenceTest.cases),'actual_probes_verified':sum(len(packets) for _,packets,_ in module.N0CandidateRegressionEvidenceTest.cases),'source_files_unchanged':len(before),'seconds':time.monotonic()-start,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
