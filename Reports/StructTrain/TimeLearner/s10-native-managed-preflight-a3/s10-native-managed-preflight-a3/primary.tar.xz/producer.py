if __name__ == '__main__':
    from pathlib import Path
    import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil
    base=Path('/media/user/Data/TimeLearnerRefactor');label='native-managed-preflight-a3';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False);source=base/'source-native-managed-integration-a3';bootstrap=base/'source-closed-worker-recovery-a3';root='713c811c4654152759aeb02f19d5b7bb0071515c';container=base/('readbacks/s10-'+label+'-container')
    runtime_path=base/'readbacks/s03-native-probe-phases-cold-asan-a1/runtime.json';templates=base/'readbacks/s09-native-pipeline-cli-asan-a1';fixtures=base/'readbacks/s10-pipeline-containment-policy-a1/fixtures'
    stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

    def write(name,value):
     p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    def sha(p):
     h=hashlib.sha256()
     with p.open('rb') as f:
      for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
     return h.hexdigest()
    write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
    try:
     memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;assert memory>=34*1024**3 and shutil.disk_usage(base).free>=4*1024**3
     runtime=json.loads(runtime_path.read_text());assert runtime['source_closure']['root']['head']=='f679d0410dd00a36995f9d32cc03812438819bb7'
     write('resource-preflight.json',{'memory_available_bytes':memory,'controller_cap_bytes':256*1024**2,'native_process_cap_bytes':4*1024**3,'controller_tasks':128,'native_tasks':64,'native_sdk_source':runtime['source_closure']['root']['head'],'model_calculate_expected':False,'shared_ledger_migration':False})
     sys.path.insert(0,str(bootstrap))
     from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
     paths=[source,bootstrap,templates,fixtures,Path(runtime['executable']['path']).parent,Path(runtime['build_flags']['NMSDK_RESOURCE_ROOT'])]
     registry=Reservations(base/'resource-reservations.sqlite3');reservation=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in paths],ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
     def heartbeat():
      while not stop.wait(20):
       try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
       except BaseException as error:errors.append(str(error));return
     thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
     assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root and not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
     for name in list(sys.modules):
      if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
     sys.path.insert(0,str(source));os.chdir(source)
     from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
     verify_runtime(runtime);(out/'native-runtime.json').write_bytes(runtime_path.read_bytes())
     for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM']:
      if key in runtime['loader_environment']:os.environ[key]=runtime['loader_environment'][key]
      else:os.environ.pop(key,None)
     os.environ['ASAN_OPTIONS']='detect_leaks=0'
     jobs={name:str(templates/(name+'-train/input/job.json')) for name in ['Classic-N0','Branch-N1']};assert all(Path(v).is_file() for v in jobs.values())
     write('native-preflight-declaration.json',{'runtime':str(out/'native-runtime.json'),'jobs':jobs,'controller':str(container),'output':str(out/'native-controls')})
     write('portable-fixtures.json',[str(fixtures/name/'process') for name in ['elder','m40']])
     os.environ.update(TIMELEARNER_CONTAINED_POLICY_FIXTURES=str(out/'portable-fixtures.json'),TIMELEARNER_MANAGED_NATIVE_PREFLIGHT=str(out/'native-preflight-declaration.json'))
     names=['test_native_process_policy','test_managed_native_preflight'];suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in names)
     def ids(suite):
      for test in suite:
       if isinstance(test,unittest.TestSuite):yield from ids(test)
       else:yield test.id()
     inventory=list(ids(suite));assert len(inventory)==len(set(inventory))==19;write('test-inventory.json',inventory)
     with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
     write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':19});assert result.testsRun==19 and result.wasSuccessful() and not result.skipped and not errors;passed=True
    except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
    finally:
     try:
      write('terminal.json',{'tests_passed':passed,'native_preflight_jobs':2 if passed else None,'native_model_ticks_expected':0,'train_export_evaluate_calibration_posttune_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
      write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
      files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
      with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
       for name,v in files.items():
        e=tarfile.TarInfo(name);e.size=v['bytes']
        with (out/name).open('rb') as f:archive.addfile(e,f)
      write('bundle.json',{'kind':'managed_native_production_preflight_checks','source_commit':root,'returncode':0 if passed else 1,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'native_sdk_source':runtime['source_closure']['root']['head'] if 'runtime' in globals() else None,'train_export_evaluate_calibration_posttune_pending':True,'scientific_verdict':None})
     finally:
      stop.set()
      if thread:thread.join(timeout=30)
     print('CLOSED',passed,flush=True)
