import pathlib,json,os,sys,traceback,xml.etree.ElementTree as ET
b=pathlib.Path('/media/user/Data/TimeLearnerRefactor');out=b/'readbacks/s01-timing-finite-regression-asan-a2'
source=b/'source-n1-measured-refinement-asan-a1';original=b/'readbacks/s01-timing-finite-current-asan-a1'
try:
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 runtime=json.loads((original/'runtime.json').read_text());closure=source_closure(source)
 assert closure==runtime['source_closure']
 os.environ.update(runtime['loader_environment']);os.environ['ASAN_OPTIONS']='detect_leaks=0'
 verify_runtime(runtime)
 (out/'runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
 (out/'source.json').write_text(json.dumps(closure,indent=2)+'\n')
 os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native-regression')
 os.environ['TIMELEARNER_ROUNDTRIP_TEST_DIR']=str(out/'roundtrip-regression')
 result=execute(runtime,['--gtest_filter=RdkLifecycleBoolean.*:TimeLearnerNativeLifecycle.*:TimeLearnerNativeRoundtrip.*:TopologiesAndRates/NativeLearnerExecution.*','--gtest_output=xml:'+str(out/'gtest.xml')],pathlib.Path(runtime['executable']['path']).parent,out/'process',3600)
 tree=ET.parse(out/'gtest.xml').getroot() if (out/'gtest.xml').exists() else None
 record={'kind':'timing_finite_regression_budget_retry','execution':result,'gtest':tree.attrib if tree is not None else None,'skipped':len(tree.findall('.//testcase/skipped')) if tree is not None else None,'reason':'original1800s budget insufficient; immutable runtime retained','scientific_verdict':None}
 (out/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
 assert result['execution']=='completed' and result['returncode']==0 and tree is not None
 assert tree.attrib['tests']=='21' and tree.attrib['failures']==tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 verify_runtime(runtime);assert source_closure(source)==closure
 (out/'terminal.json').write_text(json.dumps({'execution':'completed','tests':21,'scientific_verdict':None})+'\n')
 print(json.dumps(tree.attrib),flush=True)
except BaseException as error:
 (out/'exception.json').write_text(json.dumps({'error':str(error),'traceback':traceback.format_exc()})+'\n');raise
