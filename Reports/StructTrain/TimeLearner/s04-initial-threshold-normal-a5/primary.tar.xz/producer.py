from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,time,traceback,shutil,signal
ROOT='5c4adf7ed3b2dcd977c763846d7f4010b67869d3'
PULSE='541bf89b9966f63ca5131fa57a31a9ae3f5820ea'
base=Path('/home/user/timelearner-refactor')
source=base/'source-initial-threshold-normal-a4';build=base/'build-initial-threshold-normal-a4'
runtime=base/'runtime-initial-threshold-normal-a5';framework=base/'framework-initial-threshold-normal-a4'
out=base/'readbacks/s04-initial-threshold-normal-a5';out.mkdir(parents=True,exist_ok=False)
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def run(args,name,timeout=1800,cwd=None):
 args=list(map(str,args))
 with (out/name).open('xb') as log:
  p=subprocess.Popen(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  identity=ticks(p.pid);write('owned-'+name+'.json',{'pid':p.pid,'start_ticks':identity,'arguments':args})
  try:rc=p.wait(timeout)
  except subprocess.TimeoutExpired:
   if p.poll() is None and ticks(p.pid)==identity:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise
  if rc:raise RuntimeError(name+' failed '+str(rc))
def git(repo,*args,raw=None):return subprocess.check_output(['git','-C',str(repo),*map(str,args)],input=raw).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT,'pulselib':PULSE})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 prior=base/'readbacks/s04-initial-threshold-normal-a4'
 for filename in ['owned-supervisor.json','owned-build.log.json','native-result/process/owned-process.json']:
  record=json.loads((prior/filename).read_text());stat=Path('/proc',str(record['pid']),'stat')
  assert not stat.exists() or stat.read_text().rsplit(') ',1)[1].split()[19]!=str(record['start_ticks']),filename
 proof=json.loads((prior/'publication.json').read_text());assert proof['commit']=='721dcac83da4085c235e32a79f1ffc85e9d3de54'
 previous=json.loads((prior/'native-result/result.json').read_text())
 assert previous['inventory']['expected']==previous['inventory']['observed']==14
 assert previous['inventory']['failed_test_ids']==['NativeInitialThreshold/UnsupportedZoneIsRejectedBeforeAttachment']
 assert not runtime.exists() and git(source,'rev-parse','HEAD')=='ed12d19c7a43d7e35fa15e209159aa219b0fd61d'
 assert not git(source,'status','--porcelain','--untracked-files=no')
 oldruntime=base/'runtime-initial-threshold-normal-a4'
 def runtime_inventory(folder):
  return {p.relative_to(folder).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in folder.rglob('*') if p.is_file()}
 before=runtime_inventory(oldruntime);assert before;write('old-runtime-before.json',before)
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],'fetch-root.log')
 native_changes=git(source,'diff','--name-only','HEAD',ROOT,'--','*.cpp','*.h','*.cmake','CMakeLists.txt').splitlines()
 assert native_changes==['Tests/Integration/Libraries/Test_PulseLib_InitialThreshold.cpp'],native_changes
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',ROOT],'checkout-root.log')
 children={};urls={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  key,path=line.split(None,1);url=git(source,'config','-f','.gitmodules','--get',key[:-5]+'.url').replace('git@github.com:','https://github.com/')
  wanted=git(source,'rev-parse',ROOT+':'+path);dest=source/path
  if git(dest,'rev-parse','HEAD')!=wanted:
   run(['git','-C',dest,'fetch','--no-recurse-submodules',url,wanted],'fetch-'+path.replace('/','_')+'.log')
   run(['git','-C',dest,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+path.replace('/','_')+'.log')
  assert git(dest,'rev-parse','HEAD')==wanted and not git(dest,'status','--porcelain','--untracked-files=no')
  children[path]=wanted;urls[path]=url
 assert len(children)==7 and children['Libraries/Nmsdk-PulseLib']==PULSE and not git(source,'status','--porcelain','--untracked-files=no')
 write('source-closure.json',{'root':ROOT,'children':children,'clean':True})
 assert git(framework,'rev-parse','HEAD')=='58d77fa8070e8cec2dc1ed015d66b454c8d78850'
 write('framework.json',json.loads((prior/'framework.json').read_text()))
 write('closed-build-reuse.json',{'prior_evidence':proof,'all_known_owners_closed':True,'native_source_changes':native_changes,
       'source_and_build_reused_after_closure':True,'new_runtime':str(runtime),'old_runtime':str(oldruntime),
       'production_pulse_core_unchanged':True,'old_native_inventory':previous['inventory'],'scientific_verdict':None})
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON',
       '-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON',
       '-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':list(map(str,args))})
 run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','2'],'build.log',10800)
 after=runtime_inventory(oldruntime);write('old-runtime-after.json',after);assert after==before,'closed original runtime unexpectedly changed'
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 write('build-terminal.json',{'execution':'completed','root':ROOT,'pulselib':PULSE})
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import snapshot,source_closure
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate as run_native
 from Scripts.StructTrain.TimeLearner.stock_phasea_preflight import run_stock_preflight
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ('LD_LIBRARY_PATH','QT_PLUGIN_PATH'):os.environ.pop(key,None)
 write('native-runtime.json',snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 write('console-runtime.json',snapshot(source,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 spec=json.loads((source/'Scripts/StructTrain/TimeLearner/specs/native-initial-threshold-v1.json').read_text())
 assert len(spec['expected_test_ids'])==14
 spec.update(runtime_manifest=str(out/'native-runtime.json'),source_root=str(source),asan_options='')
 write('native-specification.json',spec)
 native=run_native(out/'native-specification.json',out/'native-result')
 assert native['execution']=='completed' and native['validity']=='valid' and native['assertion_status']=='passed'
 # Recover the prior compressed primary from Git, not a server-only path.
 bundle=out/'source-calibration';bundle.mkdir()
 prefix='Reports/StructTrain/TimeLearner/s08-positive-n1-calibration-normal-a1/'
 for name in ['README.md','manifest.json','SHA256SUMS.json','primary.tar.xz']:
  (bundle/name).write_bytes(subprocess.check_output(['git','-C',str(source),'show',ROOT+':'+prefix+name]))
 print('STOCK PREFLIGHT 100',flush=True)
 result=run_stock_preflight(bundle,out/'console-runtime.json',out/'preflight100',initial_threshold=100.)
 write('stock-preflight-result.json',result)
 count,fingerprint=fixture_fingerprint(out/'preflight100','**/*.*')
 prefix='Scripts.StructTrain.TimeLearner.tests.test_native_model_spec.NativeModelSpecTest.'
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'native-initial-threshold-model-spec-3',
       'package_fingerprint':package_fingerprint(),'modules':['Scripts.StructTrain.TimeLearner.tests.test_native_model_spec'],
       'expected_test_ids':[prefix+n for n in ['test_both_actual_native_construction_values_and_full_physics_are_bound',
       'test_schema_downgrade_unknown_factor_and_invalid_scalar_cannot_be_ignored','test_rehashed_effective_threshold_mismatch_is_rejected']],
       'fixtures':{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':{'pattern':'**/*.*','files':count,'fingerprint':fingerprint}}}
 write('reader-specification.json',spec)
 reader=run_suite(spec,{'TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT':str(out/'preflight100')},out/'reader-result')
 assert reader['assertion_status']=='passed' and reader['executed_tests']==3 and not any(reader[k] for k in ['errors','failures','skipped'])
 write('source-after.json',source_closure(source))
 passed=True
 write('terminal.json',{'execution':'completed','acceptance_status':'passed','native_tests':14,'native_preflights':2,
                       'reader_tests':3,'training_performed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 # Source hashes bind this full production build; no extracted function bodies.
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner',
                'Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'native_initial_threshold_acceptance','schema_version':1,'root':ROOT,'pulselib':PULSE,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 if not (source/'.git').exists():raise RuntimeError('source clone not complete; keep local preparation receipts')
 git(source,'config','user.name','TimeLearner Evidence');git(source,'config','user.email','timelearner@localhost')
 for path,sha in children.items():
  run(['git','-C',source/path,'fetch','--no-recurse-submodules',urls[path],sha],'publication-reachability-'+path.replace('/','_')+'.log')
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(source),*a],input=raw,env=env).decode().strip()
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s04-initial-threshold-normal-a5'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: native initial-threshold construction codec and actual stock preflights\n')
 branch='refs/heads/codex/evidence-s04-initial-threshold-normal-a5'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],
                           'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
