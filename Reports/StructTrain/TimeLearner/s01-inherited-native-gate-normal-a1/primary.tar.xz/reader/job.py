import pathlib,json,subprocess,os,time,hashlib,shutil,traceback,sys
out=pathlib.Path(__file__).resolve().parent
base=pathlib.Path("/home/user/timelearner-refactor")
assert out==base/'readbacks/s01-inherited-reader-normal-a2'
prior=base/'readbacks/s01-inherited-native-normal-a4'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name,timeout=300,env=None):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env=env)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
try:
 code=out/'code';code.mkdir()
 run(['git','init',code],'git-init.log')
 run(['git','-C',code,'fetch','--depth=1','--filter=blob:none','--no-tags','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','5b6dd147200a37ea93f303cbb01408312555e5ac'],'git-fetch.log')
 head=subprocess.check_output(['git','-C',str(code),'rev-parse','FETCH_HEAD'],text=True).strip()
 assert head=='5b6dd147200a37ea93f303cbb01408312555e5ac'
 run(['git','-C',code,'restore','--source='+head,'--worktree','--','Scripts/StructTrain/TimeLearner'],'git-materialize.log')
 deadline=time.monotonic()+43200
 owned={'pid':3326081,'start_ticks':"315193557"}
 while not (prior/'terminal.json').exists():
  if (prior/'exception.json').exists():raise RuntimeError('native_failed:'+str(prior/'exception.json'))
  stat=pathlib.Path('/proc')/str(owned['pid'])/'stat'
  if not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19]!=owned['start_ticks']:raise RuntimeError('native_owner_gone_without_terminal')
  assert time.monotonic()<deadline,'reader_wait_budget_exhausted'
  time.sleep(5)
 terminal=json.loads((prior/'terminal.json').read_text())
 assert terminal['execution']=='completed' and terminal['native_inherited_tests']==16
 artifacts=out/'artifacts';artifacts.mkdir()
 shutil.copytree(prior/'native',artifacts/'native')
 shutil.copyfile(prior/'gtest.xml',artifacts/'native.xml')
 hashes={str(p.relative_to(artifacts)):hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts.rglob('*') if p.is_file()}
 write('primary-files.json',hashes)
 env=os.environ.copy();env['PYTHONPATH']=str(code);env['TIMELEARNER_INHERITED_REPORT_DIR']=str(artifacts)
 run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_inherited_property_reports','-v'],'reader-tests.log',1200,env)
 sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.native_test_reports import inventory_native_test_run
 inventory=inventory_native_test_run(code/'Scripts/StructTrain/TimeLearner/specs/inherited-properties-native-v1.json',artifacts)
 write('inventory.json',inventory)
 write('terminal.json',{'execution':'completed','reader_tests':7,'source':head,'native_output':str(prior),'primary_members':len(hashes),'tests':inventory['tests'],'trials':inventory['trials'],'known_trial_soma_pairs':inventory['known_trial_soma_pairs'],'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
