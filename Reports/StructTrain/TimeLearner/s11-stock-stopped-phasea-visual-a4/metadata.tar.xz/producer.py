
from pathlib import Path
import os,sys,subprocess,json,hashlib,tarfile,traceback,unittest,io
base=Path('/media/user/Data/TimeLearnerRefactor');venv=base/'plot-venv-a1/bin/python'
if sys.prefix!=str(venv.parent.parent):os.execv(str(venv),[str(venv),'-u',str(Path(__file__).resolve())])
root='43b2fbf7bae735d028f73690eeb5f2c245fbe4ef';data_commit='c8381cfc3ecbf446ae1f59175c794ef547dcc93d'
out=base/'readbacks/s11-stock-stopped-phasea-visual-a4';out.mkdir(exist_ok=False)
prior=base/'readbacks/s11-stock-stopped-phasea-visual-a1';primary=prior/'source-primary';source=out/'code';repo=out/'objects.git'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 owner=json.loads((prior/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
 write('preserved-a1-failure.json',{'publication':json.loads((prior/'publication.json').read_text()),'exception':json.loads((prior/'exception.json').read_text())})
 subprocess.run(['git','clone','--shared','--bare',str(base/'source-configured-probe-ownership-asan-h14'),str(repo)],check=True)
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],check=True)
 source.mkdir();p=subprocess.Popen(['git','-C',str(repo),'archive',root,'Scripts'],stdout=subprocess.PIPE)
 subprocess.run(['tar','-xf','-','-C',str(source)],stdin=p.stdout,check=True);p.stdout.close();assert p.wait()==0
 source_proof=json.loads((prior/'source-primary-proof.json').read_text());assert source_proof['commit']==data_commit
 prefix='Reports/StructTrain/TimeLearner/s11-stock-stopped-phasea-normal-a3/'
 original=subprocess.check_output(['git','-C',str(repo),'show',data_commit+':'+prefix+'primary.tar.xz'])
 assert hashlib.sha256(original).hexdigest()==source_proof['archive_sha256']
 meta=json.loads(subprocess.check_output(['git','-C',str(repo),'show',data_commit+':'+prefix+'manifest.json']))
 names=set()
 with tarfile.open(fileobj=io.BytesIO(original),mode='r|xz') as archive:
  for entry in archive:
   name=entry.name;assert entry.isfile() and name not in names
   names.add(name);raw=archive.extractfile(entry).read()
   assert len(raw)==meta['members'][name]['bytes'] and hashlib.sha256(raw).hexdigest()==meta['members'][name]['sha256']
   path=primary/name;assert path.is_file() and path.read_bytes()==raw
 assert names==set(meta['members'])
 write('source-primary-reverified.json',{'commit':data_commit,'source_archive_sha256':source_proof['archive_sha256'],'members_byte_equal':len(names),'source_path':str(primary),'numerical_rerun':False})
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.stock_stopped_evaluation import report
 from Scripts.StructTrain.TimeLearner.plotting import plotting_runtime
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 write('plotting-runtime.json',plotting_runtime())
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_plotting.PlotScaleTest')
 with (out/'plotting-tests.log').open('w') as log:checked=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('plotting-tests.json',{'tests':checked.testsRun,'errors':len(checked.errors),'failures':len(checked.failures),'skipped':len(checked.skipped)})
 assert checked.wasSuccessful() and checked.testsRun==6 and not checked.skipped

 cache=out/'full-report-cache';result=report(primary/'evaluation',cache);write('render-result.json',result)
 assert result['trial_soma_pairs']==80 and result['trials']==32
 os.environ['TIMELEARNER_STOCK_STOPPED_EVALUATION']=str(primary/'evaluation');os.environ['TIMELEARNER_STOCK_STOPPED_REPORTS']=str(cache)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_stock_stopped_reports.StockStoppedReportsTest')
 with (out/'readers.log').open('w') as log:checked=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('readers.json',{'tests':checked.testsRun,'errors':len(checked.errors),'failures':len(checked.failures),'skipped':len(checked.skipped)})
 assert checked.wasSuccessful() and checked.testsRun==3 and not checked.skipped
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'data_commit':data_commit,'numerical_rerun':False,'manual_visual_review_complete':False,'scientific_verdict':None})
 if source.exists():write('source-hashes.json',{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts').rglob('*') if p.is_file() and '__pycache__' not in p.parts})
 print('CLOSED',passed,flush=True)
