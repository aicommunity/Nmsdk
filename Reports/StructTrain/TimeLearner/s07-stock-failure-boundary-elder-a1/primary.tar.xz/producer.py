from pathlib import Path
import subprocess,sys,os,json,unittest,traceback,hashlib
base=Path('/home/user/timelearner-refactor');donor=base/'source-initial-threshold-normal-a4';sdk=base/'analysis-stock-failure-reports-a1';out=base/'readbacks/s07-stock-failure-production-readers-normal-a1';out.mkdir(exist_ok=False)
source=base/'readbacks/s07-stock-threshold-pair-normal-a3/study';root='2b9f13a6c868e428e975252882067c9ee692d1fc'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert git(donor,'cat-file','-t',root).strip()==b'commit'
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/');git(sdk,'checkout','--detach',root)
 sys.path.insert(0,str(sdk));os.environ['TIMELEARNER_STOCK_THRESHOLD_STUDY']=str(source)
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 before=_inventory(source)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in ['Scripts.StructTrain.TimeLearner.tests.test_stock_failure_reports.StockFailureBoundaryTest','Scripts.StructTrain.TimeLearner.tests.test_stock_threshold_study.StockThresholdStudyTest'])
 with (out/'selection-readers.log').open('x') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 summary={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)};write('selection-readers.json',summary)
 assert result.wasSuccessful() and not result.skipped,summary
 assert before==_inventory(source)
 write('source-unchanged.json',{'files':len(before),'same':True,'original_proof':'e5fa71d745119af0d818059f497dd226f4c7c25d'})
 write('terminal.json',{'status':'passed','root':root,'native_rerun':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()});write('terminal.json',{'status':'not_accepted','root':root})
print('CLOSED',flush=True)
