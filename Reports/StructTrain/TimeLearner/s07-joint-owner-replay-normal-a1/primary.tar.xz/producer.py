from pathlib import Path
import sys,os,json,subprocess,hashlib,threading,traceback,shutil,tarfile,time
base=Path('/home/user/timelearner-refactor');root='8021301e894368aefd045f9d77274fcce9f60245';label='csearch-threshold-joint-owner-replay-a1'
out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-normal-a2';build=base/'build-csearch-threshold-joint-normal-a3';runtime=base/'runtime-csearch-threshold-joint-normal-a4';bootstrap=base/'source-closed-worker-recovery-a3';reader_source=base/'source-joint-owner-replay-a1';reader_root='982e23daf334977dca828f17e057fad64a2c7c84'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source),'build':str(build),'runtime':str(runtime),'contained_supervisor':str(base/('readbacks/s07-'+label+'-container'))})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;disk=shutil.disk_usage(base)
 assert disk.free>=2*1024**3 and memory>=10*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'worker_memory_max_bytes':8*1024**3,'worker_tasks_max':128,'maximum_wall_seconds':7200,'compilation_disabled':True})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3};registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 reservation=registry.reserve('s07-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,build,runtime,bootstrap,reader_source,base/'readbacks/s07-csearch-threshold-joint-normal-a4',base/'readbacks/s07-csearch-threshold-joint-full-normal-a1',base/'readbacks/s07-analysis-dispatch-normal-a1']],demands={'slots':1,'memory_bytes':8*1024**3,'disk_bytes':512*1024**2},ttl_seconds=120)
 token=reservation['token'];write('reservation.json',dict(reservation,capacity=capacity,release_policy='Hold through archive creation and worker exit; outside controller recovers only after fresh kernel closure and exact owner binding.'))
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 previous=inspect_contained(base/'readbacks/s07-csearch-threshold-joint-normal-a4-container');assert previous['all_processes_closed'];write('previous-worker-closure.json',previous)
 assert git(source,'rev-parse','HEAD')==root and not git(source,'status','--porcelain','--untracked-files=no')
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  _,path=line.split(None,1);wanted=git(source,'rev-parse','HEAD:'+path);assert git(source/path,'rev-parse','HEAD')==wanted and not git(source/path,'status','--porcelain','--untracked-files=no');assert not (source/path/'.git/objects/info/alternates').exists();children[path]=wanted
 assert len(children)==7 and children['Libraries/Nmsdk-PulseLib']=='cc97149c90ce98ff24ca688452f4a40d54e0e63d' and not (source/'.git/objects/info/alternates').exists()
 write('source-closure.json',{'root':root,'children':children,'clean':True,'read_only_reuse':True,'new_checkout_build_or_runtime_update':False})
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 current=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');previous_runtime=json.loads((base/'readbacks/s07-csearch-threshold-joint-normal-a4/native-runtime.json').read_text());assert current==previous_runtime
 write('native-runtime.json',current);write('runtime-identity-readback.json',{'unchanged_against_normal44':True,'runtime_fingerprint':current['runtime_fingerprint']})
 assert git(reader_source,'rev-parse','HEAD')==reader_root
 original=base/'readbacks/s07-csearch-threshold-joint-full-normal-a1';native=original/'native-result/native'
 assert json.loads((original/'native-verdict.json').read_text())['inventory']['observed']==304
 rows=[];matrix=set()
 for path in sorted(native.glob('*_owner_recognition_state.json')):
  package=json.loads(path.read_text());c=package['source_solo']['configuration'];m=c['model']
  if m['schema_version']!=2 or m['initial_threshold']!=100. or c['schema_version'] not in (3,4):continue
  mode='On' if c['schema_version']==4 else 'Off';key=(m['branch'],m['normalization'],mode);assert key not in matrix;matrix.add(key)
  rows.append({'id':('Branch' if m['branch'] else 'Classic')+'_'+m['normalization']+'_C'+mode,'package':path.name,'file_sha256':sha(path)})
 assert matrix=={(b,n,c) for b in (False,True) for n in ('N0','N1') for c in ('Off','On')} and len(rows)==8
 replay_spec={'kind':'timelearner_recognition_owner_replay','schema_version':1,'source_directory':str(native),'source_bundle':str(original/'bundle.json'),'source_archive':str(original/'primary.tar.xz'),'source_prefix':'native-result/native','origin_evidence_commit':'25bbda5529caea24e8847973cd603d50b1b45826','native_source_root':str(source),'runtime_manifest':str(out/'native-runtime.json'),'maximum_wall_seconds':120,'asan_options':'','cases':rows};write('replay-specification.json',replay_spec)
 args=['python3','-m','Scripts.StructTrain.TimeLearner.recognition_owner_replay',str(out/'replay-specification.json'),'--output',str(out/'fresh-owner-replay')]
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 with (out/'replay-cli.log').open('xb') as log:
  process=subprocess.Popen(args,cwd=reader_source,stdout=log,stderr=subprocess.STDOUT,env=env);write('owned-replay.json',{'pid':process.pid,'start_ticks':ticks(process.pid),'arguments':args});status=process.wait(timeout=1800)
 replay=json.loads((out/'fresh-owner-replay/index.json').read_text());assert status==0 and replay['passed'] and len(replay['cases'])==8 and all(r['passed'] for r in replay['cases'])
 prepare=r"""from pathlib import Path
import json,unittest
from Scripts.StructTrain.TimeLearner.validation import package_fingerprint,fixture_fingerprint,_tests
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-csearch-threshold-joint-owner-replay-a1';original=base/'readbacks/s07-csearch-threshold-joint-full-normal-a1';native=original/'native-result/native'
old=json.loads((base/'readbacks/s07-capacitance-full-normal-j5/reader-suite.json').read_text());suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(m) for m in old['modules']);ids=[t.id() for t in _tests(suite)];assert len(ids)==119 and set(ids)==set(old['expected_test_ids'])
extra={'test_analysis_cli.AnalysisCliTest':['test_actual_domain','test_unknown_schema_fails_without_positive_output','test_output_collision_preserves_existing_file','test_probe_cannot_omit_primary_trace','test_legacy_adapter_does_not_invent_physical_proof'],'test_recognition_owner_replay.RecognitionOwnerReplayTest':['test_all_eight_declared_models_have_actual_exact_fresh_process_waveforms','test_changed_source_binding_cannot_reuse_a_passed_native_gate','test_a_saved_pass_does_not_override_skipped_native_junit','test_nonfinite_actual_soma_cannot_reuse_the_transport_summary']}
for cls,names in extra.items():
 module='Scripts.StructTrain.TimeLearner.tests.'+cls.split('.')[0];old['modules'].append(module);old['expected_test_ids'].extend('Scripts.StructTrain.TimeLearner.tests.'+cls+'.'+m for m in names)
assert len(old['expected_test_ids'])==128
bindings={name:(original/'native-result' if name=='TIMELEARNER_NATIVE_GATE_DIR' else native) for name in old['fixtures']};bindings.update(TIMELEARNER_DOMAIN_EVIDENCE_DIR=base/'readbacks/s07-analysis-dispatch-normal-a1/native-result/native',TIMELEARNER_MODELSPEC2_FRESH_OWNER_REPLAY=out/'fresh-owner-replay',TIMELEARNER_MODELSPEC2_OWNER_SOURCE=native)
declarations={}
for name,folder in bindings.items():
 pattern='**/*.json' if name=='TIMELEARNER_MODELSPEC2_FRESH_OWNER_REPLAY' else '*.json';count,digest=fixture_fingerprint(folder,pattern);declarations[name]={'pattern':pattern,'files':count,'fingerprint':digest}
spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'joint304-real-owner8-readers128','package_fingerprint':package_fingerprint(),'modules':old['modules'],'expected_test_ids':old['expected_test_ids'],'fixtures':declarations};(out/'reader-suite.json').write_text(json.dumps(spec,indent=2)+'\n');(out/'fixture-bindings.json').write_text(json.dumps({n:str(p) for n,p in bindings.items()},indent=2)+'\n')
"""
 with (out/'prepare-readers.log').open('xb') as log:subprocess.run(['python3','-c',prepare],cwd=reader_source,stdout=log,stderr=subprocess.STDOUT,check=True,env=env)
 bindings=json.loads((out/'fixture-bindings.json').read_text());args=['python3','-m','Scripts.StructTrain.TimeLearner.validation',str(out/'reader-suite.json'),'--output',str(out/'structured-readers')]
 for name,path in bindings.items():args+=['--fixture',name+'='+path]
 with (out/'reader-cli.log').open('xb') as log:
  process=subprocess.Popen(args,cwd=reader_source,stdout=log,stderr=subprocess.STDOUT,env=env);write('owned-reader.json',{'pid':process.pid,'start_ticks':ticks(process.pid),'arguments':args});status=process.wait(timeout=1800)
 readers=json.loads((out/'structured-readers/result.json').read_text());assert status==0 and readers['executed_tests']==128 and readers['assertion_status']=='passed' and not any(readers[k] for k in ['failures','errors','skipped'])
 write('reader-source-hashes.json',{q.relative_to(reader_source).as_posix():sha(q) for q in sorted((reader_source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))});assert not errors,errors
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'execution':'completed','native_owner8_and_readers128_passed':passed,'additional_readers_pending':False,'asan_joint_native_pending':True,'whole_plan_complete':False,'scientific_verdict':None})
  hashes={}
  for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
   for p in (source/prefix).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=sha(p)
  write('source-hashes.json',hashes)
  files={}
  for p in sorted(out.rglob('*')):
   if not p.is_file():continue
   assert p.resolve().is_relative_to(out.resolve()),str(p)
   files[p.relative_to(out).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,record in files.items():
    p=out/name;assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'];info=tarfile.TarInfo(name);info.size=record['bytes']
    with p.open('rb') as f:archive.addfile(info,f)
  write('bundle.json',{'kind':'joint_model_spec2_native_owner_replay_and_readers','schema_version':1,'root':root,'reader_root':reader_root,'pulselib':children.get('Libraries/Nmsdk-PulseLib') if 'children' in globals() else None,'acceptance_status':'owner8_and_readers128_passed' if passed else 'not_accepted','members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
