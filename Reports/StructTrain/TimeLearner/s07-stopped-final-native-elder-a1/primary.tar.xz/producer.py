from pathlib import Path
import os,sys,json,hashlib,subprocess,sqlite3,shutil,threading,traceback,tarfile,re,time
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-stopped-final-native-elder-a1';out.mkdir(exist_ok=False)
source=base/'source-integrated-acceptance-normal-a1';build=base/'build-integrated-acceptance-normal-a1';runtime=base/'runtime-integrated-acceptance-normal-a1';tool=base/'source-stopped-final-diagnostics-a1'
root='2e0618110a9abb48b94f6edc6b63c51f829ec810';tool_root='ff409ba3a5107ca9a3931657ecb65e69aa2199ef';stop=threading.Event();thread=None;registry=None;token=None;errors=[];native_passed=False;readers_passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(p,*a):return subprocess.check_output(['git','-C',str(p),*a],text=True).strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'native_root':root,'reader_root':tool_root});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 disk=shutil.disk_usage(base).free;memory=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert disk>=1024**3+256*1024**2 and memory>=6*1024**3
 write('resource-preflight.json',{'disk_free_bytes':disk,'memory_available_bytes':memory,'minimum_disk_headroom_bytes':1024**3,'declared_output_budget_bytes':256*1024**2,'output_budget_basis':'Four fixed length1, two-input,32 native probes total; JSON/CSV/model files expected well below256MiB. Accounting budget, not filesystem quota.','memory_cap_bytes':6*1024**3,'wall_seconds':1800,'compilation_disabled':True})
 os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True;sys.path.insert(0,str(tool));os.chdir(tool)
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 c=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True)
 try:metadata=dict(c.execute('SELECT key,value FROM metadata'))
 finally:c.close()
 capacity=json.loads(metadata['capacity']) if metadata['schema_version']=='2' else None
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 demands={'slots':1,'memory_bytes':6*1024**3,'disk_bytes':256*1024**2} if capacity else None
 lease=registry.reserve(out.name,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,build,runtime,tool]],ttl_seconds=120,demands=demands);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert git(source,'rev-parse','HEAD')==root and not git(source,'status','--porcelain','--untracked-files=no')
 assert git(tool,'rev-parse','HEAD')==tool_root and not git(tool,'status','--porcelain','--untracked-files=no')
 assert git(source/'Libraries/Nmsdk-PulseLib','rev-parse','HEAD')=='12d8c8a41c998ae1516496f716a0ae0f3d312b3e'
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']=''
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 previous=json.loads((base/'readbacks/s06-integrated-acceptance-normal-a1/native-runtime.json').read_text())
 for field in ['executable','app_ini','source_closure','build_flags']:assert manifest[field]==previous[field],field
 assert manifest['executable']['sha256']=='bcc51673ce59f1605567e7d8c998e6785ab978e0ff33c82aa116af39f52c9291'
 write('runtime.json',manifest);write('runtime-comparison.json',{'same_binary_app_ini_source_closure_build_flags':True,'fresh_manifest_matches_previous_fingerprint':manifest['runtime_fingerprint']==previous['runtime_fingerprint'],'previous_fingerprint':previous['runtime_fingerprint'],'fresh_fingerprint':manifest['runtime_fingerprint'],'previous_manifest_not_modified':True})
 spec=json.loads((tool/'Scripts/StructTrain/TimeLearner/specs/native-stopped-final-pass-v1.json').read_text());assert len(spec['expected_test_ids'])==4
 spec.update(source_root=str(source),runtime_manifest=str(out/'runtime.json'));write('native-specification.json',spec)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed' and result['inventory']['expected']==result['inventory']['observed']==4
 native_passed=True;native=out/'native-result/native';descriptors=[]
 for topology in ['Classic','Branch']:
  for mode in [0,1]:
   prefix=f'{topology}_2000_N{mode}_sweep_budget_boundary';package=native/(prefix+'_stopped_package.json');summary=native/(prefix+'_sweep_budget_summary.json');p=json.loads(package.read_text());assert p['training_outcome']=='budget_exhausted' and p['reason']=='maximum_sweeps_exhausted' and p['certificate'] is None
   trials=[]
   for i in range(1,len(p['observed_packets'])+1):
    packet=native/(prefix+f'_training_proof_{i}.json');trace=packet.with_suffix('.csv');assert packet.is_file() and trace.is_file()
    trials.append({'packet':packet.relative_to(out/'native-result').as_posix(),'trace':trace.relative_to(out/'native-result').as_posix()})
   description={'kind':'timelearner_stopped_final_pass_inputs','schema_version':1,'package':package.relative_to(out/'native-result').as_posix(),'summary':summary.relative_to(out/'native-result').as_posix(),'trials':trials}
   name=topology+f'-N{mode}.inputs.json';write('native-result/'+name,description);descriptors.append(name)
 write('reader-inputs.json',{'descriptors':descriptors,'scope':'four actual two-input native fixtures with LTMembrane; negative final verification, not scientific eight-pattern classification'})
 (out/'tmp').mkdir();env=dict(os.environ,TIMELEARNER_STOPPED_FINAL_PRIMARY=str(out/'native-result'),TMPDIR=str(out/'tmp'))
 tests=subprocess.run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_stopped_final_pass','-v'],cwd=tool,env=env,capture_output=True,timeout=300)
 (out/'checks-stdout.log').write_bytes(tests.stdout);(out/'checks-stderr.log').write_bytes(tests.stderr)
 count_match=re.search(rb'Ran (\d+) tests',tests.stderr);count_value=int(count_match.group(1)) if count_match else None
 write('checks.json',{'returncode':tests.returncode,'tests':count_value,'expected':10,'skips_allowed':False})
 assert tests.returncode==0 and count_value==10 and tests.stderr.rstrip().endswith(b'OK'),tests.stderr.decode()
 for name in descriptors:
  result_path=out/('diagnostics/'+name.replace('.inputs.json','.json'));result_path.parent.mkdir(exist_ok=True)
  p=subprocess.run([sys.executable,'-m','Scripts.StructTrain.TimeLearner','analyze',str(out/'native-result'/name),'--format','stopped-final-pass','--output',str(result_path)],cwd=tool,env=env,capture_output=True,timeout=120)
  assert p.returncode==0,p.stderr.decode();v=json.loads(result_path.read_text());assert v['complete_measured_final_pass'] and not v['certificate_present'] and not v['training_completed'] and v['evaluation_verdict'] is None
 readers_passed=True
 registry.validate_paths(token);assert not errors
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'native4_passed':native_passed,'readers10_and_cli4_passed':readers_passed,'whole_plan_complete':False,'scientific_verdict':None})
  write('reader-source-hashes.json',{p.relative_to(tool).as_posix():sha(p) for p in (tool/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={}
  for p in sorted(out.rglob('*')):
   if p.is_file():assert p.resolve().is_relative_to(out.resolve());files[p.relative_to(out).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
  assert sum(v['bytes'] for v in files.values())<=256*1024**2
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,record in files.items():
    p=out/name;assert sha(p)==record['sha256'];info=tarfile.TarInfo(name);info.size=record['bytes']
    with p.open('rb') as stream:archive.addfile(info,stream)
  write('bundle.json',{'kind':'timelearner_stopped_final_native_reader_gate','native_root':root,'reader_root':tool_root,'native4_passed':native_passed,'readers_passed':readers_passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
 except BaseException as error:write('archive-exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
 stop.set()
 if thread:thread.join(timeout=30)
 print('CLOSED',native_passed,readers_passed,flush=True)
