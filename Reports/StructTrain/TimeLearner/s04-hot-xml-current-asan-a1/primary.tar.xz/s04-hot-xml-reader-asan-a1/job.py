import pathlib,time,subprocess,json,os,sys,hashlib,traceback,xml.etree.ElementTree as ET
b=pathlib.Path('/media/user/Data/TimeLearnerRefactor');code=b/'source-hot-xml-report-a1'
data=b/'readbacks/s04-hot-xml-baseline-asan-a1';out=b/'readbacks/s04-hot-xml-reader-asan-a1'
def write(name,obj):(out/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
try:
 manifest=json.loads((code/'code-manifest.json').read_text());assert manifest['git_root']=='59a8e1491b925510299e3c04bed360e000e082d8' and len(manifest['records'])==200
 def verify_code():
  for r in manifest['records']:
   raw=(code/r['path']).read_bytes();assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],r['path']
 verify_code()
 start=time.monotonic()
 while True:
  p=pathlib.Path('/proc/834822/stat')
  if not p.exists() or p.read_text().rsplit(') ',1)[1].split()[19]!='262176902':break
  assert time.monotonic()-start<5400,'native_wait_timeout'
  time.sleep(5)
 assert not (data/'exception.json').exists()
 native=json.loads((data/'validation.json').read_text())
 assert native['execution']['execution']=='completed' and native['execution']['returncode']==0
 assert native['gtest']['tests']=='32' and native['gtest']['failures']==native['gtest']['errors']=='0'
 assert not ET.parse(data/'gtest.xml').findall('.//testcase/skipped')
 runs=[]
 for label,module,key,path,count in [
  ('xml','Scripts.StructTrain.TimeLearner.tests.test_hot_xml_reports','TL_HOT_XML_SOURCE',data,18),
  ('warm','Scripts.StructTrain.TimeLearner.tests.test_hot_readout_reports','TL_HOT_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-asan-a1',16),
  ('loaded','Scripts.StructTrain.TimeLearner.tests.test_loaded_readout_reports','TL_LOADED_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-asan-a1/loaded',16)]:
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_HOT_EXPECT_STALE='0');env[key]=str(path)
  with (out/(label+'.log')).open('wb') as f:r=subprocess.run(['python3','-m','unittest','-v',module],cwd=code,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(out/(label+'.log')).read_text();assert r.returncode==0 and ('Ran '+str(count)+' tests') in log,(label,log)
  runs.append({'label':label,'tests':count,'returncode':r.returncode})
 sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.hot_xml_reports import audit_run
 rows,audit=audit_run(data);write('full-audit.json',audit)
 normal=b/'restored-hot-xml-current-normal-a1';nm=json.loads((normal/'manifest.json').read_text());records={x['path']:x for x in nm['records']}
 comparisons=[]
 for case in sorted(rows):
  for name in ('warm.csv','replay.csv'):
   rel='s04-hot-xml-baseline-normal-a4/artifacts/'+case+'/'+name
   raw=(normal/rel).read_bytes();h=hashlib.sha256(raw).hexdigest()
   assert h==records[rel]['sha256']
   other=hashlib.sha256((data/'artifacts'/case/name).read_bytes()).hexdigest()
   comparisons.append({'case':case,'file':name,'normal_sha256':h,'asan_sha256':other,'byte_equal':h==other})
 write('crossworker.json',comparisons)
 verify_code()
 result={'kind':'native_hot_xml_asan_data_verification','schema_version':1,'native_source':native['source'],'reader_code_root':manifest['git_root'],'code_files_verified':200,'runs':runs,'cases':len(rows),'case_soma_pairs':audit['case_soma_pairs'],'all64_csv_byte_equal':len(comparisons)==64 and all(x['byte_equal'] for x in comparisons),'scientific_verdict':None}
 write('validation.json',result);assert result['cases']==32 and result['case_soma_pairs']==68 and result['all64_csv_byte_equal'];print(json.dumps(result),flush=True)
except BaseException as e:
 write('exception.json',{'error':str(e),'traceback':traceback.format_exc()});raise
