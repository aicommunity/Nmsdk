from pathlib import Path
import subprocess,os,json,hashlib,sys,shutil,traceback,xml.etree.ElementTree as ET
base=Path("/media/user/Data/TimeLearnerRefactor");out=Path(__file__).resolve().parent
trial=base/'readbacks/s04-native-wall-gate-asan-a3'
source=base/'source-native-wall-report-asan-a2';corpus=out/'corpus'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def run(args,name):
 with (out/name).open('xb') as log:r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,timeout=3600)
 assert r.returncode==0,(name,r.returncode)
try:
 stat=Path('/proc/1428898/stat');assert not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19]!="266420077"
 assert json.loads((trial/'terminal.json').read_text())['native_wall_schedule_tests']==66
 assert not source.exists()
 run(['git','clone','--shared','--no-checkout',base/"source-native-wall-asan-a1",source],'clone.log')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','e7782709157b84b5f8b1cec62711ff0ae4ecf1a2'],'fetch.log')
 run(['git','-C',source,'sparse-checkout','set','Scripts'],'sparse.log')
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach','e7782709157b84b5f8b1cec62711ff0ae4ecf1a2'],'checkout.log')
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='e7782709157b84b5f8b1cec62711ff0ae4ecf1a2'
 shutil.copytree(trial/'native',corpus/'native');shutil.copyfile(trial/'gtest.xml',corpus/'native.xml')
 def hashes(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
 initial=hashes(corpus);actual=hashes(trial/'native')
 assert {k.removeprefix('native/'):v for k,v in initial.items() if k.startswith('native/')}==actual
 assert initial['native.xml']==hashlib.sha256((trial/'gtest.xml').read_bytes()).hexdigest()
 write('corpus-sources.json',{'source_root':'e7782709157b84b5f8b1cec62711ff0ae4ecf1a2','numeric_root':'f35f614d2d07c1cc0cdf9786bcadd31d9237ed06','corpus_hashes':initial})
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_WALL_SCHEDULE_REPORT_DIR']=str(corpus)
 run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_wall_schedule_reports','-v'],'reader-tests.log')
 from Scripts.StructTrain.TimeLearner.wall_schedule_reports import inventory_wall_schedule,render_reset_diagnostics,SPEC
 from Scripts.StructTrain.TimeLearner.native_test_reports import render_native_test_run
 inventory=inventory_wall_schedule(corpus);write('inventory.json',inventory)
 if False:
  cache=base/'report-cache/s04-native-wall-asan-a1';cache.mkdir(exist_ok=False)
  plots=render_native_test_run(SPEC,corpus,cache/'probes')
  reset=render_reset_diagnostics(corpus,cache/'reset')
  write('render.json',{'cache':str(cache),'probe_report':plots,'reset_report':reset})
 assert hashes(corpus)==initial
 write('terminal.json',{'execution':'completed','reader_tests':10,'native_tests':66,'probe_packets':46,'reset_diagnostics':4,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
