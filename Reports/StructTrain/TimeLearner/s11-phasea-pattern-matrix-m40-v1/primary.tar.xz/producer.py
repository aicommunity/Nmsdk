HOST='m40'
BASE='/media/user/Data/TimeLearnerRefactor'
DONOR='source-legacy-completed-replay-asan-a1'
BIN_DONOR='source-configured-probe-ownership-asan-h14'
from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,traceback
ROOT='d3ef795caaea9877ef3e1d8fdbfe0595b5bd751a'
base=Path(BASE);name='phasea-pattern-matrix-'+HOST+'-v1'
repo=base/('git-'+name);source=base/('code-'+name);binrepo=base/('bin-'+name)
out=base/'readbacks'/('s11-'+name);out.mkdir(parents=True,exist_ok=False)
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 for path,donor in [(repo,base/DONOR),(binrepo,base/BIN_DONOR/'Bin')]:
  assert not path.exists();subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(path)],check=True,capture_output=True)
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],check=True,capture_output=True)
 current=subprocess.check_output(['git','-C',str(repo),'rev-parse',ROOT+':Bin'],text=True).strip()
 subprocess.run(['git','-C',str(binrepo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk-Bin.git',current],check=True,capture_output=True)
 subprocess.run(['git','-C',str(binrepo),'merge-base','--is-ancestor','1c1464e248f8744e858bd66df0be99e39969fd65',current],check=True)
 source.mkdir(exist_ok=False)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',str(repo),'archive',ROOT,'Scripts/StructTrain/TimeLearner']))) as archive:archive.extractall(source)
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.__main__ import main
 from Scripts.StructTrain.TimeLearner.phasea_matrix import REVISION,PARAMETERS,OBSERVATIONS
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 fixture=out/'fixture';fixture.mkdir()
 write('fixture/binding.json',{'bin_repository':str(binrepo),'revision':REVISION,'current_bin_gitlink':current,'ancestor_verified':True})
 for path,name in [(PARAMETERS,'source-parameters.xml'),(OBSERVATIONS,'source-observations.csv')]:
  (fixture/name).write_bytes(subprocess.check_output(['git','-C',str(binrepo),'show',REVISION+':'+path]))
 assert main(['phasea-matrix','--bin-repository',str(binrepo),'--output',str(fixture/'matrix.json')])==0
 count,fingerprint=fixture_fingerprint(fixture,'*.*')
 name='Scripts.StructTrain.TimeLearner.tests.test_phasea_matrix.PhaseAMatrixTest'
 methods=['test_actual_git_matrix_retains_onset_all_labels_and_source_blobs','test_csv_row_order_does_not_select_the_target_or_change_pattern_identity','test_corrupted_missing_duplicate_or_disagreeing_input_data_is_rejected','test_rotations_bind_the_learned_target_and_do_not_share_mutable_patterns','test_production_cli_reads_exact_git_data_and_refuses_overwrite_or_symbolic_revision']
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'phasea-pattern-matrix5','package_fingerprint':package_fingerprint(),'modules':[name],'expected_test_ids':[name+'.'+n for n in methods],'fixtures':{'TIMELEARNER_PHASEA_MATRIX_SOURCE':{'pattern':'*.*','files':count,'fingerprint':fingerprint}}}
 result=run_suite(spec,{'TIMELEARNER_PHASEA_MATRIX_SOURCE':str(fixture)},out/'reader-result')
 assert result['executed_tests']==5 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 passed=True;write('terminal.json',{'reader_tests':5,'model_executions':0,'historical_presentation_reproduced':False,'scientific_verdict':None})
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'phasea_pattern_matrix_readback','schema_version':1,'root':ROOT,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),
       'native_rerun':False,'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 pg('config','user.name','TimeLearner Evidence');pg('config','user.email','timelearner@localhost')
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s11-phasea-pattern-matrix-m40-v1'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: exact historical Phase A XML CSV patterns and native design reader5\n')
 branch='refs/heads/codex/evidence-s11-phasea-pattern-matrix-m40-v1'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
