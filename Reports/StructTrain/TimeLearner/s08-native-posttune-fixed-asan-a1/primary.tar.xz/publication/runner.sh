set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-publish-asan-a1"
gate="$base/readbacks/s08-native-posttune-fixed-asan-a1"
repo="$base/source-posttune-observation-report-normal-a1"
src="$base/source-native-posttune-fixed-evidence-asan-a1"
branch=codex/timelearner-native-posttune-fixed-evidence-asan-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$gate/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b7cab7348aea1fc29038b991d5298693d10ed87e > "$out/checkout.log" 2>&1
git -C "$repo" -c submodule.recurse=false worktree add --no-checkout -b "$branch" "$src" b7cab7348aea1fc29038b991d5298693d10ed87e >> "$out/checkout.log" 2>&1
git -C "$src" sparse-checkout init --cone
git -C "$src" sparse-checkout set Scripts
git -C "$src" -c submodule.recurse=false checkout "$branch" >> "$out/checkout.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_ARCHIVE_RUN_SOURCE="$gate/runs"
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$gate/native" TIMELEARNER_FIXED_POSTTUNE_SOURCE="$gate/baseline-source"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_packaged_run_closure Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence -v > "$out/latest-reader.log" 2>&1
GATE="$gate" OUT="$out" python3 -u - <<'PY' > "$out/package.log" 2>&1
import hashlib,io,json,os,tarfile,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.artifact_bundle import verify_packaged_run_closure
from Scripts.StructTrain.TimeLearner.publisher import stage_artifact_set
g=Path(os.environ['GATE']);out=Path(os.environ['OUT'])
x=ET.parse(g/'native.xml').getroot();assert int(x.attrib['tests'])==12 and not x.findall('.//skipped')
assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled'])
v=json.loads((g/'validation.json').read_bytes());assert v['actual_owned_console_ab_jobs']==2
assert all(r['exact_transaction_and_model_bytes'] for r in v['rows'])
for p,n in [(g/'reader.log',5),(out/'latest-reader.log',9)]:
 text=p.read_text();assert 'Ran '+str(n)+' tests' in text and text.rstrip().endswith('OK')
files={}
for directory,dirs,names in os.walk(g):
 if Path(directory)==g:dirs[:]=[name for name in dirs if name!='baseline-source']
 for name in names:
  p=Path(directory)/name;assert not p.is_symlink();files['native-fixed-asan/'+p.relative_to(g).as_posix()]=p.read_bytes()
for name in ['latest-reader.log','checkout.log','runner.sh']:files['publication/'+name]=(out/name).read_bytes()
proof=verify_packaged_run_closure(files);assert proof['run_snapshots_verified']==2
d=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-fixed-asan-a1');d.mkdir(parents=True,exist_ok=False)
with tarfile.open(d/'primary.tar.xz','w:xz',preset=6) as tar:
 for name,raw in sorted(files.items()):
  p=tarfile.TarInfo(name);p.size=len(raw);p.mode=0o644;p.mtime=0;tar.addfile(p,io.BytesIO(raw))
encode=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
(d/'manifest.json').write_bytes(encode({'kind':'native_fixed_posttune_asan_proof','schema_version':1,
 'native_source_root':'38cd68a022814782eff667bedd60bdfe9a6950bc','native_source_pulse':'03d1ea86a0a9f0d7b861adb62bf7798a9c1a1c59',
 'latest_reader_root':'b7cab7348aea1fc29038b991d5298693d10ed87e','native_cases':12,'native_seconds':float(x.attrib['time']),
 'codec_cases':4,'fixed_cases':8,'original_reader_checks':5,'latest_reader_checks':9,'legacy_console_ab_jobs':2,
 'exact_legacy_transaction_and_model_bytes':True,'leak_detection_enabled':False,'packaged_run_closure':proof,
 'archive_sha256':hashlib.sha256((d/'primary.tar.xz').read_bytes()).hexdigest(),
 'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(files.items())],
 'production_fixed_job_implemented':False,'learner_dispatch_implemented':False,'full_visual_acceptance':False,'full_stage_8_accepted':False,'scientific_verdict':None}))
(d/'README.md').write_bytes(('# Native fixed-threshold PostTune: ASan\n\n'
 'Twelve real native cases passed without skips: four codecs and eight Classic/Branch fixed weight-selection, roundtrip, later calibration, budget/cancel/Reset controls. '
 'Two owned legacy Console jobs retained byte-identical transactions and models relative to original ASan bundle 88c47ddf. '
 'Five original evidence checks and nine latest checks (four archive-closure plus five fixed-evidence checks) passed. '
 'Leak detection was disabled. The source runtime was isolated and unchanged during execution.\n\n'
 'All input/source primaries of the two portable runs are included and checked against their internal run manifests. '
 'Only the top-level duplicate baseline-source extraction is omitted; its reconstruction recipe and original Git source are retained. '
 'A silent target remains FN: weights_selected is not Calibrated, recognition PASS or training Exact. '
 'Production schema-2 jobs, learner-property dispatch, full mode/physics matrix and complete visual acceptance remain open.\n').encode())
m=d/'SHA256SUMS.json';m.write_bytes(encode({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}))
print(stage_artifact_set(Path.cwd(),m.as_posix(),hashlib.sha256(m.read_bytes()).hexdigest()))
print(json.dumps({'members':len(files),'archive_bytes':(d/'primary.tar.xz').stat().st_size,'native_seconds':float(x.attrib['time'])}))
PY
git diff --cached --check
git commit -m 'Preserve complete fixed-threshold PostTune ASan and run closure proof' > "$out/commit.log"
git -c push.recurseSubmodules=no push git@github.com:aicommunity/Nmsdk.git "HEAD:refs/heads/$branch" > "$out/push.log" 2>&1
test "$(git ls-remote git@github.com:aicommunity/Nmsdk.git "refs/heads/$branch" | cut -f1)" = "$(git rev-parse HEAD)"
git rev-parse HEAD > "$out/commit.txt"

