set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-fixed-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-live-finalization-cancel-codec-asan-a1/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s08-native-live-finalization-cancel-codec-reader-asan-a1/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 200000000
test "$(cat "$base/readbacks/s07-n0-candidate-order-baseline-asan-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain)"
export BASE="$base" SRC="$src" BUILD="$build" OUT="$out" RUNTIME="$runtime" PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY' > "$out/live-source-check.json"
from pathlib import Path
import json,os
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c gc.auto=0 -c fetch.recurseSubmodules=false fetch origin 942e5df4559467a9a19c56755f945ce6501e7780 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src";export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1;unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native-evidence"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
r=execute(runtime,['--gtest_filter=BoundedTraining*.*:NativeModelEditor.*N0*:NativeTrainingService.*N0*:NativeColdTrainingService.*N0*','--gtest_output=xml:'+str(out/'native.xml')],Path(runtime['executable']['path']).parent,out/'process',300)
t=ET.parse(out/'native.xml').getroot()
v={'kind':'n0_candidate_order_fixed','process':r,'tests':int(t.attrib['tests']),'failures':int(t.attrib.get('failures',0)),'expected_failure':False}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
assert r['returncode']==0 and r['runtime_provenance']=='loaded_files_captured'
assert v['tests']>=25 and v['failures']==0 and not t.findall('.//skipped')
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
