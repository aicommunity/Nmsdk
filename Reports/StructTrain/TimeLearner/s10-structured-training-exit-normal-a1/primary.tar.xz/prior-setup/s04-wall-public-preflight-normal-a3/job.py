from pathlib import Path
import sys,json,os,time,subprocess,hashlib,copy,traceback
base=Path("/home/user/timelearner-refactor");out=Path(__file__).resolve().parent;source=base/"source-n1-measured-refinement-normal-a1"
native=base/'readbacks/s04-native-wall-integrated-normal-a1'
template=base/'readbacks/s09-native-preflight-normal-a4/corpus';corpus=out/'corpus'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
try:
 prior=base/'readbacks/s04-wall-public-preflight-normal-a1'
 write('prior-setup.json',{'cancelled':json.loads((prior/'cancelled-before-execution.json').read_text()),'prior_job':(prior/'job.py').read_text()})
 start=time.monotonic()
 while True:
  stat=Path('/proc/3563214/stat')
  if not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19]!="317256308":break
  assert time.monotonic()-start<14400,'integrated_native_job_still_owned'
  time.sleep(2)
 assert json.loads((native/'terminal.json').read_text())['integrated_native_tests']==74
 prior2=base/'readbacks/s04-wall-public-preflight-normal-a2'
 wait2=time.monotonic()
 while True:
  s=Path('/proc/3574411/stat')
  if not s.exists() or s.read_text().rsplit(')',1)[1].split()[19]!="317326349":break
  assert time.monotonic()-wait2<300,'previous_preflight_still_owned'
  time.sleep(1)
 assert json.loads((prior2/'corpus/runs/pipeline-Classic-N0/process/result.json').read_text())['reason']=='loader_environment_changed:QT_QPA_PLATFORM'
 write('prior-loader-setup.json',{'exception':json.loads((prior2/'exception.json').read_text()),'job':(prior2/'job.py').read_text(),'actual_process_result':json.loads((prior2/'corpus/runs/pipeline-Classic-N0/process/result.json').read_text()),'console_started':False})

 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 before=source_closure(source);write('source.json',before)
 assert before==json.loads((native/'source.json').read_text())
 runtime=base/'runtime-s04-native-wall-integrated-normal-a1'
 build=base/"build-n1-measured-refinement-normal-a1"
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 manifest=snapshot(source,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 corpus.mkdir();old=json.loads((template/'corpus.json').read_text());positive=old['positive']
 assert len(positive)==14
 hashes={};results={}
 for name in positive:
  path=template/'runs'/name/'input/job.json';raw=path.read_bytes();hashes[name]=hashlib.sha256(raw).hexdigest()
  job=out/'jobs'/(name+'.json');job.parent.mkdir(exist_ok=True);job.write_bytes(raw)
  result=run_job('preflight',job,None,out/'runtime.json',corpus/'runs'/name,180)
  assert result['execution']=='completed' and result['validity']=='valid',result
  results[name]=audit_run_manifest(corpus/'runs'/name/'run-manifest.json')
 negative={}
 for name,record in old['negative'].items():
  if record['stage']=='native':
   path=template/'runs'/name/'input/job.json';raw=path.read_bytes();hashes[name]=hashlib.sha256(raw).hexdigest()
   job=out/'jobs'/(name+'.json');job.write_bytes(raw)
   result=run_job('preflight',job,None,out/'runtime.json',corpus/'runs'/name,180)
   assert result['execution']=='process_error' and result['validity']=='unverified_execution',result
   audit_run_manifest(corpus/'runs'/name/'run-manifest.json')
   assert not (corpus/'runs'/name/'native/execution.json').exists()
   negative[name]={'stage':'native','reason':'native_configuration_rejected','scientific_verdict':None}
  else:
   value=json.loads((out/'jobs/pipeline-Classic-N1.json').read_text())
   if name=='invalid-unsupported-ctrim':value['optional_modes']['sync_capacitance_trim']=1
   elif name=='invalid-wrong-owner':value['owner_class']='WrongOwner'
   else:raise AssertionError(name)
   value=_signed({k:v for k,v in value.items() if k!='sha256'});job=out/'jobs'/(name+'.json');job.write_text(json.dumps(value)+'\n')
   try:run_job('preflight',job,None,out/'runtime.json',corpus/'runs'/name,180)
   except EvidenceError as error:
    assert record['reason'] in str(error),(name,str(error))
    assert not (corpus/'runs'/name).exists()
    negative[name]={'stage':'descriptor','reason':str(error),'scientific_verdict':None}
   else:raise AssertionError('descriptor accepted:'+name)
 controls={}
 for topology in ['Classic','Branch']:
  name='live-'+topology+'-legacy-budget';job=out/'jobs'/(name+'.json')
  result=run_job('train',job,None,out/'runtime.json',corpus/'runs'/('train-'+topology+'-legacy-budget'),180)
  assert result['execution']=='process_error' and result['analysis'] is not None,result
  audit_run_manifest(corpus/'runs'/('train-'+topology+'-legacy-budget')/'run-manifest.json')
  controls[topology]={'scientific_verdict':None}
 write('template-hashes.json',hashes)
 write('corpus/corpus.json',{'kind':old['kind'],'schema_version':1,'cooperative_capture':True,'positive':positive,'negative':negative,'train_controls':controls,'sources':{'numeric_root':'507c8a6c4da2b795d4dca3caf7b43806c8bf6835','template_corpus':str(template)},'scientific_verdict':None})
 os.environ['TIMELEARNER_NATIVE_PREFLIGHT_DIR']=str(corpus)
 with (out/'reader-tests.log').open('xb') as log:
  test=subprocess.run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_native_preflight','Scripts.StructTrain.TimeLearner.tests.test_prepare_native_matrix','-v'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert test.returncode==0,'reader_checks_failed'
 assert source_closure(source)==before;verify_runtime(manifest)
 write('validation.json',{'positive':results,'negative':negative,'training_controls':controls,'wall_policy_scope':'default negative limits only; no public positive override capability attested','scientific_verdict':None})
 write('terminal.json',{'execution':'completed','positive_preflights':14,'negative_preflights':6,'one_tick_controls':2,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
