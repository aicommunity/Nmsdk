from pathlib import Path
import sys,os,json,time,threading,hashlib,unittest,traceback,tarfile,io
base=Path('/media/user/Data/TimeLearnerRefactor')
source=base/'source-clock-alignment-a1-delivery'
framework=base/'source-worker-dependency-normal-a2'
study=base/'readbacks/s07-high-threshold-single-normal-a1'
out=base/'readbacks/s07-clock-alignment-normal-a1'
out.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path.insert(0,str(framework))
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'resource-reservations.sqlite3')
stop_event=threading.Event();errors=[];token=None;thread=None

def write(name,value):
 (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
try:
 reservation=registry.reserve('s07-clock-alignment-normal-a1',[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,framework,study,base/'readbacks/s07-single-pulse-console-normal-a1',base/'readbacks/s07-stock-fair-domains-normal-a2/study']],ttl_seconds=120)
 token=reservation['token'];write('reservation.json',reservation)
 def beat():
  while not stop_event.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=beat,daemon=True);thread.start()
 import subprocess
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 prior=inspect_worker_dependency(Path(str(study)+'-container'),registry,study.name)
 assert prior['state']=='ready' and prior['reservation_state']=='released',prior
 low=base/'readbacks/s07-single-pulse-console-normal-a1'
 write('source-primary-binding.json',{'high_directory':str(study),'low_directory':str(low),'native_reexecuted':False,'source_threshold_changed':False})
 bindings={}
 for corpus in [study,low]:
  design=json.loads((corpus/'single-pulse-study/single-pulse-design.json').read_text())
  for row in design['rows']:
   for key in ['original_packet','original_trace']:
    path=Path(row[key]);sha=hashlib.sha256(path.read_bytes()).hexdigest();assert sha==row[key+'_sha256'];bindings[str(path)]=sha
   for mode in ['burst','single']:
    native=corpus/'single-pulse-study/runs'/(row['name']+'-'+mode)/'native'
    if not native.exists():continue
    for name in ['probe_trial_1.json','probe_trial_1.csv']:
     path=native/name;bindings[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
 write('input-file-hashes.json',bindings)
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='5a6c731194ed0a60725983d992683873c9f6291c'
 write('owned-process.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]})
 write('source-hashes.json',{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts').rglob('*.py')})
 # The framework ledger instance remains bound; tests use the exact candidate tree.
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_HIGH_SINGLE_CORPUS']=str(study)
 os.environ['TIMELEARNER_LOW_SINGLE_CORPUS']=str(low)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in ['test_clock_alignment.RelativeClockAlignmentTest'])
 assert suite.countTestCases()==5
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests_run':result.testsRun,'successful':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
 assert result.wasSuccessful() and result.testsRun==5 and not result.skipped and not errors
 assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha for name,sha in bindings.items())
 write('terminal.json',{'clock_alignment_controls_passed':True,'native_compilation_verified':False,'waveform_equivalence_verified':False,'scientific_verdict':None})
except BaseException as e:
 write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
 write('terminal.json',{'clock_alignment_controls_passed':False,'native_compilation_verified':False,'scientific_verdict':None})
finally:
 stop_event.set()
 if thread:thread.join(timeout=30)
 payloads={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
 payloads['producer.py']=Path(__file__).read_bytes()
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w:xz') as archive:
  for name,raw in sorted(payloads.items()):
   entry=tarfile.TarInfo(name);entry.size=len(raw);archive.addfile(entry,io.BytesIO(raw))
 raw=buffer.getvalue();(out/'primary.tar.xz').write_bytes(raw)
 write('bundle.json',{'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payloads.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'root':'5a6c731194ed0a60725983d992683873c9f6291c'})
