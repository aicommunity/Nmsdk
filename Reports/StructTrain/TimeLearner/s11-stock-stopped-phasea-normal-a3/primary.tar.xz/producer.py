from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,traceback,time
ROOT='6342a56d68718d3231b11dc0f6af7c3bc045cd8d'
base=Path('/home/user/timelearner-refactor')
out=base/'readbacks/s11-stock-stopped-phasea-normal-a3';out.mkdir(exist_ok=False)
repo=base/'code-stock-stopped-phasea-normal-a3.git'
source=base/'code-stock-stopped-phasea-normal-a3';source.mkdir(exist_ok=False)
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False
try:
 previous_attempt=base/'readbacks/s11-stock-stopped-phasea-normal-a1'
 assert not live(json.loads((previous_attempt/'owned-supervisor.json').read_text())), 'prior attempt owner still live'
 write('prior-attempt.json',json.loads((previous_attempt/'exception.json').read_text()))
 attempt2=base/'readbacks/s11-stock-stopped-phasea-normal-a2'
 assert not live(json.loads((attempt2/'owned-supervisor.json').read_text()))
 write('prior-attempt-a2.json',json.loads((attempt2/'exception.json').read_text()))
 write('git-transfer.json',{'kind':'native_git_pack_transfer','commit':ROOT,'seed':'git-relay-stock-stopped-a3.git','pack_bytes':12383859,'pack_sha256':'def7ee10a3e7da58d646994947082bf33dc0bd907534d76592266289d77e87dc','connectivity_verified_before_launch':True})
 for label in ['s04-initial-threshold-normal-a5','s07-stock-threshold-pair-normal-a3']:
  previous=base/'readbacks'/label
  assert not live(json.loads((previous/'owned-supervisor.json').read_text())), 'prerequisite owner still live'
  assert not (previous/'exception.json').exists(), 'prerequisite failed'
  assert json.loads((previous/'publication.json').read_text())['acceptance_status']=='passed'
 subprocess.run(['git','clone','--shared','--bare',str(base/'git-relay-stock-stopped-a3.git'),str(repo)],check=True)
 subprocess.run(['git','-C',str(repo),'cat-file','-e',ROOT+'^{commit}'],check=True)
 raw=subprocess.check_output(['git','-C',str(repo),'archive',ROOT,'Scripts/StructTrain/TimeLearner'])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(source)
 binrepo=base/'bin-stock-stopped-phasea-normal-a3.git'
 subprocess.run(['git','clone','--shared','--bare',str(base/'source-initial-threshold-normal-a4/Bin'),str(binrepo)],check=True)
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 from Scripts.StructTrain.TimeLearner.stock_stopped_evaluation import run
 from Scripts.StructTrain.TimeLearner.phasea_matrix import from_git
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 prior=base/'readbacks/s07-stock-threshold-pair-normal-a3/study'
 runtime=json.loads((prior/'runtime.json').read_text());verify_runtime(runtime)
 executable=Path(runtime['executable']['path']).resolve()
 owners=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   if (proc/'exe').resolve()==executable:owners.append({'pid':int(proc.name),'start_ticks':ticks(int(proc.name))})
  except (FileNotFoundError,PermissionError):pass
 assert not owners, 'native runtime still owned by another executable process'
 write('runtime-readonly-lease.json',{'owner_pid':os.getpid(),'start_ticks':ticks(os.getpid()),'runtime':runtime,'other_native_owners':owners,'sdk_mutated':False})
 write('matrix.json',from_git(binrepo))
 suite='Scripts.StructTrain.TimeLearner.tests.test_stock_stopped_evaluation.'
 methods=['test_actual_complete_packages_and_all_eight_historical_patterns','test_training_threshold_and_no_lt_physics_are_not_replaced','test_mismatched_actual_source_and_false_certificate_rejected','test_retargeting_is_not_a_transient_evaluation_pattern','test_prepare_creates_all_jobs_and_bound_sources_before_native_execution']
 def readers(label,with_execution):
  fixtures={'TIMELEARNER_STOCK_THRESHOLD_STUDY':(prior,'**/*.*'),'TIMELEARNER_BIN_REPOSITORY':(binrepo,'HEAD')}
  modules=[suite+'StockStoppedJobTest'];ids=[modules[0]+'.'+m for m in methods]
  if with_execution:
   fixtures['TIMELEARNER_STOCK_STOPPED_EVALUATION']=(out/'evaluation','**/*.*')
   modules.append(suite+'StockStoppedExecutionTest');ids.append(modules[-1]+'.test_actual_public_diagnostic_execution_keeps_unfinished_role')
  declarations={}
  for k,(path,pattern) in fixtures.items():
   count,digest=fixture_fingerprint(path,pattern);declarations[k]={'pattern':pattern,'files':count,'fingerprint':digest}
  spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':label,'package_fingerprint':package_fingerprint(),'modules':modules,'expected_test_ids':ids,'fixtures':declarations}
  result=run_suite(spec,{k:str(v[0]) for k,v in fixtures.items()},out/label)
  assert result['assertion_status']=='passed' and result['executed_tests']==len(ids) and not any(result[k] for k in ['errors','failures','skipped']),result
  return result
 write('reader-preflight.json',readers('readers-before',False))
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 foreign=out/'foreign-cwd';foreign.mkdir()
 arguments=[sys.executable,'-m','Scripts.StructTrain.TimeLearner','stock-stopped-evaluation','run',str(prior),'--bin-repository',str(binrepo),'--output',str(out/'evaluation')]
 write('cli-request.json',{'arguments':arguments,'cwd':str(foreign),'PYTHONPATH':str(source)})
 with (out/'cli-stdout.log').open('xb') as so,(out/'cli-stderr.log').open('xb') as se:
  process=subprocess.run(arguments,cwd=foreign,env=dict(os.environ,PYTHONPATH=str(source)),stdout=so,stderr=se,timeout=7300)
 assert process.returncode==0,'public stock diagnostic CLI failed; inspect original stderr'
 write('analysis.json',json.loads((out/'evaluation/analysis.json').read_text()))
 write('reader-final.json',readers('readers-after',True))
 verify_runtime(runtime)
 passed=True;write('terminal.json',{'execution':'completed','diagnostic_models':4,'trials':32,'reader_preflight':5,'reader_final':6,'training_completed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 hashes={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*.py') if '__pycache__' not in p.parts}
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 write('bundle.json',{'kind':'stock_stopped_phasea_native_diagnostic','schema_version':1,'root':ROOT,'acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
