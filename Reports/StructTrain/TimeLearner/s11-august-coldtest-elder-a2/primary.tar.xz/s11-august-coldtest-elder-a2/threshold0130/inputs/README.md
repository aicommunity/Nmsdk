Конфиг для EXP01_Test_thr00130 (Test). Родитель: /home/user/Nmsdk/Bin/Configs/SpikeSamples/StructTrain/SelectivityPhaseA/EXP01_ltz_threshold_sweep/README.md
