set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-controller-latest-reader-asan-a3"
gate="$base/readbacks/s08-native-posttune-controller-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$gate/process-exit-status.txt")" = 0
cd "$base/source-native-posttune-controller-report-normal-a3"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_POSTTUNE_TRANSACTION_DIR="$gate/native"
export TIMELEARNER_POSTTUNE_CANDIDATES_DIR="$base/readbacks/s08-native-posttune-candidates-asan-a1/native"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_evidence Scripts.StructTrain.TimeLearner.tests.test_native_posttune_candidates -v > "$out/reader.log" 2>&1

