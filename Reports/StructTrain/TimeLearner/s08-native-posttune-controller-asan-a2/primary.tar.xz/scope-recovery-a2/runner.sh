set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-recognition-scope-ab-asan-a2";previous="$base/readbacks/s08-recognition-scope-ab-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
old="$base/runtime-s08-native-posttune-candidates-asan-a1"
runtime="$base/runtime-s08-recognition-scope-ab-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$previous/process-exit-status.txt"; do kill -0 3388917;sleep 10;done
test "$(cat "$previous/process-exit-status.txt")" = 1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$previous/baseline"
OUT="$out" PREVIOUS="$previous" python3 - <<'PY' > "$out/grid-recovery.log" 2>&1
import hashlib,json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['PREVIOUS']);v={'a1_gate_accepted':False,'reason':'missing ownership fixture path; recover only actual grid cases','phases':{}}
for name in ('baseline','native'):
 r=E.parse(p/(name+'.xml')).getroot();cases=list(r.iter('testcase'))
 assert len(cases)==10 and len(list(r.iter('skipped')))==8 and not list(r.iter('failure')) and not list(r.iter('error'))
 passed=[c.get('classname')+'/'+c.get('name') for c in cases if c.find('skipped') is None]
 assert set(passed)=={'NativeCalibrationTransaction/ClassicN1_2000','NativeCalibrationTransaction/BranchN1_2000'}
 v['phases'][name]={'actual_grid_cases':passed,'skipped_ownership_cases':8}
a={f.name:f for f in (p/'baseline').glob('*.csv')};b={f.name:f for f in (p/'native').glob('*.csv')}
assert a and set(a)==set(b);rows=[]
for n in sorted(a):
 x,y=a[n].read_bytes(),b[n].read_bytes();assert x==y,n
 rows.append({'path':n,'sha256':hashlib.sha256(x).hexdigest(),'bytes_exact':True})
out=Path(os.environ['OUT']);(out/'grid-recovery.json').write_text(json.dumps(v,indent=2)+'\n')
(out/'waveform-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
PY
for phase in baseline native; do
 mkdir "$out/$phase"
 RUNTIME_MANIFEST="$previous/$(test "$phase" = baseline && echo baseline-runtime.json || echo runtime-before.json)" python3 - <<'PY' > "$out/$phase-runtime.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
 binary="$runtime";test "$phase" != baseline || binary="$old"
 (cd "$binary" && TIMELEARNER_EXECUTION_OUTPUT="$out/$phase" ./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationOwnership.*' --gtest_output="xml:$out/$phase.xml") > "$out/$phase.log" 2>&1
 TIMELEARNER_CALIBRATION_OWNERSHIP_DIR="$out/$phase" python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_calibration_ownership_evidence -v > "$out/$phase-reader.log" 2>&1
done
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);v={'source_root':'efb25123c328ae98088ab3d361bb7e87d098dd4a','scientific_verdict':None}
for name in ('baseline','native'):
 r=E.parse(p/(name+'.xml')).getroot();q={'tests':len(list(r.iter('testcase'))),'failures':len(list(r.iter('failure'))),'errors':len(list(r.iter('error'))),'skips':len(list(r.iter('skipped')))}
 assert q=={'tests':8,'failures':0,'errors':0,'skips':0},q
 reader=(p/(name+'-reader.log')).read_text();assert 'Ran 4 tests' in reader and reader.endswith('OK\n')
 v[name]=q
a={f.name:json.loads(f.read_bytes()) for f in (p/'baseline').glob('*.json')};b={f.name:json.loads(f.read_bytes()) for f in (p/'native').glob('*.json')}
assert len(a)==8 and a==b
v['ownership_json_pairs_exact']=len(a);v['grid_csv_pairs_exact']=len(json.loads((p/'waveform-comparison.json').read_bytes()))
v['separate_actual_grid_cases_per_binary']=2;v['reader_checks_per_binary']=4
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
PY
