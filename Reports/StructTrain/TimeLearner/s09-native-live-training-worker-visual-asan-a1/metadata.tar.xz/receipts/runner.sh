set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s09-native-live-training-worker-visual-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-live-training-worker-visual-asan-a1"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import contextlib,hashlib,io,json,os,subprocess,tarfile,time,unittest
from Scripts.StructTrain.TimeLearner.__main__ import main as cli
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.artifact_bundle import verify_packaged_run_closure
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);start=time.monotonic()
commit='264c429974e9d97bb5d5277b1fc25c846fa80eda'
prefix='Reports/StructTrain/TimeLearner/s09-native-live-training-worker-asan-a1/'
manifest=json.loads(subprocess.check_output(['git','show',commit+':'+prefix+'manifest.json']))
archive=subprocess.check_output(['git','show',commit+':'+prefix+'primary.tar.xz'])
assert hashlib.sha256(archive).hexdigest()==manifest['archive_sha256']
assert sum(row['bytes'] for row in manifest['files'])<2*1024**3
data=out/'data';assert not data.exists();data.mkdir();expected={row['path']:row for row in manifest['files']};files={}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  row=expected.pop(member.name);raw=tar.extractfile(member).read()
  assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  p=data/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);files[member.name]=raw
assert not expected;closure=verify_packaged_run_closure(files);assert closure['run_snapshots_verified']==14
del files
corpus=data/'s09-native-live-training-worker-asan-a1/corpus';index=load(corpus/'index.json')
assert index['operations']==14 and len(index['records'])==14
def snapshot():return {p.relative_to(data).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.rglob('*')) if p.is_file()}
before=snapshot();cache=base/'cache/s09-native-live-training-worker-asan-a1';assert not cache.exists();cache.mkdir()
reports=[]
for row in index['records']:
 name=row['name'];source=corpus/'runs'/name/'run-manifest.json';target=cache/name
 with (out/(name+'-render-cli.log')).open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  code=cli(['report',str(source),'--format','pipeline-run','--output',str(target)])
 assert code==0,(name,code)
 result=load(target/'manifest.json')
 reports.append({'name':name,'source_manifest_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'result':result})
 print('RENDERED',name,'training_pairs',result['training_trial_soma_pairs'],'recognition_pairs',result['recognition_trial_soma_pairs'],flush=True)
(cache/'render-index.json').write_text(json.dumps({'kind':'native_live_pipeline_report_index','schema_version':1,'reports':reports,
 'source_proof_commit':commit,'renderer_root':'9554c0e465b5ce72a989c3d34edfd63dc0e5df2b','scientific_verdict':None},indent=2)+'\n')
os.environ['TIMELEARNER_LIVE_PIPELINE_CORPUS']=str(corpus);os.environ['TIMELEARNER_LIVE_PIPELINE_REPORTS']=str(cache)
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_pipeline_reports'))
assert r.wasSuccessful() and r.testsRun==3 and not r.skipped
assert snapshot()==before
v={'kind':'native_live_pipeline_temporal_gate','schema_version':1,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),
 'reports':reports,'operations_reported':len(reports),'seconds':time.monotonic()-start,'source_files_unchanged':len(before),'source_closure':closure,
 'cache':str(cache),'cache_files':sum(p.is_file() for p in cache.rglob('*')),'cache_bytes':sum(p.stat().st_size for p in cache.rglob('*') if p.is_file()),
 'training_trial_soma_pairs':sum(r['result']['training_trial_soma_pairs'] for r in reports),
 'recognition_trial_soma_pairs':sum(r['result']['recognition_trial_soma_pairs'] for r in reports),'new_numerical_runs':0,
 'selected_visual_review_complete':False,'full_cache_visual_review_complete':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v for k,v in v.items() if k!='reports'}),flush=True)
PY
