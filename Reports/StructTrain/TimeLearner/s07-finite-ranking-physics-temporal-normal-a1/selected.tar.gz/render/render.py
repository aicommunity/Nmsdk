
import pathlib,json,hashlib,tarfile,io,subprocess,os,sys,time,unittest,traceback,html
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');repo=base/'source-legacy-completed-replay-asan-a1';out=base/'readbacks/s07-finite-ranking-physics-temporal-m40-a1';start=time.monotonic()
try:
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit() or p.name==str(os.getpid()):continue
  try:
   if p.stat().st_uid==os.getuid():
    cwd=(p/'cwd').resolve();assert cwd!=repo and repo not in cwd.parents,('active_python_checkout_user',p.name)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--untracked-files=no'],text=True).strip()
 sha='8342f7d99e7b805ea0c64e54ade43dcd3a16abb9'
 with (out/'setup.log').open('x') as log:
  for args in [['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',sha],['git','-C',str(repo),'-c','submodule.recurse=false','checkout','--detach','FETCH_HEAD']]:subprocess.run(args,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 evidence='f5e3bccacce748960f67b53afa5574f980bc4f7c'
 with (out/'fetch-data.log').open('x') as log:subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',evidence],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
 inputs=base/'report-inputs/s07-finite-ranking-physics-normal-a1';inputs.mkdir(exist_ok=False);cache=base/'report-cache/s07-finite-ranking-physics-normal-a1';cache.mkdir(exist_ok=False)
 for phase,name in [('baseline','s07-finite-ranking-physics-baseline-normal-a1'),('correction','s07-finite-ranking-physics-normal-a1')]:
  prefix='Reports/StructTrain/TimeLearner/'+name+'/'
  def blob(n):return subprocess.check_output(['git','-C',str(repo),'show',evidence+':'+prefix+n])
  bundle=json.loads(blob('bundle.json'));archive=blob('primary.tar.gz');assert hashlib.sha256(archive).hexdigest()==bundle['archive_sha256']
  folder=inputs/phase;folder.mkdir()
  with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
   assert set(tar.getnames())==set(bundle['members'])
   for n,h in bundle['members'].items():
    m=tar.getmember(n);assert m.isfile();p=folder/n;assert p.resolve().is_relative_to(folder.resolve())
    raw=tar.extractfile(m).read();assert hashlib.sha256(raw).hexdigest()==h;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 sys.path.insert(0,str(repo));from Scripts.StructTrain.TimeLearner.probe_reports import render_probe_set
 from Scripts.StructTrain.TimeLearner.finite_ranking_evidence import load_case,audit_finite_timing_ranking
 cases=[];total=pairs=0;links=[]
 for phase in ('baseline','correction'):
  native=inputs/phase/'native4/result/native'
  for topology in ('Classic','Branch'):
   for n in (0,1):
    prefix=topology+'_2000_N'+str(n)+'_finite_ranking_zero_sync';source=load_case(native,prefix);audit=audit_finite_timing_ranking(*source)
    assert audit['selected_is_measured_minimum']==(phase=='correction')
    trials=[]
    for index,packet in enumerate(source[0]['observed_packets'],1):
     name=prefix+'_training_proof_'+str(index);assert json.loads((native/(name+'.json')).read_text())==packet
     trials.append({'trial_id':packet['requested_specification']['trial_id'],'packet':name+'.json','trace':name+'.csv'})
    spec=native/(prefix+'_report-spec.json');spec.write_text(json.dumps({'kind':'timelearner_probe_report_spec','schema_version':1,'trials':trials},indent=2)+'\n')
    report=phase+'/'+prefix;result=render_probe_set(spec,cache/report);total+=result['trials'];pairs+=result['trial_soma_pairs']
    cases.append({'phase':phase,'prefix':prefix,'source_native':str(native.relative_to(inputs)),'report':report,'primary_audit':audit,'trials':result['trials'],'trial_soma_pairs':result['trial_soma_pairs']})
    links.append('<li><a href="'+report+'/index.html">'+html.escape(phase+' / '+prefix)+'</a></li>')
 manifest={'kind':'timelearner_finite_rank_temporal_cache','schema_version':1,'reader':sha,'source_evidence':evidence,'cases':cases,'trials':total,'trial_soma_pairs':pairs,'visual_acceptance_complete':False,'scientific_verdict':None}
 (cache/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 (cache/'index.html').write_text('<!doctype html><meta charset="utf-8"><h1>Measured timing-rank controls</h1><p>Actual target-burst training probes; explicit amplitude tolerance1 isolates timing selection. Baseline Core427 versus corrected Core225. All outcomes remain BudgetExhausted; no training or classification success is inferred.</p><ul>'+''.join(links)+'</ul>')
 os.environ['TIMELEARNER_FINITE_RANK_REPORT_INPUTS']=str(inputs);os.environ['TIMELEARNER_FINITE_RANK_REPORT_DIR']=str(cache)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_finite_ranking_reports')
 with (out/'unittest.log').open('x') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 result={'execution':'completed','reader':sha,'source_evidence':evidence,'reports':8,'trials':total,'trial_soma_pairs':pairs,'png_files':len(list(cache.rglob('*.png'))),'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'successful':r.wasSuccessful(),'elapsed_wall_seconds':time.monotonic()-start,'visual_acceptance_complete':False,'scientific_verdict':None}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 (out/'error.log').write_text(traceback.format_exc());raise
