import subprocess,pathlib,json,time
p=pathlib.Path('/media/user/Data/TimeLearnerRefactor/readbacks/s07-finite-ranking-physics-temporal-m40-a1')
start=time.monotonic()
with (p/'stdout.log').open('x') as o,(p/'stderr.log').open('x') as e:
 c=subprocess.Popen(['/media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python',str(p/'render.py')],stdout=o,stderr=e,cwd='/tmp')
 (p/'owned-renderer.json').write_text(json.dumps({'pid':c.pid,'start_ticks':pathlib.Path('/proc',str(c.pid),'stat').read_text().rsplit(') ',1)[1].split()[19]})+'\n')
 rc=c.wait()
(p/'terminal.json').write_text(json.dumps({'returncode':rc,'elapsed_wall_seconds':time.monotonic()-start})+'\n')
