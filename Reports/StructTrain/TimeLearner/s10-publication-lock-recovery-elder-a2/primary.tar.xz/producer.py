from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,time
base=Path('/home/user/timelearner-refactor');source=base/'source-publication-lock-recovery-a2';out=base/'readbacks/s10-publication-lock-recovery-a2';out.mkdir(exist_ok=False);evidence=out/'fault-evidence';evidence.mkdir()
os.chdir(source);sys.dont_write_bytecode=True;sys.path.insert(0,str(source));os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['TIMELEARNER_PUBLISHER_EVIDENCE']=str(evidence);os.nice(10)
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'publication-lock-metadata-reservations.sqlite3');token=None;stop=threading.Event();thread=None;errors=[];passed=False
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'native_models_executed':0});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 prior=inspect_worker_dependency(base/"readbacks/s10-publication-lock-recovery-a1-container",registry,"s10-publication-lock-recovery-a1");assert prior["state"]=="ready",prior;write("prior-closed.json",prior)
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='10d45ed93f08928a9992a3cf569c6a4938cdcd64'
 import sqlite3,socket
 connection=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True)
 try:
  connection.execute('PRAGMA query_only=ON');connection.execute('BEGIN');metadata=dict(connection.execute('SELECT key,value FROM metadata'));assert metadata['worker_host']==socket.gethostname();held=[r for row in connection.execute("SELECT resources FROM leases WHERE state='held'") for r in json.loads(row[0])]
 finally:connection.close()
 for p in [source,out]:
  for r in held:
   q=Path(r['canonical_path']);assert not p.is_relative_to(q) and not q.is_relative_to(p)
 write('isolation.json',{'global_registry_readonly':True,'no_overlap_with_held_paths':True,'global_policy_changed':False,'native_models_executed':0})
 lease=registry.reserve(out.name,[{'path':str(source),'access':'read'},{'path':str(out),'access':'write'}],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 before={p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py')};assert len(before)==282;write('source-hashes.json',before)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_publisher')
 def tests(s):
  for t in s:
   if isinstance(t,unittest.TestSuite):yield from tests(t)
   else:yield t
 ids=[t.id() for t in tests(suite)];assert len(ids)==len(set(ids))==20;write('test-inventory.json',ids)
 with (out/'checks.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('checks.json',{'tests':result.testsRun,'expected':20,'failures':[t.id() for t,_ in result.failures],'errors':[t.id() for t,_ in result.errors],'skipped':result.skipped});assert result.testsRun==20 and result.wasSuccessful() and not result.skipped
 fault=json.loads((evidence/'frontend-crash-recovery.json').read_text());assert fault['frontend_returncode']==-9 and fault['public_cli_recovery']['recovery']=='recovered' and fault['resumed_publication']['publication']=='published' and fault['root_remote_commit']==fault['expected_root_commit'] and not fault['public_cli_recovery']['git_push_executed']
 after={p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py')};assert before==after;write('source-unchanged.json',{'files':len(after),'unchanged':True});registry.validate_paths(token);assert not errors;passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 write('terminal.json',{'checks_passed':passed,'native_models_executed':0,'whole_stage10_complete':False,'scientific_verdict':None});members={}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for p in sorted(out.rglob('*')):
   if p.is_file() and p.name not in ['primary.tar.xz','bundle.json']:
    name=p.relative_to(out).as_posix();members[name]={'bytes':p.stat().st_size,'sha256':sha(p)};info=tarfile.TarInfo(name);info.size=p.stat().st_size
    with p.open('rb') as stream:archive.addfile(info,stream)
 write('bundle.json',{'source_commit':'10d45ed93f08928a9992a3cf569c6a4938cdcd64','members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'checks_passed':passed,'scientific_verdict':None});print('CLOSED',passed,flush=True)
