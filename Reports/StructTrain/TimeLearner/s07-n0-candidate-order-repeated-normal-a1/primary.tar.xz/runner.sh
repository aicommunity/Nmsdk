set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s07-n0-candidate-order-repeated-normal-a1"
previous="$base/readbacks/s07-n0-candidate-order-fixed-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$previous/process-exit-status.txt";do
 kill -0 "$(cat "$previous/supervisor.pid")";sleep 10
done
test "$(cat "$previous/process-exit-status.txt")" = 0
test "$(git -C "$src" rev-parse HEAD)" = 942e5df4559467a9a19c56755f945ce6501e7780
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 30000000
cd "$src"
export OUT="$out" RUNTIME="$runtime" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_N0_REPEATS_DIR="$out/native"
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
git rev-parse HEAD > "$out/source-closure.txt";git submodule status --recursive >> "$out/source-closure.txt"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,hashlib,unittest,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
from Scripts.StructTrain.TimeLearner.tests import test_n0_repeat_evidence as module
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json');start=time.monotonic()
r=execute(runtime,['--gtest_filter=ConfiguredNativeTrainingN0Repeats.*','--gtest_output=xml:'+str(out/'native.xml')],Path(runtime['executable']['path']).parent,out/'process',1800)
xml=ET.parse(out/'native.xml').getroot();cases=list(xml.iter('testcase'))
expected={'ConfiguredNativeTrainingN0Repeats/'+n for n in ('ClassicNativePairs','BranchNativePairs','Schema2DeclaresPolicyAndSchema1DoesNotSilentlyChange')}
actual=[c.attrib['classname']+'/'+c.attrib['name'] for c in cases]
assert r['execution']=='completed' and r['returncode']==0 and r['runtime_provenance']=='loaded_files_captured'
assert len(actual)==3 and set(actual)==expected and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
def snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((out/'native').iterdir()) if p.is_file()}
before=snapshot()
checks=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
assert checks.wasSuccessful() and checks.testsRun==3 and not checks.skipped
assert snapshot()==before
v={'kind':'n0_configured_repeated_candidate_gate','schema_version':1,'native_tests':3,'reader_tests':3,'actual_probes':sum(len(p) for _,p in module.N0RepeatEvidenceTest.cases),'repeat_groups':sum(len(s['candidate_repeat_groups']) for s,_ in module.N0RepeatEvidenceTest.cases),'source_files_unchanged':len(before),'seconds':time.monotonic()-start,'new_build':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
