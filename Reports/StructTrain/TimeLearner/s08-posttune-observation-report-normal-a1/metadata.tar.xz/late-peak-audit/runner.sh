set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-report-peak-a2
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-posttune-observation-report-normal-a1
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_LEGACY_POSTTUNE_FREERUN_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-report-normal-a1/source/fixed-native/native
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.tests.test_legacy_posttune_evidence import LegacyPostTunePhysicalEvidenceTest as Case
names=['test_four_actual_traces_remain_diagnostics','test_missing_native_sample_is_rejected','test_unknown_foil_state_cannot_reuse_valid_summary','test_changed_actual_onset_list_is_rejected','test_selected_metric_must_match_actual_somas','test_finite_peak_summary_must_replay_from_actual_trace']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Case(name) for name in names))
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'a153c052af7cfd2953e2fe2a1ce087bc7b5f2cc7',
 'tests':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skips':len(r.skipped),'rendering_repeated':False,'sample_peak_replay':True,'scientific_verdict':None},indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==6 and not r.skipped
PY
