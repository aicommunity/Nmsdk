set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-report-normal-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-posttune-observation-report-normal-a1
export PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg MPLCONFIGDIR="$out/mpl" TMPDIR="$out"
mkdir "$out/mpl"
OUT="$out" /media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python - <<'PY' > "$out/tests.log" 2>&1
import hashlib,json,os,tarfile,unittest
from pathlib import Path
out=Path(os.environ['OUT']);bundle=Path('Reports/StructTrain/TimeLearner/s08-posttune-observation-fixed-normal-a2')
manifest=json.loads((bundle/'manifest.json').read_bytes());archive=bundle/'primary.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
records={r['path']:r for r in manifest['files']};source=out/'source';source.mkdir()
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(records)
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  raw=tar.extractfile(member).read();r=records[member.name]
  assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  p=source/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
os.environ['TIMELEARNER_LEGACY_POSTTUNE_FREERUN_DIR']=str(source/'fixed-native/native')
os.environ['TIMELEARNER_LEGACY_POSTTUNE_REPORT_OUTPUT']=str(out/'reports')
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromName(name) for name in
 ['Scripts.StructTrain.TimeLearner.tests.test_plotting','Scripts.StructTrain.TimeLearner.tests.test_legacy_posttune_evidence']])
r=unittest.TextTestRunner(verbosity=2).run(suite)
result={'reader_root':'37678c324afdc8adbfa41e4b0b26c465749b2a44','native_root':'e3fe53408b861b49c0e0ddc6c3de9acc548a9e54',
 'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped),
 'source_members_verified':len(records),'physical_runs':4,'patterns_per_run':2,'soma_channels_total':6,
 'model_certificate_claim':False,'visual_acceptance_complete':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==11 and not r.skipped,result
PY
