
from pathlib import Path
import os,sys,json,subprocess,time,hashlib,tarfile,traceback
base=Path('/media/user/Data/TimeLearnerRefactor');label='asan'
source=base/('readbacks/s03-native-probe-phases-'+label+'-a1')
out=base/('readbacks/s03-native-probe-phases-compact-'+label+'-a1');out.mkdir(exist_ok=False)
root='f679d0410dd00a36995f9d32cc03812438819bb7'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def live(r):
 try:return Path('/proc',str(r['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]==r['start_ticks']
 except FileNotFoundError:return False
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 owner=json.loads((source/'owned-supervisor.json').read_text());write('waited-source-owner.json',owner)
 while live(owner):time.sleep(5)
 bundle=json.loads((source/'bundle.json').read_text());assert bundle['acceptance_status']=='passed'
 assert hashlib.sha256((source/'primary.tar.xz').read_bytes()).hexdigest()==bundle['archive_sha256']
 for n in ['phase-readers.json','historical-readback.json','terminal.json','index.json']:
  (out/n).write_bytes((source/n).read_bytes())
 checked=json.loads((out/'phase-readers.json').read_text());assert checked=={'tests':7,'errors':0,'failures':0,'skipped':0}
 sdk=base/('source-initial-threshold-asan-a2' if label=='asan' else 'source-initial-threshold-normal-a4')
 analysis=base/('analysis-native-probe-phases-compact-'+label+'-a1')
 subprocess.run(['git','clone','--shared','--no-checkout',str(sdk),str(analysis)],check=True)
 subprocess.run(['git','-C',str(analysis),'sparse-checkout','init','--cone'],check=True)
 subprocess.run(['git','-C',str(analysis),'sparse-checkout','set','Scripts/StructTrain/TimeLearner'],check=True)
 subprocess.run(['git','-C',str(analysis),'checkout','--detach',root],check=True)
 sys.path.insert(0,str(analysis))
 from Scripts.StructTrain.TimeLearner.primary_reuse import pack,restore
 from Scripts.StructTrain.TimeLearner.native_characterization import audit_execution
 write('pack-receipt.json',pack(source,analysis,'e5fa71d745119af0d818059f497dd226f4c7c25d','Reports/StructTrain/TimeLearner/s07-stock-threshold-pair-normal-a3/primary.tar.xz',out/'compact-native'))
 restored=out/'restored';write('restore-receipt.json',restore(out/'compact-native',analysis,restored))
 rows=json.loads((restored/'index.json').read_text())['rows'];observed=[]
 for row in rows:
  # All twelve original production manifests already passed the seven readers.
  # Recheck the closed native packet after byte-exact restoration; no model rerun.
  native=restored/'runs'/row['name']/'native';result=audit_execution(native)
  assert result['execution']==row['expected_execution'] and result['terminal_phase']==row['expected_phase']
  original=source/'runs'/row['name']/'native'
  assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in native.iterdir() if p.is_file()}=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in original.iterdir() if p.is_file()}
  observed.append({'name':row['name'],'execution':result['execution'],'terminal_phase':result['terminal_phase'],'observation_complete':result['observation_complete']})
 write('restored-native-readback.json',{'rows':observed,'native_files_byte_equal':True,'scientific_verdict':None})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('compact-terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 analysis=base/('analysis-native-probe-phases-compact-'+label+'-a1')
 if analysis.exists():write('source-hashes.json',{p.relative_to(analysis).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (analysis/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts})
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and 'restored' not in p.relative_to(out).parts}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 p=out/'primary.tar.xz';write('bundle.json',{'kind':'native_probe_phase_compact_validation','root':root,'acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_bytes':p.stat().st_size,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
