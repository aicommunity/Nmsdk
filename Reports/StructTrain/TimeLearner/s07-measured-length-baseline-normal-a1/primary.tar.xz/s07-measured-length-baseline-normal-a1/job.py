import pathlib,subprocess,json,os,time,sys,traceback,xml.etree.ElementTree as ET
base=pathlib.Path("/home/user/timelearner-refactor");worker="normal"
source=base/"source-n1-measured-refinement-normal-a1";build=base/"build-n1-measured-refinement-normal-a1"
out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/"readbacks").resolve() and out.name=="s07-measured-length-baseline-normal-a1"
assert {p.name for p in out.iterdir()} <= {"job.py","pid.json","supervisor.log"}
runtime=base/("runtime-"+out.name);assert not runtime.exists()
transport_ancestors={};pid=os.getpid()
while pid>1:
 p=pathlib.Path('/proc')/str(pid)/'stat';fields=p.read_text().rsplit(') ',1)[1].split();transport_ancestors[str(pid)]=fields[19];pid=int(fields[1])
def write(name,value):
 with (out/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
def run(args,name,timeout=300):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
try:
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert pathlib.Path(git(source,'rev-parse','--show-toplevel')).resolve()==source.resolve()
 assert not git(source,'status','--porcelain','--untracked-files=no')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','a558b66beb7e8b5ca33974875cf094dd826a5080'],'fetch-root.log')
 root=git(source,'rev-parse','FETCH_HEAD');assert root=='a558b66beb7e8b5ca33974875cf094dd826a5080'
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 for child,url in [('Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib'),('Bin','Nmsdk-Bin'),('Rdk','Rdk')]:
  repo=source/child;assert not git(repo,'status','--porcelain','--untracked-files=no')
  wanted=git(source,'rev-parse','HEAD:'+child)
  run(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+url+'.git',wanted],'fetch-'+url+'.log')
  assert git(repo,'rev-parse','FETCH_HEAD')==wanted,'fetch_did_not_resolve_exact_gitlink'
  run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+url+'.log')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 assert not runtime.exists()
 run(['cmake','-S',source,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','--parallel','2'] ,'build.log',7200)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 result=execute(manifest,['--gtest_filter=BoundedTrainingLengthCandidates.*','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',300)
 tree=ET.parse(out/'gtest.xml').getroot()
 write('validation.json',{'kind':'measured_length_proposal_baseline','source':root,'execution':result,'gtest':tree.attrib,'scientific_verdict':None})
 assert result['execution']=='process_error' and result['returncode']==1
 assert tree.attrib['tests']=='4' and tree.attrib['failures']=='4' and tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 assert source_closure(source)==closure
 verify_runtime(manifest)
 write('terminal.json',{'execution':'completed','expected_failures':4,'scientific_verdict':None})
 print(json.dumps({'baseline':tree.attrib}),flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
