import pathlib,subprocess,json,hashlib,io,tarfile,os,sys,time,traceback
b=pathlib.Path('/home/user/timelearner-refactor');repo=b/'source-august-replay-proof-elder-a1';code=b/'source-archive-transfer-analysis-a1';out=b/'readbacks/s05-archive-f64-reader-normal-a2'
root='5c4e1a44cbdbc92fbab646933a1c15de606ebfda';data=b/'readbacks/s05-archive-f64-normal-a4'
out.mkdir(exist_ok=False)
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
try:
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],check=True,capture_output=True)
 raw=subprocess.check_output(['git','-C',str(repo),'archive',root,'Scripts/StructTrain/TimeLearner'])
 code.mkdir(exist_ok=False);records=[]
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  for item in t.getmembers():
   if item.isdir():continue
   assert item.isfile() and not pathlib.PurePosixPath(item.name).is_absolute() and '..' not in pathlib.PurePosixPath(item.name).parts
   path=code/item.name;assert path.resolve().is_relative_to(code.resolve())
   value=t.extractfile(item).read();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(value)
   records.append({'path':item.name,'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()})
 (code/'code-manifest.json').write_text(json.dumps({'git_root':root,'records':records},indent=2)+'\n')
 write('code-manifest.json',{'git_root':root,'records':records})
 def verify():
  for r in records:assert len((code/r['path']).read_bytes())==r['bytes'] and hashlib.sha256((code/r['path']).read_bytes()).hexdigest()==r['sha256']
 verify();runs=[]
 for label,module,key,path,count in [
  ('archive','Scripts.StructTrain.TimeLearner.tests.test_archive_transfer_reports','TL_ARCHIVE_TRANSFER_SOURCE',data,23),
  ('warm','Scripts.StructTrain.TimeLearner.tests.test_hot_readout_reports','TL_HOT_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-normal-a1',16),
  ('loaded','Scripts.StructTrain.TimeLearner.tests.test_loaded_readout_reports','TL_LOADED_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-normal-a1/loaded',16)]:
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_HOT_EXPECT_STALE='0');env[key]=str(path)
  with (out/(label+'.log')).open('wb') as f:r=subprocess.run(['python3','-m','unittest','-v',module],cwd=code,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(out/(label+'.log')).read_text();runs.append({'label':label,'expected_tests':count,'returncode':r.returncode,'reported_count_matches':('Ran '+str(count)+' tests') in log})
  write('progress.json',{'runs':runs});assert r.returncode==0 and runs[-1]['reported_count_matches'],log
 sys.dont_write_bytecode=True;sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.archive_transfer_reports import audit_run
 rows,audit=audit_run(data);write('full-audit.json',audit)
 a3=b/'readbacks/s05-archive-f64-normal-a3'
 previous=json.loads((a3/'unit-runtime.json').read_text());current=json.loads((data/'unit-runtime.json').read_text())
 earlier=json.loads((a3/'unit-validation.json').read_text());latest=json.loads((data/'unit-validation.json').read_text())
 assert previous['runtime_identity']==current['runtime_identity'] and previous['executable']['sha256']==current['executable']['sha256']
 assert earlier['execution']['runtime_provenance']=='loaded_files_captured'
 write('unit-provenance-comparison.json',{'same_executable_sha256':current['executable']['sha256'],'same_prelaunch_runtime_fingerprint':current['runtime_fingerprint'],'previous_receipt':'s05-archive-f64-normal-a3/unit-validation.json','previous_actual_mapping_status':earlier['execution']['runtime_provenance'],'current_actual_mapping_status':latest['execution']['runtime_provenance'],'current_actual_mappings_remain_unknown':latest['execution']['runtime_provenance']!='loaded_files_captured','interpretation':'Earlier identical unit executable and planned runtime were observed; this does not manufacture current process mappings.'})
 start=time.monotonic();xml=data/'hot-xml'
 while not (xml/'validation.json').exists():
  p=pathlib.Path('/proc/2937623/stat')
  assert p.exists() and p.read_text().rsplit(') ',1)[1].split()[19]=='311805270','native_supervisor_terminal_without_xml_receipt'
  assert time.monotonic()-start<1800,'xml_wait_timeout'
  time.sleep(5)
 native=json.loads((xml/'validation.json').read_text());assert native['gtest']['tests']=='32' and native['gtest']['failures']==native['gtest']['errors']=='0' and native['execution']['returncode']==0
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_HOT_XML_SOURCE=str(xml))
 with (out/'xml.log').open('wb') as f:r=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_hot_xml_reports'],cwd=code,env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(out/'xml.log').read_text();runs.append({'label':'xml','expected_tests':18,'returncode':r.returncode,'reported_count_matches':'Ran 18 tests' in log});assert r.returncode==0 and runs[-1]['reported_count_matches'],log
 from Scripts.StructTrain.TimeLearner.hot_xml_reports import audit_run as xml_audit
 _,xa=xml_audit(xml);write('xml-full-audit.json',xa);verify()
 result={'kind':'model_archive_precision_current_data_verification','schema_version':1,'code_root':root,'native_source':'90e6ef669f42fdde074ab5148f39c9d8510932cd','runs':runs,'archive_cases':len(rows),'archive_case_soma_pairs':audit['case_soma_pairs'],'xml_case_soma_pairs':xa['case_soma_pairs'],'scientific_verdict':None}
 write('validation.json',result);print(json.dumps(result),flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
