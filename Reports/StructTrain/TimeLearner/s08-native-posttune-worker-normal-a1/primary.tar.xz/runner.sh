set -euo pipefail
base=/home/user/timelearner-refactor
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
out="$base/readbacks/s08-native-posttune-worker-normal-a1";runtime="$base/runtime-s08-native-posttune-worker-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
previous="$base/readbacks/s08-native-posttune-candidates-normal-a2"
while test ! -f "$previous/process-exit-status.txt"; do kill -0 1412432;sleep 5;done
test "$(cat "$previous/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
test ! -e "$runtime"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git c6410eecc67cdc27aa5d6c05ef40f81a174a4916 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach c6410eecc67cdc27aa5d6c05ef40f81a174a4916 >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
OUT="$out" PRIMARY="$previous/native" python3 - <<'PY' > "$out/worker.log" 2>&1
import os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.tests.test_native_posttune_worker import create_actual_worker_controls
p=Path(os.environ['OUT'])
create_actual_worker_controls(Path(os.environ['PRIMARY']),p/'runtime-before.json',p/'runs')
PY
TIMELEARNER_NATIVE_POSTTUNE_WORKER_DIR="$out/runs" python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_worker -v > "$out/reader.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os
from pathlib import Path
p=Path(os.environ['OUT']);m=[json.loads(f.read_bytes()) for f in (p/'runs').glob('*/run-manifest.json')]
assert len(m)==40 and all(r['execution']=='completed' and r['validity']=='valid' for r in m)
(p/'validation.json').write_text(json.dumps({'root':'c6410eecc67cdc27aa5d6c05ef40f81a174a4916',
 'pulse':'de51a21','operations':40,'modes':5,'topology_normalization_cases':4,'patterns_per_evaluation':2,
 'independent_test_checks':4,'scientific_verdict':None},indent=2)+'\n')
PY
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
