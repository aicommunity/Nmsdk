from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,io
base=Path('/home/user/timelearner-refactor');source=base/'source-inventory-snapshots-a1';out=base/'readbacks/s09-inventory-snapshots-a1';out.mkdir(exist_ok=False)
subprocess.run(['git','-C',str(source),'-c','submodule.recurse=false','checkout','--detach','1b1b571e2b979e2775e52a9a868cc0897d54b700'],check=True)
os.chdir(source);sys.path.insert(0,str(source));os.environ['TIMELEARNER_INVENTORY_PULSE_SOURCE']=str(source/'Libraries/Nmsdk-PulseLib')
(out/'owner.json').write_text(json.dumps({'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]}))
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
program="""import unittest,json,sys
from pathlib import Path
s=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_inventory')
ids=[t.id() for group in s for t in group];assert len(ids)==len(set(ids))==10,ids
out=Path(sys.argv[1]);(out/'test-inventory.json').write_text(json.dumps(ids,indent=2))
r=unittest.TextTestRunner(verbosity=2).run(s)
(out/'tests.json').write_text(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'expected':10}))
raise SystemExit(0 if r.testsRun==10 and r.wasSuccessful() and not r.skipped else 2)
"""
with (out/'tests.log').open('xb') as log:
 p=subprocess.Popen([sys.executable,'-c',program,str(out)],stdout=log,stderr=subprocess.STDOUT);status=p.wait()
if status==0:
 with (out/'production-cli.log').open('xb') as log:
  p=subprocess.Popen([sys.executable,'-m','Scripts.StructTrain.TimeLearner','inventory','--root',str(source),'--revision','1b1b571e2b979e2775e52a9a868cc0897d54b700','--output',str(out/'production-inventory.json')],stdout=log,stderr=subprocess.STDOUT);status=p.wait()
 if status==0:
  x=json.loads((out/'production-inventory.json').read_text());counts={n:sum(v['repository']==n for v in x['scripts']) for n in x['repositories']}
  assert len(x['properties'])==217 and x['schema_version']==2 and all(v['checkout_matches_snapshot'] and not v['tracked_working_tree_status'] for v in x['repositories'].values())
  (out/'inventory-summary.json').write_text(json.dumps({'scripts':counts,'properties':len(x['properties']),'source_kind':x['source_kind'],'root':x['root_revision'],'object_only_child_repositories':True,'not_a_runtime_or_full_artifact_checkout':True},indent=2))
(out/'terminal.json').write_text(json.dumps({'returncode':status,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scientific_verdict':None}))
hashes={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py')}
(out/'source-hashes.json').write_text(json.dumps(hashes,indent=2))
files={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as a:
 for name,raw in files.items():entry=tarfile.TarInfo(name);entry.size=len(raw);a.addfile(entry,io.BytesIO(raw))
(out/'bundle.json').write_text(json.dumps({'members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in files.items()},'archive_sha256':hashlib.sha256((out/'primary.tar.xz').read_bytes()).hexdigest(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'returncode':status},indent=2))
print('CLOSED',status,flush=True)
