from pathlib import Path
import json,os,subprocess,time,traceback,hashlib,sys,unittest,tarfile,contextlib

base=Path('/media/user/Data/TimeLearnerRefactor')
native=base/('readbacks/s05-calibration-preconditions-'+'asan'+'-a1')
out=base/('readbacks/s05-calibration-preconditions-'+'asan'+'-readers-a1')
out.mkdir(exist_ok=False)
root='59f28159bf5518d01871062fb90813ebd3d55cab'

def write(name,value):
 (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def live(r):
 try:return Path('/proc',str(r['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]==r['start_ticks']
 except FileNotFoundError:return False
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 owner=json.loads((native/'owned-supervisor.json').read_text());write('waited-native-owner.json',owner)
 deadline=time.monotonic()+24000
 while live(owner):
  if time.monotonic()>deadline:raise RuntimeError('native_owner_still_live_wait_budget')
  time.sleep(5)
 b=json.loads((native/'bundle.json').read_text());assert b['acceptance_status']=='passed'
 assert hashlib.sha256((native/'primary.tar.xz').read_bytes()).hexdigest()==b['archive_sha256']
 write('native-bundle.json',b)
 # An independent Git checkout of readers does not touch the active native SDK.
 repo=out/'reader-objects.git';subprocess.run(['git','clone','--shared','--bare',str(base/'source-initial-threshold-asan-a2'),str(repo)],check=True);subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],check=True);work=out/'source';work.mkdir()
 root='59f28159bf5518d01871062fb90813ebd3d55cab'
 subprocess.run(['git','-C',str(repo),'cat-file','-e',root+'^{commit}'],check=True)
 archive=subprocess.Popen(['git','-C',str(repo),'archive',root,'Scripts/StructTrain/TimeLearner'],stdout=subprocess.PIPE)
 subprocess.run(['tar','-xf','-','-C',str(work)],stdin=archive.stdout,check=True);archive.stdout.close();assert archive.wait()==0
 hashes={p.relative_to(work).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (work/'Scripts/StructTrain/TimeLearner').rglob('*.py')}
 write('reader-source-hashes.json',hashes)
 sys.path.insert(0,str(work));os.environ['TIMELEARNER_CALIBRATED_MODEL_SPEC2_DIR']=str(native/'native-result/native')
 suite=unittest.defaultTestLoader.loadTestsFromNames(['Scripts.StructTrain.TimeLearner.tests.test_calibrated_model_spec2_evidence.CalibratedModelSpec2EvidenceTest','Scripts.StructTrain.TimeLearner.tests.test_calibration_preconditions.CalibrationPreconditionsTest'])
 assert suite.countTestCases()==7
 with (out/'readers.log').open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 value={'native_source_root':b['root'],'reader_source_root':root,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'scientific_verdict':None}
 write('reader-verdict.json',value);assert result.wasSuccessful() and result.testsRun==7 and not result.skipped
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 files=[p for p in out.iterdir() if p.is_file()]
 records={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for p in files:t.add(p,arcname=p.name,recursive=False)
 write('bundle.json',{'kind':'calibrated_model_spec2_primary_reader_validation','acceptance_status':'passed' if passed else 'not_accepted','native_root':'b82f76e2fe543acf25d6c3076abbd864f965b3a8','reader_root':'59f28159bf5518d01871062fb90813ebd3d55cab','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
