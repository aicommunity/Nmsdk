from pathlib import Path
import subprocess,json,os,sys,hashlib,traceback,signal,tarfile
ROOT='f32de33257dd67e84962926f1225b1a6f6b29fcd';OLD='63d861e823aea132625b22f3702ac11c3d1e7320'
base=Path('/media/user/Data/TimeLearnerRefactor');out=base/'readbacks/s05-calibrated-model-spec2-asan-a1';out.mkdir(exist_ok=False)
sdk=base/'source-initial-threshold-asan-a2';build=base/'build-initial-threshold-asan-a2';runtime=base/'runtime-calibrated-model-spec2-asan-a1';old_runtime=base/'runtime-initial-threshold-archive-asan-a1';seed='https://github.com/aicommunity/Nmsdk.git'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def git(*args):return subprocess.check_output(['git','-C',str(sdk),*args],text=True).strip()
def inventory():return {p.relative_to(old_runtime).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'realpath':str(p.resolve()),'bytes':p.stat().st_size} for p in old_runtime.rglob('*') if p.is_file()}
def run(args,name,timeout=1800):
 with (out/name).open('xb') as log:
  q=subprocess.Popen([str(a) for a in args],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r={'pid':q.pid,'start_ticks':ticks(q.pid),'arguments':[str(a) for a in args]};write('owned-'+name+'.json',r)
  try:rc=q.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   if live(r) and os.getpgid(q.pid)==q.pid:
    os.killpg(q.pid,signal.SIGTERM)
    try:q.wait(timeout=10)
    except subprocess.TimeoutExpired:
     if live(r) and os.getpgid(q.pid)==q.pid:os.killpg(q.pid,signal.SIGKILL);q.wait(timeout=10)
   raise
  assert rc==0,(name,rc)
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False;before=None
try:
 previous=base/'readbacks/s04-initial-threshold-archive-asan-a1'
 assert not live(json.loads((previous/'owned-supervisor.json').read_text()))
 publication=json.loads((previous/'publication.json').read_text());assert publication['acceptance_status']=='passed' and publication['native_tests']==18
 write('native18-prerequisite.json',publication)
 assert git('rev-parse','HEAD')==OLD and not git('status','--porcelain','--untracked-files=no')
 assert not runtime.exists()
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:assert not str((proc/'exe').resolve()).startswith(str(old_runtime)+'/'),'old runtime process still live'
  except (FileNotFoundError,PermissionError):pass
 before=inventory();write('old-runtime-before.json',before)
 run(['git','-C',sdk,'fetch','--no-recurse-submodules',seed,ROOT],'fetch-source.log')
 changed=git('diff','--name-only',OLD,ROOT,'--','App','Tests','CMakeLists.txt','cmake').splitlines()
 assert changed==['Tests/Integration/Libraries/Test_PulseLib_NativeModelEditor.cpp'],changed
 prior_children={}
 for r in subprocess.check_output(['git','-C',str(sdk),'ls-tree','-r','-z',ROOT]).split(b'\0'):
  if not r:continue
  info,path=r.split(b'\t',1)
  if info.split()[0]==b'160000':
   path=path.decode();sha=info.split()[2].decode();assert subprocess.check_output(['git','-C',str(sdk/path),'rev-parse','HEAD'],text=True).strip()==sha;prior_children[path]=sha
 write('closed-build-reuse.json',{'old_root':OLD,'new_root':ROOT,'only_native_source_change':changed,'children':prior_children,'all_known_owners_closed':True,'new_runtime':str(runtime),'old_runtime':str(old_runtime),'pulse_production_core_unchanged':True})
 run(['git','-C',sdk,'checkout','--detach',ROOT],'checkout-source.log')
 run(['cmake','-S',sdk,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log',3600)
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 sys.path.insert(0,str(sdk));os.chdir(sdk)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 appini=runtime/'NeuroModelerConsole.ini'
 write('native-runtime.json',snapshot(sdk,runtime/'Test_PulseLib_StorageComponents',appini,build/'CMakeCache.txt'))
 spec=load(sdk/'Scripts/StructTrain/TimeLearner/specs/native-calibrated-model-spec2-v1.json');assert len(spec['expected_test_ids'])==4
 spec.update(source_root=str(sdk),runtime_manifest=str(out/'native-runtime.json'),asan_options='detect_leaks=0');write('native-specification.json',spec)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed'
 loaded=json.loads((out/'native-result/process/loaded-files.json').read_text());assert isinstance(loaded,list)
 mappings=[r for r in loaded if 'libasan.so' in r.get('path','')];assert mappings
 write('actual-libasan-mappings.json',{'records':mappings,'detect_leaks':False})
 passed=True;write('terminal.json',{'execution':'completed','native_tests':4,'new_calibrated_model_spec2_cases':2,'production_pulse_code_changed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 if before is not None:
  after=inventory();write('old-runtime-after.json',after)
  if after!=before:passed=False;write('old-runtime-byte-guard-failed.json',{'same':False})
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner']:
  for p in (sdk/prefix).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(sdk).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 for p in (sdk/'Libraries/Nmsdk-PulseLib/Core/TimeLearner').rglob('*'):
  if p.is_file():hashes[p.relative_to(sdk).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes();write('bundle.json',{'kind':'native_calibrated_model_spec2_asan_validation','schema_version':1,'root':ROOT,'pulselib':'541bf89b9966f63ca5131fa57a31a9ae3f5820ea','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
