if __name__ == '__main__':
 from pathlib import Path,PurePosixPath
 import os,sys,json,hashlib,subprocess,tarfile,io,threading,traceback,shutil
 base=Path('/media/user/Data/TimeLearnerRefactor');label='analysis-dispatch-m40-a1';out=base/('readbacks/s03-'+label);out.mkdir(exist_ok=False);source=base/'source-cli-analysis-dispatch-a1';root='7a98295005762c11a9937e5c8f63e6628564d6d6';origin='60442fb2a8ea1572a74d3d323d37a8b74e1cb08b';bootstrap=base/'source-closed-worker-recovery-a3';stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False
 def write(n,v):
  q=out/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
 def sha(q):return hashlib.sha256(q.read_bytes()).hexdigest()
 def git(*a):return subprocess.check_output(['git','-C',str(source),*a])
 write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'root':root,'new_native_models_executed':0});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
 try:
  assert git('rev-parse','HEAD').decode().strip()==root and shutil.disk_usage(base).free>=512*1024**2
  sys.path.insert(0,str(bootstrap));from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
  registry=Reservations(base/'resource-reservations.sqlite3');lease=registry.reserve('s03-'+label,[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'}],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
  def heartbeat():
   while not stop.wait(20):
    try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
    except BaseException as e:errors.append(str(e));return
  thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
  prefix='Reports/StructTrain/TimeLearner/s03-analysis-dispatch-normal-a1/';b=json.loads(git('show',origin+':'+prefix+'bundle.json'));raw=git('show',origin+':'+prefix+'primary.tar.xz');assert len(raw)==b['archive_bytes'] and hashlib.sha256(raw).hexdigest()==b['archive_sha256'];fixture=out/'fixture';fixture.mkdir();seen=set();selected=[]
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r|xz') as archive:
   for e in archive:
    assert e.isfile() and e.name not in seen;seen.add(e.name);v=archive.extractfile(e).read();assert {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}==b['members'][e.name]
    if e.name.startswith('native-result/native/') and e.name.endswith('_domain_preview.json'):
     path=fixture/PurePosixPath(e.name).name;assert not path.exists();path.write_bytes(v);selected.append({'source_path':e.name,'fixture_name':path.name,'sha256':hashlib.sha256(v).hexdigest()})
  assert seen==set(b['members']) and len(selected)==2;write('source-primary.json',{'evidence_commit':origin,'archive_sha256':b['archive_sha256'],'members_verified':len(seen),'selected_actual_domain_previews':selected,'source_native_models_executed_on_Elder':2,'new_native_models_executed_on_M40':0})
  prepare=r"""from pathlib import Path
import json
from Scripts.StructTrain.TimeLearner.validation import package_fingerprint,fixture_fingerprint
out=Path('/media/user/Data/TimeLearnerRefactor/readbacks/s03-analysis-dispatch-m40-a1');count,digest=fixture_fingerprint(out/'fixture','*.json');prefix='Scripts.StructTrain.TimeLearner.tests.test_analysis_cli.AnalysisCliTest.'
methods=['test_actual_domain','test_unknown_schema_fails_without_positive_output','test_output_collision_preserves_existing_file','test_probe_cannot_omit_primary_trace','test_legacy_adapter_does_not_invent_physical_proof']
spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'analysis-dispatch-M40-actual-normal-data5','package_fingerprint':package_fingerprint(),'modules':['Scripts.StructTrain.TimeLearner.tests.test_analysis_cli'],'expected_test_ids':[prefix+m for m in methods],'fixtures':{'TIMELEARNER_DOMAIN_EVIDENCE_DIR':{'pattern':'*.json','files':count,'fingerprint':digest}}};(out/'reader-suite.json').write_text(json.dumps(spec,indent=2)+'\n')
"""
  with (out/'prepare.log').open('xb') as log:subprocess.run(['python3','-c',prepare],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
  args=['python3','-m','Scripts.StructTrain.TimeLearner.validation',str(out/'reader-suite.json'),'--fixture','TIMELEARNER_DOMAIN_EVIDENCE_DIR='+str(fixture),'--output',str(out/'structured-readers')]
  with (out/'reader-cli.log').open('xb') as log:status=subprocess.run(args,cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  result=json.loads((out/'structured-readers/result.json').read_text());assert status==0 and result['executed_tests']==5 and result['assertion_status']=='passed' and not any(result[k] for k in ['failures','errors','skipped']);write('source-hashes.json',{q.relative_to(source).as_posix():sha(q) for q in sorted((source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))});assert not errors;passed=True
 except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
 finally:
  try:
   write('terminal.json',{'checks_passed':passed,'actual_native_data_reanalyzed':True,'new_native_models_executed':0,'joint_csearch_acceptance_pending':True,'scientific_verdict':None})
   members={}
   with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
    for q in sorted(out.rglob('*')):
     if q.is_file() and not q.is_symlink() and q.name not in ['primary.tar.xz','bundle.json']:
      name=q.relative_to(out).as_posix();members[name]={'bytes':q.stat().st_size,'sha256':sha(q)};archive.add(q,arcname=name,recursive=False)
   write('bundle.json',{'kind':'analysis_dispatch_portable_actual_data_checks','source_commit':root,'checks_passed':passed,'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
  finally:
   stop.set()
   if thread:thread.join(timeout=30)
