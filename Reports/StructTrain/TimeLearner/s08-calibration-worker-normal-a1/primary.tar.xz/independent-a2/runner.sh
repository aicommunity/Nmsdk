set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s08-calibration-worker-audit-normal-a2
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 1279027 2>/dev/null;do sleep 10;done
test "$(cat /home/user/timelearner-refactor/readbacks/s08-calibration-worker-normal-a2/process-exit-status.txt)" = 0
cd /home/user/timelearner-refactor/source-calibration-worker-audit-normal-a2
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen 
export TIMELEARNER_NATIVE_CALIBRATION_WORKER_DIR=/home/user/timelearner-refactor/readbacks/s08-calibration-worker-normal-a2
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE=/home/user/timelearner-refactor/readbacks/s08-calibration-grid-normal-a2/native
export TIMELEARNER_NATIVE_CALIBRATION_CLI_OUTPUT="$out/native-cli"
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import os,json,sys,unittest
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_calibration_worker')
assert suite.countTestCases()==6
result=unittest.TextTestRunner(verbosity=2).run(suite)
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'819f0d9c4ea54e961ae82c658fae3f33f5565f20','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'scientific_verdict':None},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun==6 and not result.skipped else 1)
PY
