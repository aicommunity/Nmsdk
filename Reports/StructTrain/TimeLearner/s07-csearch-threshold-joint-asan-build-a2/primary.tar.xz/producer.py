from pathlib import Path
import os,sys,json,subprocess,hashlib,threading,time,traceback,shutil,tarfile,io
base=Path('/media/user/Data/TimeLearnerRefactor');root='8021301e894368aefd045f9d77274fcce9f60245';label='csearch-threshold-joint-asan-build-a2'
out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-asan-build-a1';build=base/'build-csearch-threshold-joint-asan-build-a1';runtime=base/('runtime-'+label)
bootstrap=base/'source-closed-worker-recovery-a3';donor=base/'fresh-current-develop-checkout-m40-a1'
framework=base/'framework-configured-probe-ownership-asan-h14';vendor=base/'build-configured-probe-ownership-asan-h14/_deps/llama_cpp-src'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def run(args,name):
 if token:registry.validate_paths(token)
 assert not errors,errors
 with (out/name).open('xb') as log:
  p=subprocess.Popen(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
  write('owned-'+name+'.json',{'pid':p.pid,'start_ticks':ticks(p.pid),'arguments':list(map(str,args))});status=p.wait()
 assert status==0,(name,status)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source),'build':str(build),'runtime':str(runtime),'contained_supervisor':str(base/('readbacks/s07-'+label+'-container'))})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert source.is_dir() and build.is_dir() and not runtime.exists()
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 disk=shutil.disk_usage(base);assert disk.free>=24*1024**3 and memory>=36*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'compiler_parallelism':1,'worker_memory_max_bytes':4*1024**3,'worker_tasks_max':128,'maximum_wall_seconds':21600,'native_gates_disabled':True,'minimum_available_memory_before_start':36*1024**3})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3')
 reservation=registry.reserve('s07-'+label,[{'path':str(p),'access':'write'} for p in [out,source,build,runtime]]+[{'path':str(p),'access':'read'} for p in [bootstrap,donor,framework,vendor]],ttl_seconds=120)
 token=reservation['token'];write('reservation.json',dict(reservation,ledger_schema=1,live_K1_ledger_not_migrated=True,scope='Read/write paths only; actual memory/task cap enforced by the enclosing cgroup. Build only.'))
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 old_closure=inspect_contained(base/'readbacks/s07-csearch-threshold-joint-asan-build-a1-container')
 assert old_closure['all_processes_closed']
 assert git(source,'rev-parse','HEAD')=='9f92a40b97b5868b84b156e38b91903e6b0d8176' and not git(source,'status','--porcelain','--untracked-files=no')
 write('incremental-reuse.json',{'closed_predecessor':old_closure,'old_root':'9f92a40b97b5868b84b156e38b91903e6b0d8176','new_root':root,'source':str(source),'build':str(build),'old_runtime_retained':str(base/'runtime-csearch-threshold-joint-asan-build-a1'),'new_runtime':str(runtime),'production_cpp_and_child_gitlinks_unchanged':True})
 run(['git','-C',source,'fetch','--no-recurse-submodules','--depth','1','--filter=blob:none','origin',root],'fetch-root.log')
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 assert not (source/'.git/objects/info/alternates').exists()
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  key,path=line.split(None,1);destination=source/path;destination.parent.mkdir(parents=True,exist_ok=True)
  wanted=git(source,'rev-parse','HEAD:'+path)
  assert git(destination,'rev-parse','HEAD')==wanted and not git(destination,'status','--porcelain','--untracked-files=no') and not (destination/'.git/objects/info/alternates').exists()
  children[path]=wanted
 run(['git','-C',source,'submodule','init'],'init-submodules.log')
 assert git(source,'rev-parse','HEAD')==root and not git(source,'status','--porcelain','--untracked-files=no') and len(children)==7
 assert children['Libraries/Nmsdk-PulseLib']=='cc97149c90ce98ff24ca688452f4a40d54e0e63d'
 write('source-closure.json',{'root':root,'children':children,'clean':True,'root_code_sparse_omissions':['Docs','Reports'],'all_repositories_without_alternates':True,'source_delivery':'origin shallow root/Pulse; local shallow Git transport for six accepted origin-only donor submodules'})
 assert git(framework,'rev-parse','HEAD')=='58d77fa8070e8cec2dc1ed015d66b454c8d78850' and not git(framework,'status','--porcelain','--untracked-files=no')
 assert git(vendor,'rev-parse','HEAD')=='1971adf55e3ebbfab83771d6174d37b77c352c71' and not git(vendor,'status','--porcelain','--untracked-files=no')
 write('offline-vendor.json',{'path':str(vendor),'commit':git(vendor,'rev-parse','HEAD'),'tracked_clean':True})
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DBUILD_TESTING=ON','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON','-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DRDK_LLM_LLAMA_CPP_DIR='+str(vendor),'-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':list(map(str,args))});run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes());write('build-terminal.json',{'execution':'completed','root':root,'native_gates_executed':False})
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 write('native-runtime.json',snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 write('pending-gates.json',{'status':'not_started','root':root,'declared_focused_tests':44,'declared_full_tests':304,'reason':'Build-only worker. Gate launch requires a separate resource decision after current K1 closes.','scientific_verdict':None})
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 if token and not errors:
  try:
   group=Path('/sys/fs/cgroup')/Path('/proc/self/cgroup').read_text().strip().split('0::',1)[1].lstrip('/')
   members=set()
   for entry in group.rglob('cgroup.procs'):members.update(map(int,entry.read_text().split()))
   write('reservation-release-membership.json',{'control_group':str(group),'members':sorted(members),'current_worker':os.getpid()})
   assert members=={os.getpid()},('descendants_remain',members)
   registry.release(token,note='Build-only worker completed synchronous work; fresh cgroup membership contains only this finalizing owner. No native model gates launched.')
   write('reservation-final.json',registry.inspect())
  except BaseException as error:write('reservation-release-refused.json',{'reason':str(error)});passed=False
 write('terminal.json',{'build_passed':passed,'native_gates_executed':False,'native_models_executed':0,'scientific_verdict':None,'whole_plan_complete':False})
 hashes={}
 if source.exists():
  for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
   for p in (source/prefix).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for name,raw in files.items():info=tarfile.TarInfo(name);info.size=len(raw);archive.addfile(info,io.BytesIO(raw))
 raw=(out/'primary.tar.xz').read_bytes();write('bundle.json',{'kind':'joint_csearch_threshold_asan_build_only','root':root,'build_passed':passed,'native_gates_executed':False,'members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in files.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
