transport_ancestors={'2974822': '312123012', '2974775': '312122920', '1048': '537'}
import pathlib,subprocess,json,os,time,sys,traceback,xml.etree.ElementTree as ET
base=pathlib.Path("/home/user/timelearner-refactor");worker="normal"
source=base/"source-n1-measured-refinement-normal-a1";build=base/"build-n1-measured-refinement-normal-a1";out=base/('readbacks/s01-timing-finite-current-'+worker+'-a1')
runtime=base/('runtime-s01-timing-finite-current-'+worker+'-a1')
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def run(args,name,timeout=300):
 with (out/name).open('wb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
try:
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert pathlib.Path(git(source,'rev-parse','--show-toplevel')).resolve()==source.resolve()
 assert not git(source,'status','--porcelain','--untracked-files=no')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','ebf590082a881cbc8a702bd25f48bfb26b73a50d'],'fetch-root.log')
 root=git(source,'rev-parse','FETCH_HEAD');assert root=='ebf590082a881cbc8a702bd25f48bfb26b73a50d'
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 for child,url in [('Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib'),('Bin','Nmsdk-Bin'),('Rdk','Rdk')]:
  repo=source/child;assert not git(repo,'status','--porcelain','--untracked-files=no')
  wanted=git(source,'rev-parse','HEAD:'+child)
  run(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+url+'.git',wanted],'fetch-'+url+'.log')
  assert git(repo,'rev-parse','FETCH_HEAD')==wanted,'fetch_did_not_resolve_exact_gitlink'
  run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+url+'.log')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 assert not runtime.exists()
 run(['cmake','-S',source,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','--parallel','2'] ,'build.log',7200)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'artifacts')
 result=execute(manifest,['--gtest_filter=TopologiesAndRates/NativeTimingProperties.*','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',300)
 tree=ET.parse(out/'gtest.xml').getroot()
 write('validation.json',{'kind':'timing_property_finite_correction','worker':worker,'source':root,'execution':result,'gtest':tree.attrib,'skipped':len(tree.findall('.//testcase/skipped')),'scientific_verdict':None})
 assert result['execution']=='completed' and result['returncode']==0
 assert tree.attrib['tests']=='4' and tree.attrib['failures']==tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 checks=[]
 for p in sorted((out/'artifacts').glob('timing-*.json')):
  d=json.loads(p.read_text());rows=[r for take in d['takes'] for r in take['checks']]
  assert len(rows)==30 and all(r['rejected'] and r['previous_value_preserved'] for r in rows)
  checks.append({'name':p.name,'checks':len(rows)})
 assert len(checks)==4
 write('property-readback.json',{'checks':checks,'invalid_assignments_rejected_and_preserved':120,'scientific_verdict':None})
 os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native-regression')
 os.environ['TIMELEARNER_ROUNDTRIP_TEST_DIR']=str(out/'roundtrip-regression')
 reg=execute(manifest,['--gtest_filter=RdkLifecycleBoolean.*:TimeLearnerNativeLifecycle.*:TimeLearnerNativeRoundtrip.*:TopologiesAndRates/NativeLearnerExecution.*','--gtest_output=xml:'+str(out/'regression-gtest.xml')],runtime,out/'regression-process',1800)
 rt=ET.parse(out/'regression-gtest.xml').getroot()
 write('regression-validation.json',{'execution':reg,'gtest':rt.attrib,'skipped':len(rt.findall('.//testcase/skipped')),'scientific_verdict':None})
 assert reg['execution']=='completed' and reg['returncode']==0 and rt.attrib['tests']=='21' and rt.attrib['failures']==rt.attrib['errors']=='0' and not rt.findall('.//testcase/skipped')
 assert source_closure(source)==closure
 verify_runtime(manifest)
 write('terminal.json',{'execution':'completed','property_tests':4,'regression_tests':21,'scientific_verdict':None})
 print(json.dumps({'property':tree.attrib,'regression':rt.attrib}),flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
