set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-probe-console-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-posttune-probe-console-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3812820 2>/dev/null; do sleep 10; done
test "$(cat "$base/readbacks/s08-native-posttune-probe-threshold-asan-a1/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
test ! -e "$runtime"
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 6787071ffb102dceb00d476f913b25f4cd025380 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
export TIMELEARNER_POSTTUNE_CONFIG_SOURCE="$TIMELEARNER_POSTTUNE_FIXED_SOURCE"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
filter='NativePostTuneConfiguration.*'
result=execute(runtime,['--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'native.xml')],
 Path(runtime['executable']['path']).parent,out/'process',1800)
x=ET.parse(out/'native.xml').getroot()
assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
assert result['returncode']==0 and result['execution']=='completed' and result['runtime_provenance']=='loaded_files_captured'
names={(s.attrib['name'],t.attrib['name']) for s in x.findall('testsuite') for t in s.findall('testcase')}
assert len(names)==int(x.attrib['tests'])==5
report={'kind':'native_post_tune_probe_threshold_gate','schema_version':1,'native_tests':5,
 'native_seconds':float(x.attrib['time']),'test_names':[list(n) for n in sorted(names)],
 'runtime_provenance':result['runtime_provenance'],'native_execution_attested':False,'scientific_verdict':None}
(out/'native-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
export TIMELEARNER_PROBE_THRESHOLD_ARTIFACTS="$base/readbacks/s08-native-posttune-probe-threshold-asan-a1/native"
export TIMELEARNER_PROBE_THRESHOLD_SOURCE="$base/readbacks/s08-native-posttune-fixed-console-asan-a1/runs"
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$TIMELEARNER_PROBE_THRESHOLD_ARTIFACTS"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$out/fixtures"
python3 -u - <<'PY' > "$out/reader.log" 2>&1
import os,json,shutil,unittest,time
from pathlib import Path
root=Path(os.environ['TIMELEARNER_PROBE_THRESHOLD_SOURCE']);target=Path(os.environ['TIMELEARNER_FIXED_POSTTUNE_SOURCE'])
for name in ['Classic-auto_metric','Branch-synthetic']:
 shutil.copytree(root/(name+'-legacy'),target/name)
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in [
 'test_posttune_probe_threshold_evidence','test_fixed_posttune_evidence'])
begin=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt={'tests':result.testsRun,'seconds':time.monotonic()-begin,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'scientific_verdict':None}
(Path(os.environ['OUT'])/'reader-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==10 and not result.skipped
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/console-runtime-before.json"
python3 -u - <<'PY' > "$out/console-jobs.log" 2>&1
import copy,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_calibration_worker import run_job,audit_run_manifest
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);original=Path(os.environ['TIMELEARNER_PROBE_THRESHOLD_SOURCE'])
jobs=out/'jobs';jobs.mkdir();records=[]
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
runtime=load(out/'console-runtime-before.json')
for top,name in [('Classic','Classic-auto_metric'),('Branch','Branch-synthetic')]:
 source=original/(name+'-legacy');old=load(source/'run-manifest.json');source_state=source/old['source_package_path']
 original_job=load(source/'input/job.json')
 for variant in ['legacy','inherited','fixed-probe','calibrated-probe']:
  job=copy.deepcopy(original_job)
  if variant!='legacy':
   job['schema_version']=3
   job['post_tune'].update(schema_version=3,finalization='calibrate',weight_probe_threshold=None)
  if variant in {'fixed-probe','calibrated-probe'}:
   job['post_tune'].update(weight_probe_threshold=2.,mode='keep_done',canonical_floor=0.,canonical_last=0.,resistance_bounds=[])
   if variant=='fixed-probe':
    job['post_tune']['finalization']='keep_fixed_threshold';job['thresholds']=[];job['maximum_candidates']=0
  job['sha256']=sha({k:v for k,v in job.items() if k!='sha256'})
  path=jobs/(top+'-'+variant+'.json');write(path,job)
  folder=out/'runs'/(top+'-'+variant)
  run_job(path,source_state,out/'console-runtime-before.json',folder,900,post_tune=True)
  proof=audit_run_manifest(folder/'run-manifest.json',post_tune=True)
  report=load(folder/'native/transaction.json')
  assert proof['run_evidence_consistent']
  if variant in {'legacy','inherited'}:
   assert (folder/'native/transaction.json').read_bytes()==(source/'native/transaction.json').read_bytes()
   assert (folder/'native/model.json').read_bytes()==(source/'native/model.json').read_bytes()
  if variant=='fixed-probe':
   assert report['status']=='weights_selected' and report['final_threshold_responses_observed']
  if variant=='calibrated-probe':
   assert report['status']==('calibrated' if top=='Classic' else 'search_unresolved')
  records.append({'case':top+'-'+variant,'status':report['status'],'report_schema':report['schema_version'],'run_evidence_consistent':True})
  print(json.dumps(records[-1]),flush=True)
 # Actual malformed Console invocations must fail before creating output.
 for variant,value in [('bad-bool',True),('bad-string','2')]:
  job=copy.deepcopy(load(jobs/(top+'-fixed-probe.json')));job['post_tune']['weight_probe_threshold']=value
  job['sha256']=sha({k:v for k,v in job.items() if k!='sha256'});path=jobs/(top+'-'+variant+'.json');write(path,job)
  result=execute(runtime,['--app-ini',runtime['app_ini']['path'],'--timelearner-posttune',str(path),'--timelearner-output',str(out/(top+'-'+variant))],
   Path(runtime['executable']['path']).parent,out/'negative-process'/(top+'-'+variant),120)
  assert result['returncode']==2 and result['execution']=='process_error' and not (out/(top+'-'+variant)).exists()
write(out/'console-validation.json',{'cases':records,'actual_malformed_cases':4,'scientific_verdict':None})
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/console-runtime-after.json"
cmp "$out/console-runtime-before.json" "$out/console-runtime-after.json"

