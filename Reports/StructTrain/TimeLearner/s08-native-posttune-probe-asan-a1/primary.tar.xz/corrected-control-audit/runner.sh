set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-probe-validation-asan-a1"
repo="$base/source-rdk-bool-evidence-asan-a2";work="$base/source-probe-threshold-validation-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3822935 2>/dev/null && test ! -f "$base/readbacks/s08-native-posttune-probe-console-asan-a1/process-exit-status.txt"; do sleep 10; done
test "$(cat "$base/readbacks/s08-native-posttune-probe-console-asan-a1/process-exit-status.txt")" = 1
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 7ca4c78f68392a2218767522949b042e185b3fb9 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone;git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work";export PYTHONDONTWRITEBYTECODE=1;export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
git rev-parse HEAD > "$out/auditor-source-root.txt"
sha256sum Scripts/StructTrain/TimeLearner/posttune_probe_threshold_controls.py > "$out/auditor-code.sha256"
python3 -u -m Scripts.StructTrain.TimeLearner.posttune_probe_threshold_controls \
 "$base/readbacks/s08-native-posttune-probe-console-asan-a1/runs" \
 "$base/readbacks/s08-native-posttune-fixed-console-asan-a1/runs" \
 "$base/readbacks/s08-native-posttune-probe-console-asan-a1/console-runtime-before.json" \
 "$out/controls" > "$out/validation.log" 2>&1
