from pathlib import Path
import json,time,os
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s02-obsolete-schema4-build-cache-a4';assert os.getuid()==0
assert out.resolve()==out and not out.is_symlink()
ready=out/'ready-for-readonly-process-audit.json';started=time.monotonic()
while not ready.exists():
 assert time.monotonic()-started<150,'worker preflight has not reached read-only audit boundary'
 time.sleep(1)
v=json.loads(ready.read_text());target=[str(base/n) for n in ['build-capacitance-schema4-normal-j1','build-capacitance-schema4-normal-j2']];assert v['targets']==target
worker=Path('/proc',str(v['pid']));assert (worker/'stat').read_text().rsplit(') ',1)[1].split()[19]==str(v['start_ticks'])
checked=[];refs=[];errors=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=1000:continue
  f=(p/'stat').read_text().rsplit(') ',1)[1].split()
  if f[0] in ['Z','X']:continue
  values={'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'),'cwd':str((p/'cwd').resolve(strict=True)),'exe':str((p/'exe').resolve(strict=True)),'maps':(p/'maps').read_text()}
  matched=[k for k,text in values.items() if any(d in text for d in target)]
  checked.append({'pid':int(p.name),'start_ticks':f[19]})
  if matched:refs.append({'pid':int(p.name),'start_ticks':f[19],'fields':matched})
 except (FileNotFoundError,ProcessLookupError):continue
 except PermissionError as e:errors.append({'pid':int(p.name),'reason':str(e)})
result={'role':'read-only kernel process-file audit; no filesystem deletion or model execution','worker_pid':v['pid'],'worker_start_ticks':v['start_ticks'],'nonce':v['nonce'],'targets':target,'checked_user_processes':checked,'references':refs,'read_errors':errors,'safe':not refs and not errors,'completed_unix_seconds':time.time()}
p=out/'readonly-process-audit.json';assert not p.exists()
with p.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
os.chmod(p,0o644)
print(json.dumps({'safe':result['safe'],'checked_user_processes':len(checked),'references':refs,'read_errors':errors,'password_stored':False}))
