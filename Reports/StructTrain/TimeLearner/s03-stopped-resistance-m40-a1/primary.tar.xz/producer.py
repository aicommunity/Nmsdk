ASAN=True
from pathlib import Path
import os,sys,subprocess,json,traceback,hashlib,tarfile,unittest
base=Path('/media/user/Data/TimeLearnerRefactor' if ASAN else '/home/user/timelearner-refactor');label='asan' if ASAN else 'normal'
root='87addb4078335344630828a760d6739fc88a7a0c';out=base/('readbacks/s03-native-matched-analysis-'+label+'-a3');out.mkdir(exist_ok=False)
sdk=base/('analysis-native-matched-'+label+'-a3');donor=base/('source-initial-threshold-asan-a2' if ASAN else 'source-initial-threshold-normal-a4')
source=base/('readbacks/s03-native-probe-matched-'+label+'-a1');native=base/('readbacks/s03-native-probe-stopped-'+label+'-a3')
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 assert json.loads((source/'terminal.json').read_text())['status']=='passed'
 owner=json.loads((source/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/');git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git' if ASAN else str(base/'git-relay-threshold-archive-normal-a1.git'),root);git(sdk,'checkout','--detach',root)
 sys.path.insert(0,str(sdk))
 from Scripts.StructTrain.TimeLearner.matched_resistance_analysis import analyze
 from Scripts.StructTrain.TimeLearner.primary_reuse import pack,restore
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import audit_run_manifest
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 before=_inventory(source)
 previous=base/('readbacks/s03-native-matched-analysis-'+label+'-a1')
 assert git(sdk,'show','ed4df5affc4683f616c42c9611f31ab560aec9af:Scripts/StructTrain/TimeLearner/matched_resistance_analysis.py')==git(sdk,'show',root+':Scripts/StructTrain/TimeLearner/matched_resistance_analysis.py')
 for name in ['analysis.json','matched-readers.json','matched-readers.log']:(out/name).write_bytes((previous/name).read_bytes())
 result=json.loads((out/'analysis.json').read_text());assert result['all_conditions_matched']
 assert json.loads((out/'matched-readers.json').read_text())=={'tests':4,'errors':0,'failures':0,'skipped':0}
 write('reused-matched-analysis.json',{'code_and_test_source_unchanged':True,'prior_readback':str(previous),'native_rerun':False})
 receipt=pack(source,sdk,'e5fa71d745119af0d818059f497dd226f4c7c25d','Reports/StructTrain/TimeLearner/s07-stock-threshold-pair-normal-a3/primary.tar.xz',out/'compact-native')
 write('pack-receipt.json',receipt);print('PACKED',receipt,flush=True)
 receipt=restore(out/'compact-native',sdk,out/'restored');write('restore-receipt.json',receipt)
 restored=[]
 for name in ['Classic-threshold-training100-resistance','Branch-threshold-training100-resistance']:
  checked=audit_run_manifest(out/'restored/runs'/name/'run-manifest.json');assert checked['run_evidence_consistent'];restored.append(name)
 write('restored-production-readback.json',{'passed':restored,'all_primary_files_verified_by_restore':True,'native_rerun':False})
 os.environ['TIMELEARNER_REUSE_BUNDLE']=str(out/'compact-native');os.environ['TIMELEARNER_REUSE_RESTORED']=str(out/'restored');os.environ['TIMELEARNER_REUSE_REPOSITORY']=str(sdk)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_primary_reuse.PrimaryReuseTest')
 with (out/'reuse-readers.log').open('w') as log:tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('reuse-readers.json',{'tests':tests.testsRun,'errors':len(tests.errors),'failures':len(tests.failures),'skipped':len(tests.skipped)});assert tests.wasSuccessful() and not tests.skipped

 assert before==_inventory(source);write('source-unchanged.json',{'same':True,'files':len(before)})
 (out/'source-build').mkdir()
 for name in ['CMakeCache.txt','build.log','configure.log','closed-source-lease.json','producer.py','source-hashes.json']:
  if (native/name).is_file():(out/'source-build'/name).write_bytes((native/name).read_bytes())
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'native_root':'a42ff9a0aa8cf1641f87fec1524a272b5430aa5f','scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (sdk/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 # The restored cache is deliberately excluded: all its bytes are represented
 # by the compact archive plus the immutable referenced Git archive.
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink() and not p.is_relative_to(out/'restored')};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'native_stopped_matched_analysis_compact','root':root,'native_root':'a42ff9a0aa8cf1641f87fec1524a272b5430aa5f','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
