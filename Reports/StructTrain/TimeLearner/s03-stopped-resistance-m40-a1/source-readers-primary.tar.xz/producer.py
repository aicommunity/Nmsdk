ASAN=True
from pathlib import Path
import os,sys,subprocess,json,traceback,time,hashlib,tarfile,unittest
base=Path('/media/user/Data/TimeLearnerRefactor' if ASAN else '/home/user/timelearner-refactor');label='asan' if ASAN else 'normal'
root='8f0a6bded6a5a9692cc480e6fac79b8414a7dbeb';native_root='a42ff9a0aa8cf1641f87fec1524a272b5430aa5f'
out=base/('readbacks/s03-native-stopped-readers-'+label+'-a1');out.mkdir(exist_ok=False)
sdk=base/('analysis-native-stopped-readers-'+label+'-a1');donor=base/('source-initial-threshold-asan-a2' if ASAN else 'source-initial-threshold-normal-a4')
source=base/('readbacks/s03-native-probe-stopped-'+label+'-a3');cold=base/('readbacks/s03-native-characterization-asan-a3' if ASAN else 'readbacks/s03-native-characterization-normal-a6')
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/')
 git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git' if ASAN else str(base/'git-relay-threshold-archive-normal-a1.git'),root);git(sdk,'checkout','--detach',root)
 changed=git(sdk,'diff','--name-only',native_root,root).splitlines();assert changed==['Scripts/StructTrain/TimeLearner/tests/test_native_stopped_probe.py'],changed
 write('native-source-reuse.json',{'native_root':native_root,'readers_root':root,'only_added_test':changed,'cpp_rerun':False})
 owner=json.loads((source/'owned-supervisor.json').read_text());limit=time.monotonic()+3600
 while True:
  try:alive=Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]==owner['start_ticks']
  except FileNotFoundError:alive=False
  if not alive:break
  assert time.monotonic()<limit,'source observation timeout; do not restart native job'
  time.sleep(5)
 assert json.loads((source/'terminal.json').read_text())['status']=='passed'
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 manifest=load(source/'runtime.json');write('runtime.json',manifest);runtime=Path(manifest['executable']['path']).parent;before=_inventory(runtime)
 (out/'cold-regression').mkdir();cold_results=[]
 for topology in ['Classic','Branch']:
  name=topology+'-v2-full';old=cold/'runs'/name/'native';destination=out/'cold-regression'/name
  result=run_job('probe',cold/'jobs'/(name+'.json'),None,out/'runtime.json',destination,120)
  assert result['validity']=='valid',(name,result['execution'],result['validity'])
  assert audit_run_manifest(destination/'run-manifest.json')['run_evidence_consistent']
  equal={n:(old/n).read_bytes()==(destination/'native'/n).read_bytes() for n in ['probe_trial_1.csv','probe_trial_1.json','initial-state.json','final-state.json']};assert all(equal.values()),equal
  cold_results.append({'name':name,'equal_primary_files':equal})
 write('cold-primary-equality.json',{'rows':cold_results})
 os.environ['TIMELEARNER_STOPPED_PROBE_CORPUS']=str(source)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_stopped_probe.NativeStoppedProbeTest')
 with (out/'readers.log').open('w') as log:tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('readers.json',{'tests':tests.testsRun,'errors':len(tests.errors),'failures':len(tests.failures),'skipped':len(tests.skipped)});assert tests.wasSuccessful() and not tests.skipped
 assert before==_inventory(runtime);write('runtime-unchanged.json',{'same':True,'files':len(before)})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (sdk/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'native_stopped_probe_readers','root':root,'native_root':native_root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
