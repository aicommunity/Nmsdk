set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s09-native-live-training-worker-reader-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
producer="$base/readbacks/s09-native-live-training-worker-asan-a1"
while test ! -f "$producer/process-exit-status.txt";do kill -0 89567;sleep 10;done
test "$(cat "$producer/process-exit-status.txt")" = 0
cd "$base/source-live-training-worker-reader-asan-a1"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_LIVE_PIPELINE_CORPUS="$base/readbacks/s09-native-live-training-worker-asan-a1/corpus"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import hashlib,json,os,time,unittest
start=time.monotonic();source=Path(os.environ['TIMELEARNER_LIVE_PIPELINE_CORPUS']);out=Path(os.environ['OUT'])
def snapshot():return {p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}
before=snapshot()
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_pipeline_worker'))
assert r.wasSuccessful() and r.testsRun==4 and not r.skipped
assert snapshot()==before
value={'kind':'native_live_pipeline_complete_reader','schema_version':1,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),
 'skipped':len(r.skipped),'operations_audited':14,'malformed_native_controls':16,'malformed_plan_controls':24,'malformed_packaged_controls':5,
 'source_files_unchanged':len(before),'seconds':time.monotonic()-start,'reader_root':'9554c0e465b5ce72a989c3d34edfd63dc0e5df2b',
 'new_numerical_runs':0,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)
PY
