from pathlib import Path
import json,os,subprocess,hashlib,shutil,traceback,time
base=Path('/media/user/Data/TimeLearnerRefactor');sdk=base/'source-initial-threshold-asan-a2';out=base/'readbacks/s02-rdk-startup-fresh-closure-a1';out.mkdir(exist_ok=False)
root='15b7dec4e022b899ce2426a4dda6640f18b31987';clone=base/'closure-rdk-startup-a1'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.STDOUT,text=True).strip()
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid())});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert shutil.disk_usage(base).free>=16*1024**3
 for folder in ['s02-native-event-log-asan-a3','s02-native-event-calibration-asan-a1','s02-rdk-default-startup-asan-a1']:
  owner=json.loads((base/'readbacks'/folder/'owned-supervisor.json').read_text())
  try:assert ticks(owner['pid'])!=owner['start_ticks']
  except FileNotFoundError:pass
 git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root)
 git(sdk/'Rdk','fetch','--no-recurse-submodules','https://github.com/aicommunity/Rdk.git','10e9d05aa658dd2203c89bc84ba9166595b50014')
 subprocess.run(['git','clone','--shared','--no-checkout',str(sdk),str(clone)],check=True)
 patterns=['/Docs/','/Scripts/','/App/','/Tests/','/CMakeLists.txt','/cmake/','/.gitmodules','/Libraries/','/Rdk/','/Bin/']
 for f in ['normal','asan']:
  patterns += ['/Reports/StructTrain/TimeLearner/'+n+'/' for n in ['s02-native-event-log-'+f+'-a3','s02-rdk-default-startup-'+f+'-a1','s02-native-event-calibration-'+f+'-a1']]
 git(clone,'sparse-checkout','set','--no-cone',*patterns);git(clone,'checkout','--detach',root)
 children=[]
 for line in git(clone,'ls-tree','-r','HEAD').splitlines():
  header,path=line.split('\t',1);mode,kind,sha=header.split()
  if mode!='160000':continue
  donor=sdk/path;destination=clone/path
  assert git(donor,'cat-file','-t',sha)=='commit'
  subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(destination)],check=True)
  git(destination,'checkout','--detach',sha);assert not git(destination,'status','--porcelain','--untracked-files=all')
  children.append({'path':path,'commit':sha,'actual_head':git(destination,'rev-parse','HEAD'),'working_tree_clean':True})
 assert len(children)==7
 git(clone,'submodule','init')
 status=git(clone,'submodule','status','--recursive');assert len(status.splitlines())==7 and all(not line.startswith(('-', '+', 'U')) for line in status.splitlines())
 assert not git(clone,'status','--porcelain','--ignore-submodules=none','--untracked-files=all')
 for f in ['normal','asan']:
  for folder in ['s02-native-event-log-'+f+'-a3','s02-rdk-default-startup-'+f+'-a1','s02-native-event-calibration-'+f+'-a1']:
   p=clone/'Reports/StructTrain/TimeLearner'/folder;bundle=json.loads((p/'bundle.json').read_text());assert hashlib.sha256((p/'primary.tar.xz').read_bytes()).hexdigest()==bundle['archive_sha256']
 write('closure.json',{'kind':'fresh_recursive_git_checkout','root':root,'children':children,'root_working_tree_clean':True,'submodule_status':status,'root_sparse_patterns':patterns,'all_six_primary_archives_present_and_hash_valid':True,'build_or_experiment_performed':False,'scientific_verdict':None})
 write('terminal.json',{'status':'passed'})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()});write('terminal.json',{'status':'not_accepted'})
print('CLOSED',flush=True)
