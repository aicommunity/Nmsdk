from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'/home/user/timelearner-refactor/source-contained-runner-a2')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-frzopquf/leases.sqlite3',capacity=None)
lease=r.reserve("crashed-worker",[{"path":'/tmp/timelearner-contained-frzopquf/scratch',"access":"write"}],ttl_seconds=.001,demands=None)
Path('/tmp/timelearner-contained-frzopquf/lease.json').write_text(json.dumps(lease))
