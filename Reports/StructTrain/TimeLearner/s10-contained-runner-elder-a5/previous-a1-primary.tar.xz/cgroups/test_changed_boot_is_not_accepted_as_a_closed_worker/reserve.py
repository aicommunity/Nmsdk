from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'/home/user/timelearner-refactor/source-contained-runner-a1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-81_daw9f/leases.sqlite3',capacity=None)
lease=r.reserve("crashed-worker",[{"path":'/tmp/timelearner-contained-81_daw9f/scratch',"access":"write"}],ttl_seconds=.001,demands=None)
Path('/tmp/timelearner-contained-81_daw9f/lease.json').write_text(json.dumps(lease))
