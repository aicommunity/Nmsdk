set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-calibration-ownership-baseline-normal-a1"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-calibration-ownership-baseline-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git e2a1293768bbd09af2c6ce040b76d6670dbfc79b > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach e2a1293768bbd09af2c6ce040b76d6670dbfc79b >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native";cd "$runtime"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$base/readbacks/s08-calibration-grid-normal-a2/native"
set +e
./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationOwnership.*' --gtest_output="xml:$out/native.xml" > "$out/native.log" 2>&1
status=$?
set -e
echo "$status" > "$out/native-exit-status.txt"
exit "$status"
