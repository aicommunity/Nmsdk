set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s08-calibration-ownership-audit-normal-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 1260917 2>/dev/null;do sleep 10;done
test "$(cat /home/user/timelearner-refactor/readbacks/s08-calibration-ownership-fixed-normal-a1/process-exit-status.txt)" = 0
cd /home/user/timelearner-refactor/source-calibration-ownership-audit-normal-a1
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_CALIBRATION_OWNERSHIP_DIR=/home/user/timelearner-refactor/readbacks/s08-calibration-ownership-fixed-normal-a1/native
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE=/home/user/timelearner-refactor/readbacks/s08-calibration-grid-normal-a2/native
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import os,json,sys,unittest
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_calibration_ownership_evidence')
assert suite.countTestCases()==4
result=unittest.TextTestRunner(verbosity=2).run(suite)
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'b69c66fad91a67c67e8e32772fde245791d1c104','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'scientific_verdict':None},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun==4 and not result.skipped else 1)
PY
