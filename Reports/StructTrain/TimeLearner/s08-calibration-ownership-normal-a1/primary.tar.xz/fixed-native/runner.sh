set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-calibration-ownership-fixed-normal-a1"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-calibration-ownership-fixed-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-calibration-ownership-baseline-normal-a1/process-exit-status.txt")" = 1
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 0b89622a25785cbe1055721832da55933cb4988c > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach 0b89622a25785cbe1055721832da55933cb4988c >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native";cd "$runtime"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$base/readbacks/s08-calibration-grid-normal-a2/native"
set +e
./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationOwnership.*' --gtest_output="xml:$out/native.xml" > "$out/native.log" 2>&1
status=$?
set -e
echo "$status" > "$out/native-exit-status.txt"
test "$status" = 0
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import os,json,xml.etree.ElementTree as E
from pathlib import Path
out=Path(os.environ['OUT']);r=E.parse(out/'native.xml').getroot()
cases={(c.attrib['classname'],c.attrib['name']) for c in r.iter('testcase')}
expected={('NativeCalibrationOwnership',top+case) for top in ('Classic','Branch') for case in ('ForeignResult','ConsumedResult','SamePackageImport','NormalFlow')}
assert cases==expected and len(list(r.iter('testcase')))==8
assert not list(r.iter('failure')) and not list(r.iter('error')) and not list(r.iter('skipped'))
(out/'validation.json').write_text(json.dumps({'native_cases':8,'root':'0b89622a25785cbe1055721832da55933cb4988c','scope':'real saved model ownership and normal grid flow; no fresh Train','scientific_verdict':None},indent=2)+'\n')
PY
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_text())))}))
PY
