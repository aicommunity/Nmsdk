import pathlib,json,sys,os,time,traceback,hashlib
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/'readbacks').resolve() and out.name=='s07-measured-length-positive-asan-a1'
assert {p.name for p in out.iterdir()} <= {'job.py','pid.json','supervisor.log'}
parent=base/'readbacks/s07-measured-length-native-asan-a2'
source=base/'source-n1-measured-refinement-asan-a1';analysis=base/'source-measured-length-analysis-a2'
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
try:
 start=time.monotonic()
 while not (parent/'terminal.json').exists():
  assert not (parent/'exception.json').exists()
  owned=json.loads((parent/'pid.json').read_text());p=pathlib.Path('/proc')/str(owned['pid'])/'stat'
  assert p.exists() and p.read_text().rsplit(') ',1)[1].split()[19]==str(owned['start_ticks'])
  assert time.monotonic()-start<14400;time.sleep(2)
 sys.dont_write_bytecode=True;sys.path.insert(0,str(analysis))
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 closure=source_closure(source);write('source.json',closure)
 runtime_path=parent/'current-runtime.json';runtime=json.loads(runtime_path.read_text());verify_runtime(runtime)
 write('runtime.json',runtime)
 corpus=out/'corpus';corpus.mkdir();(corpus/'inputs').mkdir();records=[]
 for topology in ['Classic','Branch']:
  name='native-n1-mesh-'+topology+'-isi030'
  original=base/'readbacks/s07-native-n1-refined-asan-a1/corpus'/name
  assert audit_run_manifest(original/'run-manifest.json')['run_evidence_consistent']
  raw=(original/'input/job.json').read_bytes();path=corpus/'inputs'/(name+'.json');path.write_bytes(raw)
  r=run_job('train',path,None,out/'runtime.json',corpus/name,1800)
  assert r['execution']=='completed' and r['validity']=='valid'
  assert audit_run_manifest(corpus/name/'run-manifest.json')['run_evidence_consistent']
  summary=json.loads((corpus/name/'native/train_learned_summary.json').read_text())
  assert summary['outcome']=='exact' and summary['certificate'] is not None
  old=json.loads((original/'native/train_learned_summary.json').read_text())
  assert summary['actual_parameters']==old['actual_parameters'] and summary['references']==old['references']
  records.append({'name':name,'source_input_sha256':hashlib.sha256(raw).hexdigest(),'source_primary':str(original),'candidates':summary['candidates'],'certificate':summary['certificate'],'scientific_verdict':None})
  print('positive Exact '+topology,flush=True)
 (corpus/'index.json').write_text(json.dumps({'kind':'native_n1_proposal_controls','schema_version':1,'records':records,'scientific_verdict':None},indent=2)+'\n')
 assert source_closure(source)==closure;verify_runtime(runtime)
 write('terminal.json',{'execution':'completed','positive_native_trains':2,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
