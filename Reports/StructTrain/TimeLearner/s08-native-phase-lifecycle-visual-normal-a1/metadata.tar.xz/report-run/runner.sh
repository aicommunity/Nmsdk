set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-phase-lifecycle-report-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git ba33ee20e14f6716dac289ed698790c374e0bfea 005e105e248b2f7e0c0151fd94e2edc1c3775c24 > "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$repo" archive ba33ee20e14f6716dac289ed698790c374e0bfea Scripts | tar -x -C "$out/source"
cd "$out/source"
export OUT="$out" REPO="$repo" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/extract.log" 2>&1
import hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
out=Path(os.environ['OUT']);repo=Path(os.environ['REPO'])
commit='005e105e248b2f7e0c0151fd94e2edc1c3775c24';prefix='Reports/StructTrain/TimeLearner/s08-native-phase-lifecycle-interrupt-normal-a1/'
blob=lambda name:subprocess.check_output(['git','-C',str(repo),'show',commit+':'+prefix+name])
m=json.loads(blob('manifest.json'));raw=blob('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
expected={r['path']:r for r in m['files']};assert len(expected)==146
data=out/'data';data.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
 for member in tar:
  assert member.isfile() and member.name in expected
  relative=Path(member.name);assert not relative.is_absolute() and '..' not in relative.parts
  raw=tar.extractfile(member).read();r=expected.pop(member.name)
  assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  p=data/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert not expected
for r in m['files']:
 raw=(data/r['path']).read_bytes();assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
print('all 146 Git members checked twice')
PY
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$out/data/fixtures"
export TIMELEARNER_PHASE_LIFECYCLE_ARTIFACTS="$out/data/execution/native"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$out/data/fixtures"
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$out/data/execution/regression"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_phase_lifecycle_evidence Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence -v > "$out/reader.log" 2>&1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.calibration_transaction_evidence import audit_native_calibration_transaction
from Scripts.StructTrain.TimeLearner.posttune_transaction_evidence import audit_posttune_transaction
from Scripts.StructTrain.TimeLearner.calibration_transaction_reports import render_calibration_transaction
from Scripts.StructTrain.TimeLearner.__main__ import main
out=Path(os.environ['OUT']);root=out/'data/execution/native'
sources={}
for name in ['Classic-auto_metric','Branch-synthetic']:
 folder=out/'data/fixtures'/name
 p=folder/load(folder/'run-manifest.json')['source_package_path'];sources[load(p)['sha256']]=p
reports=out/'reports';reports.mkdir();inputs=out/'render-inputs';inputs.mkdir();rows=[];pairs=0
write=lambda p,v:p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
paths=sorted(root.glob('*.json'));assert len(paths)==16
for path in paths:
 wrapper=load(path);r=wrapper['transaction'];source=sources[r['source_recognition']['source_solo']['sha256']]
 raw=inputs/path.name;write(raw,r)
 target=reports/path.stem;print('BEGIN',path.stem,flush=True)
 if wrapper['controller']=='threshold':
  proof=audit_native_calibration_transaction(r,load_case(source))
  result=render_calibration_transaction(raw,target)
 else:
  proof=audit_posttune_transaction(r,load_case(source))
  assert main(['report',str(raw),'--format','posttune-transaction','--source-solo',str(source),'--output',str(target)])==0
  result=load(target/'manifest.json')
 assert r['status']=='recovery_required' and not r['source_restored']
 pairs+=result['trial_soma_pairs']
 write(target/'source-binding.json',{'source_bundle_commit':'005e105e248b2f7e0c0151fd94e2edc1c3775c24',
  'wrapper_path':path.relative_to(out/'data').as_posix(),'wrapper_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
  'transaction_sha256':r['sha256'],'source_solo_sha256':r['source_recognition']['source_solo']['sha256'],
  'source_audit':proof,'native_execution_verified':False,'owner_restoration_verified':False,'evaluation_verdict':None})
 rows.append({'name':path.stem,'controller':wrapper['controller'],'operation':wrapper['operation'],
              'trial_soma_pairs':result['trial_soma_pairs'],'status':r['status']})
 sums={p.relative_to(target).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.rglob('*')) if p.is_file() and p!=target/'SHA256SUMS.json'}
 write(target/'SHA256SUMS.json',sums)
 print('END',path.stem,result['trial_soma_pairs'],flush=True)
assert len(rows)==16 and pairs==20,(len(rows),pairs)
write(out/'validation.json',{'renderer_root':'ba33ee20e14f6716dac289ed698790c374e0bfea',
 'source_bundle':'005e105e248b2f7e0c0151fd94e2edc1c3775c24','reports':16,'trial_soma_pairs':pairs,'rows':rows,
 'full_visual_acceptance':False,'owner_restoration_verified':False,'scientific_verdict':None})
PY
