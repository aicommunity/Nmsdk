set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s07-n0-candidate-order-publish-normal-a2"
job="$base/readbacks/s07-n0-candidate-order-fixed-normal-a2"
reader="$base/readbacks/s07-n0-candidate-order-reader-normal-a2"
pub="$base/source-n0-candidate-normal-proof-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
for root in "$job" "$reader";do
 while test ! -f "$root/process-exit-status.txt";do
  kill -0 "$(cat "$root/supervisor.pid")";sleep 10
 done
 test "$(cat "$root/process-exit-status.txt")" = 0
done
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 40000000
export BASE="$base" OUT="$out" JOB="$job" READER="$reader" PUB="$pub"
python3 -u - <<'PY' > "$out/package.log" 2>&1
from pathlib import Path
import os,json,hashlib,tarfile,xml.etree.ElementTree as ET
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);job=Path(os.environ['JOB']);reader=Path(os.environ['READER']);pub=Path(os.environ['PUB'])
validation=json.loads((reader/'validation.json').read_text())
assert validation['tests']==4 and validation['native_cases_verified']==31 and validation['training_phases_verified']==4
process=json.loads((job/'process/result.json').read_text())
assert process['execution']=='completed' and process['returncode']==0 and process['runtime_provenance']=='loaded_files_captured'
assert (job/'runtime-before.json').read_bytes()==(job/'runtime-after.json').read_bytes()
xml=ET.parse(job/'native.xml').getroot();assert int(xml.attrib['tests'])==31 and int(xml.attrib['failures'])==0
dest=pub/'Reports/StructTrain/TimeLearner/s07-n0-candidate-order-normal-a2';dest.mkdir(parents=True)
members={}
with tarfile.open(dest/'primary.tar.xz','w:xz',preset=6) as arc:
 for root in (job,reader):
  for path in sorted(root.rglob('*')):
   if path.is_file():
    assert not path.is_symlink()
    name=root.name+'/'+path.relative_to(root).as_posix()
    members[name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
    arc.add(path,arcname=name,recursive=False)
outcomes=[]
for topology in ('Classic','Branch'):
 for phase in ('automatic_service','automatic_cold_service'):
  name=topology+'_2000_N0_'+phase+'_training_summary.json'
  value=json.loads((job/'native-evidence'/name).read_text())
  assert value['outcome']=='search_unresolved' and value['certificate_matches_actual_model'] is True and value['certificate']['exact'] is False
  outcomes.append({'name':name,'outcome':value['outcome'],'model_revision':value['actual_model_revision'],'reference_probes':value['reference_probes'],'search_probes':value['search_probes']})
m={'kind':'n0_candidate_order_complete_proof','schema_version':1,'host':'10.245.1.11','source_root':'942e5df4559467a9a19c56755f945ce6501e7780','source_pulse':'c25db29404b544311a3256336c0c43991a384e12','reader_root':'a86f96ee5d015b304c63e7070b733477ed69891b','native_cases':31,'reader':validation,'process':process,'training_outcomes':outcomes,'members':members,'scientific_verdict':None}
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(dest/'README.md').write_text('N0 informed candidate ordering: normal scoped regression\n\nAll31 declared native cases completed without failures or skips. The unchanged runtime/executable was reused after the separately retained300-second timeout, with a3600-second wall limit. Four independent reader checks verified the exact JUnit set, all four warm/cold Classic/Branch native N0 training phases, every phase JSON/CSV and model-bound reference/candidate/final-certificate evidence, plus corrupted actual-data controls. The reader verified source files unchanged. All five new controlled-kernel ordering cases pass; native model editors cover both topologies at2000/20000Hz. Four real2000Hz N0 training controls retain SearchUnresolved and fresh negative certificates, not classification success. No scientific or full-stage7 verdict is inferred. Core CapturedPerInput targets, tolerances, anchor and native scheduler contracts are preserved. Temporal report acceptance remains pending. Original build/source closure and initial failed-budget receipt are in prior normal proof941969016c577aef6fa4dc4deca1e1d3ab3b27c8. Full primary data, actual models, process/runtime receipts and complete reader are archived here.\n')
(dest/'SHA256SUMS.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir()) if p.is_file()},indent=2)+'\n')
print(json.dumps({'members':len(members),'raw_bytes':sum(r['bytes'] for r in members.values()),'archive_bytes':(dest/'primary.tar.xz').stat().st_size,'reader':validation}),flush=True)
PY
git -C "$pub" add --sparse -f Reports/StructTrain/TimeLearner/s07-n0-candidate-order-normal-a2
git -C "$pub" -c user.name=Codex -c user.email=codex@openai.com commit -m "Preserve full normal N0 regression and independent actual-data gate"
git -C "$pub" -c push.recurseSubmodules=no push git@github.com:aicommunity/Nmsdk.git HEAD:refs/heads/codex/timelearner-n0-normal-budget-proof
git -C "$pub" rev-parse HEAD > "$out/published-commit.txt"
