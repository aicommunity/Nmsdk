import subprocess
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-bwbz_uu0/child').write_text(str(p.pid))
