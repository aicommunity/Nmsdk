set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s09-native-pipeline-controls-normal-a2
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /home/user/timelearner-refactor/source-native-pipeline-cli-normal-a1
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_NATIVE_PIPELINE_CLI_DIR=/home/user/timelearner-refactor/readbacks/s09-native-pipeline-cli-normal-a2
export TIMELEARNER_PIPELINE_CONTROL_OUTPUT="$out/native"
export TIMELEARNER_PIPELINE_TRAINING_CONTROL_OUTPUT="$out/native-training"
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,unittest
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_pipeline_worker')
r=unittest.TextTestRunner(verbosity=2).run(suite)
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'b839e87952a0f3e04e30fd13474567371e8a1aab','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped)})+'\n')
assert r.wasSuccessful() and r.testsRun==7 and not r.skipped
PY
