set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s09-probe-diagnostics-a2
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-probe-diagnostics-a2
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_N0_REPEATS_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s07-n0-repeats-asan-a2/native
export TIMELEARNER_FULL_PROBE_REPORT_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s09-n0-full-probe-reports-a1
export TIMELEARNER_DOMAIN_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s07-domain-physics-asan-a1/native
export TIMELEARNER_PROBE_PLOT_DIR="$out/figures"
export TIMELEARNER_PARTIAL_PROBE_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-asan-a1/native
export TIMELEARNER_STOPPED_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s05-stopped-asan-a3/native
export TIMELEARNER_DIAGNOSTIC_PLOT_DIR="$out/diagnostic-figures"
export TIMELEARNER_SIX_SOMA_DIR=/home/user/timelearner-refactor/readbacks/s05-pooled-full-a3/native
OUTPUT_DIR="$out" /media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python -u - <<'PY' > "$out/python.log" 2>&1
import unittest,json,os,subprocess
from pathlib import Path
modules=["test_probe_diagnostics","test_probe_reports","test_plotting","test_analysis_cli","test_full_probe_report_evidence"]
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(["Scripts.StructTrain.TimeLearner.tests."+m for m in modules]))
record={"kind":"timelearner_partial_probe_report_gate","schema_version":1,"root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"tests":result.testsRun,"skips":len(result.skipped),"failures":len(result.failures),"errors":len(result.errors),"scientific_verdict":None}
Path(os.environ["OUTPUT_DIR"],"validation.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
PY
