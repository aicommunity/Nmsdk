from pathlib import Path
import os,sys
venv=Path('/media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python')
if sys.executable!=str(venv):os.execv(str(venv),[str(venv),'-u',__file__])
import subprocess,json,hashlib,traceback,shutil,tarfile
base=Path('/media/user/Data/TimeLearnerRefactor');out=base/'readbacks/s03-native-matched-visual-asan-a1';out.mkdir(exist_ok=False)
sdk=base/'analysis-native-matched-visual-a1';donor=base/'source-initial-threshold-asan-a2';root='87addb4078335344630828a760d6739fc88a7a0c';source=base/'readbacks/s03-native-probe-matched-asan-a1'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT).decode().strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 assert json.loads((source/'terminal.json').read_text())['status']=='passed'
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/');git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root);git(sdk,'checkout','--detach',root)
 sys.path.insert(0,str(sdk))
 from Scripts.StructTrain.TimeLearner.matched_resistance_reports import render
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 before=_inventory(source);result=render(source,out/'full-report-cache');write('render-result.json',result)
 assert result['views']==30 and result['soma_channels']==5
 manifest=json.loads((out/'full-report-cache/manifest.json').read_text());assert len(manifest['views'])==30
 for v in manifest['views']:
  if v['view']!='full':assert v['sample_count']<=901 and v['local_view_has_sample_markers']
 selected=out/'selected';selected.mkdir();records=[]
 for v in manifest['views']:
  if (v['channel']==0 and v['view'] in ['full','samples-800-1700','samples-1600-2500']) or (v['topology']=='Classic' and v['channel']>0 and v['view']=='full'):
   name=v['topology']+'-soma'+str(v['channel']+1)+'-'+v['view']+'.png';p=out/'full-report-cache'/v['png'];shutil.copyfile(p,selected/name);records.append({'path':'selected/'+name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'view':v})
 write('selected.json',{'files':records,'manual_review_complete':False});assert len(records)==9 and before==_inventory(source)
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'native_models_rerun':False,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (sdk/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.iterdir() if p.is_file()}
 for name in ['manifest.json','analysis.json','SHA256SUMS.json']:
  p=out/'full-report-cache'/name
  if p.is_file():files['full-report-cache/'+name]=p
 for p in (out/'selected').glob('*.png') if (out/'selected').exists() else []:files['selected/'+p.name]=p
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'matched_resistance_waveform_report','root':root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','manual_review_complete':False,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
