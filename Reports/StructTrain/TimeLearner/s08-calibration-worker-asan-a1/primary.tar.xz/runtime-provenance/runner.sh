set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-calibration-worker-provenance-asan-a4"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3182624 2>/dev/null;do sleep 10;done
test "$(cat "$base/readbacks/s08-calibration-worker-audit-asan-a2/process-exit-status.txt")" = 0
cd "$base/source-calibration-worker-provenance-asan-a4"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_NATIVE_CALIBRATION_RUN_DIR="$base/readbacks/s08-calibration-worker-audit-asan-a2/native-cli"
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import os,json,unittest,sys
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromNames(['Scripts.StructTrain.TimeLearner.tests.test_native_calibration_worker.NativeCalibrationRunProvenanceTest','Scripts.StructTrain.TimeLearner.tests.test_runtime'])
assert suite.countTestCases()==11
result=unittest.TextTestRunner(verbosity=2).run(suite)
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'4244160dd38e62f39fb46fb9ee5e5567d373c5b6','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'scope':'four actual run provenance checks and seven runtime/strict JSON checks; no new native Train/calibration','scientific_verdict':None},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun==11 and not result.skipped else 1)
PY
OUT="$out" python3 - <<'PY' > "$out/runtime-metadata.log" 2>&1
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.runtime import snapshot
base=Path('/media/user/Data/TimeLearnerRefactor');out=Path(os.environ['OUT']);old=load(base/'readbacks/s08-calibration-worker-asan-a1/runtime-before.json')
enhanced=snapshot(base/'source-threshold-contract-asan-isolated-a1',Path(old['executable']['path']),Path(old['app_ini']['path']),base/'build-threshold-contract-asan-isolated-a1/CMakeCache.txt')
assert enhanced['executable']==old['executable'] and enhanced['app_ini']==old['app_ini']
assert 'CMAKE_CXX_FLAGS_RELWITHDEBINFO' in enhanced['build_flags'] and 'CMAKE_EXE_LINKER_FLAGS' in enhanced['build_flags']
(out/'runtime-enhanced.json').write_text(json.dumps(enhanced,indent=2)+'\n')
commands=json.loads((base/'build-threshold-contract-asan-isolated-a1/compile_commands.json').read_text())
units=[]
for suffix in ('/App/NeuroModelerConsole/TimeLearnerCalibrationJob.cpp','/Core/TimeLearner/NativeCalibratedState.cpp','/Core/NNeuronTimeLearner.cpp','/Core/NNeuronTimeLearnerBranch.cpp'):
 found=[r for r in commands if r['file'].endswith(suffix)];assert len(found)==1,(suffix,len(found))
 command=found[0].get('command') or ' '.join(found[0]['arguments'])
 if 'asan'=='asan':assert '-fsanitize=address' in command,suffix
 units.append(found[0])
(out/'actual-compile-commands.json').write_text(json.dumps({'units':units,'same_executable_and_ini_as_original_manifest':True,'original_manifest_replaced':False,'note':'Additional read-only build flag capture; original process runtime manifests are preserved unchanged.','scientific_verdict':None},indent=2)+'\n')
print('Enhanced flags and four actual compile commands captured against unchanged executable',flush=True)
PY
