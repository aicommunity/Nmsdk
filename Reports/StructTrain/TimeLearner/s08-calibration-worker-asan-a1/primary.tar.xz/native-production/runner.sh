set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-calibration-worker-asan-a1"
out="$base/readbacks/s08-calibration-worker-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-calibration-ownership-fixed-asan-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b103835b15eeacc3fef35266a9ffe638967a70ab > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach b103835b15eeacc3fef35266a9ffe638967a70ab >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_CXX_FLAGS_RELWITHDEBINFO="-O1 -g1 -fsanitize=address -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address" -DCMAKE_SHARED_LINKER_FLAGS="-fsanitize=address" > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole -j 2 > "$out/build.log" 2>&1
cd "$src"
export QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
OUT="$out" RUNTIME="$runtime" python3 - <<'PY' > "$out/native.log" 2>&1
import json,os,subprocess
from pathlib import Path
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.calibration_transaction_evidence import audit_native_calibration_transaction
from Scripts.StructTrain.TimeLearner.native_calibration_worker import validate_job,audit_execution
out=Path(os.environ['OUT']);runtime=Path(os.environ['RUNTIME'])
source=Path('/media/user/Data/TimeLearnerRefactor/readbacks/s08-calibration-grid-report-normal-a2/extracted/native-v2/native')
sources={load(p)['sha256']:load_case(p) for p in source.glob('*_learned_state.json')}
results=[]
for top in ('Classic','Branch'):
 paths=list(source.glob(top+'*_success_grid_transaction.json'));assert len(paths)==1
 r=load(paths[0])
 for case in ('success','nonseparable','budget'):
  spec={key:r[key] for key in ('protocol','data_partition_id','clock_id','criterion')}
  spec['attempt_id']=top+'/production-worker/'+case
  job={'kind':'timelearner_native_calibration_job','schema_version':1,
       'owner_class':'NNeuronTimeLearner'+('Branch' if top=='Branch' else ''),
       'implementation_id':r['source_recognition']['implementation_id'],'frequency_hz':2000,
       'maximum_model_ticks':20000,'source_recognition':r['source_recognition'],
       'thresholds':r['thresholds'] if case!='nonseparable' else [1.],
       'maximum_candidates':1 if case!='success' else len(r['thresholds']),
       'specification':spec,'trials':r['trials']}
  job['sha256']=sha(job)
  validate_job(job,sources[r['source_recognition']['source_solo']['sha256']])
  path=out/(top+'-'+case+'-job.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
  target=out/(top+'-'+case)
  with (out/(top+'-'+case+'.log')).open('wb') as log:
   done=subprocess.run([str(runtime/'NeuroModelerConsole'),'--app-ini',str(runtime/'NeuroModelerConsole.ini'),
       '--timelearner-calibrate',str(path),'--timelearner-output',str(target)],cwd=runtime,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  assert done.returncode==0,(top,case,done.returncode)
  report=load(target/'transaction.json')
  expected={'success':'calibrated','nonseparable':'nonseparable','budget':'budget_exhausted'}[case]
  assert report['status']==expected
  audit=audit_native_calibration_transaction(report,sources[report['source_recognition']['source_solo']['sha256']])
  assert audit['transaction_evidence_consistent'] is True
  effective=load(target/'model.json')
  assert effective==(report['calibrated_package'] if case=='success' else r['source_recognition'])
  binding=audit_execution(target,job,sources[r['source_recognition']['source_solo']['sha256']])
  assert binding['execution_evidence_consistent'] is True
  results.append({'topology':top,'case':case,'status':report['status'],'execution':load(target/'execution.json'),'audit':audit})
(out/'validation.json').write_text(json.dumps({'native_jobs':6,'results':results,'scientific_verdict':None},indent=2)+'\n')
print('Six production Console jobs and their full primary evidence passed',flush=True)
PY
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_text())))}))
PY
