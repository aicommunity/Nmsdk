set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s10-production-closure-publication-a1"
gate="$base/readbacks/s08-native-posttune-console-visual-publish-normal-a1"
src="$base/source-native-posttune-console-visual-publish-normal-a1"
reference="$base/source-threshold-contract-asan-isolated-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$gate/process-exit-status.txt"; do sleep 10; done
test "$(cat "$gate/process-exit-status.txt")" = 0
cd "$src"
OUT="$out" REFERENCE="$reference" PYTHONDONTWRITEBYTECODE=1 python3 -u - <<'PY' > "$out/publication.log" 2>&1
import hashlib,json,os,subprocess
from pathlib import Path
from Scripts.StructTrain.TimeLearner.publisher import _git,publish_closure
root=Path.cwd();out=Path(os.environ['OUT']);reference=Path(os.environ['REFERENCE'])
preflight=json.loads((out.parent/'s10-production-closure-preflight-a1/preflight.json').read_bytes())
records=[]
for row in preflight['children']:
 path=row['path'];target=root/path;target.parent.mkdir(parents=True,exist_ok=True)
 assert not target.exists() or not any(target.iterdir()),target
 subprocess.run(['git','clone','--shared','--no-checkout',str(reference/path),str(target)],check=True)
 subprocess.run(['git','-C',str(target),'remote','set-url','origin',row['url']],check=True)
 subprocess.run(['git','-C',str(target),'-c','fetch.recurseSubmodules=false','fetch','origin',row['commit']],check=True)
 ref=row['advertised_exact_heads'][0]
 current=_git(target,'ls-remote','--exit-code','origin',ref).split()
 assert current==[row['commit'],ref],(path,current)
 subprocess.run(['git','-C',str(target),'update-ref',ref,row['commit']],check=True)
 subprocess.run(['git','-C',str(target),'-c','submodule.recurse=false','checkout','--detach',row['commit']],check=True)
 records.append({'path':path,'commit':row['commit'],'remote':'origin','branch':ref,'push_url':row['url']})
records.append({'path':'.','commit':_git(root,'rev-parse','HEAD'),'remote':'origin',
 'branch':'refs/heads/codex/timelearner-native-posttune-console-visual-evidence-normal-a1',
 'push_url':'git@github.com:aicommunity/Nmsdk.git'})
manifest='Reports/StructTrain/TimeLearner/s08-native-posttune-console-visual-normal-a1/SHA256SUMS.json'
spec={'kind':'timelearner_git_publication','schema_version':2,'repositories':records,
 'artifacts':[{'repository':'.','manifest':manifest,'manifest_sha256':hashlib.sha256((root/manifest).read_bytes()).hexdigest()}]}
(out/'specification.json').write_text(json.dumps(spec,indent=2)+'\n')
result=publish_closure(root,spec)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['publication']=='published',result
assert len(result['repositories'])==8
PY

