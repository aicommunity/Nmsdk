set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-console-visual-latest-reader-normal-a1"
gate="$base/readbacks/s08-native-posttune-console-report-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 7e8d97f3f5ae0a81125764775d1b9ba36a00c541 > "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$repo" archive 7e8d97f3f5ae0a81125764775d1b9ba36a00c541 Scripts | tar -x -C "$out/source"
while test ! -f "$gate/process-exit-status.txt"; do sleep 10; done
test "$(cat "$gate/process-exit-status.txt")" = 0
cd "$out/source"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_POSTTUNE_RUN_REPORT_DIR="$gate/reports"
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$base/readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/runs"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_run_reports Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1

