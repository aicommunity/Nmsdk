from pathlib import Path
import subprocess,json,time,hashlib,tarfile,sys,io,os,traceback
base=Path('/media/user/Data/TimeLearnerRefactor')
out=Path(__file__).resolve().parent
assert out==base/'readbacks/s01-inherited-normal-render-a2'
branch='refs/heads/codex/timelearner-inherited-native-gate-normal-a1'
url='https://github.com/aicommunity/Nmsdk.git'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name,timeout=600,env=None):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env=env)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
try:
 deadline=time.monotonic()+43200
 attempts=0
 while True:
  attempts+=1
  r=subprocess.run(['git','ls-remote','--exit-code',url,branch],capture_output=True,text=True,timeout=120)
  if r.returncode==0:proof=r.stdout.split()[0];break
  assert time.monotonic()<deadline,'publication_wait_budget_exhausted'
  time.sleep(15)
 write('publication-resolution.json',{'branch':branch,'commit':proof,'attempts':attempts})
 repo=out/'repo';repo.mkdir()
 run(['git','init',repo],'git-init.log')
 run(['git','-C',repo,'fetch','--depth=1','--filter=blob:none','--no-tags','--no-recurse-submodules',url,proof],'git-fetch.log')
 def blob(path):return subprocess.check_output(['git','-C',str(repo),'show',proof+':Reports/StructTrain/TimeLearner/s01-inherited-native-gate-normal-a1/'+path])
 manifest=json.loads(blob('manifest.json'));archive=blob('primary.tar.xz')
 assert hashlib.sha256(archive).hexdigest()==manifest['archive_sha256']
 assert manifest['native_tests']==16 and manifest['reader_tests']==7
 records={r['path']:r for r in manifest['records']}
 artifacts=out/'artifacts';(artifacts/'native').mkdir(parents=True)
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:xz') as tar:
  assert len(tar.getmembers())==len(records)
  for member in tar.getmembers():
   assert member.isfile() and member.name in records and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
   raw=tar.extractfile(member).read();r=records[member.name]
   assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
   if member.name.startswith('native-run/native/'):
    path=Path(member.name).name
    assert member.name=='native-run/native/'+path
    (artifacts/'native'/path).write_bytes(raw)
   elif member.name=='native-run/gtest.xml':(artifacts/'native.xml').write_bytes(raw)
 code=base/'readbacks/s01-inherited-reader-asan-a2/code'
 assert (code/'Scripts/StructTrain/TimeLearner/tests/test_inherited_property_reports.py').exists()
 codehead=subprocess.check_output(['git','-C',str(code),'rev-parse','FETCH_HEAD'],text=True).strip()
 assert codehead=='5b6dd147200a37ea93f303cbb01408312555e5ac'
 env=os.environ.copy();env['PYTHONPATH']=str(code);env['TIMELEARNER_INHERITED_REPORT_DIR']=str(artifacts)
 run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_inherited_property_reports','-v'],'normal-reader-on-m40.log',1200,env)
 sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.native_test_reports import render_native_test_run
 cache=base/'report-cache/s01-inherited-normal-a1'
 result=render_native_test_run(code/'Scripts/StructTrain/TimeLearner/specs/inherited-properties-native-v1.json',artifacts,cache)
 write('render.json',result)
 write('terminal.json',{'execution':'completed','primary_proof':proof,'reader_root':codehead,'cache':str(cache),'png_files':len(list(cache.rglob('*.png'))),'visual_acceptance_complete':False,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
