from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-contained-runner-a2')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-j1j4oqro/leases.sqlite3',capacity={'slots': 1, 'memory_bytes': 1024, 'disk_bytes': 1024})
lease=r.reserve("crashed-worker",[{"path":'/tmp/timelearner-contained-j1j4oqro/scratch',"access":"write"}],ttl_seconds=.001,demands={'slots': 1, 'memory_bytes': 256, 'disk_bytes': 512})
Path('/tmp/timelearner-contained-j1j4oqro/lease.json').write_text(json.dumps(lease))
subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
