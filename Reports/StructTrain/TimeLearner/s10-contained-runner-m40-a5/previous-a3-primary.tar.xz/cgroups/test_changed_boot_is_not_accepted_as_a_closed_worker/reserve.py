from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-contained-runner-a2')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-rwjpy7fd/leases.sqlite3',capacity=None)
lease=r.reserve("crashed-worker",[{"path":'/tmp/timelearner-contained-rwjpy7fd/scratch',"access":"write"}],ttl_seconds=.001,demands=None)
Path('/tmp/timelearner-contained-rwjpy7fd/lease.json').write_text(json.dumps(lease))
