import os,sys,json,time
from pathlib import Path
p=Path(sys.argv[sys.argv.index("--timelearner-capture-directory")+1])
ticks=Path("/proc/self/stat").read_text().rsplit(") ",1)[1].split()[19]
ready={"kind":"native_runtime_capture_ready","schema_version":1,"pid":os.getpid(),"start_ticks":"0"}
(p/"capture-ready.json").write_text(json.dumps(ready))
deadline=time.monotonic()+10
while not (p/"capture-ack.json").exists() and time.monotonic()<deadline:time.sleep(.01)
assert (p/"capture-ack.json").exists()
print("actual handshake completed")
