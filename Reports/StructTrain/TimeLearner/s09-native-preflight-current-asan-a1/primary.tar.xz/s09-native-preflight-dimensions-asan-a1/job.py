import pathlib,json,os,sys,subprocess,hashlib,traceback
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/'readbacks').resolve() and out.name=='s09-native-preflight-dimensions-asan-a1'
assert {p.name for p in out.iterdir()} <= {'job.py','pid.json','supervisor.log'}
parent=base/'readbacks/s09-native-preflight-asan-a1';source=base/'source-n1-measured-refinement-asan-a1';binary_source=source
def write(name,value):
 with (out/name).open('x') as file:json.dump(value,file,indent=2);file.write('\n')
try:
 sys.path.insert(0,str(source));os.environ['PYTHONDONTWRITEBYTECODE']='1'
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 runtime=json.loads((parent/'runtime.json').read_text());closure=source_closure(binary_source);assert closure==runtime['source_closure']
 os.environ.update(runtime['loader_environment']);os.environ['ASAN_OPTIONS']='detect_leaks=0';verify_runtime(runtime)
 code={'root':closure['root']['head'],'files':[{'path':p.relative_to(source).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))]}
 write('code-manifest.json',code)
 spec={'kind':'timelearner_native_matrix_preparation','schema_version':1,
  'templates':{t+'-N'+n:json.loads((parent/'corpus/inputs'/('pipeline-'+t+'-N'+n+'.json')).read_text()) for t in ['Classic','Branch'] for n in ['0','1']},
  'input_counts':[1,2,4,6],'frequencies_hz':[2000,20000],'isi_seconds':.02,'probe_duration':.3,'window_width':.015,'n0_candidate_repeats':2,'run_prefix':'native-preflight-dimension'}
 write('specification.json',spec)
 with (out/'prepare.log').open('xb') as log:
  p=subprocess.run(['python3','-m','Scripts.StructTrain.TimeLearner','prepare',str(out/'specification.json'),'--output',str(out/'prepared')],cwd=source,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0
 prepared=json.loads((out/'prepared/manifest.json').read_text());assert len(prepared['job_sha256'])==32 and prepared['training_started'] is False
 (out/'runs').mkdir();cases={}
 for name in sorted(prepared['job_sha256']):
  path=out/'prepared/jobs'/(name+'.json');job=json.loads(path.read_text());model=job['configuration']['model'];count=len(model['inputs']);frequency=model['frequency_hz']
  r=run_job('preflight',path,None,parent/'runtime.json',out/'runs'/name,120)
  assert r['execution']=='completed' and r['validity']=='valid',name
  assert audit_run_manifest(out/'runs'/name/'run-manifest.json')['run_evidence_consistent']
  initial=json.loads((out/'runs'/name/'native/initial-state.json').read_text())
  assert len(initial['parameters'])==count and all(n['frequency_hz']==str(frequency) for n in initial['identity']['model']['nodes'])
  cases[name]={'inputs':count,'frequency_hz':frequency,'normalization':model['normalization'],'topology':'Branch' if model['branch'] else 'Classic','model_revision':r['analysis']['model_revision'],'model_ticks':0}
  print(name+' completed',flush=True)
 write('corpus.json',{'kind':'native_preflight_dimension_corpus','schema_version':1,'analysis_root':code['root'],'binary_root':closure['root']['head'],'cases':cases,'scientific_verdict':None})
 assert len(cases)==32
 assert source_closure(binary_source)==closure;verify_runtime(runtime)
 assert all(hashlib.sha256((source/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in code['files'])
 write('terminal.json',{'execution':'completed','cases':32,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
