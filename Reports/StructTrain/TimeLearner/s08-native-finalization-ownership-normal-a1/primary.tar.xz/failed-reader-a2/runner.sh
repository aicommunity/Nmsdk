set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-finalization-ownership-reader-normal-a2"
repo="$base/source-rdk-bool-evidence-normal-a2"
work="$base/source-finalization-ownership-audit-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-finalization-ownership-normal-a2/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 8e3e6678664c2940063879b2dd6257e16ad76aa5 > "$out/checkout.log" 2>&1
test -z "$(git -C "$work" status --porcelain)"
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
cd "$work"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_FINALIZATION_OWNERSHIP_NATIVE="$base/readbacks/s08-native-finalization-ownership-normal-a2/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="$base/readbacks/s08-native-posttune-probe-console-normal-a1/fixtures"
python3 -u - <<'PY' > "$out/tests.log" 2>&1
import json,os,time,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.finalization_ownership_evidence import audit_managed_finalization
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.native_evidence import load
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_finalization_ownership_evidence')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'kind':'native_finalization_ownership_reader_gate','schema_version':1,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-start,'source_root':'8e3e6678664c2940063879b2dd6257e16ad76aa5','scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==2 and not result.skipped
cases=[]
for p in sorted(Path(os.environ['TIMELEARNER_FINALIZATION_OWNERSHIP_NATIVE']).glob('*_managed_finalization_*.json')):
 source='Branch-synthetic' if p.name.startswith('Branch') else 'Classic-auto_metric'
 paths=list((Path(os.environ['TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES'])/source/'input/source').glob('*_learned_state.json'))
 assert len(paths)==1
 cases.append({'case':p.name,'audit':audit_managed_finalization(load(p),load_case(paths[0]))})
report['cases']=cases
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
