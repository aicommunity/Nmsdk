from pathlib import Path
import sys,json,tarfile,hashlib,io,traceback,xml.etree.ElementTree as ET
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

base=Path('/media/user/Data/TimeLearnerRefactor');repo=base/'source-native-wall-report-asan-a2';active=base/'source-n1-measured-refinement-asan-a1'
out=Path(__file__).resolve().parent;trial=base/'readbacks/s07-search-termination-baseline-asan-a2'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
try:
 stat=Path('/proc/1628247/stat');assert not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19]!='267941990'
 tree=ET.parse(trial/'gtest.xml').getroot();assert tree.attrib['tests']=='7' and tree.attrib['failures']=='4' and tree.attrib['errors']=='0'
 failed={c.get('name') for c in tree.findall('.//testcase') if c.find('failure') is not None}
 assert failed=={'MaximumSweepsClassicN0','MaximumSweepsClassicN1','MaximumSweepsBranchN0','MaximumSweepsBranchN1'}
 sys.path.insert(0,str(active))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 after=source_closure(active);assert after==json.loads((trial/'source.json').read_text());write('post-baseline-source.json',after)
 archive=out/'primary.tar.xz';records=[]
 with tarfile.open(archive,'w:xz',preset=6) as tar:
  sources=[(str(p.relative_to(trial)),p) for p in sorted(trial.rglob('*')) if p.is_file()]
  sources.append(('post-baseline-source.json',out/'post-baseline-source.json'))
  for name,p in sources:
   raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw));records.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 manifest={'kind':'bounded_search_termination_expected_failure','numeric_root':'91a9524b5e4607c5444a2e7ea5fc6a2561cf271f','pulse':'a18bf543007c52a3ac7a6fbb148a48cb2c351de3','controller_tests':7,'expected_budget_failures':4,'control_tests_passed':3,'reason':'Four expected sweep-budget status mismatches; Exact-last-sweep, invalid-observation recovery and no-adjustable-input controls passed','records':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'native_physics_attested':False,'scientific_verdict':None}
 files={'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode(),'primary.tar.xz':archive.read_bytes(),'README.md':b'Actual corrected ASan baseline: four sweep-budget classification failures and three independent controls passed. Controller logic and production ProbeRecorder; no simulator physics/classification inference.\n'}
 commit=publish_git_evidence(repo,'91a9524b5e4607c5444a2e7ea5fc6a2561cf271f','Reports/StructTrain/TimeLearner/s07-search-termination-baseline-asan-a2','codex/timelearner-search-termination-baseline-asan-a1',out,files,'Preserve search termination baseline and invalid-measurement fixture mistake')
 write('terminal.json',{'execution':'completed','commit':commit,'members':len(records),'archive_bytes':archive.stat().st_size})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
