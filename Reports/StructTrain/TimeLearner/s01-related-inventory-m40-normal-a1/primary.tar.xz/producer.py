from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil,time
base=Path('/media/user/Data/TimeLearnerRefactor');label='related-inventory-normal-a1';out=base/('readbacks/s01-'+label);out.mkdir(exist_ok=False)
source=base/'source-related-inventory-normal-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='0497d934d666d883903f3a8ff504169009982dbe';container=Path(str(out)+'-container')
pulse=base/'source-csearch-threshold-joint-asan-build-a1/Libraries/Nmsdk-PulseLib';primary=pulse
stop=threading.Event();thread=None;errors=[];passed=False;token=None
capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(source))
 assert shutil.disk_usage(base).free>=1024**3
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3')
 reserved=registry.reserve('s01-'+label,[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'},{'path':str(bootstrap),'access':'read'},{'path':str(primary),'access':'read'}],ttl_seconds=120)
 token=reserved['token'];write('reservation.json',reserved)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_INVENTORY_PULSE_SOURCE']=str(pulse)
 pulse_head=subprocess.check_output(['git','-C',str(pulse),'rev-parse','HEAD'],text=True).strip();assert pulse_head=='cc97149c90ce98ff24ca688452f4a40d54e0e63d'
 pulse_inputs={}
 for component in ['NNeuronTimeLearner','NNeuronTimeLearnerBranch']:
  for suffix in ['.h','.cpp']:
   path='Core/'+component+suffix;data=subprocess.check_output(['git','-C',str(pulse),'show',pulse_head+':'+path]);pulse_inputs[path]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 write('whole-pulse-source-inputs.json',{'commit':pulse_head,'source':str(pulse),'files':pulse_inputs,'native_models_executed':False})
 os.environ['TMPDIR']=str(out/'temporary');(out/'temporary').mkdir()
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_inventory');assert suite.countTestCases()==15
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':15})
 assert result.testsRun==15 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'new_native_units':0,'source_commit':root,'actual_primary':str(primary),'whole_migration_attested':False,'scientific_verdict':None,'whole_plan_complete':False})
  write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    entry=tarfile.TarInfo(name);entry.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(entry,f)
  write('bundle.json',{'kind':'timelearner_related_inventory_checks','source_commit':root,'passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'new_native_units':0})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
