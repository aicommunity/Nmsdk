import pathlib,time,subprocess,json,os,sys,hashlib,traceback
b=pathlib.Path('/media/user/Data/TimeLearnerRefactor');code=b/'source-archive-transfer-analysis-a1';data=b/'readbacks/s05-archive-f64-asan-a2';out=b/'readbacks/s05-archive-f64-reader-asan-a1'
out.mkdir(exist_ok=False)
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
try:
 cm=json.loads((code/'code-manifest.json').read_text());assert cm['git_root']=='5c4e1a44cbdbc92fbab646933a1c15de606ebfda'
 def verify_code():
  for r in cm['records']:assert hashlib.sha256((code/r['path']).read_bytes()).hexdigest()==r['sha256']
 verify_code();begin=time.monotonic()
 while True:
  p=pathlib.Path('/proc/880339/stat')
  if not p.exists() or p.read_text().rsplit(') ',1)[1].split()[19]!='262471091':break
  assert time.monotonic()-begin<3600,'native_wait_timeout'
  time.sleep(5)
 assert not (data/'exception.json').exists()
 native=json.loads((data/'validation.json').read_text());assert native['gtest']['tests']=='16' and native['gtest']['failures']==native['gtest']['errors']=='0' and native['execution']['returncode']==0
 parent=json.loads((data/'reader-validation.json').read_text());assert parent['returncode']==0 and parent['reported_count_matches']
 runs=[]
 xml=b/'readbacks/s05-archive-f64-asan-a1/hot-xml'
 for label,module,key,path,count in [
  ('archive','Scripts.StructTrain.TimeLearner.tests.test_archive_transfer_reports','TL_ARCHIVE_TRANSFER_SOURCE',data,23),
  ('warm','Scripts.StructTrain.TimeLearner.tests.test_hot_readout_reports','TL_HOT_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-asan-a1',16),
  ('loaded','Scripts.StructTrain.TimeLearner.tests.test_loaded_readout_reports','TL_LOADED_READOUT_SOURCE',b/'readbacks/s04-hot-readout-fixed-asan-a1/loaded',16),
  ('xml','Scripts.StructTrain.TimeLearner.tests.test_hot_xml_reports','TL_HOT_XML_SOURCE',xml,18)]:
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_HOT_EXPECT_STALE='0');env[key]=str(path)
  with (out/(label+'.log')).open('wb') as f:r=subprocess.run(['python3','-m','unittest','-v',module],cwd=code,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(out/(label+'.log')).read_text();runs.append({'label':label,'expected_tests':count,'returncode':r.returncode,'reported_count_matches':('Ran '+str(count)+' tests') in log})
  write('progress.json',{'runs':runs});assert r.returncode==0 and runs[-1]['reported_count_matches'],log
 sys.dont_write_bytecode=True;sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.archive_transfer_reports import audit_run
 from Scripts.StructTrain.TimeLearner.hot_xml_reports import audit_run as xml_audit
 rows,audit=audit_run(data);write('full-audit.json',audit);xrows,xa=xml_audit(xml);write('xml-full-audit.json',xa)
 normal=b/'restored-archive-f64-current-normal-a1';manifest=json.loads((normal/'manifest.json').read_text());records={r['path']:r for r in manifest['records']}
 comparison=[]
 for case in rows.values():
  for record in case['summary']['primary']:
   name=record['path'];rel='s05-archive-f64-normal-a4/artifacts/'+name;raw=(normal/rel).read_bytes();assert hashlib.sha256(raw).hexdigest()==records[rel]['sha256']
   a=json.loads(raw);z=json.loads((data/'artifacts'/name).read_text())
   equal=all(a[k]==z[k] for k in ('waveform','actual_input','soma','time_s'))
   if 'archive' in a:
    identity_equal=a['archive']['graph']['identity']['sha256']==z['archive']['graph']['identity']['sha256']
    images_a={x['name']:x['snapshot']['identity']['sha256'] for x in a['archive']['class_definitions']}
    images_z={x['name']:x['snapshot']['identity']['sha256'] for x in z['archive']['class_definitions']}
    identity_equal=identity_equal and images_a==images_z
   else:identity_equal=a['identity']['sha256']==z['identity']['sha256']
   comparison.append({'file':name,'selected_arrays_equal':equal,'model_and_images_identity_equal':identity_equal})
 write('crossworker-archive.json',comparison)
 xml_comparison=[]
 for name in sorted(xrows):
  for file in ('warm.csv','replay.csv'):
   rel='s05-archive-f64-normal-a4/hot-xml/artifacts/'+name+'/'+file
   raw=(normal/rel).read_bytes();a=hashlib.sha256(raw).hexdigest();assert a==records[rel]['sha256']
   z=hashlib.sha256((xml/'artifacts'/name/file).read_bytes()).hexdigest()
   xml_comparison.append({'case':name,'file':file,'normal_sha256':a,'asan_sha256':z,'byte_equal':a==z})
 write('crossworker-xml.json',xml_comparison);verify_code()
 result={'kind':'native_archive_precision_asan_data_verification','schema_version':1,'code_root':cm['git_root'],'native_source':native['source'],'runs':runs,'archive_case_soma_pairs':12,'xml_case_soma_pairs':68,'all24_archive_arrays_and_identities_equal':len(comparison)==24 and all(x['selected_arrays_equal'] and x['model_and_images_identity_equal'] for x in comparison),'all64_xml_csv_byte_equal':len(xml_comparison)==64 and all(x['byte_equal'] for x in xml_comparison),'scientific_verdict':None}
 write('validation.json',result);assert result['all24_archive_arrays_and_identities_equal'] and result['all64_xml_csv_byte_equal'];print(json.dumps(result),flush=True)
except BaseException as e:
 write('exception.json',{'error':str(e),'traceback':traceback.format_exc()});raise
