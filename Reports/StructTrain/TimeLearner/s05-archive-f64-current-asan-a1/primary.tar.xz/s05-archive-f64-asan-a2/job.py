transport_ancestors={'880335': '262471061', '880282': '262470981', '925914': '119626011'}
import pathlib,subprocess,json,os,time,sys,traceback,xml.etree.ElementTree as ET
base=pathlib.Path("/media/user/Data/TimeLearnerRefactor");worker="asan"
source=base/"source-n1-measured-refinement-asan-a1";build=base/"build-n1-measured-refinement-asan-a1";out=base/('readbacks/s05-archive-f64-'+worker+'-a2')
runtime=base/('runtime-s05-archive-f64-'+worker+'-a2')
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def run(args,name,timeout=300):
 with (out/name).open('wb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
try:
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert pathlib.Path(git(source,'rev-parse','--show-toplevel')).resolve()==source.resolve()
 assert not git(source,'status','--porcelain','--untracked-files=no')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','820f637e48dd3f365b98c33ac2799bb32c82fd75'],'fetch-root.log')
 root=git(source,'rev-parse','FETCH_HEAD');assert root=='820f637e48dd3f365b98c33ac2799bb32c82fd75'
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 for child,url in [('Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib'),('Bin','Nmsdk-Bin'),('Rdk','Rdk')]:
  repo=source/child;assert not git(repo,'status','--porcelain','--untracked-files=no')
  wanted=git(source,'rev-parse','HEAD:'+child)
  run(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+url+'.git',wanted],'fetch-'+url+'.log')
  assert git(repo,'rev-parse','FETCH_HEAD')==wanted,'fetch_did_not_resolve_exact_gitlink'
  run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+url+'.log')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 assert not runtime.exists()
 run(['cmake','-S',source,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime),'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address'],'configure.log')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','Test_MatrixNodeTextFormat','--parallel','2'] ,'build.log',7200)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 unit_manifest=snapshot(source,runtime/'Test_MatrixNodeTextFormat',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('unit-runtime.json',unit_manifest)
 unit_result=execute(unit_manifest,['--gtest_output=xml:'+str(out/'unit-gtest.xml')],runtime,out/'unit-process',300)
 unit_tree=ET.parse(out/'unit-gtest.xml').getroot()
 write('unit-validation.json',{'execution':unit_result,'gtest':unit_tree.attrib,'skipped':len(unit_tree.findall('.//testcase/skipped')),'scientific_verdict':None})
 assert unit_result['execution']=='completed' and unit_result['returncode']==0 and unit_tree.attrib['tests']=='10' and unit_tree.attrib['failures']==unit_tree.attrib['errors']=='0' and not unit_tree.findall('.//testcase/skipped')
 verify_runtime(unit_manifest)
 os.environ['TIMELEARNER_ARCHIVE_TEST_DIR']=str(out/'artifacts')
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 result=execute(manifest,['--gtest_filter=SingleRate/NativeArchive.*:TimeLearnerModelArchive.*-TimeLearnerModelArchive.FreshProcessImport','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',1800)
 data=ET.parse(out/'gtest.xml').getroot().attrib if (out/'gtest.xml').exists() else None
 write('validation.json',{'worker':worker,'phase':'model_archive_f64_precision','source':root,'pulse':closure['Libraries/Nmsdk-PulseLib']['head'],'rdk':closure['Rdk']['head'],'execution':result,'gtest':data,'scientific_verdict':None})
 print(json.dumps(data),flush=True)
 if data and data['tests']=='16' and data['failures']==data['errors']=='0':
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_ARCHIVE_TRANSFER_SOURCE=str(out))
  with (out/'archive-reader.log').open('wb') as f:reader=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_archive_transfer_reports'],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
  text=(out/'archive-reader.log').read_text()
  write('reader-validation.json',{'source':root,'expected_tests':23,'returncode':reader.returncode,'reported_count_matches':'Ran 23 tests' in text,'scientific_verdict':None})
 assert source_closure(source)==closure
 verify_runtime(manifest)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
