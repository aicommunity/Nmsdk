set -euo pipefail
base=/home/user/timelearner-refactor
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
out="$base/readbacks/s08-recognition-scope-ab-normal-a1";old="$base/runtime-s08-native-posttune-candidates-normal-a2"
runtime="$base/runtime-s08-recognition-scope-ab-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-candidates-normal-a2/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
test ! -e "$runtime"
ps -eo pid,comm,args | awk '$2 ~ /^(Test_PulseLib|NeuroModelerCons|cc1plus|cmake|gmake|ninja)/ {print}' > "$out/process-inventory.txt"
test ! -s "$out/process-inventory.txt"
cp "$base/readbacks/s08-native-posttune-candidates-normal-a2/runtime-before.json" "$out/baseline-runtime.json"
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen 
RUNTIME_MANIFEST="$out/baseline-runtime.json" python3 - <<'PY' > "$out/baseline-preflight.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
mkdir "$out/baseline"
(cd "$old" && TIMELEARNER_EXECUTION_OUTPUT="$out/baseline" ./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationTransaction.*:NativeCalibrationOwnership.*' --gtest_output="xml:$out/baseline.xml") > "$out/baseline.log" 2>&1
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git efb25123c328ae98088ab3d361bb7e87d098dd4a > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach efb25123c328ae98088ab3d361bb7e87d098dd4a >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationTransaction.*:NativeCalibrationOwnership.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import hashlib,json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);v={'new_root':'efb25123c328ae98088ab3d361bb7e87d098dd4a','pulse':'fbf6b731b18d4788e31acbe33db14ef883ffa065','scientific_verdict':None}
for name in ('baseline','native'):
 r=E.parse(p/(name+'.xml')).getroot()
 q={'tests':len(list(r.iter('testcase'))),'failures':len(list(r.iter('failure'))),'errors':len(list(r.iter('error'))),'skips':len(list(r.iter('skipped')))}
 assert q=={'tests':10,'failures':0,'errors':0,'skips':0},q
 v[name]=q
a={f.name:f for f in (p/'baseline').glob('*.csv')};b={f.name:f for f in (p/'native').glob('*.csv')}
assert a and set(a)==set(b)
rows=[]
for n in sorted(a):
 x,y=a[n].read_bytes(),b[n].read_bytes()
 rows.append({'path':n,'bytes_exact':x==y,'baseline_sha256':hashlib.sha256(x).hexdigest(),'new_sha256':hashlib.sha256(y).hexdigest()})
assert all(r['bytes_exact'] for r in rows)
(p/'waveform-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
v['exact_csv_pairs']=len(rows);(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
PY
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
