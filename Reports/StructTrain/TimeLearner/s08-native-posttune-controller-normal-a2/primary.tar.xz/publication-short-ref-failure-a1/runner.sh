set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-worker-publish-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
p="$base/readbacks/s08-native-posttune-worker-normal-a1"
while test ! -f "$p/process-exit-status.txt"; do kill -0 1416186;sleep 5;done
test "$(cat "$p/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s08-native-posttune-candidates-publish-normal-a2/process-exit-status.txt")" = 0
src="$base/source-posttune-fixed-evidence-normal-a1"
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git ae28a9de8 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false switch -c codex/timelearner-native-posttune-worker-evidence-normal-a1 FETCH_HEAD >> "$out/checkout.log" 2>&1
cd "$src"
python3 - <<'PY' > "$out/package.log" 2>&1
import hashlib,io,json,tarfile
from pathlib import Path
p=Path('/home/user/timelearner-refactor/readbacks/s08-native-posttune-worker-normal-a1')
v=json.loads((p/'validation.json').read_bytes());assert v['operations']==40 and v['independent_test_checks']==4
assert json.loads((p/'runtime-after.json').read_bytes())['verified'] is True
reader=(p/'reader.log').read_text();assert 'Ran 4 tests' in reader and reader.endswith('OK\n')
files={}
for f in sorted(p.rglob('*')):
 assert not f.is_symlink()
 if f.is_file() and f.suffix in ('.json','.csv','.xml','.log','.txt','.sh'):
  files[f.relative_to(p).as_posix()]=f.read_bytes()
dest=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-worker-normal-a1');dest.mkdir(parents=True,exist_ok=False)
with tarfile.open(dest/'primary.tar.xz','w:xz',preset=6) as tar:
 for n,raw in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
encode=lambda x:(json.dumps(x,indent=2,allow_nan=False)+'\n').encode()
(dest/'manifest.json').write_bytes(encode({'kind':'native_posttune_worker_primary_bundle','schema_version':1,
 'validation':v,'archive_sha256':hashlib.sha256((dest/'primary.tar.xz').read_bytes()).hexdigest(),
 'files':[{'path':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in sorted(files.items())],
 'all_visual_reports_accepted':False,'full_stage_8_accepted':False,'scientific_verdict':None}))
(dest/'README.md').write_text('# Native PostTune Console export and frozen evaluation\n\nRoot c6410eecc67cdc27aa5d6c05ef40f81a174a4916 / PulseLib de51a21: forty actual owned-process operations (20 exports, 20 evaluations) pass, followed by four independent checks. Classic/Branch N0/N1 each export Off, KeepDone, CanonRmin, FlatLastR and SearchSyntheticCandidate through the production Console and pipeline wrapper. Every fresh-process export exactly matches its original native candidate package and advances zero physical ticks. Each frozen evaluation records complete actual target/foil responses, raw soma/input/LT potential/spike samples and unchanged full learned model identity. All portable runtime/process/source manifests are included.\n\nThese are diagnostic evaluations of fixed inherited thresholds. Source training outcomes remain unchanged; no search convergence, threshold calibration, independent Test or full SearchSynthetic controller is claimed. Waveform visual acceptance and ASan remain separate gates.\n')
(dest/'SHA256SUMS.json').write_bytes(encode({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in dest.iterdir() if f.is_file()}))
print(len(files),(dest/'primary.tar.xz').stat().st_size,flush=True)
PY
test "$(git ls-remote https://github.com/aicommunity/Nmsdk-PulseLib.git refs/heads/codex/timelearner-native-posttune | cut -f1)" = "$(git ls-tree HEAD Libraries/Nmsdk-PulseLib | awk '{print $3}')"
git add --sparse Reports/StructTrain/TimeLearner/s08-native-posttune-worker-normal-a1
git commit -m 'Preserve forty owned native PostTune export and complete frozen target foil evaluations'
git -c push.recurseSubmodules=no push git@github.com:aicommunity/Nmsdk.git HEAD > "$out/publish.log" 2>&1
test "$(git ls-remote git@github.com:aicommunity/Nmsdk.git refs/heads/codex/timelearner-native-posttune-worker-evidence-normal-a1 | cut -f1)" = "$(git rev-parse HEAD)"
git rev-parse HEAD
