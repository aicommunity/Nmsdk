set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-controller-normal-a1";previous="$base/readbacks/s08-recognition-scope-ab-normal-a2"
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-posttune-controller-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$previous/process-exit-status.txt"; do kill -0 1485866;sleep 10;done
test "$(cat "$previous/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
test ! -e "$runtime"
df -h "$base" > "$out/disk-before.txt"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git c1895c4bbe9686c6144c05ce15c11001a84fb91c > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach c1895c4bbe9686c6144c05ce15c11001a84fb91c >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen 
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$base/readbacks/s08-recognition-scope-ab-normal-a1/baseline"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativePostTuneTransaction.*:NativeCalibrationOwnership.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);r=E.parse(p/'native.xml').getroot();q={'tests':len(list(r.iter('testcase'))),'failures':len(list(r.iter('failure'))),'errors':len(list(r.iter('error'))),'skips':len(list(r.iter('skipped')))}
assert q=={'tests':10,'failures':0,'errors':0,'skips':0},q
q.update({'root':'c1895c4bbe9686c6144c05ce15c11001a84fb91c','pulse':'bdcc76229922b91f372c7f90231b036accf03bd4','scientific_verdict':None})
(p/'validation.json').write_text(json.dumps(q,indent=2)+'\n')
PY
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
