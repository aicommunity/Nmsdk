from pathlib import Path
import subprocess,sys,json,os,hashlib,io,tarfile,traceback
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

out=Path(__file__).resolve().parent
base=out.parent.parent;worker='normal' if str(base).startswith('/home') else 'asan'
repo=base/('source-legacy-completed-replay-normal-a1' if worker=='normal' else 'source-capacitance-temporal-report-a1')
active=base/('source-capacitance-state-normal-b1' if worker=='normal' else 'source-finite-ranking-asan-a1')
target='e9f39959f56be1139d41165edbce1b787e45ff9a';negative='5a6e91174fb8c2ffbcbf1e48c41888d27733edbf'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def git(*args,raw=None):return subprocess.check_output(['git','-C',str(repo),*args],input=raw)
try:
 write('pid.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]})
 for commit in [target,negative]:git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',commit)
 source=out/'source';source.mkdir()
 with tarfile.open(fileobj=io.BytesIO(git('archive',target,'Scripts/StructTrain/TimeLearner')),mode='r:') as tar:
  for member in tar:
   path=source/member.name;assert source.resolve() in path.resolve().parents
   if member.isdir():path.mkdir(parents=True,exist_ok=True)
   else:assert member.isfile();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(tar.extractfile(member).read())
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.migration import verify_migration
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 before=source_closure(active);write('active-context-before.json',before)
 manifest=json.loads(git('show',target+':Docs/StructTrain/TimeLearner/script_migration.json'))
 mapping=json.loads(git('show',target+':Docs/StructTrain/TimeLearner/History/RootRevisionMap-2026-10-30.json'));write('revision-map.json',mapping)
 for row in manifest['retired_files']+manifest['moved_files']:
  if row['repository']!='root':continue
  commit=mapping['mapping'].get(row['archive_commit'],row['archive_commit'])
  if subprocess.run(['git','-C',str(repo),'cat-file','-e',commit],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',commit)
 children={};repositories=out/'repositories';repositories.mkdir()
 for name,path,remote in [('Bin','Bin','Nmsdk-Bin'),('PulseLib','Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib')]:
  child=repositories/name;subprocess.run(['git','clone','--shared','--no-checkout',str(active/path),str(child)],check=True,capture_output=True);children[name]=child
  commit=git('rev-parse',target+':'+path).decode().strip()
  subprocess.run(['git','-C',str(child),'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+remote+'.git',commit],check=True,capture_output=True)
 result=verify_migration(repo,target,children['Bin'],children['PulseLib'],out/'revision-map.json')
 assert result['source_records_verified']==81 and result['manifest_declares_complete'] is False;write('positive.json',result)
 try:verify_migration(repo,negative,children['Bin'],children['PulseLib'],out/'revision-map.json')
 except EvidenceError as error:
  assert 'migration_old_path_still_present' in str(error);write('negative.json',{'fixture_commit':negative,'rejected_reason':str(error),'positive_receipt_created':False})
 else:raise AssertionError('restored_bin_paths_were_accepted')
 old='14a88195a8a5538d3a2f5c0657981488e38829b7';new='07fbeb4357a7337a2fb924330846f8d4ec05ac4b'
 rows=subprocess.check_output(['git','-C',str(children['Bin']),'diff','--name-status',old,new]).decode().splitlines()
 deleted=[r.split('\t')[1] for r in rows if r.startswith('D\t')];modified=[r.split('\t')[1] for r in rows if r.startswith('M\t')]
 assert len(rows)==25 and len(deleted)==17 and len(modified)==8 and all(p.endswith('.sh') for p in deleted) and all(p.endswith('.md') for p in modified)
 for path in modified:
  previous=subprocess.check_output(['git','-C',str(children['Bin']),'show',old+':'+path]);current=subprocess.check_output(['git','-C',str(children['Bin']),'show',new+':'+path]);assert current.endswith(previous)
 names=[Path(path).name for path in deleted];scan={}
 for name,repository,revision in [('root',repo,target),('Bin',children['Bin'],new),('PulseLib',children['PulseLib'],git('rev-parse',target+':Libraries/Nmsdk-PulseLib').decode().strip())]:
  args=['git','-C',str(repository),'grep','-I','-n','-F']
  for filename in names:args+=['-e',filename]
  args+=[revision,'--','*.sh','*.py','*.ps1','*.bat']
  match=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert match.returncode==1,(name,match.stdout,match.stderr);scan[name]={'literal_executable_consumers':0,'revision':revision}
 write('scope.json',{'deleted':deleted,'historical_documents_prefixed_body_preserved':modified,'other_git_paths_identical':True,'executable_reference_scan':scan,'runtime_equivalence_attested':False,'scientific_verdict':None})
 after=source_closure(active);assert before==after;write('active-context-after.json',after)
 archive=io.BytesIO();records=[]
 with tarfile.open(fileobj=archive,mode='w:xz',preset=6) as tar:
  for path in sorted(out.iterdir()):
   if not path.is_file() or path.name=='supervisor.log':continue
   raw=path.read_bytes();member=tarfile.TarInfo(path.name);member.size=len(raw);tar.addfile(member,io.BytesIO(raw));records.append({'path':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 raw=archive.getvalue();metadata={'kind':'timelearner_asymrm_launcher_retirement_gate','schema_version':1,'source':target,'worker':worker,'source_records_verified':81,'new_retired_files':17,'negative_fixture_commit':negative,'active_source_context_unchanged':True,'records':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'runtime_equivalence_attested':False,'scientific_verdict':None}
 commit=publish_git_evidence(repo,target,'Reports/StructTrain/TimeLearner/s09-asymrm-launcher-retirement-'+worker+'-a1','codex/evidence-s09-asymrm-launcher-retirement-'+worker+'-a1',out,{'manifest.json':(json.dumps(metadata,indent=2)+'\n').encode(),'primary.tar.xz':raw},'evidence: verify81 historical retrieval records and retire17 AsymRm launchers on '+worker)
 write('terminal.json',{'execution':'completed','commit':commit,'verified_records':81,'members':len(records),'archive_bytes':len(raw)})
except BaseException as error:write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
