from pathlib import Path
import subprocess,json,os,sys,hashlib,traceback,tarfile,unittest,contextlib
base=Path('/home/user/timelearner-refactor');root='63ec438adfd8657634a29d81d66a66d3ff891b4a'
out=base/('readbacks/s05-model-spec-production-'+'normal'+'-a4');out.mkdir(exist_ok=False)
sdk=base/'source-initial-threshold-normal-a4';runtime=base/'runtime-calibrated-model-spec2-normal-a1';build=base/'build-initial-threshold-normal-a4'
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def inventory(folder):
 return {p.relative_to(folder).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'realpath':str(p.resolve()),'bytes':p.stat().st_size} for p in folder.rglob('*') if p.is_file()}
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def git(*a):return subprocess.check_output(['git','-C',str(sdk),*a],text=True).strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'orchestration_root':root,'runtime_root':'f32de33257dd67e84962926f1225b1a6f6b29fcd'})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False;before=None
try:
 previous=base/('readbacks/s05-calibrated-model-spec2-'+'normal'+'-a1')
 assert not live(json.loads((previous/'owned-supervisor.json').read_text()))
 prior=base/'readbacks/s05-model-spec-production-normal-a3'
 assert not live(json.loads((prior/'owned-supervisor.json').read_text()))
 assert 'File exists' in (prior/'run.log').read_text() and 'reused-completed-operations.json' in (prior/'run.log').read_text()
 canonical=base/'readbacks/s05-model-spec-production-normal-a2'
 assert not live(json.loads((canonical/'owned-supervisor.json').read_text()))
 (out/'prior-attempt').mkdir()
 for name in ['primary.tar.xz','bundle.json']:(out/'prior-attempt'/name).write_bytes((prior/name).read_bytes())
 assert git('rev-parse','HEAD')=='f32de33257dd67e84962926f1225b1a6f6b29fcd'
 assert not git('status','--porcelain','--untracked-files=no')
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:assert not str((proc/'exe').resolve()).startswith(str(runtime)+'/'),'runtime_still_in_use'
  except (FileNotFoundError,PermissionError):pass
 before=inventory(runtime);write('runtime-before.json',before)
 repo=Path('/home/user/timelearner-refactor/git-relay-threshold-archive-normal-a1.git');code=out/'orchestration';code.mkdir()
 if 'normal'=='asan':
  subprocess.run(['git','init','--bare',str(repo)],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['git','-C',str(repo),'remote','add','origin','https://github.com/aicommunity/Nmsdk.git'],check=True)
  subprocess.run(['git','-C',str(repo),'config','remote.origin.promisor','true'],check=True)
  subprocess.run(['git','-C',str(repo),'config','remote.origin.partialclonefilter','blob:none'],check=True)
  with (out/'fetch-orchestration.log').open('w') as log:
   subprocess.run(['git','-C',str(repo),'fetch','--depth=1','--filter=blob:none','origin',root],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 assert subprocess.check_output(['git','-C',str(repo),'cat-file','-t',root],text=True).strip()=='commit'
 archive=subprocess.Popen(['git','-C',str(repo),'archive',root,'Scripts/StructTrain/TimeLearner'],stdout=subprocess.PIPE)
 subprocess.run(['tar','-xf','-','-C',str(code)],stdin=archive.stdout,check=True);archive.stdout.close();assert archive.wait()==0
 hashes={p.relative_to(code).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (code/'Scripts/StructTrain/TimeLearner').rglob('*') if p.is_file()}
 write('orchestration-source-hashes.json',hashes)
 sys.path.insert(0,str(code));os.chdir('/tmp')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.__main__ import main as cli
 write('runtime.json',snapshot(sdk,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 os.environ['TIMELEARNER_MODEL_SPEC_TRANSPORT_REPOSITORY']=str(sdk)
 def readers(label,test):
  suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_model_spec_transport.'+test)
  expected=4 if label=='prepare-readers' else 5
  assert suite.countTestCases()==expected
  with (out/(label+'.log')).open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
   result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
  write(label+'.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
  assert result.wasSuccessful() and result.testsRun==expected and not result.skipped
 readers('prepare-readers','ModelSpecTransportPreparationTest')
 for action,source,destination in [('prepare',sdk,out/'prepared'),('run',out/'prepared',out/'corpus')]:
  args=['model-spec-transport',action,str(source),'--output',str(destination)]
  if action=='run':args+=['--runtime-manifest',str(out/'runtime.json'),'--completed-prefix',str(base/'readbacks/s05-model-spec-production-normal-a2/corpus')]
  with (out/(action+'.log')).open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):result=cli(args)
  write(action+'-exit.json',{'exit_code':result});assert result==0,(action,result)
 os.environ['TIMELEARNER_MODEL_SPEC_TRANSPORT_PREPARED']=str(out/'prepared')
 os.environ['TIMELEARNER_MODEL_SPEC_TRANSPORT_RUN']=str(out/'corpus')
 readers('final-readers','ModelSpecTransportRunTest')
 index=json.loads((out/'corpus/index.json').read_text());assert index['all_calibrated_transfers_completed']
 passed=True;write('terminal.json',{'status':'passed','cold_train_conditions':4,'calibrated_fresh_transfers':4,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 if before is not None:
  after=inventory(runtime);write('runtime-after.json',after)
  if after!=before:passed=False;write('runtime-byte-guard-failed.json',{'same':False})
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and 'orchestration' not in p.relative_to(out).parts and not any(s.endswith('.git') for s in p.relative_to(out).parts)}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 write('bundle.json',{'kind':'native_model_spec_production_transport','acceptance_status':'passed' if passed else 'not_accepted','orchestration_root':root,'runtime_root':'f32de33257dd67e84962926f1225b1a6f6b29fcd','pulselib':'541bf89b9966f63ca5131fa57a31a9ae3f5820ea','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
