from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil,time
base=Path('/home/user/timelearner-refactor');label='managed-live-routing-normal-a5';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False);source=base/'source-native-runtime-interface-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='8c9ee9f6b319a06224d6ebdcdd537b88e993fc4a';container=Path(str(out)+'-container')
runtime_path=base/'readbacks/s02-native-runtime-interface-a1/console-runtime.json';templates=base/'readbacks/s09-native-pipeline-cli-normal-a2';stop=threading.Event();thread=None;errors=[];passed=False;token=None
capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 dependency_source=base/'source-worker-dependency-normal-a2'
 sys.path.insert(0,str(dependency_source))
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 dependency_registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 predecessor=base/'readbacks/s10-managed-pipeline-coordinator-normal-a4-container';observation=inspect_worker_dependency(predecessor,dependency_registry,'s10-managed-pipeline-coordinator-normal-a4');assert observation['state']=='ready',observation
 full=base/'readbacks/s10-managed-pipeline-coordinator-normal-a4';assert json.loads((full/'tests.json').read_text())=={'tests':8,'failures':0,'errors':0,'skipped':0,'expected':8}
 guard=base/'readbacks/s02-native-runtime-interface-a1';assert json.loads((guard/'terminal.json').read_text())['tests_passed']
 write('queue-prerequisite.json',{'resource':observation,'full_coordinator8_passed':True,'interface7_passed':True,'actual_console_manifest':str(runtime_path)})
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;assert memory>=8*1024**3 and shutil.disk_usage(base).free>=2*1024**3
 runtime=json.loads(runtime_path.read_text());assert runtime['source_closure']['root']['head']=='33fc48278cff860d20c570cb703198847f028065'
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':shutil.disk_usage(base).free,'controller_cap_bytes':512*1024**2,'native_process_cap_bytes':4*1024**3,'cold_training_expected':True,'same_matrix_frozen':True,'runtime_immutable':True,'compilation_disabled':True})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 positive_templates=base/'readbacks/s05-model-spec-production-normal-a4/corpus/runs'
 calibration_templates=base/'readbacks/s10-managed-native-calibration-normal-a1/actual-controls';os.environ['TIMELEARNER_COORDINATOR_CALIBRATION_TEMPLATES']=str(calibration_templates)
 paths=[source,bootstrap,dependency_source,templates,positive_templates,calibration_templates,runtime_path.parent,Path(runtime['executable']['path']).parent,Path(runtime['build_flags']['NMSDK_RESOURCE_ROOT'])]
 reserved=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(v),'access':'read'} for v in paths],demands={'slots':1,'memory_bytes':4*1024**3+512*1024**2,'disk_bytes':512*1024**2},ttl_seconds=120);token=reserved['token'];write('reservation.json',reserved)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root and not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 verify_runtime(runtime);(out/'native-runtime.json').write_bytes(runtime_path.read_bytes())
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM']:
  if key in runtime['loader_environment']:os.environ[key]=runtime['loader_environment'][key]
  else:os.environ.pop(key,None)
 os.environ.pop('ASAN_OPTIONS',None)
 write('declaration.json',{'runtime':str(out/'native-runtime.json'),'templates':str(templates),'positive_templates':str(positive_templates),'controller':str(container),'output':str(out/'actual-controls')});os.environ['TIMELEARNER_MANAGED_NATIVE_PIPELINE']=str(out/'declaration.json')
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_managed_live_pipeline');assert suite.countTestCases()==6
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':6});assert result.testsRun==6 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'actual_managed_native_phases':10 if passed else None,'other_modes_and_fault_matrix_pending':True,'independent_partition_verified':False,'scientific_verdict':None,'whole_plan_complete':False})
  write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    entry=tarfile.TarInfo(name);entry.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(entry,f)
  write('bundle.json',{'kind':'managed_actual_live_finalization_pipeline_checks','source_commit':root,'passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
