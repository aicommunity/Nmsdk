set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-combined-asan-a1
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-repeat-boundary-combined-a1
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_REPEAT_BOUNDARY_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-asan-a3/native
export TIMELEARNER_LEARNED_EVIDENCE_DIR="$TIMELEARNER_REPEAT_BOUNDARY_DIR"
export TIMELEARNER_NATIVE_TEST_REPORT_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-asan-a3
export TIMELEARNER_STOPPED_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s05-stopped-asan-a3/native
export TIMELEARNER_N0_REPEATS_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s07-n0-repeats-asan-a2/native
export TIMELEARNER_FULL_PROBE_REPORT_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s09-n0-full-probe-reports-a1
export TIMELEARNER_DOMAIN_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s07-domain-physics-asan-a1/native
export TIMELEARNER_PROBE_PLOT_DIR="$out/figures"
export TIMELEARNER_PARTIAL_PROBE_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-asan-a1/native
export TIMELEARNER_SIX_SOMA_DIR=/home/user/timelearner-refactor/readbacks/s05-pooled-full-a3/native
export TIMELEARNER_DIAGNOSTIC_PLOT_DIR="$out/diagnostic-figures"
OUT="$out" /media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python -u - <<'PY' > "$out/python.log" 2>&1
import json,os,unittest,subprocess,platform
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_test_reports import inventory_native_test_run
mods=["test_repeat_boundary_evidence","test_learned_evidence","test_stopped_evidence","test_n0_repeat_evidence","test_process_runner","test_publisher","test_condition","test_runtime","test_probe_reports","test_plotting","test_analysis_cli","test_full_probe_report_evidence","test_probe_diagnostics","test_native_test_reports"]
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(["Scripts.StructTrain.TimeLearner.tests."+m for m in mods]))
out=Path(os.environ["OUT"])
record={"kind":"timelearner_repeat_boundary_combined_readback","schema_version":1,"root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"python":platform.python_version(),"tests":r.testsRun,"skips":len(r.skipped),"failures":len(r.failures),"errors":len(r.errors),"inputs":{k:v for k,v in os.environ.items() if k.startswith("TIMELEARNER_")},"scientific_verdict":None}
(out/"validation.json").write_text(json.dumps(record,indent=2)+"\n")
if r.wasSuccessful() and not r.skipped:
 inv=inventory_native_test_run(Path("Scripts/StructTrain/TimeLearner/specs/repeat-boundary-native-v1.json"),Path(os.environ["TIMELEARNER_NATIVE_TEST_REPORT_DIR"]))
 (out/"inventory.json").write_text(json.dumps(inv,indent=2)+"\n")
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
PY
