from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,traceback
ROOT='74369ef343ec577e301c63f4c9ad6b0dabd2b935'
base=Path('/home/user/timelearner-refactor')
repo=base/'source-initial-threshold-normal-a1'
out=base/'readbacks/s04-stock-final-physics-reader-a1';out.mkdir(parents=True,exist_ok=False)
source=base/'code-stock-final-physics-reader-a1';source.mkdir(exist_ok=False)
fixtures=base/'cache-stock-final-physics-reader-a1';fixtures.mkdir(exist_ok=False)
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],check=True)
 raw=subprocess.check_output(['git','-C',str(repo),'archive',ROOT,'Scripts/StructTrain/TimeLearner'])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(source)
 commit='322409d685f20ab6b0be03f7d69e69399f127239';prefix='Reports/StructTrain/TimeLearner/s07-stock-phasea-cold-normal-a1/'
 def get(n):return subprocess.check_output(['git','-C',str(repo),'show',commit+':'+prefix+n])
 manifest=json.loads(get('manifest.json'));sums=json.loads(get('SHA256SUMS.json'))
 for n,digest in sums.items():assert hashlib.sha256(get(n)).hexdigest()==digest
 raw=get('primary.tar.xz');assert len(raw)==manifest['archive_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['archive_sha256']
 seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  for member in t:
   assert member.isfile() and member.name not in seen and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   seen.add(member.name);record=manifest['members'][member.name];data=t.extractfile(member).read()
   assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
   dest=fixtures/member.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 assert seen==set(manifest['members'])
 write('fixture-source.json',{'root':commit,'prefix':prefix,'archive_sha256':manifest['archive_sha256'],'members_verified':len(seen),'native_rerun':False})
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 count,fingerprint=fixture_fingerprint(fixtures,'**/*.*')
 name='Scripts.StructTrain.TimeLearner.tests.test_stock_threshold_study.StockFinalPhysicsTest'
 methods=['test_actual_growth_and_individual_resistance_edits_preserve_stock_physics','test_rehashed_added_lt_membrane_is_rejected',
          'test_rehashed_growth_channel_capacity_drift_is_rejected','test_rehashed_feedback_destination_change_is_rejected']
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'stock-final-physics4',
       'package_fingerprint':package_fingerprint(),'modules':[name],'expected_test_ids':[name+'.'+n for n in methods],
       'fixtures':{'TIMELEARNER_STOCK_COLD_PHYSICS':{'pattern':'**/*.*','files':count,'fingerprint':fingerprint}}}
 result=run_suite(spec,{'TIMELEARNER_STOCK_COLD_PHYSICS':str(fixtures)},out/'reader-result')
 assert result['executed_tests']==4 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 passed=True;write('terminal.json',{'readers':4,'native_rerun':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'stock_final_physics_readback','schema_version':1,'root':ROOT,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),
       'native_rerun':False,'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 pg('config','user.name','TimeLearner Evidence');pg('config','user.email','timelearner@localhost')
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s04-stock-final-physics-reader-a1'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: actual cold stock final physics and rehashed LT capacity feedback regressions\n')
 branch='refs/heads/codex/evidence-s04-stock-final-physics-reader-a1'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
