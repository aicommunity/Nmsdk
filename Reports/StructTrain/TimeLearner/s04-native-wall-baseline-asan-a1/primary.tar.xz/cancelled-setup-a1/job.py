from pathlib import Path
import subprocess,json,sys,os,time,traceback,hashlib,xml.etree.ElementTree as ET
base=Path('/media/user/Data/TimeLearnerRefactor');old=base/'source-n1-measured-refinement-asan-a1'
source=base/'source-native-wall-asan-a1';build=base/'build-native-wall-asan-a1';runtime=base/'runtime-s04-native-wall-baseline-asan-a1'
out=Path(__file__).resolve().parent
assert out==base/'readbacks/s04-native-wall-baseline-asan-a1'
root='162afc02abc321368304c8913a12a8ab2195682b'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name,timeout=600):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-c','submodule.recurse=false','-C',str(repo),*args],text=True).strip()
def context():
 return {'root':git(old,'rev-parse','HEAD'),'root_status':git(old,'status','--porcelain','--untracked-files=no'),
         'rdk':git(old/'Rdk','rev-parse','HEAD'),'pulse':git(old/'Libraries/Nmsdk-PulseLib','rev-parse','HEAD'),
         'bin':git(old/'Bin','rev-parse','HEAD'),
         'existing_build_cache_sha256':hashlib.sha256((base/'build-n1-measured-refinement-asan-a1/CMakeCache.txt').read_bytes()).hexdigest()}
try:
 assert not source.exists() and not build.exists() and not runtime.exists()
 mem={line.split(':',1)[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))}
 disk=os.statvfs(base);resources={'memory':mem,'free_bytes':disk.f_bavail*disk.f_frsize,'cpu_count':os.cpu_count(),'compile_parallel_jobs':2}
 write('resources.json',resources);assert mem['MemAvailable']>6*1024**3 and resources['free_bytes']>15*1024**3 and (os.cpu_count() or 0)>=4
 before=context();write('existing-native-context-before.json',before)
 run(['git','clone','--shared','--no-checkout','--origin','local-source',old,source],'clone-root.log')
 run(['git','-C',source,'fetch','--no-tags','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],'fetch-root.log')
 assert git(source,'rev-parse','FETCH_HEAD')==root
 trees=[line.split('\t',1)[1] for line in git(source,'ls-tree',root).splitlines() if line.split()[1]=='tree']
 keep=[name for name in trees if name not in ['Docs','Reports']]
 run(['git','-C',source,'sparse-checkout','set',*keep],'sparse-root.log')
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 count=0
 def children(original,cloned,revision):
  global count
  for line in git(cloned,'ls-tree','-r',revision).splitlines():
   head,path=line.split('\t',1)
   if not head.startswith('160000 '):continue
   relative=Path(path);assert not relative.is_absolute() and '..' not in relative.parts
   oldChild=original/relative;newChild=cloned/relative
   assert Path(git(oldChild,'rev-parse','--show-toplevel')).resolve()==oldChild.resolve(),'source_child_alias:'+path
   wanted=head.split()[2];count+=1;tag=str(count)
   newChild.parent.mkdir(parents=True,exist_ok=True)
   run(['git','clone','--shared','--no-checkout','--origin','local-source',oldChild,newChild],'clone-child-'+tag+'.log')
   assert git(newChild,'cat-file','-t',wanted)=='commit'
   run(['git','-C',newChild,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-child-'+tag+'.log')
   children(oldChild,newChild,wanted)
 children(old,source,root)
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 run(['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DBUILD_TESTING=ON',
      '-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer',
      '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DNMSDK_BUILD_PARALLEL_JOBS=2',
      '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DNMSDK_DEPLOY_ROOT='+str(runtime),
      '-DNMSDK_RESOURCE_ROOT='+str(source/'Bin')],'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','2'],'build.log',14400)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native')
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 result=execute(manifest,['--gtest_filter=NativeWallSchedule.ClassicN1OwnerLarge:NativeWallSchedule.BranchN1GeneratorLarge','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',3600)
 write('execution.json',result);assert result['execution']=='process_error' and result['returncode']==1,result
 tree=ET.parse(out/'gtest.xml').getroot();write('validation.json',{'gtest':tree.attrib,'scientific_verdict':None})
 assert tree.attrib['tests']=='2' and tree.attrib['failures']=='2' and tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 policies=[json.loads(p.read_text()) for p in (out/'native').glob('*_wall_policy.json')]
 assert len(policies)==2 and all(p['status']=='completed' and p['observed_samples']>0 and not p['changed_individual_parameters'] and p['effective_limit_after_probe']==1000000000 for p in policies),policies
 write('baseline-policy-readback.json',{'cases':policies,'interpretation':'unsupported scheduling policy accepted; actual wall skips not attested','scientific_verdict':None})
 assert source_closure(source)==closure;verify_runtime(manifest)
 after=context();write('existing-native-context-after.json',after);assert before==after
 write('terminal.json',{'execution':'expected_baseline_failure','native_tests':2,'expected_failures':2,'separate_submodule_clones':count,'existing_native_source_and_build_unchanged':True,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
