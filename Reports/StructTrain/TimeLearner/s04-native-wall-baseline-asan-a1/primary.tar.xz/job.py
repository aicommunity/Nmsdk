from pathlib import Path
import subprocess,json,sys,os,time,traceback,hashlib,pathlib,xml.etree.ElementTree as ET
base=Path('/media/user/Data/TimeLearnerRefactor');old=base/'source-n1-measured-refinement-asan-a1'
source=base/'source-native-wall-asan-a1';build=base/'build-native-wall-asan-a1';runtime=base/'runtime-s04-native-wall-baseline-asan-a2'
out=Path(__file__).resolve().parent
assert out==base/'readbacks/s04-native-wall-baseline-asan-a2'
root='162afc02abc321368304c8913a12a8ab2195682b'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args,name,timeout=600):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-c','submodule.recurse=false','-C',str(repo),*args],text=True).strip()
def context():
 return {'root':git(old,'rev-parse','HEAD'),'root_status':git(old,'status','--porcelain','--untracked-files=no'),
         'rdk':git(old/'Rdk','rev-parse','HEAD'),'pulse':git(old/'Libraries/Nmsdk-PulseLib','rev-parse','HEAD'),
         'bin':git(old/'Bin','rev-parse','HEAD'),
         'existing_build_cache_sha256':hashlib.sha256((base/'build-n1-measured-refinement-asan-a1/CMakeCache.txt').read_bytes()).hexdigest()}
try:
 assert source.exists() and build.exists() and not runtime.exists()
 mem={line.split(':',1)[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))}
 disk=os.statvfs(base);resources={'memory':mem,'free_bytes':disk.f_bavail*disk.f_frsize,'cpu_count':os.cpu_count(),'compile_parallel_jobs':2}
 write('resources.json',resources);assert mem['MemAvailable']>6*1024**3 and resources['free_bytes']>15*1024**3 and (os.cpu_count() or 0)>=4
 before=context();write('existing-native-context-before.json',before)
 transport_ancestors={};pid=os.getpid()
 while pid>1:
  fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(') ',1)[1].split();transport_ancestors[str(pid)]=fields[19];pid=int(fields[1])
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert git(source,'rev-parse','HEAD')==root
 assert not git(source,'status','--porcelain','--untracked-files=no')
 prior=base/'readbacks/s04-native-wall-baseline-asan-a1'
 write('prior-setup.json',{'cancelled':json.loads((prior/'cancelled.json').read_text()),'original_source_manifest_sha256':hashlib.sha256((prior/'source.json').read_bytes()).hexdigest()})
 cache=base/'build-n1-measured-refinement-asan-a1/CMakeCache.txt'
 inherited={}
 for line in cache.read_text().splitlines():
  if ':BOOL=' in line and line.startswith(('RDK_','NO_MOTION_CONTROL:')):
   key,value=line.split(':BOOL=',1);inherited[key]=value
 assert inherited['RDK_LLM_BUILD_EMBEDDED']=='OFF'
 forwarded=['-D'+k+'='+v for k,v in sorted(inherited.items())]
 write('inherited-build-policy.json',{'reference_cache_sha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'flags':inherited,'previous_llama_default_cancelled':True})
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure);assert closure==json.loads((prior/'source.json').read_text())
 run(['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DBUILD_TESTING=ON',
      '-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer',
      '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DNMSDK_BUILD_PARALLEL_JOBS=2',
      '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DNMSDK_DEPLOY_ROOT='+str(runtime),
      '-DNMSDK_RESOURCE_ROOT='+str(source/'Bin'),*forwarded],'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','2'],'build.log',14400)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native')
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 result=execute(manifest,['--gtest_filter=NativeWallSchedule.ClassicN1OwnerLarge:NativeWallSchedule.BranchN1GeneratorLarge','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',3600)
 write('execution.json',result);assert result['execution']=='process_error' and result['returncode']==1,result
 tree=ET.parse(out/'gtest.xml').getroot();write('validation.json',{'gtest':tree.attrib,'scientific_verdict':None})
 assert tree.attrib['tests']=='2' and tree.attrib['failures']=='2' and tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 policies=[json.loads(p.read_text()) for p in (out/'native').glob('*_wall_policy.json')]
 assert len(policies)==2 and all(p['status']=='completed' and p['observed_samples']>0 and not p['changed_individual_parameters'] and p['effective_limit_after_probe']==1000000000 for p in policies),policies
 write('baseline-policy-readback.json',{'cases':policies,'interpretation':'unsupported scheduling policy accepted; actual wall skips not attested','scientific_verdict':None})
 assert source_closure(source)==closure;verify_runtime(manifest)
 after=context();write('existing-native-context-after.json',after);assert before==after
 write('terminal.json',{'execution':'expected_baseline_failure','native_tests':2,'expected_failures':2,'source_clones_reused_from_prior_setup':True,'existing_native_source_and_build_unchanged':True,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
