from pathlib import Path
import os,sys,json,traceback,xml.etree.ElementTree as ET
base=Path('/media/user/Data/TimeLearnerRefactor');out=Path(__file__).resolve().parent
assert out.parent==(base/'readbacks').resolve() and out.name=='s07-measured-length-regression-asan-a2'
assert {p.name for p in out.iterdir()} <= {'job.py','pid.json','supervisor.log'}
previous=base/'readbacks/s07-measured-length-current-asan-a1'
source=base/'source-n1-measured-refinement-asan-a1'
sys.path.insert(0,str(base/'readbacks/s02-source-worktree-identity-asan-a2/current'))
from Scripts.StructTrain.TimeLearner.runtime import source_closure
from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
try:
 for pid in [1021013,1025812]:assert not (Path('/proc')/str(pid)).exists(),'previous_process_still_present'
 manifest=json.loads((previous/'runtime.json').read_text())
 assert source_closure(source)==json.loads((previous/'source.json').read_text())
 verify_runtime(manifest)
 write('runtime.json',manifest);write('source.json',source_closure(source))
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native-regression')
 args=['--gtest_filter=NativeResistanceDomains.*:NativeModelEditor.*','--gtest_output=xml:'+str(out/'gtest.xml')]
 result=execute(manifest,args,Path(manifest['executable']['path']).parent,out/'process',14400)
 write('execution.json',result)
 assert result['execution']=='completed' and result['returncode']==0,result
 tree=ET.parse(out/'gtest.xml').getroot()
 write('validation.json',{'kind':'measured_length_native_regression_remaining','gtest':tree.attrib,'previous_attempt':'s07-measured-length-current-asan-a1','previous_timeout_seconds':7200,'previous_four_training_cases_passed_in_stdout':True,'current_expected_tests':24,'same_frozen_runtime':True,'scientific_verdict':None})
 assert tree.attrib['tests']=='24' and tree.attrib['failures']==tree.attrib['errors']=='0' and not tree.findall('.//testcase/skipped')
 assert source_closure(source)==json.loads((out/'source.json').read_text())
 verify_runtime(manifest)
 write('terminal.json',{'execution':'completed','native_regression_tests':24,'scientific_verdict':None})
except BaseException as e:
 write('exception.json',{'error':str(e),'traceback':traceback.format_exc()});raise
