
from pathlib import Path
import os,sys,json,subprocess,hashlib,shutil,time,threading,traceback,importlib.util,tarfile
base=Path('/media/user/Data/TimeLearnerRefactor');root='e218753e49b12f05708a60a4f22266882f810430'
out=base/'readbacks/s00-current-develop-checkout-m40-a1';out.mkdir(exist_ok=False)
source=base/'fresh-current-develop-checkout-m40-a1'
stop=threading.Event();thread=None;lease=None;token=None;errors=[];passed=False
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source)})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
def run(args,label):
 if token:lease.validate_paths(token)
 assert not errors,errors
 with (out/(label+'.log')).open('xb') as log:
  p=subprocess.Popen(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
  write('owned-'+label+'.json',{'pid':p.pid,'start_ticks':ticks(p.pid),'arguments':list(map(str,args))})
  rc=p.wait()
 assert rc==0,(label,rc)
def git(directory,*args):return subprocess.check_output(['git','-C',str(directory),*args],text=True).strip()
try:
 assert not source.exists()
 memory=int(next(r.split()[1] for r in Path('/proc/meminfo').read_text().splitlines() if r.startswith('MemAvailable:')))*1024
 disk=shutil.disk_usage(base);assert memory>=8*1024**3 and disk.free>=20*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'neural_runs':0,'builds':0})
 implementation=base/'readbacks/s10-resource-budgets-m40-a2/source/Scripts/StructTrain/TimeLearner/resource_reservations.py'
 spec=importlib.util.spec_from_file_location('checkout_reservations',implementation);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 lease=module.Reservations(base/'resource-reservations.sqlite3')
 reservation=lease.reserve('s00-current-develop-checkout-m40-a1',[{'path':str(p),'access':'write'} for p in [source,out]],ttl_seconds=120)
 token=reservation['token'];write('reservation.json',dict(reservation,implementation_root='63d7d6285ee8c8aa38221206037ce92ce50372e2',implementation_sha256=hashlib.sha256(implementation.read_bytes()).hexdigest(),capacity_policy='existing shared schema1 ledger; no live migration'))
 def heartbeat():
  while not stop.wait(20):
   try:lease.heartbeat(token,ttl_seconds=120);lease.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 run(['git','init',source],'init-root')
 run(['git','-C',source,'config','core.autocrlf','false'],'configure-line-endings')
 run(['git','-C',source,'remote','add','origin','https://github.com/aicommunity/Nmsdk.git'],'root-origin')
 run(['git','-C',source,'fetch','--no-recurse-submodules','--depth=1','--filter=blob:none','origin',root],'fetch-pinned-root')
 run(['git','-C',source,'checkout','--detach',root],'checkout-pinned-root')
 run(['git','-C',source,'-c','url.https://github.com/.insteadOf=git@github.com:','submodule','update','--init','--recursive','--depth=1'],'checkout-exact-gitlinks')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 closure=source_closure(source);assert closure['root']['head']==root
 assert all(not r['status'] for r in closure.values())
 write('source-closure.json',closure)
 repositories=[('',source)]
 status=git(source,'submodule','status','--recursive');(out/'submodule-status.txt').write_text(status+'\n')
 for line in status.splitlines():
  assert not line.startswith(('+','-','U')),line
  fields=line.split();repositories.append((fields[1],source/fields[1]))
 assert len(repositories)>=8
 verified={}
 for name,repo in repositories:
  assert not git(repo,'status','--porcelain','--untracked-files=no')
  files={};total=0
  for entry in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z','HEAD']).split(b'\0'):
   if not entry:continue
   header,path=entry.split(b'\t',1);mode,kind,sha=header.split()
   if kind==b'commit':continue
   assert kind==b'blob'
   relative=path.decode();actual=repo/relative
   raw=os.fsencode(os.readlink(actual)) if mode==b'120000' else actual.read_bytes()
   assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha.decode(),(name,relative)
   files[relative]={'git_blob':sha.decode(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)};total+=len(raw)
  verified[name or 'root']={'head':git(repo,'rev-parse','HEAD'),'files':files,'tracked_bytes':total}
  run(['git','-C',repo,'fsck','--connectivity-only','--no-dangling'],'connectivity-'+(name.replace('/','_') or 'root'))
 write('tracked-files-verified.json',verified)
 assert git(source,'rev-parse','HEAD:Libraries/Nmsdk-PulseLib')=='9ec4566d71bf56d4eeb5c8a920bbc683fcd85299'
 assert not errors
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 if token:
  if not errors:lease.release(token,note='All synchronous Git and integrity operations closed; no numerical process launched.')
  write('reservation-final.json',lease.inspect())
 write('terminal.json',{'acceptance_status':'passed' if passed else 'not_accepted','root':root,'origin_only_fresh_checkout':True,'alternate_object_donors_used':False,'builds':0,'neural_runs':0,'complete_plan_attested':False,'scientific_verdict':None})
 files={p.name:p.read_bytes() for p in out.iterdir() if p.is_file()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  import io
  for name,raw in files.items():entry=tarfile.TarInfo(name);entry.size=len(raw);archive.addfile(entry,io.BytesIO(raw))
 raw=(out/'primary.tar.xz').read_bytes();write('bundle.json',{'kind':'fresh_recursive_develop_checkout','schema_version':1,'root':root,'acceptance_status':'passed' if passed else 'not_accepted','members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in files.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
