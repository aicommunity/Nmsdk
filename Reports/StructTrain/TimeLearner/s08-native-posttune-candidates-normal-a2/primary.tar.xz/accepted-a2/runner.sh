set -euo pipefail
base=/home/user/timelearner-refactor
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
out="$base/readbacks/s08-native-posttune-candidates-normal-a2";runtime="$base/runtime-s08-native-posttune-candidates-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
test ! -e "$runtime"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 149a1af0aea88b523871a4e3f6a72fc0bf217c2b > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach 149a1af0aea88b523871a4e3f6a72fc0bf217c2b >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native" "$out/regressions"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativePostTuneCandidates.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/regressions" ./Test_PulseLib_StorageComponents --gtest_filter='NativeRecognitionState.SpecIsStrictAndRoundtrips:NativeRecognitionState.StoppedPackageCannotBecomeCompletedRecognition:NativeRecognitionState.ClassicN0Identity:NativeRecognitionState.BranchN1HistoricalScale' --gtest_output="xml:$out/regressions.xml") > "$out/regressions.log" 2>&1
TIMELEARNER_POSTTUNE_CANDIDATES_DIR="$out/native" python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_candidates -v > "$out/reader.log" 2>&1
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);v={'root':'149a1af0aea88b523871a4e3f6a72fc0bf217c2b','scientific_verdict':None}
for name,expected in [('native',5),('regressions',4)]:
 r=E.parse(p/(name+'.xml')).getroot()
 q={'tests':len(list(r.iter('testcase'))),'failures':len(list(r.iter('failure'))),'errors':len(list(r.iter('error'))),'skips':len(list(r.iter('skipped')))}
 assert q=={'tests':expected,'failures':0,'errors':0,'skips':0},q
 v[name]=q
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
PY
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
