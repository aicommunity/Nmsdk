set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-reader-asan-a2
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-posttune-observation-report-normal-a1
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_LEGACY_POSTTUNE_FREERUN_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-fixed-asan-a2/native
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.tests.test_legacy_posttune_evidence import LegacyPostTunePhysicalEvidenceTest as Case
names=['test_four_actual_traces_remain_diagnostics','test_missing_native_sample_is_rejected','test_unknown_foil_state_cannot_reuse_valid_summary','test_changed_actual_onset_list_is_rejected','test_selected_metric_must_match_actual_somas','test_finite_peak_summary_must_replay_from_actual_trace']
r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Case(name) for name in names))
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'a153c052af7cfd2953e2fe2a1ce087bc7b5f2cc7',
 'tests':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skips':len(r.skipped),'rendering_repeated':False,'sample_peak_replay':True,'scientific_verdict':None},indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==6 and not r.skipped
import hashlib
normal=Path('/media/user/Data/TimeLearnerRefactor/readbacks/s08-posttune-observation-report-normal-a1/source/fixed-native/native')
actual=Path(os.environ['TIMELEARNER_LEGACY_POSTTUNE_FREERUN_DIR'])
comparison=[]
for p in sorted(actual.glob('*_posttune_inference_physical.json')):
 q=normal/p.name
 comparison.append({'case':p.stem,'packet_semantically_equal':json.loads(p.read_bytes())==json.loads(q.read_bytes()),
  'csv_sha256':hashlib.sha256(p.with_suffix('.csv').read_bytes()).hexdigest(),
  'normal_csv_sha256':hashlib.sha256(q.with_suffix('.csv').read_bytes()).hexdigest()})
for row in comparison:row['csv_byte_identical']=row['csv_sha256']==row['normal_csv_sha256']
Path(os.environ['OUT'],'normal-asan-comparison.json').write_text(json.dumps({'cases':comparison,
 'same_waveform_cache_correspondence':all(row['csv_byte_identical'] and row['packet_semantically_equal'] for row in comparison),
 'independent_scientific_repeats':False,'scientific_verdict':None},indent=2)+'\n')
PY
