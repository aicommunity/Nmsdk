from pathlib import Path
import sys,os,json,subprocess,hashlib,threading,traceback,shutil,tarfile,io,time,xml.etree.ElementTree as ET
base=Path('/media/user/Data/TimeLearnerRefactor');venv=base/'plot-venv-a1/bin/python'
assert venv.is_file()
if sys.prefix!=str(venv.parent.parent):os.execv(str(venv),[str(venv),'-u',str(Path(__file__).resolve())])
label='joint44-frozen-visual-a3';out=base/('readbacks/s11-'+label);out.mkdir(exist_ok=False)
source=base/'source-csearch-threshold-joint-asan-build-a1';repo=base/'source-inventory-snapshots-a1';bootstrap=base/'source-closed-worker-recovery-a3';job='94c3fa262b6691faa0bef7ed1479d7b7882a6ab8'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git','-c','remote.origin.url=https://github.com/aicommunity/Nmsdk.git','-C',str(repo),*args])
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'job_source':job,'renderer_source':'8021301e894368aefd045f9d77274fcce9f60245','contained_supervisor':str(base/('readbacks/s11-'+label+'-container'))})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;disk=shutil.disk_usage(base);assert memory>=34*1024**3 and disk.free>=16*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':disk.free,'worker_memory_max_bytes':2*1024**3,'worker_tasks_max':64,'native_models_executed':0})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 assert inspect_contained(base/'readbacks/s11-joint44-frozen-visual-a2-container')['all_processes_closed']
 registry=Reservations(base/'resource-reservations.sqlite3');reservation=registry.reserve('s11-'+label,[{'path':str(p),'access':'write'} for p in [out,repo]]+[{'path':str(p),'access':'read'} for p in [source,bootstrap,venv.parent.parent]],ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert inspect_contained(base/'readbacks/s07-csearch-threshold-joint-asan-build-a2-container')['all_processes_closed']
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='8021301e894368aefd045f9d77274fcce9f60245'
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 with (out/'fetch.log').open('wb') as log:subprocess.run(['git','-c','remote.origin.url=https://github.com/aicommunity/Nmsdk.git','-C',str(repo),'fetch','--no-recurse-submodules','--depth','1','--filter=blob:none','origin',job,'82910cad87425fcad0ef67480d612bb917c6d933'],stdout=log,stderr=subprocess.STDOUT,check=True)
 recipe_path='Scripts/StructTrain/TimeLearner/specs/native-joint44-frozen-report-v1.json';reader_path='Scripts/StructTrain/TimeLearner/tests/test_joint_frozen_report_evidence.py'
 recipe_raw=git('show',job+':'+recipe_path);reader_raw=git('show',job+':'+reader_path);(out/'recipe.json').write_bytes(recipe_raw);(out/'data-reader.py').write_bytes(reader_raw);recipe=json.loads(recipe_raw)
 write('job-source-hashes.json',{recipe_path:hashlib.sha256(recipe_raw).hexdigest(),reader_path:hashlib.sha256(reader_raw).hexdigest()})
 pre=recipe['primary_prefix'];proof=recipe['primary_proof'];raw=git('show',proof+':'+pre+'primary.tar.xz');bundle=json.loads(git('show',proof+':'+pre+'bundle.json'));assert len(raw)==bundle['archive_bytes'] and hashlib.sha256(raw).hexdigest()==bundle['archive_sha256']==recipe['primary_archive_sha256']
 inputs=out/'inputs';inputs.mkdir();seen=set()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r|xz') as archive:
  for entry in archive:
   assert entry.isfile() and entry.name not in seen and not entry.name.startswith('/') and '..' not in entry.name.split('/');seen.add(entry.name);value=archive.extractfile(entry).read();assert {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}==bundle['members'][entry.name]
   path=inputs/entry.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(value)
 assert seen==set(bundle['members']);del raw
 junit=ET.parse(inputs/'native-result/native.xml');cases=list(junit.iter('testcase'));spec=json.loads((inputs/'native-specification.json').read_text());ids={x.get('classname')+'/'+x.get('name') for x in cases};assert len(cases)==len(ids)==44 and ids==set(spec['expected_test_ids']) and {x['test_id'] for x in recipe['models']}.issubset(ids) and all(x.get('result')=='completed' and not any(x.find(k) is not None for k in ['failure','error','skipped']) for x in cases)
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256
 from Scripts.StructTrain.TimeLearner.reports import render_evaluation
 write('renderer-source-closure.json',source_closure(source))
 native=inputs/'native-result/native';cache=out/'full-report-cache';cache.mkdir();declarations=out/'declarations';declarations.mkdir();rows=[];failures=[]
 for index,model in enumerate(recipe['models']):
  try:
   stem=model['stem'];package=json.loads((native/(stem+'_owner_recognition_state.json')).read_text())
   declaration={'kind':'timelearner_recognition_evaluation_spec','schema_version':1,'run_id':stem+'_frozen','model_revision':package['model_revision'],'coverage_policy':recipe['coverage_policy'],'criterion':recipe['criterion'],'trials':[]}
   folder=declarations/f'case-{index:02d}';folder.mkdir();(folder/'model.json').write_text(json.dumps(package))
   for trial in recipe['trials']:
    n=trial['presentation_index'];name=f'trial-{n}.json';(folder/name).write_bytes((native/(stem+'_frozen_trial_'+str(n)+'.json')).read_bytes());declaration['trials'].append({k:v for k,v in trial.items() if k!='pattern_isi'}|{'pattern_hash':canonical_model_sha256(trial['pattern_isi']),'observation':name})
   (folder/'evaluation.json').write_text(json.dumps(declaration));target=cache/(stem.split('_',1)[0]+f'-case-{index:02d}');result=render_evaluation(folder/'evaluation.json',folder/'model.json',target);assert result['trial_soma_pairs']==4*model['soma_channels'];rows.append({'test_id':model['test_id'],'case':target.name,'result':result,'analysis':json.loads((target/'analysis.json').read_text())})
  except BaseException as error:failures.append({'test_id':model['test_id'],'reason':str(error),'traceback':traceback.format_exc()})
  write('render-progress.json',{'completed':len(rows),'failures':failures,'expected':10})
 assert not failures,failures
 env=dict(os.environ,PYTHONPATH=str(source),TIMELEARNER_JOINT44_VISUAL_DIR=str(cache),TIMELEARNER_JOINT44_VISUAL_RECIPE=str(out/'recipe.json'))
 with (out/'reader-tests.log').open('wb') as log:result=subprocess.run([sys.executable,str(out/'data-reader.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert result.returncode==0,result.returncode
 reader=(out/'reader-tests.log').read_text();assert 'Ran 5 tests' in reader and reader.rstrip().endswith('OK') and 'skipped' not in reader.lower()
 summaries=out/'report-summaries';summaries.mkdir()
 for row in rows:
  folder=cache/row['case'];dest=summaries/row['case'];dest.mkdir()
  for name in ['analysis.json','manifest.json','series.json','SHA256SUMS.json']:(dest/name).write_bytes((folder/name).read_bytes())
 write('render-summary.json',{'models':10,'trials':40,'trial_soma_pairs':60,'reader_tests_passed':5,'rows':rows,'cache_path':str(cache),'visual_acceptance_pending':True,'native_models_executed':0,'primary_source_git':proof,'scientific_verdict':None});assert not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'render_and_reader_checks_passed':passed,'visual_acceptance_pending':True,'scientific_verdict':None,'native_models_executed':0,'whole_plan_complete':False})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and p.relative_to(out).parts[0] not in ['inputs','declarations','full-report-cache']}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    info=tarfile.TarInfo(name);info.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(info,f)
  write('bundle.json',{'kind':'joint44_frozen_visual_report_checks','job_source':job,'renderer_source':'8021301e894368aefd045f9d77274fcce9f60245','render_and_reader_checks_passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'primary_source_git':'82910cad87425fcad0ef67480d612bb917c6d933','full_cache_excluded':True,'visual_acceptance_pending':True,'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
