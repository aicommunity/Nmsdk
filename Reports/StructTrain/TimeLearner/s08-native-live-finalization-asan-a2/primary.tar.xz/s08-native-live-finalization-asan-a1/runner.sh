set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-live-finalization-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-owned-posttune-worker-reader-asan-a2/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 600000000
test -z "$(git -C "$src" status --porcelain)"
export BASE="$base" SRC="$src" BUILD="$build" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
from pathlib import Path
import json,os
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c gc.auto=0 -c fetch.recurseSubmodules=false fetch origin 6659caaf57744489e2cd2b615f7e17a3bfb9003d > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src";export PYTHONDONTWRITEBYTECODE=1
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
unset QT_QPA_PLATFORM
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
result=execute(runtime,['--gtest_filter=NativeLiveFinalization.ClassicAutomaticFixed:NativeLiveFinalization.BranchAutomaticFixed:NativeFinalizationClockHandoff.*','--gtest_output=xml:'+str(out/'native.xml')],Path(runtime['executable']['path']).parent,out/'process',1800)
tree=ET.parse(out/'native.xml').getroot()
assert result['execution']=='completed' and result['returncode']==0 and result['runtime_provenance']=='loaded_files_captured'
assert int(tree.attrib['tests'])==6 and not any(int(tree.attrib.get(k,0)) for k in ('failures','errors','disabled')) and not tree.findall('.//skipped')
rows=[p.name for p in (out/'native').glob('*_live_finalization_*.json')];assert len(rows)==2
summary={'kind':'native_live_finalization_smoke_gate','schema_version':1,'tests':6,'seconds':float(tree.attrib['time']),'live_records':rows,'native_execution_attested':False,'live_train_handoff_implemented':True,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
