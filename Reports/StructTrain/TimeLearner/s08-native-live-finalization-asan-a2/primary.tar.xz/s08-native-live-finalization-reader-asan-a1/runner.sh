set -euo pipefail
out='/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-live-finalization-reader-asan-a1'
producer='/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-live-finalization-asan-a1'
src='/media/user/Data/TimeLearnerRefactor/source-threshold-contract-asan-isolated-a1'
runtime='/media/user/Data/TimeLearnerRefactor/runtime-s08-native-training-threshold-reference-asan-a1'
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$producer/process-exit-status.txt"; do kill -0 1251;sleep 10;done
cd '/media/user/Data/TimeLearnerRefactor/source-live-finalization-reader-asan-a1'
export PYTHONDONTWRITEBYTECODE=1 TIMELEARNER_LIVE_FINALIZATION_NATIVE="$producer/native" OUT="$out" PRODUCER="$producer"
python3 - <<'PY' > "$out/native-prerequisite.json"
from pathlib import Path
import os,json,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
p=Path(os.environ['PRODUCER']);x=ET.parse(p/'native.xml').getroot();r=load(p/'process/result.json')
assert int(x.attrib['tests'])==6 and not any(int(x.attrib.get(k,0)) for k in ('failures','errors','disabled')) and not x.findall('.//skipped')
assert r['execution']=='completed' and r['returncode']==0 and r['runtime_provenance']=='loaded_files_captured'
print(json.dumps({'native_tests':6,'seconds':float(x.attrib['time']),'process_returncode':0,'supervisor_status':int((p/'process-exit-status.txt').read_text()),'native_source':'6659caaf57744489e2cd2b615f7e17a3bfb9003d','scientific_verdict':None}))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache '/media/user/Data/TimeLearnerRefactor/build-threshold-contract-asan-isolated-a1/CMakeCache.txt' --output "$out/runtime-after.json"
cmp "$producer/runtime-before.json" "$out/runtime-after.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
import os,json,time,unittest
from pathlib import Path
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_finalization_evidence')
r=unittest.TextTestRunner(verbosity=2).run(suite)
value={'kind':'native_live_finalization_reader_gate','schema_version':1,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,'native_execution_attested':False,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==2 and not r.skipped,value
print(json.dumps(value),flush=True)
PY
