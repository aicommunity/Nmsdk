set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-live-finalization-reader-asan-a2"
producer="$base/readbacks/s08-native-live-finalization-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$producer/process-exit-status.txt";do kill -0 20741;sleep 10;done
test "$(cat "$producer/process-exit-status.txt")" = 0
cd "$base/source-live-finalization-reader-asan-a2"
export OUT="$out" PRODUCER="$producer" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_LIVE_FINALIZATION_NATIVE="$producer/native"
export TIMELEARNER_NATIVE_GATE_ROOT="$producer"
export TIMELEARNER_NATIVE_GATE_AFTER="$producer/runtime-after.json"
export TIMELEARNER_NATIVE_GATE_SPEC="$PWD/Scripts/StructTrain/TimeLearner/Specifications/native-live-finalization-regression.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,unittest,hashlib
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.native_execution_gate import read_native_gate,audit_native_gate
start=time.monotonic();producer=Path(os.environ['PRODUCER']);out=Path(os.environ['OUT'])
def snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((producer/'native').iterdir()) if p.is_file()}
before=snapshot()
spec=load(Path(os.environ['TIMELEARNER_NATIVE_GATE_SPEC']))
native=audit_native_gate(spec,read_native_gate(spec,producer,producer/'runtime-after.json'))
rows=[]
for name,count in (('test_native_execution_gate',2),('test_live_finalization_evidence',4)):
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name))
 row={'module':name,'tests':r.testsRun,'planned':count,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped)}
 rows.append(row)
 (out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.wasSuccessful() and r.testsRun==count and not r.skipped,row
assert snapshot()==before
value={'kind':'full_live_finalization_reader_gate','schema_version':1,'tests':sum(r['tests'] for r in rows),'modules':rows,'native_gate':native,
 'source_native_root':'f0cf989cb85c3286781330e6af85261a90ea3936','source_pulse':'cf530be5f36e17d319365a9491f7a58311b28951',
 'source_reader_root':'d16237f838eec366df86d05455b3d266386a0e88','seconds':time.monotonic()-start,'source_files_unchanged':len(before),'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value),flush=True)
PY
