import pathlib,json,subprocess,os,sys,hashlib,io,tarfile,traceback,time
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/'readbacks').resolve() and out.name=='s07-measured-length-native-asan-a2'
assert {p.name for p in out.iterdir()} <= {'job.py','pid.json','supervisor.log'}
source=base/'source-n1-measured-refinement-asan-a1';build=base/'build-n1-measured-refinement-asan-a1'
parent=base/'readbacks/s07-measured-length-current-asan-a1'
analysis=base/'source-measured-length-analysis-a2';assert not analysis.exists()
root='41261d366b4d7537dcb24e7e7e22bafad5c6c8ed'
def write(name,value):
 with (out/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','-C',str(source),*args])
try:
 prior=base/'readbacks/s07-measured-length-native-asan-a1';owned=json.loads((prior/'pid.json').read_text());proc=pathlib.Path('/proc')/str(owned['pid'])/'stat'
 assert not proc.exists() or proc.read_text().rsplit(') ',1)[1].split()[19]!=str(owned['start_ticks'])
 start=time.monotonic()
 while not (parent/'validation.json').exists():
  assert not (parent/'exception.json').exists()
  owned=json.loads((parent/'pid.json').read_text());p=pathlib.Path('/proc')/str(owned['pid'])/'stat'
  assert p.exists() and p.read_text().rsplit(') ',1)[1].split()[19]==str(owned['start_ticks'])
  assert time.monotonic()-start<7200
  time.sleep(2)
 validation=json.loads((parent/'validation.json').read_text());assert validation['gtest']['tests']=='39' and validation['gtest']['failures']=='0'
 git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root)
 assert git('rev-parse','HEAD').decode().strip()=='1cdbdaa2b072715d623cc00de62e0ca13c1ca918'
 assert git('rev-parse','HEAD:App/NeuroModelerConsole')==git('rev-parse',root+':App/NeuroModelerConsole')
 assert git('rev-parse','HEAD:Libraries/Nmsdk-PulseLib')==git('rev-parse',root+':Libraries/Nmsdk-PulseLib')
 analysis.mkdir()
 archive=git('archive',root,'Scripts/StructTrain/TimeLearner')
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
  for member in tar:
   target=(analysis/member.name).resolve()
   assert analysis.resolve() in target.parents and not member.issym() and not member.islnk()
   if member.isdir():target.mkdir(parents=True,exist_ok=True)
   else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
 files={str(p.relative_to(analysis)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(analysis.rglob('*.py'))}
 write('analysis-source.json',{'root':root,'binary_root':'1cdbdaa2b072715d623cc00de62e0ca13c1ca918','files':files})
 sys.path.insert(0,str(analysis))
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['PYTHONDONTWRITEBYTECODE']='1'
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 closure=source_closure(source);write('source.json',closure)
 runtime=base/'runtime-s07-measured-length-current-asan-a1'
 manifest=snapshot(source,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('current-runtime.json',manifest)
 baseline_path=base/'readbacks/s09-native-preflight-asan-a1/runtime.json'
 baseline=json.loads(baseline_path.read_text());verify_runtime(baseline);write('baseline-runtime.json',baseline)
 templates=base/'readbacks/s09-native-preflight-dimensions-asan-a1/prepared/jobs'
 env=dict(os.environ,TIMELEARNER_LENGTH_TEMPLATES=str(templates),PYTHONPATH=str(analysis))
 with (out/'generator-tests.log').open('xb') as log:
  r=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_length_proposal_experiment'],cwd=analysis,env=env,stdout=log,stderr=subprocess.STDOUT)
 write('generator-validation.json',{'returncode':r.returncode,'expected_tests':4})
 assert r.returncode==0 and 'Ran 4 tests' in (out/'generator-tests.log').read_text() and 'skipped' not in (out/'generator-tests.log').read_text()
 with (out/'experiment.log').open('xb') as log:
  r=subprocess.run(['python3','-m','Scripts.StructTrain.TimeLearner.length_proposal_experiment','--templates',str(templates),'--baseline-runtime',str(out/'baseline-runtime.json'),'--current-runtime',str(out/'current-runtime.json'),'--output',str(out/'corpus')],cwd=analysis,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=14400)
 write('experiment-validation.json',{'returncode':r.returncode})
 assert r.returncode==0
 index=json.loads((out/'corpus/index.json').read_text());assert len(index['records'])==8
 assert source_closure(source)==closure;verify_runtime(manifest);verify_runtime(baseline)
 write('terminal.json',{'execution':'completed','native_runs':8,'generator_tests':4,'scientific_verdict':None})
 print('completed eight cold burst A/B runs',flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
