from pathlib import Path
import os,sys,subprocess,json,traceback,time,hashlib,tarfile,unittest
base=Path('/media/user/Data/TimeLearnerRefactor');buildjob=base/'readbacks/s03-native-characterization-asan-a2';out=base/'readbacks/s03-native-characterization-asan-a3';out.mkdir(exist_ok=False)
sdk=base/'source-initial-threshold-asan-a2';prior=base/'readbacks/s05-model-spec-production-asan-a4';root='111d0b578566342a6159a50977c6bcdab9f9c647'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 record=json.loads((buildjob/'owned-supervisor.json').read_text());limit=time.monotonic()+3600
 while True:
  try:alive=Path('/proc',str(record['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]==record['start_ticks']
  except FileNotFoundError:alive=False
  if not alive:break
  assert time.monotonic()<limit,'build observation wait; no restart'
  time.sleep(5)
 assert json.loads((buildjob/'terminal.json').read_text())['status']=='built'
 assert subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()==root
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.native_characterization import prepare_job, audit_execution
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 manifest=load(buildjob/'runtime.json');write('runtime.json',manifest);runtime=Path(manifest['executable']['path']).parent;before=_inventory(runtime)
 (out/'jobs').mkdir();(out/'runs').mkdir();rows=[]
 cases=[('Classic-v1',0,'full'),('Classic-v2',1,'full'),('Branch-v1',0,'full'),('Branch-v2',1,'full'),
        ('Classic-v2',1,'partial'),('Branch-v2',1,'partial'),('Classic-v2',0,'missing'),('Branch-v2',1,'missing')]
 for name,index,mode in cases:
  label=name+'-'+mode;template=load(prior/'prepared/jobs'/(name+'-train.json'))
  job=prepare_job(template,index,label);job.pop('sha256');job['maximum_model_ticks']=10 if mode=='partial' else int(job['probe']['duration']*job['model']['frequency_hz'])+4
  if mode=='missing':job['probe']['minimum_amplitude']=100.
  job=_signed(job);write('jobs/'+label+'.json',job)
  result=run_job('probe',out/'jobs'/(label+'.json'),None,out/'runtime.json',out/'runs'/label,180)
  checked=audit_run_manifest(out/'runs'/label/'run-manifest.json');assert checked['run_evidence_consistent']
  audit=audit_execution(out/'runs'/label/'native');expected='model_tick_budget_exhausted' if mode=='partial' else 'completed'
  assert audit['execution']==expected and audit['observation_complete']==(mode!='partial') and audit['observation_valid']==(mode=='full'),audit
  rows.append({'name':label,'branch':job['model']['branch'],'model_schema':job['model']['schema_version'],'input_index':index,
               'expected_execution':expected,'expected_complete':mode!='partial','expected_valid':mode=='full'})
  write('index.json',{'rows':rows});print('PROBE',label,audit,flush=True)
 negatives=[];(out/'negative').mkdir()
 for factor in ['index','schema','spikes','digest','profile']:
  job=load(out/'jobs/Classic-v2-full.json');job.pop('sha256')
  if factor=='index':job['probe']['input_index']=999
  elif factor=='schema':job['schema_version']=2
  elif factor=='spikes':job['probe']['record_spikes']=True
  elif factor=='profile':job['stimulus_profile']['amplitude']*=2
  job=_signed(job)
  if factor=='digest':job['probe']['trial_id']='changed-after-signature'
  folder=out/'negative'/factor;folder.mkdir();(folder/'job.json').write_text(json.dumps(job))
  result=execute(manifest,['--app-ini',manifest['app_ini']['path'],'--timelearner-probe',str(folder/'job.json'),'--timelearner-output',str(folder/'native')],runtime,folder/'process',120,cooperative_capture=True)
  assert result['returncode']==2 and not (folder/'native').exists(),factor
  negatives.append({'factor':factor,'returncode':2,'no_observation':True,'stderr':(folder/'process/stderr.log').read_text()})
 write('negative-cases.json',{'rows':negatives})
 # Address the changed shared writer with a real cold Train, not a copied body.
 template=prior/'prepared/jobs/Classic-v1-train.json';regression=out/'regression'
 run_job('train',template,None,out/'runtime.json',regression,300)
 assert audit_run_manifest(regression/'run-manifest.json')['run_evidence_consistent']
 original=prior/'corpus/runs/Classic-v1-train/native';new=regression/'native'
 names=sorted(p.name for p in original.iterdir() if p.name.endswith(('.csv','.json')))
 equality={name:(original/name).read_bytes()==(new/name).read_bytes() for name in names}
 write('train-writer-equality.json',{'original':str(original),'files':equality});assert all(equality.values()),equality
 os.environ['TIMELEARNER_CHARACTERIZATION_CORPUS']=str(out)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_characterization.NativeCharacterizationTest')
 with (out/'readers.log').open('w') as log:tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('readers.json',{'tests':tests.testsRun,'errors':len(tests.errors),'failures':len(tests.failures),'skipped':len(tests.skipped)});assert tests.wasSuccessful() and not tests.skipped
 assert before==_inventory(runtime);verify_runtime(manifest)
 write('runtime-unchanged.json',{'same':True,'files':len(before)})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['App/NeuroModelerConsole','Scripts/StructTrain/TimeLearner'] for p in (sdk/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'native_characterization_validation','root':root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
