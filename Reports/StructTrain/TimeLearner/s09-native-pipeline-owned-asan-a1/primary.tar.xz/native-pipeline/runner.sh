set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
src="$base/source-threshold-contract-asan-isolated-a1";build="$base/build-threshold-contract-asan-isolated-a1"
out="$base/readbacks/s09-native-pipeline-asan-a1";runtime="$base/runtime-s09-native-pipeline-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-calibration-worker-asan-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git d5ef1fa18221f2ffb3e8efdeb32cccff059226e0 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach d5ef1fa18221f2ffb3e8efdeb32cccff059226e0 >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_CXX_FLAGS_RELWITHDEBINFO="-O1 -g1 -fsanitize=address -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address" -DCMAKE_SHARED_LINKER_FLAGS="-fsanitize=address" > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src";export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
OUT="$out" RUNTIME="$runtime" python3 - <<'PY' > "$out/native.log" 2>&1
import copy,json,os,subprocess
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case,audit_learned_state
from Scripts.StructTrain.TimeLearner.recognition_evidence import audit_recognition_source
from Scripts.StructTrain.TimeLearner.recognition_metrics import load_evaluation,score_recognition_evaluation
out=Path(os.environ['OUT']);runtime=Path(os.environ['RUNTIME'])
source=Path('/media/user/Data/TimeLearnerRefactor/readbacks/s08-calibration-grid-report-normal-a2/extracted/native-v2/native')
def run(mode,job,folder):
 job['sha256']=sha(job);path=out/(folder.name+'-job.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
 with (out/(folder.name+'.log')).open('wb') as log:
  done=subprocess.run([str(runtime/'NeuroModelerConsole'),'--app-ini',str(runtime/'NeuroModelerConsole.ini'),'--timelearner-'+mode,str(path),'--timelearner-output',str(folder)],cwd=runtime,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 assert done.returncode==0,(folder.name,done.returncode)
 return load(folder/'execution.json')
results=[]
for top in ('Classic','Branch'):
 original=load(next(source.glob(top+'*_learned_state.json')))
 declaration=load(next(source.glob(top+'*_success_grid_transaction.json')))
 for norm in ('N0','N1'):
  case=top+'-'+norm;c=copy.deepcopy(original['configuration']);c['run_id']='production/'+case
  c['model']['normalization']=norm
  if norm=='N0':
   for bound in c['search']['bounds']:
    bound['maximum_synapses']=3;bound['maximum_resistance']=bound['minimum_resistance']
  job={'kind':'timelearner_native_training_job','schema_version':1,'owner_class':'NNeuronTimeLearner'+('Branch' if top=='Branch' else ''),
       'implementation_id':'native-training-worker-v1','configuration':c,'profile_archives':[original['neuron']],
       'optional_modes':{'sync_capacitance_trim':0,'post_train_tuning':False,'auto_calibrate_threshold':False},
       'calculate_mode':0 if norm=='N1' else 1,'structure_build_mode':1 if norm=='N1' else 0,'maximum_model_ticks':40000}
  train=out/(case+'-train');execution=run('train',job,train)
  assert execution['completed_boundary'] is True,(case,execution)
  learned=train/'train_learned_state.json';package=load(learned);source_case=load_case(learned)
  audit=audit_learned_state(*source_case);assert audit['certificate_consistent'] is True
  assert package['configuration']['model']['normalization']==norm
  initial=load(train/'initial-state.json')
  assert initial['training_started'] is False
  assert [(p['length'],p['synapses'],p['resistance']) for p in initial['parameters']]==[(p['attachment'],p['synapses'],p['resistance']) for p in c['model']['inputs']]
  export=out/(case+'-export')
  exported=run('export',{'kind':'timelearner_native_recognition_export_job','schema_version':1,'implementation_id':package['implementation_id'],
      'source_solo':package,'conversion_spec':{'schema_version':1,'mode':'identity','resistance_bounds':[]}},export)
  assert exported['model_ticks']==0
  recognition=load(export/'model.json');assert recognition['source_solo']==package
  audit_recognition_source(recognition,source_case)
  trials=copy.deepcopy(declaration['trials'])
  for q in trials:q['run_id']=case+'/frozen-evaluation'
  evaluate=out/(case+'-evaluate')
  evaluated=run('evaluate',{'kind':'timelearner_native_evaluation_job','schema_version':1,'owner_class':job['owner_class'],
      'implementation_id':recognition['implementation_id'],'source_recognition':recognition,'maximum_model_ticks':20000,
      'run_id':case+'/frozen-evaluation','coverage_policy':'per_trial_windows','criterion':{'id':'post_anchor_target_whole_window_foil_v1',**declaration['criterion']},'trials':trials},evaluate)
  assert load(evaluate/'model.json')==load(evaluate/'model-after.json')==recognition
  metrics=score_recognition_evaluation(*load_evaluation(evaluate/'evaluation.json'),recognition)
  assert metrics['validity']=='valid',metrics
  (evaluate/'analysis.json').write_text(json.dumps(metrics,indent=2)+'\n')
  results.append({'case':case,'training_outcome':package['training_outcome'],'training_audit':audit,'frozen_metrics':metrics,'native_phases':3})
  print(case,package['training_outcome'],'valid frozen evaluation',flush=True)
(out/'validation.json').write_text(json.dumps({'native_cases':4,'native_phases':12,'root':'d5ef1fa18221f2ffb3e8efdeb32cccff059226e0','results':results,'scientific_verdict':None},indent=2)+'\n')
PY
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
