set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s09-native-pipeline-controls-asan-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-native-pipeline-cli-asan-a1
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
export TIMELEARNER_NATIVE_PIPELINE_CLI_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s09-native-pipeline-cli-asan-a1
export TIMELEARNER_PIPELINE_CONTROL_OUTPUT="$out/native"
OUT="$out" python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,unittest
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_pipeline_worker')
r=unittest.TextTestRunner(verbosity=2).run(suite)
Path(os.environ['OUT'],'validation.json').write_text(json.dumps({'reader_root':'c8bb72b996afbce2f77b607ae34e165d83315340','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped)})+'\n')
assert r.wasSuccessful() and r.testsRun==6 and not r.skipped
PY
