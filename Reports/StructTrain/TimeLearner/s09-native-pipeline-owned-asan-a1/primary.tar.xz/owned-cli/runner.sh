set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s09-native-pipeline-cli-asan-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-native-pipeline-cli-asan-a1
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
python3 - <<'PY' > "$out/validation.log" 2>&1
import copy,json,subprocess,sys
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load,EvidenceError
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_pipeline_worker import audit_run_manifest
base=Path('/media/user/Data/TimeLearnerRefactor/readbacks')
native=base/'s09-native-pipeline-asan-a1';out=base/'s09-native-pipeline-cli-asan-a1'
assert (native/'process-exit-status.txt').read_text().strip()=='0'
runtime=native/'runtime-before.json'
def run(mode,job,folder,source=None):
 job.pop('sha256',None);job['sha256']=sha(job);path=out/(folder.name+'-job.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
 command=[sys.executable,'-m','Scripts.StructTrain.TimeLearner',mode,str(path),'--runtime-manifest',str(runtime),
          '--wall-seconds','600','--output',str(folder)]
 if source:command.extend(('--source-solo',str(source)))
 with (out/(folder.name+'.stdout.log')).open('wb') as stdout,(out/(folder.name+'.stderr.log')).open('wb') as stderr:
  result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=660)
 assert result.returncode==0,(folder.name,result.returncode)
 audit=audit_run_manifest(folder/'run-manifest.json');assert audit['run_evidence_consistent'] is True
 return load(folder/'run-manifest.json')
results=[]
for case in ('Classic-N0','Classic-N1','Branch-N0','Branch-N1'):
 train=out/(case+'-train');t=run('train',load(native/(case+'-train-job.json')),train)
 source=train/'native/train_learned_state.json'
 ej=load(native/(case+'-export-job.json'));ej['source_solo']=load(source)
 export=out/(case+'-export');e=run('export',ej,export,source)
 vj=load(native/(case+'-evaluate-job.json'));vj['source_recognition']=load(export/'native/model.json')
 evaluate=out/(case+'-evaluate');v=run('evaluate',vj,evaluate,source)
 results.append({'case':case,'training_outcome':t['analysis']['training_outcome'],'frozen_metrics':v['analysis']['metrics']})
 print(case,'owned train/export/evaluate and portable audit passed',flush=True)
(out/'validation.json').write_text(json.dumps({'reader_root':'c8bb72b996afbce2f77b607ae34e165d83315340','native_cases':4,
 'owned_native_phases':12,'portable_audits':12,'results':results,'scientific_verdict':None},indent=2)+'\n')
PY
