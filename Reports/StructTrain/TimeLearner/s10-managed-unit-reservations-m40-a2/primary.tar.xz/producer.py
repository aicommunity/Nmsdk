if __name__ == '__main__':
    from pathlib import Path
    import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil
    base=Path('/media/user/Data/TimeLearnerRefactor');label='managed-unit-reservations-a2';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False);source=base/'source-managed-unit-reservations-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='34394c3017d3641377d8ec886eca3a1cfc502b92';container=base/('readbacks/s10-'+label+'-container')
    stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

    def write(name,value):
     p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    def sha(p):
     h=hashlib.sha256()
     with p.open('rb') as f:
      for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
     return h.hexdigest()
    write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
    try:
     memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;assert memory>=33*1024**3 and shutil.disk_usage(base).free>=4*1024**3
     write('resource-preflight.json',{'memory_available_bytes':memory,'worker_memory_max_bytes':256*1024**2,'worker_tasks_max':128,'native_models_executed':0,'shared_ledger_migration':False})
     sys.path.insert(0,str(bootstrap))
     from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
     registry=Reservations(base/'resource-reservations.sqlite3');reservation=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,bootstrap]],ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
     def heartbeat():
      while not stop.wait(20):
       try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
       except BaseException as error:errors.append(str(error));return
     thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
     assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root and not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
     for name in list(sys.modules):
      if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
     sys.path.insert(0,str(source));os.chdir(source)
     os.environ.update(TIMELEARNER_CONTAINED_EVIDENCE_DIR=str(out/'kernel-cases'),TIMELEARNER_MANAGED_RESERVATION_OUTPUT=str(out/'managed-cases'),TIMELEARNER_TEST_CONTROLLER_DIRECTORY=str(container),TIMELEARNER_LEGACY_RESERVATIONS_SOURCE=str(bootstrap/'Scripts/StructTrain/TimeLearner/resource_reservations.py'))
     names=['test_resource_reservations','test_resource_budgets','test_contained_process','test_closed_worker_recovery','test_managed_unit_reservations'];suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+n) for n in names)
     def ids(suite):
      for test in suite:
       if isinstance(test,unittest.TestSuite):yield from ids(test)
       else:yield test.id()
     inventory=list(ids(suite));assert len(inventory)==len(set(inventory))==61;write('test-inventory.json',inventory)
     with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
     write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':61});assert result.testsRun==61 and result.wasSuccessful() and not result.skipped and not errors;passed=True
    except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
    finally:
     try:
      write('terminal.json',{'tests_passed':passed,'native_models_executed':0,'production_worker_runtime_acceptance_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
      write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts});write('legacy-source-hashes.json',{'source_commit':'adc1f6227144360097b378a33e1db564794e0442','Scripts/StructTrain/TimeLearner/resource_reservations.py':sha(bootstrap/'Scripts/StructTrain/TimeLearner/resource_reservations.py')})
      files={}
      for p in out.rglob('*'):
       if not p.is_file():continue
       name=p.name
       if p.suffix not in ['.json','.log','.py','.sqlite3','.sqlite','.ini'] and name not in ['start.ack','child']:continue
       files[p.relative_to(out).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
      with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
       for name,v in files.items():
        e=tarfile.TarInfo(name);e.size=v['bytes']
        with (out/name).open('rb') as f:archive.addfile(e,f)
      write('bundle.json',{'kind':'managed_unit_reservations_kernel_tests','source_commit':root,'returncode':0 if passed else 1,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'native_models_executed':0,'production_worker_runtime_acceptance_pending':True,'scientific_verdict':None})
     finally:
      stop.set()
      if thread:thread.join(timeout=30)
     print('CLOSED',passed,flush=True)
