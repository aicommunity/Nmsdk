from pathlib import Path
import sys,json
p={'source': '/media/user/Data/TimeLearnerRefactor/source-managed-unit-reservations-a1', 'root': '/media/user/Data/TimeLearnerRefactor/readbacks/s10-managed-unit-reservations-a1/managed-cases/test_parent_exit_keeps_runtime_until_separate_managed_unit_closes', 'owned': '/media/user/Data/TimeLearnerRefactor/readbacks/s10-managed-unit-reservations-a1/managed-cases/test_parent_exit_keeps_runtime_until_separate_managed_unit_closes/owned', 'ini': '/media/user/Data/TimeLearnerRefactor/readbacks/s10-managed-unit-reservations-a1/managed-cases/test_parent_exit_keeps_runtime_until_separate_managed_unit_closes/app.ini', 'parent_unit': '/media/user/Data/TimeLearnerRefactor/readbacks/s10-managed-unit-reservations-a1/managed-cases/test_parent_exit_keeps_runtime_until_separate_managed_unit_closes/fault-parent-unit', 'child_unit': '/media/user/Data/TimeLearnerRefactor/readbacks/s10-managed-unit-reservations-a1/managed-cases/test_parent_exit_keeps_runtime_until_separate_managed_unit_closes/owned/fault-child-unit'}
sys.path.insert(0,p['source'])
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
from Scripts.StructTrain.TimeLearner.contained_process import start
from Scripts.StructTrain.TimeLearner.runtime import file_record,resolved_libraries,digest_json,runtime_content_identity
out=Path(p['root']);capacity={'slots':1,'memory_bytes':512*1024**2,'disk_bytes':16*1024**2,'tasks':128};demands={'slots':1,'memory_bytes':256*1024**2,'disk_bytes':8*1024**2,'tasks':64}
registry=Reservations(out/'fault.sqlite3',capacity=capacity,managed_units=True)
lease=registry.reserve('fault',[{'path':p['owned'],'access':'write'}],demands=demands,controller_directory=p['parent_unit'],ttl_seconds=300)
(out/'fault-lease.json').write_text(json.dumps(lease,indent=2))
manifest={'schema_version':2,'source_closure':{'kind':'managed_unit_recovery_fault_control','native_models_executed':0},'executable':file_record(Path('/bin/sleep')),'app_ini':file_record(Path(p['ini'])),'compiler':file_record(Path('/usr/bin/c++')),'build_flags':{'role':'actual isolated sleep; not a neural model'},'resolved_libraries':resolved_libraries(Path('/bin/sleep')),'loaded_process_files':None,'loader_environment':{}}
manifest['runtime_identity']=runtime_content_identity(manifest);manifest['runtime_fingerprint']=digest_json(manifest['runtime_identity'])
start(manifest,['20'],out,p['child_unit'],memory_bytes=64*1024**2,tasks=16,maximum_wall_seconds=30,managed_reservation=(registry,lease['token']))
(out/'parent-exits-with-child-live.json').write_text(json.dumps({'lease':lease['token'],'native_models_executed':0}))
