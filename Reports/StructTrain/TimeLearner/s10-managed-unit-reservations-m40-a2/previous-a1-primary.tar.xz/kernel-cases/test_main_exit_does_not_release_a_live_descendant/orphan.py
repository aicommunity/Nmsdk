import subprocess
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-78muw9xi/child').write_text(str(p.pid))
