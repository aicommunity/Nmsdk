set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-fixed-reader-normal-a1"
repo="$base/source-native-posttune-controller-n0-evidence-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 38cd68a022814782eff667bedd60bdfe9a6950bc > "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$repo" archive 38cd68a022814782eff667bedd60bdfe9a6950bc Scripts | tar -x -C "$out/source"
cd "$out/source"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$base/readbacks/s08-native-posttune-fixed-normal-a2/native"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence -v > "$out/reader.log" 2>&1

