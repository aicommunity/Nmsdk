set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-fixed-package-repair-normal-a1"
src="$base/source-native-posttune-fixed-evidence-normal-a1"
gate="$base/readbacks/s08-native-posttune-fixed-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(git -C "$src" rev-parse HEAD)" = d447fc2eafa5461ffafecc37e8f11703f012b7eb
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b7cab7348aea1fc29038b991d5298693d10ed87e > "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$src" archive b7cab7348aea1fc29038b991d5298693d10ed87e Scripts | tar -x -C "$out/source"
cd "$out/source"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_ARCHIVE_RUN_SOURCE="$gate/runs"
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$gate/native"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$gate/baseline-source"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_packaged_run_closure Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence -v > "$out/reader.log" 2>&1
ROOT="$src" BASE="$base" OUT="$out" python3 -u - <<'PY' > "$out/package.log" 2>&1
import hashlib,io,json,os,tarfile
from pathlib import Path
from Scripts.StructTrain.TimeLearner.artifact_bundle import verify_packaged_run_closure
from Scripts.StructTrain.TimeLearner.publisher import stage_artifact_set
root=Path(os.environ['ROOT']);b=Path(os.environ['BASE'])/'readbacks';out=Path(os.environ['OUT'])
d=root/'Reports/StructTrain/TimeLearner/s08-native-posttune-fixed-normal-a2'
m=json.loads((d/'manifest.json').read_bytes());assert len(m['files'])==71
files={}
folders=[(b/'s08-native-posttune-fixed-normal-a2','native-fixed-a2',{'baseline-source'}),
 (b/'s08-native-posttune-fixed-normal-a1','fixture-build-failure-a1',set()),
 (b/'s08-native-posttune-fixed-reader-normal-a1','fixed-reader-a1',{'source'}),
 (b/'s02-static-cache-dedup-elder-20261031-a1','cache-dedup-a1',set())]
for folder,prefix,excluded_top_level in folders:
 for directory,dirs,names in os.walk(folder):
  # Exclude code caches by role and ONLY at the declared top level.
  # The real runs/*/input/source trees are never excluded.
  if Path(directory)==folder:dirs[:]=[name for name in dirs if name not in excluded_top_level]
  for name in names:
   p=Path(directory)/name;assert not p.is_symlink()
   files[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for name in ['reader.log','checkout.log','runner.sh']:
 files['packaging-repair-a1/'+name]=(out/name).read_bytes()
proof=verify_packaged_run_closure(files);assert proof['run_snapshots_verified']==2
primary_files=sum('/input/source/' in name for name in files);assert primary_files>0
old_files={r['path']:r for r in m['files']}
# The original included primary bytes are untouched; only omitted data/receipts are added.
assert all(name in files and len(files[name])==r['bytes'] and hashlib.sha256(files[name]).hexdigest()==r['sha256']
 for name,r in old_files.items())
with tarfile.open(d/'primary.tar.xz','w:xz',preset=6) as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
m.update({'packaged_run_closure':proof,'packaging_repair':{'original_incomplete_commit':'d447fc2eafa5461ffafecc37e8f11703f012b7eb',
 'cause':'unscoped source code-cache filter also excluded runs/input/source',
 'original_members':71,'restored_primary_files':primary_files,'native_rerun':False,
 'repair_reader_root':'b7cab7348aea1fc29038b991d5298693d10ed87e','repair_checks':9},
 'archive_sha256':hashlib.sha256((d/'primary.tar.xz').read_bytes()).hexdigest(),
 'files':[{'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(files.items())]})
encode=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
(d/'manifest.json').write_bytes(encode(m))
p=d/'README.md';p.write_bytes(p.read_bytes()+(
 '\nPackaging erratum: original d447fc2e omitted '+str(primary_files)+' input/source primary files because a code-cache '
 'filter excluded every directory named source. The original 71 included files were byte-correct but the archive was not a complete portable run snapshot. '
 'The M40 reader failed before rendering, not after a new scientific verdict. All raw originals remained on Elder and in the original Git bundle. '
 'This repair adds the omitted files, preserves every previously included byte, and gates packaging on each embedded run-manifest artifact closure. '
 'Nine checks (four inclusion/corruption regressions and five fixed-evidence checks) passed without native rerun.\n').encode())
s=d/'SHA256SUMS.json';s.write_bytes(encode({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file() and p!=s}))
print(stage_artifact_set(root,s.relative_to(root).as_posix(),hashlib.sha256(s.read_bytes()).hexdigest()))
print(json.dumps({'members':len(files),'restored_primary_files':primary_files,'archive_bytes':(d/'primary.tar.xz').stat().st_size,'closure':proof}))
PY
git -C "$src" diff --cached --check
git -C "$src" commit -m 'Restore omitted source primaries and gate fixed proof packaging on internal run closure' > "$out/commit.log"
ROOT="$src" python3 - <<'PY' > "$out/verification.json"
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.publisher import verify_artifact_set,_git
root=Path(os.environ['ROOT']);p='Reports/StructTrain/TimeLearner/s08-native-posttune-fixed-normal-a2/SHA256SUMS.json'
print(json.dumps(verify_artifact_set(root,_git(root,'rev-parse','HEAD'),
 {'repository':'.','manifest':p,'manifest_sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()})))
PY
git -C "$src" -c push.recurseSubmodules=no push git@github.com:aicommunity/Nmsdk.git HEAD:refs/heads/codex/timelearner-native-posttune-fixed-evidence-normal-a1 > "$out/push.log" 2>&1
test "$(git -C "$src" ls-remote git@github.com:aicommunity/Nmsdk.git refs/heads/codex/timelearner-native-posttune-fixed-evidence-normal-a1 | cut -f1)" = "$(git -C "$src" rev-parse HEAD)"
git -C "$src" rev-parse HEAD > "$out/commit.txt"

