set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-fixed-normal-a1"
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-posttune-fixed-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test ! -e "$runtime"
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
test -z "$(git -C "$src" status --porcelain)"
SRC="$src" BUILD="$build" python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
base=Path('/home/user/timelearner-refactor');active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(str(base)+'/runtime-') or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch origin 8777e801cfc63ae40ac1c2325ca56eb47a0a1ece > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach 8777e801cfc63ae40ac1c2325ca56eb47a0a1ece >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
git -C "$src" rev-parse HEAD >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 OUT="$out" SRC="$src"
unset QT_QPA_PLATFORM ASAN_OPTIONS
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/extract.log" 2>&1
import hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
out=Path(os.environ['OUT']);src=Path(os.environ['SRC'])
commit='3c1751f977b26a6d6a1d82065f34a44c456a1b41'
prefix='Reports/StructTrain/TimeLearner/s08-native-posttune-console-normal-a2/'
blob=lambda name:subprocess.check_output(['git','-C',str(src),'show',commit+':'+prefix+name])
m=json.loads(blob('manifest.json'));archive=blob('primary.tar.xz')
assert hashlib.sha256(archive).hexdigest()==m['archive_sha256']
base='native-production/runs/';cases=['Classic-auto_metric','Branch-synthetic']
def selected(name):
 if name==base+'controls.json':return True
 if name.startswith(base) and name.endswith('/input/job.json'):return True
 return any(name==base+c+'/run-manifest.json' or name.startswith(base+c+'/input/source/') for c in cases)
expected={r['path']:r for r in m['files'] if selected(r['path'])}
dest=out/'baseline-source';dest.mkdir()
count=len(expected);assert count>21
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for member in tar:
  if member.name not in expected:continue
  assert member.isfile();raw=tar.extractfile(member).read();r=expected.pop(member.name)
  assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  name=member.name[len(base):];relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
  p=dest/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert not expected
rows=[]
for case in cases:
 expected={part:next(r['sha256'] for r in m['files'] if r['path']==base+case+'/native/'+part) for part in ['transaction.json','model.json']}
 rows.append({'name':case,'expected_native_sha256':expected})
(out/'baseline.json').write_text(json.dumps({'source_commit':commit,'extracted_members':count,'cases':rows},indent=2)+'\n')
print(json.dumps({'extracted_members':count,'cases':cases}))
PY
(cd "$runtime" && TIMELEARNER_POSTTUNE_CONFIG_SOURCE="$out/baseline-source" TIMELEARNER_POSTTUNE_FIXED_SOURCE="$out/baseline-source" TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativePostTuneConfiguration.*:NativeFixedPostTune.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
python3 -u - <<'PY' > "$out/console-ab.log" 2>&1
import hashlib,json,os,shutil,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_calibration_worker import run_job,audit_run_manifest
p=Path(os.environ['OUT']);xml=ET.parse(p/'native.xml').getroot()
assert int(xml.attrib['tests'])==12 and not xml.findall('.//skipped')
assert all(int(xml.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled'])
baseline=json.loads((p/'baseline.json').read_bytes());rows=[]
for control in baseline['cases']:
 assert shutil.disk_usage('/').free>512*1024*1024
 name=control['name'];source=p/'baseline-source'/name;original=json.loads((source/'run-manifest.json').read_bytes())
 print('BEGIN',name,flush=True)
 result=run_job(source/'input/job.json',source/original['source_package_path'],p/'runtime-before.json',p/'runs'/name,1800,post_tune=True)
 assert result['execution']=='completed' and result['validity']=='valid'
 proof=audit_run_manifest(p/'runs'/name/'run-manifest.json',post_tune=True)
 for part,digest in control['expected_native_sha256'].items():
  assert hashlib.sha256((p/'runs'/name/'native'/part).read_bytes()).hexdigest()==digest,(name,part)
 rows.append({'name':name,'exact_transaction_and_model_bytes':True,'run_audit':proof})
 print('DONE',rows[-1],flush=True)
(p/'validation.json').write_text(json.dumps({'source_root':'8777e801cfc63ae40ac1c2325ca56eb47a0a1ece','codec_cases':4,'fixed_native_cases':8,
 'original_production_jobs_decoded':18,'actual_owned_console_ab_jobs':len(rows),'rows':rows,
 'legacy_algorithm_changed':False,'fixed_finalization_implemented':True,'learner_property_dispatch_complete':False,'full_stage_8_accepted':False},indent=2)+'\n')
PY
df -h / > "$out/disk-after.txt"

