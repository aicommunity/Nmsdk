import pathlib,time,subprocess,json,os,sys,hashlib
b=pathlib.Path('/media/user/Data/TimeLearnerRefactor');repo=b/'source-august-csv-adapter-m40-a1';data=b/'readbacks/s04-hot-readout-fixed-asan-a1';out=b/'readbacks/s04-hot-reader-asan-a1'
expected='932c90c396b61162ab56cd7f205924afbdd2e50a'
def revision():return subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
assert revision()==expected
start=time.monotonic()
while True:
 p=pathlib.Path('/proc/792527/stat')
 if not p.exists() or p.read_text().rsplit(') ',1)[1].split()[19]!='261869449':break
 assert time.monotonic()-start<5400,'native_wait_timeout'
 time.sleep(5)
assert revision()==expected and not (data/'exception.json').exists()
runs=[]
for label,module,key,path in [('hot','Scripts.StructTrain.TimeLearner.tests.test_hot_readout_reports','TL_HOT_READOUT_SOURCE',data),('loaded','Scripts.StructTrain.TimeLearner.tests.test_loaded_readout_reports','TL_LOADED_READOUT_SOURCE',data/'loaded')]:
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_HOT_EXPECT_STALE='0');env[key]=str(path)
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(['python3','-m','unittest','-v',module],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 runs.append({'label':label,'tests':16,'returncode':r.returncode})
sys.path.insert(0,str(repo))
from Scripts.StructTrain.TimeLearner.hot_readout_reports import audit_run as hot_audit
from Scripts.StructTrain.TimeLearner.loaded_readout_reports import audit_run as loaded_audit
_,hot=hot_audit(data);loaded_rows,loaded=loaded_audit(data/'loaded')
(out/'hot-audit.json').write_text(json.dumps(hot,indent=2)+'\n');(out/'loaded-audit.json').write_text(json.dumps(loaded,indent=2)+'\n')
normal=b/'restored-hot-readout-current-normal-a1';manifest=json.loads((normal/'manifest.json').read_text());records={r['path']:r for r in manifest['records']}
comparison=[]
for kind,cases,relative in [('warm',hot['cases'],'artifacts'),('loaded',loaded_rows,'loaded/artifacts')]:
 for name in cases:
  namefile='warm.csv' if kind=='warm' else 'roundtrip.csv'
  rel=relative+'/'+name+'/'+namefile
  before=normal/'s04-hot-readout-fixed-normal-a1'/rel;after=data/rel
  a=hashlib.sha256(before.read_bytes()).hexdigest();z=hashlib.sha256(after.read_bytes()).hexdigest()
  assert a==records['s04-hot-readout-fixed-normal-a1/'+rel]['sha256']
  comparison.append({'kind':kind,'case':name,'normal_sha256':a,'asan_sha256':z,'byte_equal':a==z})
(out/'crossworker.json').write_text(json.dumps(comparison,indent=2)+'\n')
result={'kind':'native_hot_reset_asan_data_verification','schema_version':1,'reader_source':expected,'native_source':'5c202d61c6312521a7472a86491145164808da33','runs':runs,'hot_cases':8,'hot_case_soma_pairs':16,'hot_stale_cases':hot['stale_cases'],'loaded_cases':32,'loaded_case_soma_pairs':68,'all40_csv_byte_equal':len(comparison)==40 and all(r['byte_equal'] for r in comparison),'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
assert all(r['returncode']==0 for r in runs) and result['all40_csv_byte_equal'] and hot['stale_cases']==0
assert revision()==expected
print(json.dumps(result),flush=True)
