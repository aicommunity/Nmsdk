from pathlib import Path
import subprocess,sys,json,os,time,shutil,xml.etree.ElementTree as ET
base=Path('/home/user/timelearner-refactor');old=base/'source-order-fixed-a1'
src=base/'source-n1-measured-refinement-normal-a1'
build=base/'build-n1-measured-refinement-normal-a1'
runtime=base/'runtime-s07-n1-measured-refinement-normal-a1'
out=base/'readbacks/s07-n1-measured-refinement-build-normal-a1'
rootsha='e19a303f2d9252a5179ad0f457593e48c0c35fd1'
pulsesha='bf50ae57512ff0a1591937f4f23cef172a8928dc'
start=time.time();steps=[];status=1
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',ASAN_OPTIONS='detect_leaks=0',PYTHONDONTWRITEBYTECODE='1',TIMELEARNER_EXECUTION_OUTPUT=str(out/'native'))
def read(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
def run(args,name,cwd=None):
 print(name,flush=True)
 with (out/(name+'.log')).open('wb') as log:p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':list(map(str,args)),'returncode':p.returncode})
 (out/'progress.json').write_text(json.dumps(steps,indent=2)+'\n')
 if p.returncode:raise RuntimeError(name+':'+str(p.returncode))
try:
 assert shutil.disk_usage(base).free>25*1024**3
 assert not src.exists() and not build.exists() and not runtime.exists()
 run(['git','-C',old,'fetch','--no-recurse-submodules','origin',rootsha],'source-fetch')
 run(['git','-C',old,'worktree','add','--no-checkout','--detach',src,rootsha],'source-worktree')
 run(['git','-C',src,'sparse-checkout','init','--cone'],'source-sparse-init')
 run(['git','-C',src,'sparse-checkout','set','--skip-checks','App','cmake','Libraries','Tests','Scripts','Rdk','Bin'],'source-sparse-set')
 run(['git','-C',src,'checkout','--detach',rootsha],'source-checkout')
 trees=subprocess.check_output(['git','-C',str(src),'ls-tree','-r','-z','HEAD']).split(b'\0')
 for entry in trees:
  if not entry:continue
  fields,path=entry.split(b'\t',1);mode,_,sha=fields.decode().split()
  if mode!='160000':continue
  path=path.decode();repository=old/path;target=src/path
  assert repository.exists(),path
  label=path.replace('/','-')
  exists=subprocess.run(['git','-C',str(repository),'cat-file','-e',sha+'^{commit}'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  if not exists:run(['git','-C',repository,'fetch','--no-recurse-submodules','origin',sha],'child-fetch-'+label)
  run(['git','-C',repository,'worktree','add','--no-checkout','--detach',target,sha],'child-worktree-'+label)
  if path=='Bin':
   run(['git','-C',target,'sparse-checkout','init','--cone'],'bin-sparse-init')
   run(['git','-C',target,'sparse-checkout','set','--skip-checks','ClDesc','WatchPresets','WatchTemplates','CodeTemplates','Styles'],'bin-sparse-set')
  run(['git','-C',target,'checkout','--detach',sha],'child-checkout-'+label)
 assert read(src/'Libraries/Nmsdk-PulseLib','rev-parse','HEAD')==pulsesha
 assert not read(src,'status','--porcelain')
 flags=[]
 for line in (base/'build-order-fixed-normal-a1/CMakeCache.txt').read_text().splitlines():
  if not line or line.startswith(('#','//')) or ':' not in line or '=' not in line:continue
  name,rest=line.split(':',1);typ,value=rest.split('=',1)
  keep=typ!='INTERNAL' and (name.startswith(('RDK_','CMAKE_CXX_FLAGS','CMAKE_EXE_LINKER_FLAGS')) or name in ('CMAKE_BUILD_TYPE','NO_MOTION_CONTROL','BUILD_TESTING','BUILD_TESTS','NMSDK_PULSELIB_BUILD_CORE_ONLY'))
  if keep:flags.append('-D'+name+'='+value)
 flags+=['-DNMSDK_BUILD_PARALLEL_JOBS=2','-DNMSDK_DEPLOY_ROOT='+str(runtime),'-DNMSDK_RESOURCE_ROOT='+str(src/'Bin')]
 run(['cmake','-S',src,'-B',build,*flags],'configure')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','-j2'],'build-tests')
 (out/'native').mkdir()
 run([runtime/'Test_PulseLib_StorageComponents','--gtest_filter=MeasuredResistanceSearch.*:BoundedTraining*:NativeResistanceDomains.*','--gtest_output=xml:'+str(out/'kernel.xml')],'kernel-tests',out)
 cases=ET.parse(out/'kernel.xml').getroot().findall('.//testcase')
 fresh=[c for c in cases if c.get('classname') in ('MeasuredResistanceSearch','BoundedTrainingN1Refinement')]
 assert len(fresh)==7 and all(not list(c) for c in fresh),[(c.attrib,list(c)) for c in fresh]
 run(['cmake','--build',build,'--target','NeuroModelerConsole','-j2'],'build-console')
 run([sys.executable,'-m','Scripts.StructTrain.TimeLearner.runtime','--root',src,'--executable',runtime/'NeuroModelerConsole','--app-ini',runtime/'NeuroModelerConsole.ini','--cache',build/'CMakeCache.txt','--output',out/'runtime.json'],'runtime-snapshot',src)
 status=0
except Exception as e:
 (out/'error.txt').write_text(repr(e)+'\n')
finally:
 (out/'completion.json').write_text(json.dumps({'kind':'native_n1_measured_refinement_build','status':status,'steps':steps,'source_root':rootsha,'pulse':pulsesha,'wall_seconds':time.time()-start,'runtime':str(runtime)},indent=2)+'\n')
sys.exit(status)
