from pathlib import Path
import subprocess,sys,json,os,time,hashlib,xml.etree.ElementTree as ET
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-n1-measured-refinement-build-normal-a2'
previous=base/'readbacks/s07-n1-measured-refinement-build-normal-a1'
src=base/'source-n1-measured-refinement-normal-a1';build=base/'build-n1-measured-refinement-normal-a1'
oldruntime=base/'runtime-s07-n1-measured-refinement-normal-a1'
runtime=base/'runtime-s07-n1-measured-refinement-normal-a2'
rootsha='a8709e790cc7d12558ad3b8130973c6c5ca77c06';pulsesha='c89a067ea4719c2c3f7546a9cf77b11b188b334d'
start=time.time();steps=[];status=1;oldhashes={}
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',ASAN_OPTIONS='detect_leaks=0',PYTHONDONTWRITEBYTECODE='1',TIMELEARNER_EXECUTION_OUTPUT=str(out/'native'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,name,cwd=None):
 print(name,flush=True)
 with (out/(name+'.log')).open('wb') as log:p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 steps.append({'name':name,'command':list(map(str,args)),'returncode':p.returncode})
 (out/'progress.json').write_text(json.dumps(steps,indent=2)+'\n')
 if p.returncode:raise RuntimeError(name+':'+str(p.returncode))
try:
 assert json.loads((previous/'completion.json').read_text())['status']==0
 old=json.loads((previous/'launch.json').read_text());s=Path('/proc',str(old['pid']),'stat')
 if s.exists():
  fields=s.read_text().split(') ',1)[1].split()
  assert fields[19]!=old['start_ticks'] or fields[0]=='Z','A1 still running'
 active=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   exe=(proc/'exe').resolve();cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  except (OSError,PermissionError):continue
  if exe.name in ('NeuroModelerConsole','Test_PulseLib_StorageComponents','cmake','cc1plus','g++','c++','ld','ld.bfd','gmake','make') and any(str(p) in cmd or str(p) in str(exe) for p in (src,build,oldruntime)):
   active.append((proc.name,str(exe)))
 assert not active,active
 assert not runtime.exists()
 oldhashes={name:digest(oldruntime/name) for name in ('NeuroModelerConsole','Test_PulseLib_StorageComponents')}
 (previous/'source-reused-after-terminal.json').write_text(json.dumps({'next_root':rootsha,'next_pulse':pulsesha,'new_receipts':str(out),'old_binaries':oldhashes,'reason':'incremental verification after terminal A1; old runtime is not selected for final physical acceptance'},indent=2)+'\n')
 assert not subprocess.check_output(['git','-C',str(src),'status','--porcelain']).strip()
 run(['git','-C',src,'fetch','--no-recurse-submodules','origin',rootsha],'source-fetch')
 run(['git','-C',src,'checkout','--detach',rootsha],'source-checkout')
 pulse=src/'Libraries/Nmsdk-PulseLib'
 run(['git','-C',pulse,'fetch','--no-recurse-submodules','origin',pulsesha],'pulse-fetch')
 run(['git','-C',pulse,'checkout','--detach',pulsesha],'pulse-checkout')
 assert not subprocess.check_output(['git','-C',str(src),'status','--porcelain']).strip()
 run(['cmake','-S',src,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','-j2'],'build-tests')
 (out/'native').mkdir()
 run([runtime/'Test_PulseLib_StorageComponents','--gtest_filter=MeasuredResistanceSearch.*:BoundedTraining*:NativeResistanceDomains.*','--gtest_output=xml:'+str(out/'kernel.xml')],'kernel-tests',out)
 cases=ET.parse(out/'kernel.xml').getroot().findall('.//testcase')
 fresh=[c for c in cases if c.get('classname') in ('MeasuredResistanceSearch','BoundedTrainingN1Refinement')]
 assert len(fresh)==7 and all(not list(c) for c in fresh)
 assert any(c.get('name')=='AChangedNormalizedPhysicalScopeOrSourceCannotReuseTheOldBracket' for c in fresh)
 run(['cmake','--build',build,'--target','NeuroModelerConsole','-j2'],'build-console')
 run([sys.executable,'-m','Scripts.StructTrain.TimeLearner.runtime','--root',src,'--executable',runtime/'NeuroModelerConsole','--app-ini',runtime/'NeuroModelerConsole.ini','--cache',build/'CMakeCache.txt','--output',out/'runtime.json'],'runtime-snapshot',src)
 assert all(digest(oldruntime/name)==sha for name,sha in oldhashes.items())
 status=0
except Exception as e:(out/'error.txt').write_text(repr(e)+'\n')
finally:
 (out/'completion.json').write_text(json.dumps({'kind':'native_n1_measured_refinement_build','attempt':'a2','status':status,'steps':steps,'source_root':rootsha,'pulse':pulsesha,'wall_seconds':time.time()-start,'runtime':str(runtime),'old_runtime_binaries_unchanged':oldhashes if status==0 else None},indent=2)+'\n')
sys.exit(status)
