from pathlib import Path
import json,os,sys,hashlib,shutil,traceback,tarfile
base=Path('/media/user/Data/TimeLearnerRefactor')
out=base/'readbacks/s02-rdk-default-startup-asan-a1';out.mkdir(exist_ok=False)
runtime=base/'runtime-native-event-log-asan-a3';sdk=base/'source-initial-threshold-asan-a2';build=base/'build-initial-threshold-asan-a2'
copy=base/'runtime-rdk-default-startup-asan-a1';copy.mkdir(exist_ok=False)
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def inv(root):return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]})
(out/'producer.py').write_bytes(Path(__file__).read_bytes());before=inv(runtime);write('runtime-before.json',before)
passed=False
try:
 assert (runtime/'NeuroModelerConsole').is_file()
 for name in ['NeuroModelerConsole','NeuroModelerConsole.ini']:shutil.copy2(runtime/name,copy/name)
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute
 manifest=snapshot(sdk,copy/'NeuroModelerConsole',copy/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 result=execute(manifest,['--app-ini',str(copy/'NeuroModelerConsole.ini'),'--check-config',str(out/'missing-project.ini')],copy,out/'process',120)
 assert result['returncode']==1,result
 pid=json.loads((out/'process/owned-process.json').read_text())['pid']
 files=[p for p in (copy/'EventsLog').rglob('*') if p.is_file() and not p.is_symlink()]
 assert files and all(int(p.name.rsplit('.',1)[1])==pid for p in files)
 (out/'owned-default-logs').mkdir()
 for p in files:shutil.copy2(p,out/'owned-default-logs'/p.name)
 write('default-startup.json',{'execution_returncode':1,'missing_project_is_expected_negative':True,'native_output_argument_absent':True,'default_work_directory_is_executable_directory':True,'owned_log_pid':pid,'log_names':[p.name for p in files],'copied_executable_sha256':hashlib.sha256((copy/'NeuroModelerConsole').read_bytes()).hexdigest(),'same_executable_as_native_runtime':(copy/'NeuroModelerConsole').read_bytes()==(runtime/'NeuroModelerConsole').read_bytes(),'scientific_verdict':None})
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 after=inv(runtime);write('runtime-after.json',after);passed=passed and before==after
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','native_runtime_unchanged':before==after,'scientific_verdict':None})
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
 records={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 write('bundle.json',{'kind':'rdk_default_startup_validation','root':'b3bfe86e913bc1f7aeb5a340a72698eacb060f00','rdk':'0e70cf07ddc52f6af81ac0b291e299434925319c','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
