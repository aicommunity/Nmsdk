set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-finalization-boundary-visual-tests-asan-a1"
work="$base/source-finalization-boundary-visual-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-finalization-boundary-visual-asan-a1/process-exit-status.txt")" = 0
test ! -e /proc/3899161
test -z "$(git -C "$work" status --porcelain)"
git -C "$work" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git a32c3590a4689dbc52a9009d7d2f0b6a23e79ec2 > "$out/checkout.log" 2>&1
git -C "$work" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
cd "$work"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_FINALIZATION_BOUNDARY_REPORTS="$base/cache/s08-native-finalization-boundary-asan-a1"
export TIMELEARNER_FINALIZATION_BOUNDARY_NATIVE="$base/readbacks/s08-native-finalization-boundary-asan-a4/native"
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/tests.log" 2>&1
import json,os,time,unittest
from pathlib import Path
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_finalization_boundary_reports')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'kind':'native_finalization_boundary_visual_tests','schema_version':1,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-start,'source_root':'a32c3590a4689dbc52a9009d7d2f0b6a23e79ec2','scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==3 and not result.skipped
print(json.dumps(report))
PY
