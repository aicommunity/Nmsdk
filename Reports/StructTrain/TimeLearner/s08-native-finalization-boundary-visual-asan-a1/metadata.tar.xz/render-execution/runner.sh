set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-finalization-boundary-visual-asan-a1"
repo="$base/source-rdk-bool-evidence-asan-a2"
work="$base/source-finalization-boundary-visual-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-finalization-boundary-asan-a4/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 52bd7ff2f43ec828714df8758bc468c0e97fff0b > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --detach --no-checkout "$work" FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export BASE="$base" OUT="$out" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/render.log" 2>&1
import hashlib,json,os,time
from pathlib import Path
from PIL import Image
from Scripts.StructTrain.TimeLearner.finalization_boundary_reports import render_boundary_replay
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.recognition_metrics import load_evaluation
base=Path(os.environ['BASE']);out=Path(os.environ['OUT'])
native=base/'readbacks/s08-native-finalization-boundary-asan-a4/native'
corpus=base/'readbacks/s08-native-posttune-fixed-asan-a1/baseline-source'
cache=base/'cache/s08-native-finalization-boundary-asan-a1'
assert not cache.exists()
cache.mkdir(parents=True)
start=time.monotonic();records=[];pairs=0;selected=[]
for topology,jobfolder in [('Classic','Classic-auto_metric'),('Branch','Branch-synthetic')]:
 for scenario in (0,1):
  name=f'{topology}_finalization_boundary_{scenario}'
  folder=cache/name
  record=render_boundary_replay(native/(name+'_replay.json'),native/(name+'_capture-comparison.json'),
    corpus/jobfolder/'input/job.json',folder)
  inner=load(folder/'evaluation/manifest.json')
  spec,observations=load_evaluation(folder/'evaluation/primary/evaluation.json')
  raw=load(native/(name+'_replay.json'))
  assert observations==raw['observations']
  channels=1 if topology=='Branch' else 2
  assert {(f['trial_id'],f['descriptor']['index']) for f in inner['figures']}=={(q['trial_id'],i) for q in spec['trials'] for i in range(channels)}
  assert len(observations)==2 and all(o['complete'] and o['valid'] and not o['censored'] for o in observations)
  for figure in inner['figures']:
   assert any(v['time_view']!='overview' for v in figure['views'])
   for view in figure['views']:
    assert view['downsampling'] is False
    for relative in view['files']:
     p=folder/'evaluation'/relative;assert p.is_file()
     if p.suffix=='.png':
      with Image.open(p) as im:assert im.width>=1600 and im.height>=800
   if scenario==0 and figure['label']=='target' and figure['descriptor']['index']==0:
    views=[figure['views'][0],next(v for v in figure['views'] if v['time_view']!='overview')]
    for view in views:
     png=next(p for p in view['files'] if p.endswith('.png'))
     selected.append((folder/'evaluation'/png).relative_to(cache).as_posix())
  pairs+=len(inner['figures']);records.append({'name':name,'source_replay_sha256':record['source_replay_sha256'],'pairs':len(inner['figures'])})
assert pairs==12 and len(records)==4 and len(selected)==4
files=[p for p in cache.rglob('*') if p.is_file()]
report={'kind':'native_finalization_boundary_visual_gate','schema_version':1,'cache':str(cache),
 'reports':records,'complete_trial_soma_pairs':pairs,'selected_png':selected,'seconds':time.monotonic()-start,
 'files':len(files),'bytes':sum(p.stat().st_size for p in files),'visual_acceptance_complete':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
