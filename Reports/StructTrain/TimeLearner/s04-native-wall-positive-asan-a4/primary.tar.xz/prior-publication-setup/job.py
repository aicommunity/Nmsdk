from pathlib import Path
import sys,json,tarfile,hashlib,io,traceback,xml.etree.ElementTree as ET
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

base=Path("/media/user/Data/TimeLearnerRefactor");repo=base/"source-native-wall-asan-a1"
out=Path(__file__).resolve().parent;trial=base/'readbacks/s04-native-wall-gate-asan-a3';reader=base/'readbacks/s04-native-wall-reader-asan-a1'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
try:
 stat=Path('/proc/1596723/stat');assert not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[19]!="267745326"
 assert json.loads((reader/'terminal.json').read_text())['reader_tests']==9
 assert json.loads((trial/'terminal.json').read_text())['native_wall_schedule_tests']==66
 tree=ET.parse(trial/'gtest.xml').getroot()
 assert tree.attrib['tests']=='66' and tree.attrib['failures']==tree.attrib['errors']=='0'
 sys.path.insert(0,str(repo))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 after=source_closure(repo);assert after==json.loads((trial/'source.json').read_text())
 write('post-gate-source.json',after)
 sources=[('native-run/'+str(p.relative_to(trial)),p) for p in sorted(trial.rglob('*')) if p.is_file()]
 sources.extend(('reader/'+p.name,p) for p in sorted(reader.iterdir()) if p.is_file() and p.suffix in ('.json','.log','.py'))
 sources.append(('post-gate-source.json',out/'post-gate-source.json'))
 files={};selected=[];cache=None
 if 'asan'=='asan':
  cache=base/'report-cache/s04-native-wall-asan-a1'
  inventory=json.loads((cache/'probes/manifest.json').read_text())
  for i,g in enumerate(inventory['groups']):
   name=g['identity'];views=[]
   if '_probe_4_evidence.json' in name:views=['overview','zoom-001']
   elif '_wall_live_mid_' in name:views=['overview']
   elif '_wall_observation_sink_' in name:views=['overview']
   for view in views:
    p=cache/'probes'/f'group-{i:03d}'/'probe-0000'/'soma-001'/(view+'.png')
    assert p.is_file(),p
    dest=f'selected/probe-{i:03d}-{view}.png';files[dest]=p.read_bytes()
    selected.append({'path':dest,'cache_source':str(p.relative_to(cache)),'primary_packet':name,'sha256':hashlib.sha256(files[dest]).hexdigest()})
  reset=json.loads((cache/'reset/index.json').read_text())
  for row in reset['plots']:
   if row['channel']==0 and row['view']=='overview':
    p=cache/'reset'/row['file'];dest='selected/reset-'+p.parent.name+'.png';files[dest]=p.read_bytes()
    selected.append({'path':dest,'cache_source':'reset/'+row['file'],'primary_packet':row['source'],'sha256':hashlib.sha256(files[dest]).hexdigest()})
  assert len(selected)==16,len(selected)
  sources.extend(('render-metadata/'+str(p.relative_to(cache)),p) for p in sorted(cache.rglob('*')) if p.is_file() and p.suffix in ('.json','.html') and 'primary' not in p.relative_to(cache).parts and not any(x.endswith('-input') for x in p.relative_to(cache).parts))
 archive=out/'primary.tar.xz';records=[]
 with tarfile.open(archive,'w:xz',preset=6) as tar:
  for name,p in sources:
   raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw));records.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 manifest={'kind':'native_wall_schedule_positive_execution_gate','worker':'asan','numeric_root':'f35f614d2d07c1cc0cdf9786bcadd31d9237ed06','reader_root':'e110ab627021e28deb98a582cb4a529d762cd2a4','pulse':'151a3883137bf112519543f64aa0b9bbf500c579','rdk':'0a1c1d05a1b12de20feabf54a25712e210865791','native_tests':66,'reader_tests':9,'probe_packets':46,'reset_diagnostics':4,'plottable_trial_soma_pairs':21,'full_render_cache':str(cache) if cache else None,'selected':selected,'records':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'visual_acceptance_complete':False,'scientific_verdict':None}
 files.update({'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode(),'primary.tar.xz':archive.read_bytes(),'README.md':b'Actual 66-case native wall-policy execution gate and nine production report-reader checks. 46 strict probe packets, including expected rejected/partial data, plus four separate raw Reset diagnostics. No classification or complete lifecycle claim. ASan worker holds full reproducible report cache; only 16 selected PNGs included for direct review. Visual acceptance remains unproven until review.\n'})
 commit=publish_git_evidence(repo,'e110ab627021e28deb98a582cb4a529d762cd2a4','Reports/StructTrain/TimeLearner/s04-native-wall-positive-asan-a3','codex/timelearner-native-wall-positive-asan-a3',out,files,'Publish actual native wall-policy gate and complete observation inventory on asan')
 write('terminal.json',{'execution':'completed','commit':commit,'primary_members':len(records),'archive_bytes':archive.stat().st_size,'selected_pngs':len(selected),'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
