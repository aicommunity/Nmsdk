from pathlib import Path
import subprocess,sys,json,os,hashlib,io,tarfile,traceback
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

base=Path("/home/user/timelearner-refactor");out=Path(__file__).resolve().parent
repo=base/'source-native-wall-report-normal-a2';active=base/"source-n1-measured-refinement-normal-a1"
target='6b8292822e5f41702321eb8848e012f8aef67f9d'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def git(*args,env=None,raw=None):
 return subprocess.check_output(['git','-C',str(repo),*args],input=raw,env=env).decode().strip()
try:
 sys.path.insert(0,str(repo))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 before=source_closure(active);write('active-context-before.json',before)
 git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',target)
 assert git('rev-parse','FETCH_HEAD')==target
 manifest=json.loads(git('show',target+':Docs/StructTrain/TimeLearner/script_migration.json'))
 mapping=json.loads(git('show',target+':Docs/StructTrain/TimeLearner/History/RootRevisionMap-2026-10-30.json'))
 write('revision-map.json',mapping)
 for r in manifest['retired_files']+manifest['moved_files']:
  if r['repository']!='root':continue
  sha=mapping['mapping'].get(r['archive_commit'],r['archive_commit'])
  if subprocess.run(['git','-C',str(repo),'cat-file','-e',sha],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
   git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',sha)
 repos=out/'repositories';repos.mkdir()
 children={}
 for name,relative in [('Bin','Bin'),('PulseLib','Libraries/Nmsdk-PulseLib')]:
  child=repos/name
  subprocess.run(['git','clone','--shared','--no-checkout',str(active/relative),str(child)],check=True,capture_output=True)
  children[name]=child
 from Scripts.StructTrain.TimeLearner.migration import verify_migration
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 result=verify_migration(repo,target,children['Bin'],children['PulseLib'],out/'revision-map.json')
 assert result['source_records_verified']==64 and result['manifest_declares_complete'] is False
 write('positive.json',result)
 selected=next(r for r in manifest['retired_files'] if r['old_path'].endswith('plans/AGENT_PLAN_2026-10-20/tools/check_model_wiring.py'))
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'negative.index'))
 git('read-tree',target,env=env)
 git('update-index','--add','--cacheinfo','100644',selected['blob_sha1'],selected['old_path'],env=env)
 negative=git('commit-tree',git('write-tree',env=env),'-p',target,raw=b'Restored historical plan path negative fixture\n')
 try:verify_migration(repo,negative,children['Bin'],children['PulseLib'],out/'revision-map.json')
 except EvidenceError as error:
  assert 'migration_old_path_still_present' in str(error)
  write('negative.json',{'fixture_commit':negative,'rejected_reason':str(error),'source_path':selected['old_path'],'positive_receipt_created':False})
 else:raise AssertionError('restored_path_was_accepted')
 branch='codex/timelearner-plan-tools-restored-negative-normal-a1'
 git('update-ref','refs/heads/'+branch,negative,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==negative
 after=source_closure(active);assert before==after;write('active-context-after.json',after)
 archive=io.BytesIO();records=[]
 with tarfile.open(fileobj=archive,mode='w:xz',preset=6) as tar:
  for p in sorted(out.iterdir()):
   if not p.is_file() or p.name in ('supervisor.log','negative.index'):continue
   raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw));records.append({'path':p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 raw=archive.getvalue()
 metadata={'kind':'timelearner_historical_plan_tool_retirement_gate','source':target,'worker':'normal','source_records_verified':64,'new_retired_files':16,'exact_evidence_copies':7,'negative_fixture_commit':negative,'negative_fixture_branch':branch,'active_source_context_unchanged':True,'records':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'runtime_equivalence_attested':False,'scientific_verdict':None}
 files={'manifest.json':(json.dumps(metadata,indent=2)+'\n').encode(),'primary.tar.xz':raw,'README.md':b'Production Git migration verifier: 64 exact retrieval/absence records, including 16 historical plan tools; restored old path rejected. Seven source files are exact evidence copies. Separate clones/index preserve active native build sources. Historical scripts not executed; no numerical, ASan or runtime-equivalence claim.\n'}
 commit=publish_git_evidence(repo,target,'Reports/StructTrain/TimeLearner/s09-plan-tools-retirement-normal-a1','codex/timelearner-plan-tools-retirement-proof-normal-a1',out,files,'Verify historical plan tool retrieval and current absence on normal')
 write('terminal.json',{'execution':'completed','commit':commit,'verified_records':64,'members':len(records),'archive_bytes':len(raw)})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
