set -euo pipefail
out=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-audit-asan-a1
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
cd /media/user/Data/TimeLearnerRefactor/source-repeat-boundary-audit-a1
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_REPEAT_BOUNDARY_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s05-repeat-boundary-asan-a3/native
export TIMELEARNER_LEARNED_EVIDENCE_DIR="$TIMELEARNER_REPEAT_BOUNDARY_DIR"
export TIMELEARNER_STOPPED_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s05-stopped-asan-a3/native
export TIMELEARNER_N0_REPEATS_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s07-n0-repeats-asan-a2/native
export TIMELEARNER_FULL_PROBE_REPORT_DIR=/media/user/Data/TimeLearnerRefactor/readbacks/s09-n0-full-probe-reports-a1
export TIMELEARNER_DOMAIN_EVIDENCE_DIR=/home/user/timelearner-refactor/readbacks/s07-domain-physics-asan-a1/native
export TIMELEARNER_PROBE_PLOT_DIR="$out/figures"
OUTPUT_DIR="$out" /media/user/Data/TimeLearnerRefactor/plot-venv-a1/bin/python -u - <<'PY' > "$out/python.log" 2>&1
import os,json,unittest,hashlib,xml.etree.ElementTree as E
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import audit_probe,audit_training_summary,load
out=Path(os.environ["OUTPUT_DIR"]);native=Path(os.environ["TIMELEARNER_REPEAT_BOUNDARY_DIR"])
xml=E.parse(native.parent/"native.xml").getroot()
assert int(xml.attrib["tests"])==51,xml.attrib
assert int(xml.attrib["failures"])==int(xml.attrib.get("errors","0"))==int(xml.attrib.get("disabled","0"))==0,xml.attrib
stopped=Path(os.environ["TIMELEARNER_STOPPED_EVIDENCE_DIR"])
assert len(list(stopped.glob("*_stopped_state.json")))==20
checks=[];total=0
for path in sorted(list(native.glob("*_training_summary.json"))+list(native.glob("*_xml_summary.json"))):
    summary=load(path);prefix=path.name.removesuffix("_training_summary.json").removesuffix("_xml_summary.json")
    packets={}
    marker="_xmlprobe_" if path.name.endswith("_xml_summary.json") else "_service_"
    for primary in sorted(native.glob(prefix+marker+"*.json")):
        packet=load(primary);audit_probe(packet,primary.with_suffix(".csv"))
        trial=packet["requested_specification"]["trial_id"];assert trial not in packets
        packets[trial]=packet
    check=audit_training_summary(summary,packets,"pulse0")
    checks.append({"source":path.name,"primary_trials":len(packets),"audit":check});total+=len(packets)
assert len(checks)==8 and total==132,(len(checks),total)
modules=["test_repeat_boundary_evidence","test_learned_evidence","test_stopped_evidence","test_n0_repeat_evidence","test_process_runner","test_publisher","test_condition","test_runtime","test_probe_reports","test_plotting","test_analysis_cli","test_full_probe_report_evidence"]
suite=unittest.defaultTestLoader.loadTestsFromNames(["Scripts.StructTrain.TimeLearner.tests."+m for m in modules])
result=unittest.TextTestRunner(verbosity=2).run(suite)
inputs={}
for name in ("TIMELEARNER_STOPPED_EVIDENCE_DIR","TIMELEARNER_N0_REPEATS_DIR","TIMELEARNER_DOMAIN_EVIDENCE_DIR","TIMELEARNER_FULL_PROBE_REPORT_DIR"):
    directory=Path(os.environ[name]);inputs[name]={"path":str(directory)}
    if name=="TIMELEARNER_STOPPED_EVIDENCE_DIR":
        inputs[name]["packages"]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.glob("*_stopped_state.json"))}
record={"kind":"timelearner_repeat_boundary_gate","schema_version":1,"producer_root":"8d73c0fd575aeeedd163479aa7065245915056d9","auditor_root":"02cf1542de6edfd67aa9da15798d34dd1b0eb08f","cpp_source_equivalent":True,"pulse":"7b5939c5744877ba1a762393d78f7183853fd5c0","native_tests":51,"python_tests":result.testsRun,"skips":len(result.skipped),"failures":len(result.failures),"errors":len(result.errors),"current_configured_audits":checks,"current_configured_primary_trials":total,"auxiliary_inputs":inputs,"scientific_verdict":None}
(out/"validation.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
PY
