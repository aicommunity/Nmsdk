import sys,json,unittest
from pathlib import Path
if __name__=='__main__':
 sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/readbacks/s10-resource-reservations-m40-a2/source')
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_resource_reservations.ResourceReservationsTest')
 with Path('/media/user/Data/TimeLearnerRefactor/readbacks/s10-resource-reservations-m40-a2/tests.log').open('w') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 value={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped)}
 Path('/media/user/Data/TimeLearnerRefactor/readbacks/s10-resource-reservations-m40-a2/tests.json').write_text(json.dumps(value,indent=2)+'\n')
 sys.exit(0 if r.wasSuccessful() and r.testsRun==15 and not r.skipped else 2)
