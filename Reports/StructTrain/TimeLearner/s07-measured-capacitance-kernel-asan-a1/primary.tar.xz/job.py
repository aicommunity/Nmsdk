from pathlib import Path
import subprocess,sys,json,os,hashlib,io,tarfile,traceback,re,xml.etree.ElementTree as ET,shlex
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

out=Path(__file__).resolve().parent;base=out.parent.parent;worker='normal' if str(base).startswith('/home') else 'asan'
repo=base/('source-legacy-completed-replay-normal-a1' if worker=='normal' else 'source-capacitance-temporal-report-a1')
active=base/('source-capacitance-state-normal-b1' if worker=='normal' else 'source-finite-ranking-asan-a1')
root='b951fb3d44eb713a21d5aefd69b13f0e9440ac77';pulse='0832d3ea17fa0a224a332d802f0cee00514c7cec'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
def extract(repository,commit,path,destination):
 raw=subprocess.check_output(['git','-C',str(repository),'show',commit+':'+path]);target=destination/path;target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(raw);return {'path':str(target),'git_commit':commit,'git_path':path,'sha256':hashlib.sha256(raw).hexdigest()}
try:
 write('pid.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]})
 git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root)
 source=out/'source';source.mkdir()
 with tarfile.open(fileobj=io.BytesIO(git('archive',root,'Scripts/StructTrain/TimeLearner')),mode='r:') as tar:
  for member in tar:
   path=source/member.name;assert source.resolve() in path.resolve().parents
   if member.isdir():path.mkdir(parents=True,exist_ok=True)
   else:assert member.isfile();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(tar.extractfile(member).read())
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 before=source_closure(active);write('active-context-before.json',before)
 child=out/'pulselib-git';subprocess.run(['git','clone','--shared','--no-checkout',str(active/'Libraries/Nmsdk-PulseLib'),str(child)],check=True,capture_output=True)
 subprocess.run(['git','-C',str(child),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk-PulseLib.git',pulse],check=True,capture_output=True)
 records=[];modules=['MeasuredCapacitanceSearch','MeasuredLengthSearch','MeasuredResistanceSearch']
 for module in modules:
  for suffix in ['h','cpp']:records.append(extract(child,pulse,'Core/TimeLearner/'+module+'.'+suffix,out/'production'))
  records.append(extract(repo,root,'Tests/Integration/Libraries/Test_PulseLib_'+module+'.cpp',out/'production'))
 expected=[]
 for module in modules:
  test=out/'production/Tests/Integration/Libraries'/('Test_PulseLib_'+module+'.cpp')
  expected+=['/'.join(pair) for pair in re.findall(r'TEST\((\w+),\s*(\w+)\)',test.read_text())]
 assert len(expected)==23 and len(set(expected))==23
 flags=['-std=c++20','-Wall','-Wextra','-Werror','-pthread','-O2'] if worker=='normal' else ['-std=c++20','-Wall','-Wextra','-Werror','-pthread','-O1','-g1','-fsanitize=address','-fno-omit-frame-pointer']
 args=['/usr/bin/c++',*flags,'-I'+str(out/'production/Core')]+[str(out/'production/Core/TimeLearner'/(m+'.cpp')) for m in modules]+[str(out/'production/Tests/Integration/Libraries'/('Test_PulseLib_'+m+'.cpp')) for m in modules]
 dependencies={}
 if worker=='normal':
  gtest=base/'build-capacitance-state-normal-b1/_deps/googletest-src/googletest'
  library=base/'runtime-s07-capacitance-owner-current-normal-c2/Lib.CMake/libgtest.a'
  args+=['-I'+str(gtest/'include'),str(gtest/'src/gtest_main.cc'),str(library)]
  for path in [*sorted((gtest/'include').rglob('*.h')),gtest/'src/gtest_main.cc',library]:dependencies[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
 else:
  args+=shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','gtest_main']).decode())
  dependencies['/usr/include/gtest/gtest.h']=hashlib.sha256(Path('/usr/include/gtest/gtest.h').read_bytes()).hexdigest()
 binary=out/'measured-capacitance-tests';args+=['-o',str(binary)]
 write('compile-request.json',{'root':root,'pulselib':pulse,'arguments':args,'sources':records,'framework_dependencies':dependencies,'expected_test_ids':expected,'scope':'Production source modules compiled directly as numerical unit tests; no extracted function bodies, no Rdk/native controller integration claim.'})
 with (out/'compile.log').open('xb') as log:rc=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
 write('compile-terminal.json',{'returncode':rc});assert rc==0
 (out/'compiler-version.txt').write_bytes(subprocess.check_output(['/usr/bin/c++','--version']))
 (out/'binary-ldd.txt').write_bytes(subprocess.check_output(['ldd',str(binary)]))
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',LD_DEBUG='libs')
 with (out/'stdout.log').open('xb') as log,(out/'stderr.log').open('xb') as err:
  rc=subprocess.run([str(binary),'--gtest_output=xml:'+str(out/'tests.xml')],env=env,stdout=log,stderr=err,timeout=120).returncode
 tree=ET.parse(out/'tests.xml');cases=tree.findall('.//testcase');actual=[c.attrib['classname']+'/'+c.attrib['name'] for c in cases]
 assert rc==0 and len(actual)==len(expected) and set(actual)==set(expected) and all(not c.findall('failure') and not c.findall('skipped') and c.attrib.get('status')=='run' for c in cases)
 if worker=='asan':assert 'calling init:' in (out/'stderr.log').read_text() and 'libasan.so' in (out/'stderr.log').read_text()
 write('unit-result.json',{'execution':'completed','returncode':rc,'expected':23,'observed':23,'assertion_status':'passed','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'asan_instrumented':worker=='asan','native_integration_attested':False,'scientific_verdict':None})
 after=source_closure(active);assert after==before;write('active-context-after.json',after)
 archive=io.BytesIO();members=[]
 with tarfile.open(fileobj=archive,mode='w:xz',preset=6) as tar:
  for path in sorted(out.iterdir()):
   if not path.is_file() or path.name in ['supervisor.log',binary.name]:continue
   raw=path.read_bytes();member=tarfile.TarInfo(path.name);member.size=len(raw);tar.addfile(member,io.BytesIO(raw));members.append({'path':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 raw=archive.getvalue();metadata={'kind':'timelearner_measured_capacitance_kernel_unit_gate','schema_version':1,'root':root,'pulselib':pulse,'worker':worker,'tests':23,'new_capacitance_tests':12,'production_sources_verified':records,'records':members,'archive_sha256':hashlib.sha256(raw).hexdigest(),'native_integration_attested':False,'scientific_verdict':None}
 commit=publish_git_evidence(repo,root,'Reports/StructTrain/TimeLearner/s07-measured-capacitance-kernel-'+worker+'-a1','codex/evidence-s07-measured-capacitance-kernel-'+worker+'-a1',out,{'manifest.json':(json.dumps(metadata,indent=2)+'\n').encode(),'primary.tar.xz':raw},'evidence: production measured capacitance kernel12 plus11 proposal regressions on '+worker)
 write('terminal.json',{'execution':'completed','commit':commit,'tests':23,'archive_bytes':len(raw),'members':len(members)})
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()});raise
