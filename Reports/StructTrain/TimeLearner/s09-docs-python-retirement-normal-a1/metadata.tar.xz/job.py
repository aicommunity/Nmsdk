from pathlib import Path
import subprocess,os,json,hashlib,tarfile,io,sys,traceback
def publish_git_evidence(repo,parent,report,branch,out,files,message):
 import subprocess,os,hashlib,json
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',parent],check=True,capture_output=True)
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 files['SHA256SUMS.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in files.items()},indent=2)+'\n').encode()
 git('read-tree',parent)
 for name,raw in files.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=raw),report+'/'+name)
 commit=git('commit-tree',git('write-tree'),'-p',parent,raw=(message+'\n').encode())
 git('update-ref','refs/heads/'+branch,commit,'0'*40)
 git('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch+':refs/heads/'+branch)
 assert git('ls-remote','git@github.com:aicommunity/Nmsdk.git','refs/heads/'+branch).split()[0]==commit
 print(json.dumps({'commit':commit,'report':report}),flush=True)
 return commit

base=Path("/home/user/timelearner-refactor")
out=Path(__file__).resolve().parent
assert out==base/'readbacks/s09-docs-python-retirement-normal-a1'
source=base/'source-n1-measured-refinement-normal-a1';root='2c3ac22a64c9f6443b6d8bc38ccb227ad1185919'
def write(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def git(repo,*args,env=None,raw=None):return subprocess.check_output(['git','-c','submodule.recurse=false','-C',str(repo),*args],env=env,input=raw).decode().strip()
def run(args,n,timeout=600):
 with (out/n).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 assert r.returncode==0,(n,r.returncode)
def context():
 return {str(p):{'head':git(p,'rev-parse','HEAD'),'top':git(p,'rev-parse','--show-toplevel'),'tracked_status':git(p,'status','--porcelain','--untracked-files=no')} for p in [source,source/'Bin',source/'Libraries/Nmsdk-PulseLib',source/'Rdk']}
try:
 before=context();write('source-context-before.json',before)
 repo=out/'repo'
 run(['git','clone','--shared','--no-checkout','--origin','local-source',source,repo],'clone.log')
 run(['git','-C',repo,'fetch','--no-tags','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],'fetch.log')
 assert git(repo,'rev-parse','FETCH_HEAD')==root
 run(['git','-C',repo,'sparse-checkout','set','Scripts/StructTrain/TimeLearner','Docs/StructTrain/TimeLearner'],'sparse.log')
 run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',root],'checkout.log')
 sys.path.insert(0,str(repo))
 from Scripts.StructTrain.TimeLearner.migration import verify_migration
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 result=verify_migration(repo,root,source/'Bin',source/'Libraries/Nmsdk-PulseLib')
 assert result['source_records_verified']==48 and result['manifest_declares_complete'] is False and result['whole_migration_attested'] is False
 write('positive-verification.json',result)
 manifest=json.loads((repo/'Docs/StructTrain/TimeLearner/script_migration.json').read_text())
 old=next(r for r in manifest['retired_files'] if r['old_path'].endswith('/monitor_softcold_autosave.py'))
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'negative.index'))
 git(repo,'read-tree',root,env=env)
 git(repo,'update-index','--add','--cacheinfo','100644',old['blob_sha1'],old['old_path'],env=env)
 tree=git(repo,'write-tree',env=env)
 fixture=git(repo,'commit-tree',tree,'-p',root,env=env,raw=b'Restored historical script negative fixture\n')
 try:verify_migration(repo,fixture,source/'Bin',source/'Libraries/Nmsdk-PulseLib')
 except EvidenceError as error:
  assert str(error)=='migration_old_path_still_present:'+old['old_path'],str(error)
  write('negative-verification.json',{'fixture_commit':fixture,'fixture_parent':root,'restored_blob':old['blob_sha1'],'path':old['old_path'],'expected_rejection':str(error),'positive_receipt':False,'scientific_verdict':None})
 else:raise AssertionError('restored historical path was accepted')
 after=context();write('source-context-after.json',after);assert before==after
 selected=['job.py','source-context-before.json','source-context-after.json','clone.log','fetch.log','sparse.log','checkout.log','positive-verification.json','negative-verification.json']
 records=[];archive=out/'metadata.tar.xz'
 with tarfile.open(archive,'w:xz',preset=6) as tar:
  for n in selected:
   raw=(out/n).read_bytes();info=tarfile.TarInfo(n);info.size=len(raw);info.mode=0o644;tar.addfile(info,io.BytesIO(raw));records.append({'path':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 summary={'kind':'docs_python_retirement_git_verification','source':root,'worker':'normal','records_verified':48,'newly_retired':4,'negative_fixture_rejected':True,'live_source_context_unchanged':True,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'records':records,'whole_migration_complete':False,'runtime_equivalence_attested':False,'scientific_verdict':None}
 files={'manifest.json':(json.dumps(summary,indent=2)+'\n').encode(),'metadata.tar.xz':archive.read_bytes(),'README.md':b'Production migration verifier checked48 records, including4 retired historical Docs Python tools, against exact Git trees/blobs/content hashes. Restoring one old path in a separate commit fixture was rejected. Source/code/results of live native jobs unchanged; tracked source context compared before/after. Read-only metadata verification, no numerical run, archived script execution or full migration claim.\n'}
 commit=publish_git_evidence(repo,root,'Reports/StructTrain/TimeLearner/s09-docs-python-retirement-normal-a1','codex/timelearner-docs-python-retirement-normal-a1',out,files,'Verify retired historical Docs Python tools and restored-path rejection on normal')
 write('terminal.json',{'execution':'completed','commit':commit,'records_verified':48,'negative_fixture_rejected':True,'scientific_verdict':None})
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
