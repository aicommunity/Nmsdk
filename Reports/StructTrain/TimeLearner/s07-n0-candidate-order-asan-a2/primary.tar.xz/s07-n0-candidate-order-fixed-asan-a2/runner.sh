set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-fixed-asan-a2"
previous="$base/readbacks/s07-n0-candidate-order-fixed-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$previous/process-exit-status.txt";do
 kill -0 "$(cat "$previous/supervisor.pid")";sleep 10
done
export BASE="$base" SRC="$src" BUILD="$build" OUT="$out" RUNTIME="$runtime" PREVIOUS="$previous" PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY' > "$out/previous-state.json"
import json,os
from pathlib import Path
previous=Path(os.environ['PREVIOUS']);result=json.loads((previous/'process/result.json').read_text())
assert result['execution']=='timeout' and result['reason']=='wall_budget_exhausted'
owned=json.loads((previous/'process/owned-process.json').read_text());pid=Path('/proc')/str(owned['pid'])
if pid.exists():
 try:assert (pid/'stat').read_text().split()[21]!=owned['start_ticks']
 except FileNotFoundError:pass
print(json.dumps({'previous_process':result,'same_binary_reused':True,'rebuild':False}))
PY
test "$(git -C "$src" rev-parse HEAD)" = 942e5df4559467a9a19c56755f945ce6501e7780
test -z "$(git -C "$src" status --porcelain)"
cp "$previous/source-closure.txt" "$out/source-closure.txt"
cd "$src";export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1;unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native-evidence"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
r=execute(runtime,['--gtest_filter=BoundedTraining*.*:NativeModelEditor.*N0*:NativeTrainingService.*N0*:NativeColdTrainingService.*N0*','--gtest_output=xml:'+str(out/'native.xml')],Path(runtime['executable']['path']).parent,out/'process',3600)
t=ET.parse(out/'native.xml').getroot()
v={'kind':'n0_candidate_order_fixed','process':r,'tests':int(t.attrib['tests']),'failures':int(t.attrib.get('failures',0)),'expected_failure':False}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
assert r['returncode']==0 and r['runtime_provenance']=='loaded_files_captured'
assert v['tests']>=25 and v['failures']==0 and not t.findall('.//skipped')
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
