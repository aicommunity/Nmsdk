from pathlib import Path
import subprocess,json,os,sys,hashlib,traceback,signal,tarfile,time
ROOT='b82f76e2fe543acf25d6c3076abbd864f965b3a8';OLD='f679d0410dd00a36995f9d32cc03812438819bb7'
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s05-calibration-preconditions-normal-a1';out.mkdir(exist_ok=False)
sdk=base/'source-initial-threshold-normal-a4';build=base/'build-initial-threshold-normal-a4';runtime=base/'runtime-calibration-preconditions-normal-a1';old_runtime=base/'runtime-native-probe-phases-normal-a1';seed=base/'git-relay-threshold-archive-normal-a1.git'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def git(*args):return subprocess.check_output(['git','-C',str(sdk),*args],text=True).strip()
def inventory():return {p.relative_to(old_runtime).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'realpath':str(p.resolve()),'bytes':p.stat().st_size} for p in old_runtime.rglob('*') if p.is_file()}
def run(args,name,timeout=1800):
 with (out/name).open('xb') as log:
  q=subprocess.Popen([str(a) for a in args],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r={'pid':q.pid,'start_ticks':ticks(q.pid),'arguments':[str(a) for a in args]};write('owned-'+name+'.json',r)
  try:rc=q.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   if live(r) and os.getpgid(q.pid)==q.pid:
    os.killpg(q.pid,signal.SIGTERM)
    try:q.wait(timeout=10)
    except subprocess.TimeoutExpired:
     if live(r) and os.getpgid(q.pid)==q.pid:os.killpg(q.pid,signal.SIGKILL);q.wait(timeout=10)
   raise
  assert rc==0,(name,rc)
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False;before=None
try:
 previous=base/'readbacks/s03-native-probe-phases-normal-a1'
 owner=json.loads((previous/'owned-supervisor.json').read_text());write('waiting-for-closed-source.json',owner)
 while live(owner):time.sleep(5)
 prerequisite=json.loads((previous/'terminal.json').read_text());assert prerequisite['status']=='passed',prerequisite
 write('closed-source-prerequisite.json',{'owner':owner,'terminal':prerequisite})
 assert git('rev-parse','HEAD')==OLD and not git('status','--porcelain','--untracked-files=no')
 assert not runtime.exists()
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:assert not str((proc/'exe').resolve()).startswith(str(old_runtime)+'/'),'old runtime process still live'
  except (FileNotFoundError,PermissionError):pass
 before=inventory();write('old-runtime-before.json',before)
 run(['git','-C',sdk,'fetch','--no-recurse-submodules',seed,ROOT],'fetch-source.log')
 changed=git('diff','--name-only','603d1ad90bd8628c7c85bb5bec2ba7adbeca02b0',ROOT,'--','App','Tests','CMakeLists.txt','cmake').splitlines()
 assert changed==['Tests/Integration/Libraries/Test_PulseLib_NativeModelEditor.cpp'],changed
 prior_children={}
 for r in subprocess.check_output(['git','-C',str(sdk),'ls-tree','-r','-z',ROOT]).split(b'\0'):
  if not r:continue
  info,path=r.split(b'\t',1)
  if info.split()[0]==b'160000':
   path=path.decode();sha=info.split()[2].decode();assert subprocess.check_output(['git','-C',str(sdk/path),'rev-parse','HEAD'],text=True).strip()==sha;prior_children[path]=sha
 write('closed-build-reuse.json',{'old_root':OLD,'new_root':ROOT,'only_native_source_change':changed,'children':prior_children,'all_known_owners_closed':True,'new_runtime':str(runtime),'old_runtime':str(old_runtime),'pulse_production_core_unchanged':True})
 run(['git','-C',sdk,'checkout','--detach',ROOT],'checkout-source.log')
 run(['cmake','-S',sdk,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log',3600)
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 sys.path.insert(0,str(sdk));os.chdir(sdk)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 appini=runtime/'NeuroModelerConsole.ini'
 write('native-runtime.json',snapshot(sdk,runtime/'Test_PulseLib_StorageComponents',appini,build/'CMakeCache.txt'))
 spec=load(sdk/'Scripts/StructTrain/TimeLearner/specs/native-calibration-preconditions-v1.json');assert len(spec['expected_test_ids'])==8
 spec.update(source_root=str(sdk),runtime_manifest=str(out/'native-runtime.json'),asan_options='');write('native-specification.json',spec)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result)
 assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed'
 passed=True;write('terminal.json',{'execution':'completed','native_tests':8,'positive_calibration_cases':4,'legacy_negative_cases':4,'production_pulse_code_changed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 if before is not None:
  after=inventory();write('old-runtime-after.json',after)
  if after!=before:passed=False;write('old-runtime-byte-guard-failed.json',{'same':False})
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner']:
  for p in (sdk/prefix).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(sdk).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 for p in (sdk/'Libraries/Nmsdk-PulseLib/Core/TimeLearner').rglob('*'):
  if p.is_file():hashes[p.relative_to(sdk).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes();write('bundle.json',{'kind':'native_calibrated_model_spec2_validation','schema_version':1,'root':ROOT,'pulselib':'541bf89b9966f63ca5131fa57a31a9ae3f5820ea','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
