from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,traceback,threading,time,shutil,io
base=Path('/home/user/timelearner-refactor');source=base/'source-psi-retirement-a1';out=base/'readbacks/s09-psi-retirement-a2';out.mkdir(exist_ok=False)
root='554c45786cc2d0203ac5199cc7df568828f66e58';before='17b60cdfbd9285f8d4af5259c2019b4abc30fd0d';child='f03e31ebc0c393e5f9c25dc4c58a0daef9c1a1bc';oldchild='525aafbafe72679b40332eeb7704a922c3c72eee'
sys.path.insert(0,str(source));os.nice(10)
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a,data=None):return subprocess.check_output(['git','-C',str(repo),*a],input=data).decode().strip()
def raw(repo,rev,path):return subprocess.check_output(['git','-C',str(repo),'show',rev+':'+path])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'metadata_only':True,'root':root});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'psi-metadata-reservations.sqlite3');token=None;stop=threading.Event();thread=None;errors=[];passed=False
try:
 assert shutil.disk_usage(base).free>=1024**3
 import sqlite3,socket
 connection=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True)
 try:
  connection.execute('PRAGMA query_only=ON');connection.execute('BEGIN')
  metadata=dict(connection.execute('SELECT key,value FROM metadata'))
  assert metadata['schema_version'] in ('1','2') and metadata['worker_host']==socket.gethostname()
  held=[r for row in connection.execute("SELECT resources FROM leases WHERE state='held'") for r in json.loads(row[0])]
  write('global-registry-readonly.json',{'metadata':metadata,'held_resources':held,'opened_readonly':True,'policy_modified':False})
 finally:connection.close()
 for p in [source,out]:
  for r in held:
   q=Path(r['canonical_path']);assert not p.is_relative_to(q) and not q.is_relative_to(p),str(q)
 write('isolation.json',{'no_overlap_with_held_global_resources':True,'source_private_no_alternates':not(source/'.git/objects/info/alternates').exists(),'native_models_executed':0,'global_capacity_or_slot_changed':False,'own_bounded_memory_bytes':512*1024**2})
 lease=registry.reserve(out.name,[{'path':str(source),'access':'write'},{'path':str(out),'access':'write'}],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert git(source,'rev-parse','HEAD')==root
 manifest=json.loads(raw(source,root,'Docs/StructTrain/TimeLearner/script_migration.json'));assert len(manifest['retired_files'])+len(manifest['moved_files'])==205 and not manifest['complete']
 retired=[r for r in manifest['retired_files'] if r['repository']=='Bin' and r['old_path'].startswith('Configs/SpikeSamples/StructTrain/SelectivityPresynapticInhib/scripts/')];assert len(retired)==19
 mapping=out/'revision-map.json';mapping.write_bytes(raw(source,root,'Docs/StructTrain/TimeLearner/History/RootRevisionMap-2026-10-30.json'))
 args=['python3','-m','Scripts.StructTrain.TimeLearner','history','verify-migration',root,'--root',str(source),'--bin-repository',str(source/'Bin'),'--pulselib-repository',str(source/'Libraries/Nmsdk-PulseLib'),'--map',str(mapping),'--output',str(out/'positive.json')]
 p=subprocess.run(args,cwd=source,capture_output=True,timeout=300);(out/'positive-stdout.log').write_bytes(p.stdout);(out/'positive-stderr.log').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()
 positive=json.loads((out/'positive.json').read_text());assert positive['source_records_verified']==205 and not positive['whole_migration_attested'] and not positive['runtime_equivalence_attested']
 expected={r['old_path']:'D' for r in retired};prefix='Configs/SpikeSamples/StructTrain/SelectivityPresynapticInhib/'
 docs=[prefix+n for n in ['README.md','REPORT.md','REPORT_autothr.md','REPORT_gui_autothr.md','REPORT_k_sweep.md','REPORT_time_compress.md','REPORT_time_expand.md']]
 expected.update({name:'M' for name in docs})
 changed={line.split('\t',1)[1]:line.split('\t',1)[0] for line in git(source/'Bin','diff','--no-renames','--name-status',oldchild,child).splitlines()};assert changed==expected,(changed,expected)
 prefixes=[]
 for name in docs:
  previous=raw(source/'Bin',oldchild,name);current=raw(source/'Bin',child,name);assert current.endswith(previous);prefixes.append(current[:-len(previous)])
 assert len(set(prefixes))==1 and prefixes[0];preserved_report_bodies=docs
 root_paths=set(git(source,'diff','--name-only',before,root).splitlines());assert root_paths=={'Bin','Docs/StructTrain/TimeLearner/script_migration.json','Docs/StructTrain/TimeLearner/PsiToolRetirement.ru.md'}
 unchanged={}
 for path in ['Scripts','Tests','App','CMakeLists.txt','Libraries','Rdk']:
  a=git(source,'rev-parse',before+':'+path);b=git(source,'rev-parse',root+':'+path);assert a==b;unchanged[path]=a
 write('scope.json',{'root_base':before,'root_candidate':root,'bin_base':oldchild,'bin_candidate':child,'bin_exact_changes':changed,'root_exact_changes':sorted(root_paths),'all_other_bin_blobs_unchanged':True,'preserved_original_report_bodies':preserved_report_bodies,'unchanged_root_native_and_code_trees':unchanged,'scientific_verdict':None})
 def tree(repo,old,changes):
  entries={}
  for item in (subprocess.check_output(['git','-C',str(repo),'ls-tree','-z',old]).split(b'\0') if old else []):
   if item:
    h,n=item.split(b'\t',1);mode,kind,oid=h.decode().split();entries[n.decode()]=(mode,kind,oid)
  groups={}
  for path,value in changes.items():
   h,sep,tail=path.partition('/')
   if sep:groups.setdefault(h,{})[tail]=value
   else:entries[h]=value
  for name,sub in groups.items():entries[name]=('040000','tree',tree(repo,entries[name][2] if name in entries else None,sub))
  content=b''.join((entries[n][0].lstrip('0')+' '+n).encode()+b'\0'+bytes.fromhex(entries[n][2]) for n in sorted(entries,key=lambda n:n+('/' if entries[n][1]=='tree' else '')))
  return git(repo,'hash-object','-w','-t','tree','--stdin',data=content)
 record=retired[0];path=record['old_path'];mode=git(source/'Bin','ls-tree',oldchild,'--',path).split()[0]
 btree=tree(source/'Bin',git(source/'Bin','rev-parse',child+'^{tree}'),{path:(mode,'blob',record['blob_sha1'])})
 badbin=git(source/'Bin','-c','user.name=TimeLearner Agent','-c','user.email=timelearner@localhost','commit-tree',btree,'-p',child,data=b'Negative restored historical PSI script path\n')
 rtree=tree(source,git(source,'rev-parse',root+'^{tree}'),{'Bin':('160000','commit',badbin)})
 negative=git(source,'-c','user.name=TimeLearner Agent','-c','user.email=timelearner@localhost','commit-tree',rtree,'-p',root,data=b'Negative root points at restored historical PSI script\n')
 args[5]=negative;args[-1]=str(out/'negative-must-not-exist.json');p=subprocess.run(args,cwd=source,capture_output=True,timeout=300);(out/'negative-stdout.log').write_bytes(p.stdout);(out/'negative-stderr.log').write_bytes(p.stderr)
 assert p.returncode==2 and ('migration_old_path_still_present:'+path).encode() in p.stderr and not (out/'negative-must-not-exist.json').exists()
 for name,repo,tip,exclude in [('root',source,negative,root),('bin',source/'Bin',badbin,child)]:
  with (out/('negative-'+name+'.pack')).open('wb') as f:subprocess.run(['git','-C',str(repo),'pack-objects','--revs','--stdout'],input=(tip+'\n^'+exclude+'\n').encode(),stdout=f,check=True)
 write('negative.json',{'root_commit':negative,'bin_commit':badbin,'restored_path':path,'returncode':p.returncode,'expected_reason':'migration_old_path_still_present:'+path,'output_receipt_absent':True,'old_script_materialized_or_executed':False})
 write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py')})
 registry.validate_paths(token);assert not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 write('terminal.json',{'checks_passed':passed,'records_verified':205 if passed else None,'native_models_executed':0,'old_scripts_executed':False,'whole_migration_complete':False,'scientific_verdict':None})
 members={}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as t:
  for p in sorted(out.rglob('*')):
   if p.is_file() and p.name not in ['primary.tar.xz','bundle.json']:
    name=p.relative_to(out).as_posix();members[name]={'bytes':p.stat().st_size,'sha256':sha(p)};info=tarfile.TarInfo(name);info.size=p.stat().st_size
    with p.open('rb') as f:t.addfile(info,f)
 write('bundle.json',{'root':root,'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'checks_passed':passed,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
