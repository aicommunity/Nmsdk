import subprocess
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-zj_5h8om/child').write_text(str(p.pid))
