from pathlib import Path
import os,sys,json
base=Path('/media/user/Data/TimeLearnerRefactor');out=base/'readbacks/s10-contained-worker-unit-graph-baseline-a1';runtime=out/'runtime-tree';runtime.mkdir(parents=True,exist_ok=False);script=runtime/'child.py';script.write_text("from pathlib import Path\nimport time,os,json\nPath('child-entered.json').write_text(json.dumps({'pid':os.getpid()}))\ntime.sleep(180)\n")
sys.path.insert(0,str(base/'source-closed-worker-recovery-a3'))
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
from Scripts.StructTrain.TimeLearner.contained_process import start
from Scripts.StructTrain.TimeLearner.runtime import file_record,resolved_libraries,digest_json,runtime_content_identity
registry=Reservations(out/'isolated-reservations.sqlite3');lease=registry.reserve('isolated-unit-graph-baseline',[{'path':str(runtime),'access':'write'}],ttl_seconds=300);(out/'lease.json').write_text(json.dumps(lease,indent=2))
m={'schema_version':2,'source_closure':{'kind':'isolated_unit_graph_fault_control','neural_model':False},'executable':file_record(Path(sys.executable)),'app_ini':file_record(script),'compiler':file_record(Path('/usr/bin/c++')),'build_flags':{'role':'Python sleep control; not a neural executable'},'resolved_libraries':resolved_libraries(Path(sys.executable)),'loaded_process_files':None,'loader_environment':{k:os.environ[k] for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM'] if k in os.environ}}
m['runtime_identity']=runtime_content_identity(m);m['runtime_fingerprint']=digest_json(m['runtime_identity']);binding=start(m,[str(script)],runtime,out/'native-child',memory_bytes=128*1024**2,tasks=32,maximum_wall_seconds=180)
(out/'child-binding.json').write_text(json.dumps(binding,indent=2));(out/'parent-returned-with-live-child.json').write_text(json.dumps({'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'recovery_api_source':'adc1f6227144360097b378a33e1db564794e0442','native_models_executed':0},indent=2))
