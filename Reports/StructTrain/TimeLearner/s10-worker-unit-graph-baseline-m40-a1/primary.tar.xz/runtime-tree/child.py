from pathlib import Path
import time,os,json
Path('child-entered.json').write_text(json.dumps({'pid':os.getpid()}))
time.sleep(180)
