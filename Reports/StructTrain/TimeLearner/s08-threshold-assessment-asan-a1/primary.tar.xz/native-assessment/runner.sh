set -euo pipefail
base=/home/user/timelearner-refactor
src="$base/source-order-baseline-a1"
build="$base/build-order-baseline-a1"
data=/media/user/Data/TimeLearnerRefactor
out="$data/readbacks/s08-threshold-assessment-asan-a1"
runtime="$data/runtime-s08-threshold-assessment-asan-a1"
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'status=$?; echo "$status" > "$out/process-exit-status.txt"' EXIT
while kill -0 2891452 2>/dev/null; do sleep 15; done
test "$(cat /media/user/Data/TimeLearnerRefactor/readbacks/s08-threshold-potential-asan-a2/process-exit-status.txt)" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" diff --cached --quiet
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git ad975bbeb5df18555d94329d3ee95f321921c171 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach ad975bbeb5df18555d94329d3ee95f321921c171 >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
test "$(git -C "$src/Libraries/Nmsdk-PulseLib" rev-parse HEAD)" = 25cf6a5bfadc0ee72182cb924f1d0730cf6dc71b
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
mkdir -p "$out/native" "$out/legacy-native"
export QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0 PYTHONDONTWRITEBYTECODE=1
cd "$src"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
cd "$runtime"
status=0
for phase in potential-2k potential-20k legacy-2k legacy-expanded; do
 case "$phase" in
 potential-2k) filter='NativeThresholdPotential.*_2000'; destination=native ;;
 potential-20k) filter='NativeThresholdPotential.*_20000'; destination=native ;;
 legacy-2k) filter='NativeThresholdCandidate.*_2000'; destination=legacy-native ;;
 legacy-expanded) filter='NativeThresholdCandidate.*_20000:NativeRecognitionOwner.ClassicFreshDestination:NativeRecognitionOwner.BranchFreshDestination:NativeRecognitionState.ClassicN0Identity:NativeRecognitionState.BranchN1HistoricalScale'; destination=legacy-native ;;
 esac
 export TIMELEARNER_EXECUTION_OUTPUT="$out/$destination"
 set +e
 ./Test_PulseLib_StorageComponents --gtest_filter="$filter" --gtest_output="xml:$out/$phase.xml" >> "$out/native.log" 2>&1
 status=$?
 set -e
 echo "$status" > "$out/$phase-exit-status.txt"
 if test "$status" != 0; then break; fi
done
echo "$status" > "$out/native-exit-status.txt"
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
r=json.loads(Path(os.environ["RUNTIME_MANIFEST"]).read_text())
print(json.dumps({"verified":True,"executable":str(verify_runtime(r)),"scientific_verdict":None},indent=2))
PY
test "$status" = 0
OUT="$out" python3 - <<'PY'
import json,os,xml.etree.ElementTree as E
from pathlib import Path
out=Path(os.environ["OUT"]);root=E.Element("testsuites");seen=set()
for phase,count in (("potential-2k",2),("potential-20k",2),("legacy-2k",4),("legacy-expanded",8)):
 r=E.parse(out/(phase+".xml")).getroot();cases=list(r.iter("testcase"));assert len(cases)==count
 assert not list(r.iter("failure")) and not list(r.iter("error")) and not list(r.iter("skipped"))
 for c in cases:
  key=c.attrib["classname"],c.attrib["name"];assert key not in seen;seen.add(key)
 for child in r:root.append(child)
expected={("NativeThresholdCandidate",top+norm+"_"+freq) for top in ("Classic","Branch") for norm in ("N0","N1") for freq in ("2000","20000")}
expected|={("NativeThresholdPotential",top+"N1_"+freq) for top in ("Classic","Branch") for freq in ("2000","20000")}
expected|={("NativeRecognitionOwner","ClassicFreshDestination"),("NativeRecognitionOwner","BranchFreshDestination"),("NativeRecognitionState","ClassicN0Identity"),("NativeRecognitionState","BranchN1HistoricalScale")}
assert seen==expected,(seen^expected)
root.attrib.update(tests="16",failures="0",errors="0",disabled="0")
E.ElementTree(root).write(out/"native.xml",encoding="utf-8",xml_declaration=True)
(out/"native-validation.json").write_text(json.dumps({"kind":"timelearner_threshold_assessment_native_gate","schema_version":1,"tests":16,"errors":0,"failures":0,"skips":0,"fixture_wall_seconds":1800,"scientific_verdict":None},indent=2)+"\n")
PY
