set -euo pipefail
base=/home/user/timelearner-refactor
reader="/media/user/Data/TimeLearnerRefactor/source-threshold-assessment-audit-a1"
out="/media/user/Data/TimeLearnerRefactor/readbacks/s08-threshold-assessment-audit-asan-a1"
native="/media/user/Data/TimeLearnerRefactor/readbacks/s08-threshold-assessment-asan-a1"
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 2925779 2>/dev/null; do sleep 15; done
test "$(cat "$native/process-exit-status.txt")" = 0
test -f "$native/native-validation.json"
cd "$reader"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_THRESHOLD_CANDIDATE_DIR="$native/legacy-native"
export TIMELEARNER_THRESHOLD_POTENTIAL_DIR="$native/native"
export AUDIT_OUTPUT="$out"
python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,sys,unittest
from pathlib import Path
names=['test_threshold_candidate_evidence','test_calibration','test_threshold_proposal_evidence','test_native_calibration_evidence']
suite=unittest.defaultTestLoader.loadTestsFromNames(['Scripts.StructTrain.TimeLearner.tests.'+name for name in names])
assert suite.countTestCases()==35,suite.countTestCases()
result=unittest.TextTestRunner(verbosity=2).run(suite)
record={'reader_revision':'1ef44e2e6c5ce40339f9aeaa5e4426810e36844b','tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'scientific_verdict':None}
Path(os.environ['AUDIT_OUTPUT'],'validation.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun==35 and not result.skipped else 1)
PY
