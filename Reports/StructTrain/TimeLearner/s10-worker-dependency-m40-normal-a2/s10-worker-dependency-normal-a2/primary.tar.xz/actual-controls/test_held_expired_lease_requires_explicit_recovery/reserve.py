import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-worker-dependency-normal-a2')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations,ReservationError
r=Reservations('/tmp/timelearner-contained-hwglci7s/leases.sqlite3')
values=[]
for i in range(1):
 try:
  values.append(r.reserve("actual-dependency",[{"path":'/tmp/timelearner-contained-hwglci7s'+"/scratch-"+str(i),"access":"write"}],ttl_seconds=.001))
 except ReservationError as error:
  Path('/tmp/timelearner-contained-hwglci7s/duplicate-rejection.json').write_text(json.dumps({"reason":str(error)}))
  break
Path('/tmp/timelearner-contained-hwglci7s/leases.json').write_text(json.dumps(values))
