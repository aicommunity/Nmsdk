from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');label='worker-dependency-normal-a2';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False)
source=base/'source-worker-dependency-normal-a2';bootstrap=base/'source-closed-worker-recovery-a3';root='1e714a38401c3aa77dce42873188d96a6867c643'
stop=threading.Event();thread=None;errors=[];passed=False
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'native_models_executed':0})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 predecessor=base/'readbacks/s10-worker-dependency-normal-a1-container'
 assert inspect_contained(predecessor)['all_processes_closed']
 previous=json.loads((predecessor/'operator-recovery.json').read_text());assert previous['closure']['all_processes_closed']
 write('previous-attempt-recovery.json',previous)
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 assert memory>=3*1024**3 and shutil.disk_usage(base).free>=1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':shutil.disk_usage(base).free,'parent_memory_bytes':512*1024**2,'maximum_two_child_units_memory_bytes':256*1024**2,'native_models_executed':0,'neural_runtime_modified':False})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3')
 lease=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'},{'path':str(bootstrap),'access':'read'}],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_CONTAINED_EVIDENCE_DIR']=str(out/'actual-controls')
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_worker_dependency');assert suite.countTestCases()==9
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':9})
 assert result.testsRun==9 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'expected_actual_kernel_units':10,'native_models_executed':0,'condition_spec_dispatch_and_publisher_complete':False,'scientific_verdict':None,'whole_plan_complete':False})
  write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    entry=tarfile.TarInfo(name);entry.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(entry,f)
  write('bundle.json',{'kind':'worker_dependency_actual_kernel_gate','root':root,'passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz')})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
