import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-worker-dependency-normal-a1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-4gky25c0/leases.sqlite3')
values=[]
for i in range(2):
 values.append(r.reserve("actual-dependency",[{"path":'/tmp/timelearner-contained-4gky25c0'+"/scratch-"+str(i),"access":"write"}],ttl_seconds=.001))
Path('/tmp/timelearner-contained-4gky25c0/leases.json').write_text(json.dumps(values))
