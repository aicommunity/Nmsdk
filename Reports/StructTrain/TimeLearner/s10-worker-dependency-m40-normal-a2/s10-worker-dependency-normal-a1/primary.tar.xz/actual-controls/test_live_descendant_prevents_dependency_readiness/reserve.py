import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-worker-dependency-normal-a1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-re47u6x7/leases.sqlite3')
values=[]
for i in range(1):
 values.append(r.reserve("actual-dependency",[{"path":'/tmp/timelearner-contained-re47u6x7'+"/scratch-"+str(i),"access":"write"}],ttl_seconds=.001))
Path('/tmp/timelearner-contained-re47u6x7/leases.json').write_text(json.dumps(values))
subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
