import json,sys,subprocess
from pathlib import Path
sys.path.insert(0,'/media/user/Data/TimeLearnerRefactor/source-worker-dependency-normal-a1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-l6q9ngg6/leases.sqlite3')
values=[]
for i in range(1):
 values.append(r.reserve("actual-dependency",[{"path":'/tmp/timelearner-contained-l6q9ngg6'+"/scratch-"+str(i),"access":"write"}],ttl_seconds=.001))
Path('/tmp/timelearner-contained-l6q9ngg6/leases.json').write_text(json.dumps(values))
