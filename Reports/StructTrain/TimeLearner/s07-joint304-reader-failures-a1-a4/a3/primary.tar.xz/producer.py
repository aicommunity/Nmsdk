if __name__ == '__main__':
 from pathlib import Path
 import os,sys,json,hashlib,subprocess,threading,traceback,tarfile,shutil,time
 base=Path('/home/user/timelearner-refactor');label='csearch-threshold-joint-readers-a3';out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
 source=base/'source-csearch-threshold-joint-normal-a2';previous=base/'readbacks/s07-csearch-threshold-joint-full-normal-a1';controller=base/('readbacks/s07-'+label+'-container');bootstrap=base/'source-closed-worker-recovery-a3';root='8021301e894368aefd045f9d77274fcce9f60245'
 def write(n,v):
  path=out/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
 def sha(path):
  h=hashlib.sha256()
  with path.open('rb') as f:
   for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
  return h.hexdigest()
 write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'root':root,'source':str(source)})
 (out/'producer.py').write_bytes(Path(__file__).read_bytes());registry=None;token=None;thread=None;stop=threading.Event();errors=[];passed=False;returncode=None
 try:
  assert shutil.disk_usage(base).free>=2*1024**3
  assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root
  native=json.loads((previous/'native-verdict.json').read_text());assert native['inventory']['observed']==304 and native['assertion_status']=='passed'
  assert json.loads((base/(str(previous.relative_to(base))+'-container')/'closure.json').read_text())['all_processes_closed']
  sys.path.insert(0,str(bootstrap));from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
  registry=Reservations(base/'resource-reservations.sqlite3',capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3})
  paths=[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'},{'path':str(previous),'access':'read'}]
  lease=registry.reserve('s07-'+label,paths,demands={'slots':1,'memory_bytes':512*1024**2,'disk_bytes':256*1024**2},ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
  def heartbeat():
   while not stop.wait(20):
    try:registry.heartbeat(token,ttl_seconds=120)
    except BaseException as e:errors.append(str(e));return
  thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
  # Prepare the declaration in the exact runtime Python package, in a fresh
  # subprocess so the operational bootstrap cannot shadow scientific readers.
  prepare=r"""from pathlib import Path
import sys,json,hashlib,unittest
from Scripts.StructTrain.TimeLearner.validation import package_fingerprint,fixture_fingerprint,_tests
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s07-csearch-threshold-joint-readers-a3';previous=base/'readbacks/s07-csearch-threshold-joint-full-normal-a1';source=base/'source-csearch-threshold-joint-normal-a2'
old=json.loads((base/'readbacks/s07-capacitance-full-normal-j5/reader-suite.json').read_text());suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in old['modules']);ids=[t.id() for t in _tests(suite)]
assert len(ids)==119 and set(ids)==set(old['expected_test_ids'])
bindings={name:(previous/'native-result' if name=='TIMELEARNER_NATIVE_GATE_DIR' else previous/'native-result/native') for name in old['fixtures']}
declarations={}
for name,folder in bindings.items():
 count,digest=fixture_fingerprint(folder,'*.json');declarations[name]={'pattern':'*.json','files':count,'fingerprint':digest}
spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'joint304-primary-readers119','package_fingerprint':package_fingerprint(),'modules':old['modules'],'expected_test_ids':old['expected_test_ids'],'fixtures':declarations}
(out/'reader-suite.json').write_text(json.dumps(spec,indent=2)+'\n');(out/'fixture-bindings.json').write_text(json.dumps({n:str(p) for n,p in bindings.items()},indent=2)+'\n');(out/'previous-reader-template.json').write_text(json.dumps(old,indent=2)+'\n')
hashes={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((source/'Scripts/StructTrain/TimeLearner').rglob('*.py'))};(out/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
"""
  with (out/'prepare.log').open('xb') as log:subprocess.run(['python3','-c',prepare],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
  bindings=json.loads((out/'fixture-bindings.json').read_text());args=['python3','-m','Scripts.StructTrain.TimeLearner.validation',str(out/'reader-suite.json'),'--output',str(out/'structured-readers')]
  for name,path in bindings.items():args+=['--fixture',name+'='+path]
  with (out/'reader-cli.log').open('xb') as log:
   process=subprocess.Popen(args,cwd=source,stdout=log,stderr=subprocess.STDOUT);write('owned-reader.json',{'pid':process.pid,'start_ticks':Path('/proc',str(process.pid),'stat').read_text().rsplit(') ',1)[1].split()[19],'arguments':args});returncode=process.wait(timeout=900)
  result=json.loads((out/'structured-readers/result.json').read_text());assert result['executed_tests']==119 and result['assertion_status']=='passed' and not any(result[k] for k in ['failures','errors','skipped']);assert returncode==0 and not errors;passed=True
 except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
  write('terminal.json',{'readers_passed':passed,'returncode':returncode,'native304_reused':True,'numerical_restart':False,'joint_asan_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
  members={}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for path in sorted(out.rglob('*')):
    if not path.is_file() or path.is_symlink() or path.name in ['primary.tar.xz','bundle.json']:continue
    name=path.relative_to(out).as_posix();members[name]={'bytes':path.stat().st_size,'sha256':sha(path)};archive.add(path,arcname=name,recursive=False)
  write('bundle.json',{'kind':'joint304_primary_readers','source_commit':root,'readers_passed':passed,'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'primary_native_evidence_commit':'25bbda5529caea24e8847973cd603d50b1b45826','scientific_verdict':None})
