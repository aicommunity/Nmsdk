import subprocess
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-kjg28hnp/child').write_text(str(p.pid))
