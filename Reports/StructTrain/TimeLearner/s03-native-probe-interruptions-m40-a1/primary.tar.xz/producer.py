ASAN=True
from pathlib import Path
import os,sys,subprocess,json,traceback,time,hashlib,tarfile,unittest,threading
root='07ff1081f88dd020eafa345c3dc0cf4594a0941c'
base=Path('/media/user/Data/TimeLearnerRefactor' if ASAN else '/home/user/timelearner-refactor')
sdk=base/('source-initial-threshold-asan-a2' if ASAN else 'source-initial-threshold-normal-a4')
build=base/('build-initial-threshold-asan-a2' if ASAN else 'build-initial-threshold-normal-a4')
label='asan' if ASAN else 'normal';out=base/('readbacks/s03-native-probe-interruptions-'+label+'-a1');out.mkdir(exist_ok=False)
runtime=base/('runtime-native-probe-interruptions-'+label+'-a1')
prior=base/('readbacks/s03-native-characterization-asan-a3' if ASAN else 'readbacks/s03-native-characterization-normal-a6')
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(*a):return subprocess.check_output(['git','-C',str(sdk),*a],text=True).strip()
def run(args,name):
 with (out/name).open('xb') as log:
  p=subprocess.Popen([str(a) for a in args],stdout=log,stderr=subprocess.STDOUT)
  write('owned-'+name+'.json',{'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().rsplit(') ',1)[1].split()[19]})
  assert p.wait()==0,(name,p.returncode)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 assert not runtime.exists() and not git('status','--porcelain','--untracked-files=no')
 owner=json.loads((prior/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
 users=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  try:
   refs=[str((proc/'cwd').resolve()),str((proc/'exe').resolve())]+(proc/'maps').read_text().splitlines()
   if any(str(sdk) in s or str(build) in s for s in refs):users.append(proc.name)
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 assert not users,users
 write('closed-source-lease.json',{'active_users':users,'initial_root':git('rev-parse','HEAD')})
 remote='https://github.com/aicommunity/Nmsdk.git' if ASAN else str(base/'git-relay-threshold-archive-normal-a1.git')
 run(['git','-C',sdk,'fetch','--no-recurse-submodules',remote,root],'fetch.log')
 run(['git','-C',sdk,'checkout','--detach',root],'checkout.log');assert not git('status','--porcelain','--untracked-files=no')
 run(['cmake','-S',sdk,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 run(['cmake','--build',build,'--target','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_characterization import audit_execution
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 manifest=snapshot(sdk,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 before=_inventory(runtime);(out/'jobs').mkdir();(out/'runs').mkdir();rows=[]
 for topology in ['Classic','Branch']:
  for mode in ['completed','timeout','cancelled']:
   name=topology+'-'+mode;job=load(prior/'jobs'/(topology+'-v2-full.json'));job.pop('sha256')
   if mode=='timeout':job['maximum_wall_seconds']=1e-9
   elif mode=='cancelled':
    job['probe']['duration']=5.;job['probe']['window']['end']=5.;job['probe']['maximum_samples']=10010;job['maximum_model_ticks']=10010
   job=_signed(job);write('jobs/'+name+'.json',job)
   destination=out/'runs'/name;stop=threading.Event();watch=[]
   def cancel_after_trace_is_visible():
    limit=time.monotonic()+120
    while not stop.is_set():
     trace=destination/'native/raw-trial-1.csv'
     if trace.exists() and trace.stat().st_size>0:
      request={'kind':'native_probe_cancel_request','reason':'explicit_interruption_control','observed_trace_bytes':trace.stat().st_size}
      path=destination/'native/cancel.request'
      with path.open('x') as f:json.dump(request,f);f.write('\n')
      watch.append(request);return
     if time.monotonic()>limit:return
     stop.wait(.002)
   watcher=threading.Thread(target=cancel_after_trace_is_visible)
   if mode=='cancelled':watcher.start()
   try:result=run_job('probe',out/'jobs'/(name+'.json'),None,out/'runtime.json',destination,120)
   finally:
    stop.set()
    if mode=='cancelled':watcher.join()
   assert audit_run_manifest(destination/'run-manifest.json')['run_evidence_consistent']
   audit=audit_execution(destination/'native');assert audit['execution']==mode,audit
   assert audit['observation_complete']==(mode=='completed') and audit['observation_valid']==(mode=='completed'),audit
   if mode=='cancelled':assert len(watch)==1;write(name+'-watcher.json',watch[0])
   if mode=='completed':
    old=prior/'runs'/(topology+'-v2-full')/'native'
    equal={n:(old/n).read_bytes()==(destination/'native'/n).read_bytes() for n in ['probe_trial_1.json','probe_trial_1.csv','initial-state.json','final-state.json']}
    assert all(equal.values()),equal;write(name+'-primary-equality.json',equal)
   rows.append({'name':name,'branch':topology=='Branch','expected_execution':mode});write('index.json',{'rows':rows})
   print('PROBE',name,audit,flush=True)
 os.environ['TIMELEARNER_PROBE_INTERRUPTION_CORPUS']=str(out);os.environ['TIMELEARNER_CHARACTERIZATION_CORPUS']=str(prior)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in ['Scripts.StructTrain.TimeLearner.tests.test_native_probe_interruptions.NativeProbeInterruptionTest','Scripts.StructTrain.TimeLearner.tests.test_native_characterization.NativeCharacterizationTest'])
 with (out/'readers.log').open('w') as log:tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('readers.json',{'tests':tests.testsRun,'errors':len(tests.errors),'failures':len(tests.failures),'skipped':len(tests.skipped)});assert tests.wasSuccessful() and not tests.skipped
 assert before==_inventory(runtime);write('runtime-unchanged.json',{'same':True,'files':len(before)})
 if ASAN:
  for row in rows:
   loaded=load(destination/'process/runtime.json')
   assert any('libasan.so' in r['path'] for r in json.loads((out/'runs'/row['name']/'process/loaded-files.json').read_text()))
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','root':root,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['App/NeuroModelerConsole','Scripts/StructTrain/TimeLearner'] for p in (sdk/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for n,p in files.items():archive.add(p,arcname=n,recursive=False)
 archive=out/'primary.tar.xz';write('bundle.json',{'kind':'native_probe_interruption_validation','root':root,'members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'acceptance_status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
