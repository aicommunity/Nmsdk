set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s09-native-live-training-worker-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-live-finalization-cancel-normal-a1/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s08-native-live-finalization-cancel-reader-normal-a1/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s09-native-live-training-worker-normal-a1/process-exit-status.txt")" = 1
test "$(cat "$base/readbacks/s09-native-live-training-worker-normal-a1/codec-process/result.json" | python3 -c 'import sys,json;print(json.load(sys.stdin)["returncode"])')" = 1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 200000000
test -z "$(git -C "$src" status --porcelain)"
export BASE="$base" SRC="$src" BUILD="$build" OUT="$out" RUNTIME="$runtime" PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY' > "$out/live-source-check.json"
from pathlib import Path
import json,os
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c gc.auto=0 -c fetch.recurseSubmodules=false fetch origin 9d8da9af3079a91f512d13f4dd005b96063dc3c8 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src";unset ASAN_OPTIONS;unset QT_QPA_PLATFORM
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
export TIMELEARNER_EXECUTION_OUTPUT="$out/codec-native"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/codec-runtime-before.json"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,time,unittest,xml.etree.ElementTree as ET
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
from Scripts.StructTrain.TimeLearner.tests.live_pipeline_corpus import run_corpus
out=Path(os.environ['OUT']);runtime=load(out/'codec-runtime-before.json');start=time.monotonic()
result=execute(runtime,['--gtest_filter=NativeLiveFinalizationPlanCodec.*','--gtest_output=xml:'+str(out/'codec-native.xml')],Path(runtime['executable']['path']).parent,out/'codec-process',180)
tree=ET.parse(out/'codec-native.xml').getroot()
assert result['execution']=='completed' and result['returncode']==0 and result['runtime_provenance']=='loaded_files_captured'
assert int(tree.attrib['tests'])==1 and not any(int(tree.attrib.get(k,0)) for k in ('failures','errors','disabled')) and not tree.findall('.//skipped')
codec=load(out/'codec-native/live-finalization-plan-codec.json');assert len(codec['plans'])==4 and codec['malformed_controls']==32
assert os.statvfs(out).f_bavail*os.statvfs(out).f_frsize>150000000
corpus=run_corpus(Path(os.environ['TIMELEARNER_POSTTUNE_FIXED_SOURCE']),out/'runtime-before.json',out/'corpus',1800)
os.environ['TIMELEARNER_LIVE_PIPELINE_CORPUS']=str(out/'corpus')
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_pipeline_worker'))
assert r.wasSuccessful() and r.testsRun==3 and not r.skipped
value={'kind':'native_live_training_worker_gate','schema_version':1,'operations':corpus['operations'],'codec_tests':1,'codec_malformed_controls':32,
 'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,
 'independent_partition_verified':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/codec-runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
cmp "$out/codec-runtime-before.json" "$out/codec-runtime-after.json"
