set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-console-negative-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-threshold-contract-asan-isolated-a1"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1 ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
python3 -u - <<'PY' > "$out/tests.log" 2>&1
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
from Scripts.StructTrain.TimeLearner.tests.test_native_fixed_posttune_worker import fixed_job,resign
base=Path(os.environ['BASE']);out=Path(os.environ['OUT'])
runtime=load(base/'readbacks/s08-native-posttune-fixed-console-asan-a1/runtime-before.json')
original=load(base/'readbacks/s08-native-posttune-fixed-asan-a1/baseline-source/Classic-auto_metric/input/job.json')
rows=[]
for name in ['unused-grid','outer-downgrade','unknown-finalization','empty-calibrate']:
 job=fixed_job(original)
 if name=='unused-grid':job['thresholds']=[1.]
 if name=='outer-downgrade':job['schema_version']=1
 if name=='unknown-finalization':job['post_tune']['finalization']='automatic'
 if name=='empty-calibrate':job['post_tune']['finalization']='calibrate'
 resign(job)
 p=out/(name+'.json');p.write_text(json.dumps(job,indent=2)+'\n')
 target=out/(name+'-native')
 process=execute(runtime,['--app-ini',runtime['app_ini']['path'],'--timelearner-posttune',str(p),'--timelearner-output',str(target)],
                 Path(runtime['executable']['path']).parent,out/(name+'-process'),120)
 assert process['returncode']==2 and not target.exists(),(name,process)
 rows.append({'case':name,'returncode':process['returncode'],'native_output_created':False})
 print(name,'rejected before native output',flush=True)
(out/'validation.json').write_text(json.dumps({'controls':rows,'scientific_verdict':None},indent=2)+'\n')
PY
