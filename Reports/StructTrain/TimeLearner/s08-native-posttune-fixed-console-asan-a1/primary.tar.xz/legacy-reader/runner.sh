set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-console-legacy-reader-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-threshold-contract-asan-isolated-a1"
test "$(git rev-parse HEAD)" = 2d6ab1a059005af30bc3d55a78c2192e6cbd9813
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$base/readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/runs"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_controller_worker -v > "$out/tests.log" 2>&1
