set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-console-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-posttune-fixed-console-asan-a1"
baseline="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-fixed-asan-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain)"
test ! -e "$runtime"
export SRC="$src" BUILD="$build"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
base=Path('/media/user/Data/TimeLearnerRefactor');active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(str(base)+'/runtime-') or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 2d6ab1a059005af30bc3d55a78c2192e6cbd9813 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
export OUT="$out" BASE="$base" TIMELEARNER_FIXED_POSTTUNE_SOURCE="$baseline"
unset QT_QPA_PLATFORM
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_fixed_posttune_worker.NativeFixedPostTunePreflightTest -v > "$out/preflight-tests.log" 2>&1
python3 -u - <<'PY' > "$out/console.log" 2>&1
import copy,hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_calibration_worker import run_job,audit_run_manifest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.tests.test_native_fixed_posttune_worker import fixed_job,resign
out=Path(os.environ['OUT']);baseline=Path(os.environ['TIMELEARNER_FIXED_POSTTUNE_SOURCE'])
old=Path(os.environ['BASE'])/'readbacks/s08-native-posttune-fixed-asan-a1/runs'
jobs=out/'jobs';jobs.mkdir();runs=out/'runs';runs.mkdir();records=[]
for case in ['Classic-auto_metric','Branch-synthetic']:
 original=load(baseline/case/'input/job.json')
 prior=load(baseline/case/'run-manifest.json')
 source=baseline/case/prior['source_package_path']
 for phase in ['legacy','v2_calibrate','fixed']:
  job=copy.deepcopy(original)
  if phase=='v2_calibrate':
   job['schema_version']=2;job['post_tune'].update(schema_version=2,finalization='calibrate');resign(job)
  if phase=='fixed':
   job=fixed_job(job)
   if case.startswith('Classic'):
    job['post_tune'].update(mode='keep_done',canonical_floor=0.,canonical_last=0.,resistance_bounds=[])
   job['specification']['attempt_id']+='/production-fixed';resign(job)
  name=case+'-'+phase;p=jobs/(name+'.json');p.write_text(json.dumps(job,indent=2,allow_nan=False)+'\n')
  print('BEGIN',name,flush=True)
  run_job(p,source,out/'runtime-before.json',runs/name,1200,post_tune=True)
  proof=audit_run_manifest(runs/name/'run-manifest.json',post_tune=True)
  assert proof['run_evidence_consistent']
  report=load(runs/name/'native/transaction.json')
  if phase=='fixed':
   assert report['status']=='weights_selected'
  else:
   for part in ['transaction.json','model.json']:
    assert (runs/name/'native'/part).read_bytes()==(old/case/'native'/part).read_bytes(),(name,part)
  records.append({'name':name,'phase':phase,'expected_status':report['status']})
  print('END',name,report['status'],flush=True)
(runs/'controls.json').write_text(json.dumps({'records':records},indent=2)+'\n')
PY
export TIMELEARNER_FIXED_POSTTUNE_RUNS="$out/runs"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_fixed_posttune_worker -v > "$out/worker-tests.log" 2>&1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
