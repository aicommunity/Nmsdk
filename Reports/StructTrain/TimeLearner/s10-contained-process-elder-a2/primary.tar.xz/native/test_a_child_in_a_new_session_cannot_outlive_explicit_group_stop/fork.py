import subprocess,time,json
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-4aso8si9/child.json').write_text(json.dumps({"pid":p.pid}))
time.sleep(20)
