from pathlib import Path
import sys,os,json,time,threading,hashlib,unittest,traceback,tarfile,io
base=Path('/media/user/Data/TimeLearnerRefactor')
source=base/'source-profile-probe-admission-a1'
framework=base/'source-worker-dependency-normal-a2'
study=base/'readbacks/s07-stock-fair-domains-normal-a2/study'
out=base/'readbacks/s07-profile-probe-admission-a2'
out.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path.insert(0,str(framework))
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'resource-reservations.sqlite3')
stop_event=threading.Event();errors=[];token=None;thread=None

def write(name,value):
 (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
try:
 reservation=registry.reserve('s07-profile-probe-admission-a2',[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,framework,study]],ttl_seconds=120)
 token=reservation['token'];write('reservation.json',reservation)
 def beat():
  while not stop_event.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=beat,daemon=True);thread.start()
 import subprocess
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='367b811974b325a076e48b7abbd3d39cd90fee6e'
 write('owned-process.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]})
 write('source-hashes.json',{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts').rglob('*.py')})
 # The framework ledger instance remains bound; tests use the exact candidate tree.
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_STOCK_WAVE_SOURCE']=str(study)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in ['test_single_pulse_job.SinglePulseJobTest','test_feedback_profile_job.FeedbackProfileJobTest'])
 assert suite.countTestCases()==9
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests_run':result.testsRun,'successful':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
 assert result.wasSuccessful() and result.testsRun==9 and not result.skipped and not errors
 write('terminal.json',{'admission_controls_passed':True,'native_compilation_verified':False,'waveform_equivalence_verified':False,'scientific_verdict':None})
except BaseException as e:
 write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
 write('terminal.json',{'admission_controls_passed':False,'native_compilation_verified':False,'scientific_verdict':None})
finally:
 stop_event.set()
 if thread:thread.join(timeout=30)
 payloads={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
 payloads['producer.py']=Path(__file__).read_bytes()
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w:xz') as archive:
  for name,raw in sorted(payloads.items()):
   entry=tarfile.TarInfo(name);entry.size=len(raw);archive.addfile(entry,io.BytesIO(raw))
 raw=buffer.getvalue();(out/'primary.tar.xz').write_bytes(raw)
 write('bundle.json',{'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payloads.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'root':'367b811974b325a076e48b7abbd3d39cd90fee6e'})
