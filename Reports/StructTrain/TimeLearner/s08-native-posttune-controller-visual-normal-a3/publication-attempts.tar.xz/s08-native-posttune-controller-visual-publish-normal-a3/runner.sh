set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-controller-visual-publish-normal-a3"
gate="$base/readbacks/s08-native-posttune-controller-report-normal-a3"
repo="$base/source-posttune-observation-report-normal-a1"
src="$base/source-native-posttune-controller-visual-publish-normal-a3"
branch=codex/timelearner-native-posttune-controller-visual-evidence-normal-a3
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$gate/process-exit-status.txt"; do sleep 10; done
test "$(cat "$gate/process-exit-status.txt")" = 0
test ! -e "$src"
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b884691c402a469aea948eb0237ec24715560184 > "$out/checkout.log" 2>&1
git -C "$repo" -c submodule.recurse=false worktree add -b "$branch" "$src" b884691c402a469aea948eb0237ec24715560184 >> "$out/checkout.log" 2>&1
cd "$src"
OUT="$out" GATE="$gate" python3 -u - <<'PY' > "$out/package.log" 2>&1
import hashlib,io,json,os,tarfile
from pathlib import Path
out=Path(os.environ['OUT']);gate=Path(os.environ['GATE']);base=gate.parent
dest=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3')
dest.mkdir(parents=True,exist_ok=False);selected=dest/'selected';selected.mkdir()
load=lambda p:json.loads(p.read_bytes())
encode=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
files={};cache=gate/'reports';parents=sorted(cache.glob('*/manifest.json'))
assert len(parents)==24
log=(gate/'evidence-reader.log').read_text();assert 'Ran 20 tests' in log and log.rstrip().endswith('OK')
log=(gate/'reader.log').read_text();assert 'Ran 9 tests' in log and log.rstrip().endswith('OK')
pairs=0;matrixCount=0;cacheFileCount=0
for path in parents:
 root=path.parent;m=load(path)
 assert m['kind']=='timelearner_posttune_transaction_visual_report' and m['visual_acceptance_complete'] is False
 sums=load(root/'SHA256SUMS.json')
 assert set(sums)|{'SHA256SUMS.json'}=={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file()}
 for n,h in sums.items():
  f=root/n;assert not f.is_symlink() and hashlib.sha256(f.read_bytes()).hexdigest()==h,(root,n)
 cacheFileCount+=len(sums)+1;pairs+=m['trial_soma_pairs'];matrixCount+=len(m['weight_matrices'])
 if m['calibration'] is not None:matrixCount+=load(root/'calibration/manifest.json')['completed_matrices']
 for f in sorted(root.rglob('*')):
  assert not f.is_symlink()
  if f.is_file() and 'primary' not in f.relative_to(root).parts and f.suffix in ('.json','.html'):
   files['reports/'+root.name+'/'+f.relative_to(root).as_posix()]=f.read_bytes()
 if not(root.name.endswith('_post_tune_keep') or root.name.endswith('_post_tune_synthetic')):continue
 top='branch' if root.name.startswith('Branch_') else 'classic'
 mode='keep' if root.name.endswith('_keep') else 'synthetic'
 def choose(folder,prefix,zoom=False):
  plot=load(folder/'manifest.json');count=0
  for figure in plot['figures']:
   if figure['descriptor']['index']!=0:continue
   label=figure['label'];assert label in {'target','foil'}
   view=next(v for v in figure['views'] if v['view']=='overview')
   target=selected/(prefix+'-'+label+'-overview.png')
   assert not target.exists();target.write_bytes((folder/view['files'][0]).read_bytes());count+=1
   if zoom and label=='target':
    view=next(v for v in figure['views'] if v['time_view']!='overview' and v['y_scale']=='shared')
    (selected/(prefix+'-'+label+'-zoom.png')).write_bytes((folder/view['files'][0]).read_bytes());count+=1
  return count
 assert choose(root/'weights-0000',top+'-'+mode+'-weights',True)==3
 if mode=='keep':assert choose(root/'calibration/fresh-confirmation',top+'-keep-confirmation')==2
assert len(list(selected.iterdir()))==16
for name in ['s08-native-posttune-controller-report-normal-a1','s08-native-posttune-controller-report-normal-a2','s08-native-posttune-controller-report-normal-a3']:
 p=base/name
 for f in sorted(p.iterdir()):
  if f.is_file() and f.suffix in ('.json','.log','.txt','.sh'):files[name+'/'+f.name]=f.read_bytes()
with tarfile.open(dest/'metadata.tar.xz','w:xz',preset=6) as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
manifest={'kind':'native_posttune_controller_visual_bundle','schema_version':1,
 'native_source_root':'44a1598af2cfdd2fa1703d5ea70f8f1e8beabc9b',
 'renderer_source_root':'e9f3cc85275bcdd9b1ab7a0ef4f355dd52d8cf2d',
 'primary_bundle_commit':'7ee932184d091bd068495f91be2464cdc0e6103f','full_cache':str(cache),
 'transaction_reports':24,'complete_matrices':matrixCount,'trial_soma_pairs':pairs,
 'cache_files_verified':cacheFileCount,'evidence_reader_checks':20,'report_and_plot_checks':9,
 'archive_sha256':hashlib.sha256((dest/'metadata.tar.xz').read_bytes()).hexdigest(),
 'files':[{'path':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in sorted(files.items())],
 'selected':[{'path':f.relative_to(dest).as_posix(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(selected.iterdir())],
 'selected_manual_review_complete':False,'all_visual_reports_accepted':False,'full_stage_8_accepted':False,'scientific_verdict':None}
(dest/'manifest.json').write_bytes(encode(manifest))
(dest/'README.md').write_text('# Measured PostTune controller: soma/input reports\n\n'
 'All 24 genuine Classic/Branch N1/2000 Hz parent transactions were audited and rendered on M40, '
 'including every complete weight-candidate matrix, actual threshold-grid matrix and fresh confirmation. '
 'All patterns and soma channels have full native samples, measured input overlays, 1920x960 overview and readable detail views. '
 'Incomplete probes are retained as primary data without inferred complete responses.\n\n'
 'Twenty independent evidence checks and nine report/plot checks passed. A1 renderer failed on empty calibration; '
 'A2 failed on an incorrect test-module name; both receipts are preserved. A3 is the accepted scoped render, '
 'not full visual/manual acceptance or independent classification.\n\n'
 'Primary bundle: 7ee932184d091bd068495f91be2464cdc0e6103f / '
 'Reports/StructTrain/TimeLearner/s08-native-posttune-controller-normal-a2.\n\n'
 'Full cache: '+str(cache)+'. metadata.tar.xz is a provenance snapshot, not a self-contained HTML report; '
 'rebuild full reports from the lossless primary bundle using renderer source e9f3cc852. '
 'Git stores only metadata and 16 selected PNG; manual review remains pending. No eight-pattern scientific claim is made.\n')
sums={f.relative_to(dest).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in dest.rglob('*') if f.is_file()}
(dest/'SHA256SUMS.json').write_bytes(encode(sums))
print(json.dumps({k:manifest[k] for k in ('transaction_reports','complete_matrices','trial_soma_pairs','cache_files_verified')}))
PY
artifact=Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3
git add -- "$artifact/README.md" "$artifact/manifest.json" "$artifact/metadata.tar.xz" "$artifact/SHA256SUMS.json"
git add -f -- "$artifact/selected"
python3 - <<'PY' > "$out/index-artifact-verification.json"
import hashlib,json,subprocess
from pathlib import Path
d=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3')
s=json.loads((d/'SHA256SUMS.json').read_bytes())
for name,h in s.items():
 b=subprocess.check_output(['git','show',':'+(d/name).as_posix()]);assert hashlib.sha256(b).hexdigest()==h,name
print(json.dumps({'verified_index_artifacts':len(s),'selected':16}))
PY
git diff --cached --check
git commit -m 'Preserve all measured PostTune visual cache metadata and selected native soma input plots' > "$out/commit.log"
git -c push.recurseSubmodules=no push -u origin "$branch" > "$out/push.log" 2>&1
head=$(git rev-parse HEAD)
test "$(git ls-remote origin "refs/heads/$branch" | cut -f1)" = "$head"
git rev-parse HEAD > "$out/commit.txt"

