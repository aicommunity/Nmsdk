set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-controller-visual-publish-recovery-normal-a4"
previous="$base/readbacks/s08-native-posttune-controller-visual-publish-normal-a3"
src="$base/source-native-posttune-controller-visual-publish-normal-a3"
branch=codex/timelearner-native-posttune-controller-visual-evidence-normal-a3
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$previous/process-exit-status.txt")" = 1
cd "$src"
test "$(git branch --show-current)" = "$branch"
test "$(git rev-parse HEAD)" = b884691c402a469aea948eb0237ec24715560184
python3 - <<'PY' > "$out/recovery.json"
import hashlib,json
from pathlib import Path
d=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3')
m=json.loads((d/'manifest.json').read_bytes());assert len(m['selected'])==16
for name,h in json.loads((d/'SHA256SUMS.json').read_bytes()).items():
 assert hashlib.sha256((d/name).read_bytes()).hexdigest()==h,name
record={'kind':'posttune_controller_visual_publication_recovery','schema_version':1,
 'reason':'sparse_checkout_requires_explicit_git_add_sparse','original_attempt_exit':1,
 'native_or_render_repeated':False,'selected_png':16,'committed_blob_verification_required':True}
(d/'publication-recovery.json').write_text(json.dumps(record,indent=2)+'\n')
sums={f.relative_to(d).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in d.rglob('*') if f.is_file() and f.name!='SHA256SUMS.json'}
(d/'SHA256SUMS.json').write_text(json.dumps(sums,indent=2)+'\n')
print(json.dumps(record))
PY
artifact=Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3
git add --sparse -- "$artifact/README.md" "$artifact/manifest.json" "$artifact/metadata.tar.xz" "$artifact/SHA256SUMS.json" "$artifact/publication-recovery.json"
git add -f --sparse -- "$artifact/selected"
python3 - <<'PY' > "$out/index-verification.json"
import hashlib,json,subprocess
from pathlib import Path
d=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3')
s=json.loads((d/'SHA256SUMS.json').read_bytes())
for name,h in s.items():
 assert hashlib.sha256(subprocess.check_output(['git','show',':'+(d/name).as_posix()])).hexdigest()==h,name
print(json.dumps({'index_artifacts_verified':len(s),'selected_png':16}))
PY
git diff --cached --check
git commit -m 'Publish measured PostTune full cache metadata and sixteen selected native soma input figures' > "$out/commit.log"
python3 - <<'PY' > "$out/commit-verification.json"
import hashlib,json,subprocess
from pathlib import Path
d=Path('Reports/StructTrain/TimeLearner/s08-native-posttune-controller-visual-normal-a3')
s=json.loads(subprocess.check_output(['git','show','HEAD:'+(d/'SHA256SUMS.json').as_posix()]))
for name,h in s.items():
 assert hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+(d/name).as_posix()])).hexdigest()==h,name
print(json.dumps({'committed_artifacts_verified':len(s)+1,'selected_png':16}))
PY
git -c push.recurseSubmodules=no push -u origin "$branch" > "$out/push.log" 2>&1
head=$(git rev-parse HEAD)
test "$(git ls-remote origin "refs/heads/$branch" | cut -f1)" = "$head"
git rev-parse HEAD > "$out/commit.txt"

