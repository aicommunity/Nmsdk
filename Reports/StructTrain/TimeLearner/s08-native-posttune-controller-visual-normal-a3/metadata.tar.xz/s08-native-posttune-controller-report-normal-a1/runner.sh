set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-controller-report-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1"
src="$base/source-native-posttune-controller-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test ! -e "$src"
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 030887fe7f74b9c621d96a25c84d96b80ff506c1 > "$out/checkout.log" 2>&1
git -C "$repo" -c submodule.recurse=false worktree add --detach "$src" 030887fe7f74b9c621d96a25c84d96b80ff506c1 >> "$out/checkout.log" 2>&1
cd "$src"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 -u - <<'PY' > "$out/extract.log" 2>&1
import hashlib,json,os,subprocess,tarfile,io
from pathlib import Path,PurePosixPath
p=Path(os.environ['OUT']);d='Reports/StructTrain/TimeLearner/s08-native-posttune-controller-normal-a2/'
read=lambda n:subprocess.check_output(['git','show','HEAD:'+d+n])
m=json.loads(read('manifest.json'));raw=read('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
expected={r['path']:r for r in m['files']};seen=set()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r|xz') as tar:
 for v in tar:
  assert v.name in expected and v.name not in seen
  path=PurePosixPath(v.name);assert v.isfile() and not path.is_absolute() and '..' not in path.parts
  data=tar.extractfile(v).read();r=expected[v.name]
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  target=p/'data'/v.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);seen.add(v.name)
assert seen==set(expected) and len(seen)==907
(p/'git-primary-manifest.json').write_bytes(read('manifest.json'))
print('verified',len(seen))
PY
export TIMELEARNER_POSTTUNE_TRANSACTION_DIR="$out/data/controller-fixed-a2/native"
export TIMELEARNER_POSTTUNE_REPORT_DIR="$out/reports"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.__main__ import main
from Scripts.StructTrain.TimeLearner.posttune_transaction_reports import render_posttune_transaction
p=Path(os.environ['OUT']);root=Path(os.environ['TIMELEARNER_POSTTUNE_TRANSACTION_DIR'])
reports=p/'reports';reports.mkdir()
sources={load(v)['sha256']:v for v in root.glob('*_learned_state.json')};assert len(sources)==2
records=[(v,load(v)) for v in sorted(root.glob('*_post_tune_*.json')) if load(v).get('kind')=='native_post_tune_transaction']
assert len(records)==24
rows=[]
for index,(path,record) in enumerate(records):
 source=sources[record['source_recognition']['source_solo']['sha256']]
 target=reports/path.stem
 print('BEGIN',index,path.name,flush=True)
 if index==0:
  assert main(['report',str(path),'--format','posttune-transaction','--source-solo',str(source),'--output',str(target)])==0
 else:
  render_posttune_transaction(path,source,target)
 m=load(target/'manifest.json')
 rows.append({'path':target.name,'status':record['status'],'mode':record['mode'],'metric':record['metric'],
  'source_transaction_sha256':record['sha256'],'weight_matrices':len(m['weight_matrices']),
  'trial_soma_pairs':m['trial_soma_pairs'],'manifest_sha256':hashlib.sha256((target/'manifest.json').read_bytes()).hexdigest()})
 print('DONE',index,rows[-1],flush=True)
(p/'validation.json').write_text(json.dumps({'source_root':'030887fe7f74b9c621d96a25c84d96b80ff506c1',
 'native_source_root':'44a1598af2cfdd2fa1703d5ea70f8f1e8beabc9b','primary_bundle_members':907,
 'transaction_reports':len(rows),'rows':rows,'visual_acceptance_complete':False,'scientific_verdict':None},indent=2)+'\n')
PY
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_reports Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1

