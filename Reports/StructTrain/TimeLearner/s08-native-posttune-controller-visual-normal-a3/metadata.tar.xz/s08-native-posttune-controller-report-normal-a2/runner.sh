set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-controller-report-normal-a2"
repo="$base/source-posttune-observation-report-normal-a1"
src="$base/source-native-posttune-controller-report-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test ! -e "$src"
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git e9f3cc85275bcdd9b1ab7a0ef4f355dd52d8cf2d > "$out/checkout.log" 2>&1
git -C "$repo" -c submodule.recurse=false worktree add --detach "$src" e9f3cc85275bcdd9b1ab7a0ef4f355dd52d8cf2d >> "$out/checkout.log" 2>&1
cd "$src"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 -u - <<'PY' > "$out/extract.log" 2>&1
import hashlib,json,os
from pathlib import Path
p=Path(os.environ['OUT']);old=p.parent/'s08-native-posttune-controller-report-normal-a1'
assert (old/'process-exit-status.txt').read_text().strip()=='1'
m=json.loads((old/'git-primary-manifest.json').read_bytes())
assert len(m['files'])==907
for r in m['files']:
 f=old/'data'/r['path'];assert f.stat().st_size==r['bytes']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==r['sha256'],r['path']
(p/'primary-source.json').write_text(json.dumps({'source_directory':str(old/'data'),
 'manifest_sha256':hashlib.sha256((old/'git-primary-manifest.json').read_bytes()).hexdigest(),
 'members_verified':907,'native_repeated':False},indent=2)+'\n')
print('verified',len(m['files']))
PY
export TIMELEARNER_POSTTUNE_TRANSACTION_DIR="$base/readbacks/s08-native-posttune-controller-report-normal-a1/data/controller-fixed-a2/native"
export TIMELEARNER_POSTTUNE_REPORT_DIR="$out/reports"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_evidence Scripts.StructTrain.TimeLearner.tests.test_posttune_candidate_evidence -v > "$out/evidence-reader.log" 2>&1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.__main__ import main
from Scripts.StructTrain.TimeLearner.posttune_transaction_reports import render_posttune_transaction
p=Path(os.environ['OUT']);root=Path(os.environ['TIMELEARNER_POSTTUNE_TRANSACTION_DIR'])
reports=p/'reports';reports.mkdir()
sources={load(v)['sha256']:v for v in root.glob('*_learned_state.json')};assert len(sources)==2
records=[(v,load(v)) for v in sorted(root.glob('*_post_tune_*.json')) if load(v).get('kind')=='native_post_tune_transaction']
assert len(records)==24
rows=[]
for index,(path,record) in enumerate(records):
 source=sources[record['source_recognition']['source_solo']['sha256']]
 target=reports/path.stem
 print('BEGIN',index,path.name,flush=True)
 if index==0:
  assert main(['report',str(path),'--format','posttune-transaction','--source-solo',str(source),'--output',str(target)])==0
 else:
  render_posttune_transaction(path,source,target)
 m=load(target/'manifest.json')
 rows.append({'path':target.name,'status':record['status'],'mode':record['mode'],'metric':record['metric'],
  'source_transaction_sha256':record['sha256'],'weight_matrices':len(m['weight_matrices']),
  'trial_soma_pairs':m['trial_soma_pairs'],'manifest_sha256':hashlib.sha256((target/'manifest.json').read_bytes()).hexdigest()})
 print('DONE',index,rows[-1],flush=True)
(p/'validation.json').write_text(json.dumps({'source_root':'e9f3cc85275bcdd9b1ab7a0ef4f355dd52d8cf2d',
 'native_source_root':'44a1598af2cfdd2fa1703d5ea70f8f1e8beabc9b','primary_bundle_members':907,
 'transaction_reports':len(rows),'rows':rows,'visual_acceptance_complete':False,'scientific_verdict':None},indent=2)+'\n')
PY
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_transaction_reports Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1

