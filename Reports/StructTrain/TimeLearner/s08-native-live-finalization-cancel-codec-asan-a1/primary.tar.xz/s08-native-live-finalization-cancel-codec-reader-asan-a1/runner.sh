set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-live-finalization-cancel-codec-reader-asan-a1"
producer="$base/readbacks/s08-native-live-finalization-cancel-codec-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$producer/process-exit-status.txt";do kill -0 69156;sleep 10;done
test "$(cat "$producer/process-exit-status.txt")" = 0
cd "$base/source-live-finalization-cancel-codec-reader-asan-a1"
export OUT="$out" PRODUCER="$producer" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_LIVE_CANCEL_NATIVE="$producer/native"
export TIMELEARNER_LIVE_FINALIZATION_NATIVE="$base/readbacks/s08-native-live-finalization-asan-a2/native"
export TIMELEARNER_NATIVE_GATE_ROOT="$producer"
export TIMELEARNER_NATIVE_GATE_AFTER="$producer/runtime-after.json"
export TIMELEARNER_NATIVE_GATE_SPEC="$PWD/Scripts/StructTrain/TimeLearner/Specifications/native-live-finalization-cancel-codec.json"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,unittest,hashlib
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.native_execution_gate import read_native_gate,audit_native_gate
start=time.monotonic();producer=Path(os.environ['PRODUCER']);out=Path(os.environ['OUT'])
def snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((producer/'native').iterdir()) if p.is_file()}
before=snapshot()
spec=load(Path(os.environ['TIMELEARNER_NATIVE_GATE_SPEC']))
native=audit_native_gate(spec,read_native_gate(spec,producer,producer/'runtime-after.json'))
rows=[]
for name,count in (('test_native_execution_gate',2),('test_live_finalization_evidence',6)):
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name))
 row={'module':name,'tests':r.testsRun,'planned':count,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped)}
 rows.append(row)
 (out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.wasSuccessful() and r.testsRun==count and not r.skipped,row
codec=load(producer/'native/live-finalization-plan-codec.json')
assert codec['kind']=='native_live_finalization_plan_codec_control' and len(codec['plans'])==4 and codec['malformed_controls']==32
from Scripts.StructTrain.TimeLearner.live_training_worker import validate_live_plan
fixtures=Path('/media/user/Data/TimeLearnerRefactor/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source')
for i,plan in enumerate(codec['plans']):
 job=load(fixtures/('Classic-auto_metric' if i<2 else 'Branch-synthetic')/'input/job.json')
 validate_live_plan(plan,job['source_recognition']['source_solo']['configuration'],job['implementation_id'])
assert snapshot()==before
value={'kind':'live_finalization_cancel_codec_reader_gate','schema_version':1,'tests':sum(r['tests'] for r in rows),'modules':rows,'native_gate':native,
 'source_native_root':'dcc64fff651e29569e03312f1f8acad0179d9c00','source_pulse':'019e5d17aa1d2dcc551dc71a32a85c383953c71a',
 'source_reader_root':'dbc3aec3424c97efad0798fb1a130e6767eb9eca','seconds':time.monotonic()-start,'source_files_unchanged':len(before),'actual_codec_plans_checked':4,'native_codec_malformed_controls':32,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value),flush=True)
PY
