from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,io,threading,traceback,unittest,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');label='pipeline-containment-policy-a1';out=base/('readbacks/s10-'+label);out.mkdir(exist_ok=False);source=base/'source-pipeline-containment-a1';repo=base/'source-inventory-snapshots-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='1fd77d34feeabfb6026d4d8db880823bb03e90e7'
stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False

def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def git(*args):return subprocess.check_output(['git','-c','remote.origin.url=https://github.com/aicommunity/Nmsdk.git','-C',str(repo),*args])
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(base/('readbacks/s10-'+label+'-container'))});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;assert memory>=33*1024**3 and shutil.disk_usage(base).free>=4*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'worker_memory_max_bytes':512*1024**2,'worker_tasks_max':64,'native_models_executed':0})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3');reservation=registry.reserve('s10-'+label,[{'path':str(p),'access':'write'} for p in [out,repo]]+[{'path':str(p),'access':'read'} for p in [source,bootstrap]],ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as error:errors.append(str(error));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root and not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 references=[('elder','df72d059f9540c6237f5cf680d2748bba228eb42'),('m40','dbbacf0c1be37c67479d9da5288c111e9209c870')]
 with (out/'fetch.log').open('wb') as log:subprocess.run(['git','-c','remote.origin.url=https://github.com/aicommunity/Nmsdk.git','-C',str(repo),'fetch','--no-recurse-submodules','--depth','1','--filter=blob:none','origin',*[ref for _,ref in references]],stdout=log,stderr=subprocess.STDOUT,check=True)
 fixtures=[];receipts=[]
 for name,ref in references:
  prefix='Reports/StructTrain/TimeLearner/s10-contained-runner-'+name+'-a5/';b=json.loads(git('show',ref+':'+prefix+'bundle.json'));raw=git('show',ref+':'+prefix+'primary.tar.xz');assert len(raw)==b.get('archive_bytes',len(raw)) and hashlib.sha256(raw).hexdigest()==b['archive_sha256'];seen=set();count=0;directory=out/'fixtures'/name/'process'
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r|xz') as archive:
   for e in archive:
    assert e.isfile() and e.name not in seen and not e.name.startswith('/') and '..' not in e.name.split('/');seen.add(e.name);v=archive.extractfile(e).read();assert {'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}==b['members'][e.name]
    if e.name.startswith('native-result/process/'):
     p=directory/e.name[len('native-result/process/'):];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v);count+=1
  assert seen==set(b['members']) and count>10;fixtures.append(str(directory));receipts.append({'worker':name,'proof_commit':ref,'archive_sha256':b['archive_sha256'],'archive_members_verified':len(seen),'native_process_files_reused':count,'source_kind':'Actual previously accepted C++ codec/storage execution; no new native process or model run'})
 write('fixture-inventory.json',fixtures);write('fixture-provenance.json',receipts)
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source);os.environ['TIMELEARNER_CONTAINED_POLICY_FIXTURES']=str(out/'fixture-inventory.json')
 module='Scripts.StructTrain.TimeLearner.tests.test_native_process_policy';suite=unittest.defaultTestLoader.loadTestsFromName(module)
 def ids(suite):
  for x in suite:
   if isinstance(x,unittest.TestSuite):yield from ids(x)
   else:yield x.id()
 names=list(ids(suite));assert len(names)==len(set(names))==15;write('test-inventory.json',names)
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':15});assert result.testsRun==15 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'native_models_executed':0,'production_worker_runtime_acceptance_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
  hashes={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts};write('source-hashes.json',hashes)
  files={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():entry=tarfile.TarInfo(name);entry.size=len(v);archive.addfile(entry,io.BytesIO(v))
  raw=(out/'primary.tar.xz').read_bytes();write('bundle.json',{'kind':'pipeline_containment_policy_portable_tests','source_commit':root,'returncode':0 if passed else 1,'members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in files.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'native_models_executed':0,'production_worker_runtime_acceptance_pending':True,'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
