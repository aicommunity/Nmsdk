set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-posttune-probe-validation-normal-a1"
repo="$base/source-rdk-bool-evidence-normal-a2";work="$base/source-probe-threshold-validation-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-probe-console-normal-a1/process-exit-status.txt")" = 1
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 7ca4c78f68392a2218767522949b042e185b3fb9 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone;git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work";export PYTHONDONTWRITEBYTECODE=1;unset ASAN_OPTIONS
git rev-parse HEAD > "$out/auditor-source-root.txt"
sha256sum Scripts/StructTrain/TimeLearner/posttune_probe_threshold_controls.py > "$out/auditor-code.sha256"
python3 -u -m Scripts.StructTrain.TimeLearner.posttune_probe_threshold_controls \
 "$base/readbacks/s08-native-posttune-probe-console-normal-a1/runs" \
 "$base/readbacks/s08-native-posttune-fixed-console-normal-a1/runs" \
 "$base/readbacks/s08-native-posttune-probe-console-normal-a1/console-runtime-before.json" \
 "$out/controls" > "$out/validation.log" 2>&1
