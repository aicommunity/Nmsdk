set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s02-static-cache-prune-elder-20261031-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
export BASE="$base" OUT="$out"
python3 -u - <<'PY' > "$out/receipt.log" 2>&1
from pathlib import Path
import hashlib,json,os
base=Path(os.environ['BASE']).resolve(strict=True);out=Path(os.environ['OUT'])
assert str(base)=='/home/user/timelearner-refactor'
keep='runtime-s08-native-posttune-probe-threshold-normal-a1'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def active():
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
  except (OSError,RuntimeError):continue
  if str(exe).startswith(str(base)+'/runtime-') or (str(cwd).startswith(str(base)) and exe.name in {'cmake','make','gmake','ninja','cc1plus','g++','c++','ar','ld','collect2'}):
   result.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
 return result
assert not active()
free=lambda:os.statvfs(base).f_bavail*os.statvfs(base).f_frsize
before=free();rows=[];cache={};executables={}
for p in sorted(base.glob('runtime-*/Lib.CMake/lib*.a')):
 if keep in p.parts:continue
 assert p.resolve(strict=True)==p and p.is_relative_to(base) and not p.is_symlink() and p.is_file()
 with p.open('rb') as f:assert f.read(8)==b'!<arch>\n'
 stat=p.stat();key=(stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)
 if key not in cache:cache[key]=sha(p)
 rows.append({'path':str(p),'bytes':stat.st_size,'sha256':cache[key],'device':stat.st_dev,'inode':stat.st_ino,'mtime_ns':stat.st_mtime_ns})
 for name in ['NeuroModelerConsole','Test_PulseLib_StorageComponents']:
  binary=p.parent.parent/name
  if binary.is_file() and str(binary) not in executables:executables[str(binary)]=sha(binary)
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
write(out/'planned-removal.json',{'cache_class':'rebuildable_CMake_static_link_archives','retained_runtime':keep,'files':rows,'executables':executables})
assert not active()
for r in rows:
 p=Path(r['path']);assert p.resolve(strict=True)==p and p.is_relative_to(base)
 assert p.parent.name=='Lib.CMake' and p.name.startswith('lib') and p.suffix=='.a'
 stat=p.stat();assert (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)==(r['device'],r['inode'],r['bytes'],r['mtime_ns'])
 p.unlink()
for p,digest in executables.items():assert sha(Path(p))==digest
report={'kind':'rebuildable_static_archive_cache_cleanup','schema_version':1,'base':str(base),'removed_paths':len(rows),
 'sum_removed_logical_bytes':sum(r['bytes'] for r in rows),'free_bytes_before':before,'free_bytes_after':free(),
 'executables_unchanged':len(executables),'scientific_primary_removed':False,'executable_removed':False,
 'retained_runtime':keep,'duplicate_content_claimed':False,'active_owned_jobs_before':[],'scientific_verdict':None}
write(out/'receipt.json',report);print(json.dumps(report))
PY
