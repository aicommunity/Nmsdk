set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-phase-lifecycle-interrupt-normal-a1"
src="$base/source-order-fixed-a1";build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s08-native-phase-lifecycle-interrupt-normal-a1"
baseline="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-fixed-console-normal-a1/process-exit-status.txt")" = 0
test ! -e "$runtime"
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1500000000
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git ba33ee20e14f6716dac289ed698790c374e0bfea > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$baseline" TIMELEARNER_POSTTUNE_CONFIG_SOURCE="$baseline"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='NativePhaseLifecycle.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/regression" ./Test_PulseLib_StorageComponents --gtest_filter='NativeFixedPostTune.*:NativePostTuneConfiguration.*' --gtest_output="xml:$out/regression.xml") > "$out/regression.log" 2>&1
python3 - <<'PY' > "$out/native-validation.json"
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
out=Path(os.environ['OUT']);rows=[]
for name,expected in [('native',16),('regression',12)]:
 x=ET.parse(out/(name+'.xml')).getroot()
 assert int(x.attrib['tests'])==expected and not x.findall('.//skipped')
 assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled'])
 rows.append({'suite':name,'tests':expected,'seconds':float(x.attrib['time'])})
print(json.dumps({'suites':rows}))
PY
export TIMELEARNER_PHASE_LIFECYCLE_ARTIFACTS="$out/native"
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$out/regression"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$baseline"
python3 -m unittest Scripts.StructTrain.TimeLearner.tests.test_phase_lifecycle_evidence Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence -v > "$out/reader.log" 2>&1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
