set -euo pipefail
reader="/home/user/timelearner-refactor/source-threshold-proposal-links-a1"
out="/home/user/timelearner-refactor/readbacks/s08-threshold-proposal-links-normal-a1"
native="/home/user/timelearner-refactor/readbacks/s08-threshold-potential-normal-a3"
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$native/potential-20k-exit-status.txt"; do
 kill -0 1022716 2>/dev/null || exit 1
 sleep 15
done
test "$(cat "$native/potential-2k-exit-status.txt")" = 0
test "$(cat "$native/potential-20k-exit-status.txt")" = 0
cd "$reader"
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_THRESHOLD_POTENTIAL_DIR="$native/native"
export AUDIT_OUTPUT="$out"
python3 - <<'PY' > "$out/tests.log" 2>&1
import json,os,sys,unittest
from pathlib import Path
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_threshold_proposal_evidence')
assert suite.countTestCases()==8,suite.countTestCases()
result=unittest.TextTestRunner(verbosity=2).run(suite)
record={'reader_revision':'6b03832182e281d6d1c7534a84ba7b300035ec75','scope':'all four completed potential cases only; remaining legacy native phases are separate','tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'scientific_verdict':None}
Path(os.environ['AUDIT_OUTPUT'],'validation.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() and result.testsRun==8 and not result.skipped else 1)
PY
