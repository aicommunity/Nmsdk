import pathlib,time,subprocess,json,os,sys,hashlib
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');repo=base/'source-august-csv-adapter-m40-a1'
data=base/'readbacks/s04-loaded-readout-fixed-asan-a4';out=base/'readbacks/s04-loaded-readout-reader-asan-a1'
start=time.monotonic()
while True:
 p=pathlib.Path('/proc/739700/stat')
 if not p.exists() or p.read_text().rsplit(') ',1)[1].split()[19]!='261493480':break
 assert time.monotonic()-start<4000,'native_regression_wait_timeout'
 time.sleep(5)
assert not (data/'exception.json').exists(),(data/'exception.json').read_text()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TL_LOADED_READOUT_SOURCE=str(data))
with (out/'reader.log').open('wb') as f:
 r=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_loaded_readout_reports'],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0,'reader_tests_failed'
sys.path.insert(0,str(repo))
from Scripts.StructTrain.TimeLearner.loaded_readout_reports import audit_run
parsed,summary=audit_run(data)
assert len(parsed)==32 and summary['case_soma_pairs']==68
result={'status':0,'tests':16,'cases':32,'case_soma_pairs':68,'reader_source':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'native_source':'e1b7624749d370631b8f44552e6b99a679a2d2e5','scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'full-audit.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps(result),flush=True)
