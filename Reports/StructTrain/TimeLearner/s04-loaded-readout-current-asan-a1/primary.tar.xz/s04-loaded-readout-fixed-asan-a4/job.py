transport_ancestors={'739696': '261493449', '739641': '261493374', '925914': '119626011'}
import pathlib,subprocess,json,os,time,sys,traceback,xml.etree.ElementTree as ET
base=pathlib.Path("/media/user/Data/TimeLearnerRefactor");worker="asan"
source=base/"source-n1-measured-refinement-asan-a1";build=base/"build-n1-measured-refinement-asan-a1";out=base/('readbacks/s04-loaded-readout-fixed-'+worker+'-a4')
runtime=base/('runtime-s04-loaded-readout-fixed-'+worker+'-a4')
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def run(args,name,timeout=300):
 with (out/name).open('wb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
try:
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert pathlib.Path(git(source,'rev-parse','--show-toplevel')).resolve()==source.resolve()
 assert not git(source,'status','--porcelain','--untracked-files=no')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','e1b7624749d370631b8f44552e6b99a679a2d2e5'],'fetch-root.log')
 root=git(source,'rev-parse','FETCH_HEAD');assert root=='e1b7624749d370631b8f44552e6b99a679a2d2e5'
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 for child,url in [('Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib'),('Bin','Nmsdk-Bin'),('Rdk','Rdk')]:
  repo=source/child;assert not git(repo,'status','--porcelain','--untracked-files=no')
  wanted=git(source,'rev-parse','HEAD:'+child)
  run(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+url+'.git',('codex/timelearner-loaded-readout' if child=='Libraries/Nmsdk-PulseLib' else 'codex/timelearner-matrix-resize' if child=='Rdk' else 'develop')],'fetch-'+url+'.log')
  run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+url+'.log')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 assert not runtime.exists()
 run(['cmake','-S',source,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 run(['cmake','--build',build,'--target','Test_MDMatrixResize','--parallel','2'],'math-build.log',7200)
 math_runtime=snapshot(source,runtime/'Test_MDMatrixResize',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('math-runtime.json',math_runtime)
 math_result=execute(math_runtime,['--gtest_output=xml:'+str(out/'math-gtest.xml')],runtime,out/'math-process',120)
 math_data=ET.parse(out/'math-gtest.xml').getroot().attrib if (out/'math-gtest.xml').exists() else None
 write('math-validation.json',{'execution':math_result,'gtest':math_data,'source':root,'rdk':closure['Rdk']['head'],'scientific_verdict':None})
 assert math_result['execution']=='completed' and math_data and math_data['tests']=='10' and math_data['failures']==math_data['errors']=='0','matrix_gate_failed'
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','--parallel','2'] ,'build.log',7200)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 os.environ['TL_LOADED_READOUT_DIR']=str(out/'artifacts')
 manifest=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 result=execute(manifest,['--gtest_filter=NativeStorage/LoadedLearnerReadout.*','--gtest_output=xml:'+str(out/'gtest.xml')],runtime,out/'process',1800)
 data=ET.parse(out/'gtest.xml').getroot().attrib if (out/'gtest.xml').exists() else None
 write('validation.json',{'worker':worker,'phase':'fixed_native_load','source':root,'pulse':closure['Libraries/Nmsdk-PulseLib']['head'],'rdk':closure['Rdk']['head'],'execution':result,'gtest':data,'scientific_verdict':None})
 print(json.dumps(data),flush=True)
 if data and data['failures']=='0' and data['errors']=='0':
  os.environ['TIMELEARNER_EXECUTION_OUTPUT']=str(out/'native-regression')
  os.environ['TIMELEARNER_ROUNDTRIP_TEST_DIR']=str(out/'roundtrip-regression')
  reg=execute(manifest,['--gtest_filter=RdkLifecycleBoolean.*:TimeLearnerNativeLifecycle.*:TimeLearnerNativeRoundtrip.*:TopologiesAndRates/NativeLearnerExecution.*','--gtest_output=xml:'+str(out/'regression-gtest.xml')],runtime,out/'regression-process',(3600 if worker=='asan' else 1200))
  tree=ET.parse(out/'regression-gtest.xml').getroot() if (out/'regression-gtest.xml').exists() else None
  write('regression-validation.json',{'execution':reg,'gtest':tree.attrib if tree is not None else None,'skipped':len(tree.findall('.//testcase/skipped')) if tree is not None else None,'scientific_verdict':None})

 assert source_closure(source)==closure
 verify_runtime(manifest)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
