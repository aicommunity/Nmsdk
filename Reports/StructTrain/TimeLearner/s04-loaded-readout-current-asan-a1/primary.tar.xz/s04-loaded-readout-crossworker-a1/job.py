import pathlib,subprocess,json,hashlib,tarfile,io,csv,math
b=pathlib.Path('/media/user/Data/TimeLearnerRefactor');repo=b/'source-august-csv-adapter-m40-a1'
proof='c794e3cbf11c920d8fae5bb86dddd6f91bbceb17';report='Reports/StructTrain/TimeLearner/s04-loaded-readout-current-normal-a1'
subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',proof],check=True,capture_output=True)
def read(n):return subprocess.check_output(['git','-C',str(repo),'show',proof+':'+report+'/'+n])
checks=json.loads(read('SHA256SUMS.json'));raw=read('primary.tar.xz');manifest=read('manifest.json')
assert hashlib.sha256(raw).hexdigest()==checks['primary.tar.xz'] and hashlib.sha256(manifest).hexdigest()==checks['manifest.json']
m=json.loads(manifest);records={r['path']:r for r in m['records']};comparisons=[]
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for name,r in records.items():
  if not name.endswith('/roundtrip.csv'):continue
  normal=t.extractfile(name).read();assert hashlib.sha256(normal).hexdigest()==r['sha256']
  suffix=name.split('/artifacts/',1)[1];asan=(b/'readbacks/s04-loaded-readout-fixed-asan-a4/artifacts'/suffix).read_bytes()
  n=list(csv.reader(io.StringIO(normal.decode())));a=list(csv.reader(io.StringIO(asan.decode())))
  assert n[0]==a[0] and len(n)==len(a)
  diff=0.
  for nr,ar in zip(n[1:],a[1:]):
   assert len(nr)==len(ar)
   for nv,av in zip(nr,ar):
    x,y=float(nv),float(av);assert math.isfinite(x) and math.isfinite(y)
    diff=max(diff,abs(x-y))
  comparisons.append({'case':suffix.split('/')[0],'normal_sha256':r['sha256'],'asan_sha256':hashlib.sha256(asan).hexdigest(),'byte_equal':normal==asan,'maximum_absolute_numeric_difference':diff,'rows':len(n)-1})
assert len(comparisons)==32 and all(r['maximum_absolute_numeric_difference']<=1e-12 for r in comparisons)
out=b/'readbacks/s04-loaded-readout-crossworker-a1';out.mkdir(exist_ok=False)
result={'kind':'native_loaded_readout_crossworker_comparison','schema_version':1,'normal_primary':proof,'source_root':'e1b7624749d370631b8f44552e6b99a679a2d2e5','normal_archive_sha256':checks['primary.tar.xz'],'cases':comparisons,'all_csv_byte_equal':all(r['byte_equal'] for r in comparisons),'scope':'Completed native32 matrix only. ASan regression and whole-run acceptance remain separately required. No independent stochastic replicate or selectivity verdict.','scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':len(comparisons),'all_csv_byte_equal':result['all_csv_byte_equal'],'max_difference':max(r['maximum_absolute_numeric_difference'] for r in comparisons)}))
