set -euo pipefail
src=/home/user/timelearner-refactor/source-order-fixed-a1
build=/home/user/timelearner-refactor/build-order-fixed-normal-a1
out=/home/user/timelearner-refactor/readbacks/s05-repeat-boundary-normal-a3
runtime=/home/user/timelearner-refactor/runtime-s05-repeat-boundary-normal-a3
data=/home/user/timelearner-refactor
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
test -f "$data/readbacks/s05-repeat-boundary-normal-a1/process-exit-status.txt"
BASELINE="$data/readbacks/s05-repeat-boundary-normal-a1" PYTHONPATH="$src" python3 - <<'PY'
import os,json,xml.etree.ElementTree as E
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
root=Path(os.environ["BASELINE"]);tree=E.parse(root/"native.xml").getroot()
cases=list(tree.iter("testcase"));assert len(cases)==10
for case in cases:
    failures=case.findall("failure")
    assert len(failures)==2,(case.attrib,failures)
    assert {f.attrib["message"].splitlines()[0].rsplit(":",1)[-1] for f in failures}=={"1609","1610"}
manifest=json.loads((root/"runtime-before.json").read_text())
(root/"runtime-after-readback.json").write_text(json.dumps({"runtime_verified_after_terminal":True,"executable":str(verify_runtime(manifest))},indent=2)+"\n")
PY
test -z "$(git -C "$src" status --porcelain)"
git -C "$src" -c fetch.recurseSubmodules=false fetch origin codex/timelearner-repeat-boundary > "$out/checkout.log" 2>&1
git -C "$src" checkout --detach 02cf1542de6edfd67aa9da15798d34dd1b0eb08f >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 2 > "$out/build.log" 2>&1
export QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0 PYTHONDONTWRITEBYTECODE=1
mkdir -p "$out/native"
cd "$src"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
cd "$runtime"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
set +e
./Test_PulseLib_StorageComponents --gtest_filter='BoundedTraining*:ConfiguredNativeTraining*:NativeLearnedState.*N0Repeated*:NativeStoppedState.*N0Repeated*:NativeLearnedState.ClassicN0:NativeLearnedState.BranchN0:NativeLearnedState.ClassicN1:NativeLearnedState.BranchN1:NativeStoppedState.ClassicN0BudgetSearch:NativeStoppedState.BranchN0BudgetSearch' --gtest_output="xml:$out/native.xml" > "$out/native.log" 2>&1
status=$?
set -e
printf '%s\n' "$status" > "$out/native-exit-status.txt"
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
record=json.loads(Path(os.environ["RUNTIME_MANIFEST"]).read_text())
print(json.dumps({"verified":True,"executable":str(verify_runtime(record)),"runtime_fingerprint":record["runtime_fingerprint"]},indent=2))
PY
test "$status" = 0
export TIMELEARNER_REPEAT_BOUNDARY_DIR="$out/native"
export TIMELEARNER_LEARNED_EVIDENCE_DIR="$out/native"
export TIMELEARNER_STOPPED_EVIDENCE_DIR="/home/user/timelearner-refactor/readbacks/s05-stopped-normal-a2/native"
export TIMELEARNER_N0_REPEATS_DIR="$data/readbacks/s07-n0-repeats-normal-a2/native"
export TIMELEARNER_FULL_PROBE_REPORT_DIR="$data/readbacks/s09-n0-full-probe-reports-a1"
export TIMELEARNER_DOMAIN_EVIDENCE_DIR="/home/user/timelearner-refactor/readbacks/s07-domain-physics-normal-a1/native"
export TIMELEARNER_PROBE_PLOT_DIR="$out/figures"
OUTPUT_DIR="$out" "python3" -u - <<'PY' > "$out/python.log" 2>&1
import os,json,unittest,hashlib,xml.etree.ElementTree as E
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import audit_probe,audit_training_summary,load
out=Path(os.environ["OUTPUT_DIR"]);native=out/"native"
xml=E.parse(out/"native.xml").getroot()
assert int(xml.attrib["tests"])==51,xml.attrib
assert int(xml.attrib["failures"])==int(xml.attrib.get("errors","0"))==int(xml.attrib.get("disabled","0"))==0,xml.attrib
stopped=Path(os.environ["TIMELEARNER_STOPPED_EVIDENCE_DIR"])
assert len(list(stopped.glob("*_stopped_state.json")))==20
checks=[];total=0
for path in sorted(list(native.glob("*_training_summary.json"))+list(native.glob("*_xml_summary.json"))):
    summary=load(path);prefix=path.name.removesuffix("_training_summary.json").removesuffix("_xml_summary.json")
    packets={}
    marker="_xmlprobe_" if path.name.endswith("_xml_summary.json") else "_service_"
    for primary in sorted(native.glob(prefix+marker+"*.json")):
        packet=load(primary);audit_probe(packet,primary.with_suffix(".csv"))
        trial=packet["requested_specification"]["trial_id"];assert trial not in packets
        packets[trial]=packet
    check=audit_training_summary(summary,packets,"pulse0")
    checks.append({"source":path.name,"primary_trials":len(packets),"audit":check});total+=len(packets)
assert len(checks)==8 and total==132,(len(checks),total)
modules=["test_repeat_boundary_evidence","test_learned_evidence","test_stopped_evidence","test_n0_repeat_evidence","test_process_runner","test_publisher","test_condition","test_runtime","test_probe_reports","test_plotting","test_analysis_cli","test_full_probe_report_evidence"]
suite=unittest.defaultTestLoader.loadTestsFromNames(["Scripts.StructTrain.TimeLearner.tests."+m for m in modules])
result=unittest.TextTestRunner(verbosity=2).run(suite)
inputs={}
for name in ("TIMELEARNER_STOPPED_EVIDENCE_DIR","TIMELEARNER_N0_REPEATS_DIR","TIMELEARNER_DOMAIN_EVIDENCE_DIR","TIMELEARNER_FULL_PROBE_REPORT_DIR"):
    directory=Path(os.environ[name]);inputs[name]={"path":str(directory)}
    if name=="TIMELEARNER_STOPPED_EVIDENCE_DIR":
        inputs[name]["packages"]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.glob("*_stopped_state.json"))}
record={"kind":"timelearner_repeat_boundary_gate","schema_version":1,"root":"02cf1542de6edfd67aa9da15798d34dd1b0eb08f","pulse":"7b5939c5744877ba1a762393d78f7183853fd5c0","native_tests":51,"python_tests":result.testsRun,"skips":len(result.skipped),"failures":len(result.failures),"errors":len(result.errors),"current_configured_audits":checks,"current_configured_primary_trials":total,"auxiliary_inputs":inputs,"scientific_verdict":None}
(out/"validation.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)
PY
tail -n 6 "$out/native.log"
tail -n 4 "$out/python.log"
