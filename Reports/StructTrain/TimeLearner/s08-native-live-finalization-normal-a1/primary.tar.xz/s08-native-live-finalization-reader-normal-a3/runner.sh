set -euo pipefail
out='/home/user/timelearner-refactor/readbacks/s08-native-live-finalization-reader-normal-a3'
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd '/home/user/timelearner-refactor/source-live-finalization-reader-normal-a1'
export OUT="$out" BASE='/home/user/timelearner-refactor' PYTHONDONTWRITEBYTECODE=1
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import hashlib,json,os,re,time,unittest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.native_execution_gate import audit_native_gate,read_native_gate
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);start=time.monotonic();native_gates=[]
for attempt,specification in (('a2','addressed'),('a3','stopped')):
 p=base/'readbacks'/('s08-native-live-finalization-normal-'+attempt)
 spec=load(Path('Scripts/StructTrain/TimeLearner/Specifications/native-live-finalization-'+specification+'.json'))
 native_gates.append(audit_native_gate(spec,read_native_gate(spec,p,p/'runtime-after.json')))
corpus=out/'corpus';corpus.mkdir();rows=[];excluded=[]
for attempt in ('a2','a3'):
 folder=base/'readbacks'/('s08-native-live-finalization-normal-'+attempt)/'native'
 for p in sorted(folder.iterdir()):
  if attempt=='a2' and re.match(r'(?:Classic|Branch)_live_finalization_0_local_2(?:[_.])',p.name):
   excluded.append({'source_run':folder.parent.name,'path':p.name});continue
  assert p.is_file() and not p.is_symlink()
  dest=corpus/p.name;assert not dest.exists()
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  os.link(p,dest);assert hashlib.sha256(dest.read_bytes()).hexdigest()==digest
  rows.append({'path':p.name,'source_run':folder.parent.name,'source_path':'native/'+p.name,'bytes':p.stat().st_size,'sha256':digest})
mapping={'kind':'native_live_primary_composition','schema_version':1,'sources':[
 {'run':'s08-native-live-finalization-normal-a2','root':'5afe5b96311c871d09aab0c63d463caa17a9e0d5','pulse':'cf530be5f36e17d319365a9491f7a58311b28951','tests':31},
 {'run':'s08-native-live-finalization-normal-a3','root':'f0cf989cb85c3286781330e6af85261a90ea3936','pulse':'cf530be5f36e17d319365a9491f7a58311b28951','tests':2}],
 'selection':'Use the two stopped-primary serialization follow-ups; retain all other original records from the 31-case gate. Original stopped records remain in their producer, not deleted.',
 'files':rows,'excluded_from_composed_view':excluded,'independent_scientific_repetitions':False,'scientific_verdict':None}
(out/'composition.json').write_text(json.dumps(mapping,indent=2)+'\n')
os.environ['TIMELEARNER_LIVE_FINALIZATION_NATIVE']=str(corpus)
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_finalization_evidence'))
summary={'kind':'complete_live_finalization_reader_gate','schema_version':1,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,'native_gates':native_gates,'primary_composition':'composition.json','scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==4 and not r.skipped,summary
for row in rows:assert hashlib.sha256((corpus/row['path']).read_bytes()).hexdigest()==row['sha256']
print(json.dumps(summary),flush=True)
PY
