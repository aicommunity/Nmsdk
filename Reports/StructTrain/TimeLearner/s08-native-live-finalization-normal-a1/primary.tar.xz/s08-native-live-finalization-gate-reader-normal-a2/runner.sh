set -euo pipefail
out='/home/user/timelearner-refactor/readbacks/s08-native-live-finalization-gate-reader-normal-a2'
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd '/home/user/timelearner-refactor/source-live-finalization-reader-normal-a1'
export PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_NATIVE_GATE_SPEC='/home/user/timelearner-refactor/source-live-finalization-reader-normal-a1/Scripts/StructTrain/TimeLearner/Specifications/native-live-finalization-smoke.json'
export TIMELEARNER_NATIVE_GATE_ROOT='/home/user/timelearner-refactor/readbacks/s08-native-live-finalization-normal-a1'
export TIMELEARNER_NATIVE_GATE_AFTER='/home/user/timelearner-refactor/readbacks/s08-native-live-finalization-reader-normal-a1/runtime-after.json'
export OUT="$out"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,unittest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.native_execution_gate import audit_native_gate,read_native_gate
start=time.monotonic();spec=load(Path(os.environ['TIMELEARNER_NATIVE_GATE_SPEC']))
result=audit_native_gate(spec,read_native_gate(spec,Path(os.environ['TIMELEARNER_NATIVE_GATE_ROOT']),Path(os.environ['TIMELEARNER_NATIVE_GATE_AFTER'])))
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_execution_gate'))
summary={'kind':'native_gate_reader_validation','schema_version':1,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,'actual_audit':result,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==2 and not r.skipped,summary
print(json.dumps(summary),flush=True)
PY
