set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-finalization-ownership-visual-asan-a1"
repo="$base/source-rdk-bool-evidence-asan-a2"
work="$base/source-finalization-ownership-visual-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3933734 2>/dev/null && test ! -f "$base/readbacks/s08-native-finalization-ownership-asan-a3/process-exit-status.txt"; do sleep 10; done
test "$(cat "$base/readbacks/s08-native-finalization-ownership-asan-a3/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git eb58ac90344ca6ecc8a0952998e1702aa6879808 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --detach --no-checkout "$work" eb58ac90344ca6ecc8a0952998e1702aa6879808 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export BASE="$base" OUT="$out" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/render.log" 2>&1
import hashlib,json,os,time
from pathlib import Path
from PIL import Image
from Scripts.StructTrain.TimeLearner.finalization_ownership_reports import render_managed_finalization
from Scripts.StructTrain.TimeLearner.posttune_transaction_reports import render_posttune_transaction
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.recognition_metrics import load_evaluation
base=Path(os.environ['BASE']);out=Path(os.environ['OUT'])
native=base/'readbacks/s08-native-finalization-ownership-asan-a3/native'
fixtures=base/'readbacks/s08-native-posttune-probe-console-asan-a1/fixtures'
cache=base/'cache/s08-native-finalization-ownership-asan-a1'
assert not cache.exists()
inputs=[p for source in ('Classic-auto_metric','Branch-synthetic') for p in (fixtures/source/'input/source').rglob('*') if p.is_file()]
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
cache.mkdir(parents=True);start=time.monotonic();records=[];pairs=0;selected=[]
for topology,jobfolder in [('Classic','Classic-auto_metric'),('Branch','Branch-synthetic')]:
 source_files=list((fixtures/jobfolder/'input/source').glob('*_learned_state.json'))
 assert len(source_files)==1
 for mode in (0,1):
  name=f'{topology}_managed_finalization_{mode}'
  folder=cache/name
  outer=render_managed_finalization(native/(name+'.json'),source_files[0],folder)
  raw=load(native/(name+'.json'));post=load(folder/'posttune/manifest.json')
  assert post['trial_soma_pairs']==(8 if topology=='Classic' else 4)
  assert len(post['weight_matrices'])==len(post['final_model_matrices'])==1
  for matrix in post['weight_matrices']+post['final_model_matrices']:
   root=folder/'posttune'/matrix['name'];visual=load(root/'manifest.json')
   spec,observations=load_evaluation(root/'primary/evaluation.json')
   expected=raw['transaction']['candidates'][0]['matrix'] if matrix['role']=='weight_measurement' else raw['transaction']['final_model_matrix']
   assert observations==expected['observations']
   channels=1 if topology=='Branch' else 2
   assert {(f['trial_id'],f['descriptor']['index']) for f in visual['figures']}=={(q['trial_id'],i) for q in spec['trials'] for i in range(channels)}
   for f in visual['figures']:
    assert any(v['time_view']!='overview' for v in f['views'])
    for view in f['views']:
     assert view['downsampling'] is False
     if view['time_view']!='overview':assert view['minimum_native_tick_pixels_on_zoom']>=8
     png,svg,pdf=[root/p for p in view['files']]
     with Image.open(png) as im:assert im.size==(1920,960)
     assert 'Actual shared input' in svg.read_text() and pdf.read_bytes().startswith(b'%PDF-')
    if mode==0 and f['label']=='target' and f['descriptor']['index']==0:
     for view in (f['views'][0],next(v for v in f['views'] if v['time_view']!='overview')):
      selected.append((root/next(p for p in view['files'] if p.endswith('.png'))).relative_to(cache).as_posix())
  pairs+=post['trial_soma_pairs']
  records.append({'name':name,'pairs':post['trial_soma_pairs'],'record_sha256':outer['source_record_sha256']})
assert pairs==24 and len(selected)==8
# Exercise the unchanged filename-based production entry point after extracting
# the common data renderer; use a real original-source fixed transaction.
source=list((fixtures/'Classic-auto_metric/input/source').glob('*_learned_state.json'))[0]
legacy=render_posttune_transaction(native/'Classic_fixed_0_transaction.json',source,cache/'legacy-front-control')
assert legacy['trial_soma_pairs']>0
assert before=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
files=[p for p in cache.rglob('*') if p.is_file()]
report={'kind':'native_managed_finalization_visual_gate','schema_version':1,'cache':str(cache),
 'reports':records,'complete_managed_trial_soma_pairs':pairs,'selected_png':selected,
 'legacy_entry_point_control':legacy,'original_source_files_unchanged':len(before),
 'seconds':time.monotonic()-start,'files':len(files),'bytes':sum(p.stat().st_size for p in files),
 'renderer_root':'eb58ac90344ca6ecc8a0952998e1702aa6879808','visual_acceptance_complete':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
