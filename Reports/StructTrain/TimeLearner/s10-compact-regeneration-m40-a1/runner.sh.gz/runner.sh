set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out=$base/readbacks/s10-compact-regeneration-m40-a1
cache=$base/report-cache/repeat-boundary-m40-from-compact-a1
input=$base/readbacks/s10-compact-bundle-m40-a1
renderer=$base/source-repeat-boundary-full-visual-a1
trap 'status=$?; printf "%s\n" "$status" > "$out/process-exit-status.txt"' EXIT
test "$(cat "$input/process-exit-status.txt")" = 0
test "$(git -C "$renderer" rev-parse HEAD)" = b2f357bcc75264a233524bfb30153b5d95816d6c
cd "$renderer"
export PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u -m Scripts.StructTrain.TimeLearner report "$input/extracted/contract.json" --format native-test-run --artifacts "$input/extracted" --output "$cache" > "$out/render.log" 2>&1
cd "$base/source-compact-bundle-a1"
export TIMELEARNER_NATIVE_TEST_REPORT_DIR="$input/extracted"
export TIMELEARNER_NATIVE_TEST_VISUAL_DIR="$cache"
CACHE="$cache" OUT="$out" "$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/readback.log" 2>&1
import os,json,hashlib,unittest,subprocess
from pathlib import Path
base=Path("/media/user/Data/TimeLearnerRefactor")
cache=Path(os.environ["CACHE"]);original=base/"readbacks/s05-repeat-boundary-full-visual-m40-a1/report"
pngs={p.relative_to(cache).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in cache.rglob("*.png")}
expected={p.relative_to(original).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in original.rglob("*.png")}
assert len(pngs)==3087 and pngs==expected,(len(pngs),len(expected),len(set(pngs)^set(expected)))
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName("Scripts.StructTrain.TimeLearner.tests.test_native_test_visual_evidence"))
bundle=json.loads((base/"readbacks/s10-compact-bundle-m40-a1/primary-bundle/manifest.json").read_text())
record={"kind":"timelearner_compact_full_cache_regeneration","schema_version":1,"reader_root":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"renderer_root":"b2f357bcc75264a233524bfb30153b5d95816d6c","cache":str(cache),"source_archive_sha256":bundle["archive"]["sha256"],"trials":338,"trial_soma_pairs":507,"compared_pngs":len(pngs),"all_png_byte_identical":True,"tests":r.testsRun,"skips":len(r.skipped),"failures":len(r.failures),"errors":len(r.errors),"scientific_verdict":None,"global_visual_acceptance":False}
Path(os.environ["OUT"],"validation.json").write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(0 if r.wasSuccessful() and not r.skipped else 1)
PY
