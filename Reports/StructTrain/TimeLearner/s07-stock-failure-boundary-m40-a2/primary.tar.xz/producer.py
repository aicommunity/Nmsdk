from pathlib import Path,PurePosixPath
import json,sys,os,subprocess,tarfile,io,hashlib,traceback,contextlib,unittest,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');venv=base/'plot-venv-a1/bin/python'
if sys.executable!=str(venv):os.execv(str(venv),[str(venv),'-u',__file__])
root='988d4bfb706f9a3e3520bb012a6fe93304baf4ef';donor=base/'source-initial-threshold-asan-a2';sdk=base/'analysis-stock-failure-reports-a1';out=base/'readbacks/s07-stock-failure-production-visual-a2';out.mkdir(exist_ok=False)
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 assert shutil.disk_usage(base).free>=2*1024**3
 previous=base/'readbacks/s07-stock-failure-production-visual-a1'
 owner=json.loads((previous/'owned-supervisor.json').read_text())
 try:assert Path('/proc',str(owner['pid']),'stat').read_text().rsplit(') ',1)[1].split()[19]!=owner['start_ticks']
 except FileNotFoundError:pass
 assert json.loads((previous/'terminal.json').read_text())['status']=='passed'
 assert git(sdk,'rev-parse','HEAD').decode().strip()=='2b9f13a6c868e428e975252882067c9ee692d1fc'
 git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root)
 git(sdk,'checkout','--detach',root)
 import ast
 for path in ['stock_failure_reports.py','native_evidence.py','probe_diagnostics.py']:
  full='Scripts/StructTrain/TimeLearner/'+path
  assert git(sdk,'show','2b9f13a6c868e428e975252882067c9ee692d1fc:'+full)==git(sdk,'show',root+':'+full)
 test='Scripts/StructTrain/TimeLearner/tests/test_stock_failure_reports.py'
 def selection_class(sha):return next(n for n in ast.parse(git(sdk,'show',sha+':'+test)).body if isinstance(n,ast.ClassDef) and n.name=='StockFailureBoundaryTest')
 assert ast.dump(selection_class('2b9f13a6c868e428e975252882067c9ee692d1fc'),include_attributes=False)==ast.dump(selection_class(root),include_attributes=False)
 assert json.loads((previous/'selection-readers.json').read_text())=={'tests':12,'failures':0,'errors':0,'skipped':0}
 sys.path.insert(0,str(sdk));os.environ['PYTHONPATH']=str(sdk);os.environ['MPLCONFIGDIR']=str(out/'matplotlib-cache')
 from Scripts.StructTrain.TimeLearner.n1_protocol_robustness import _inventory
 old_cache=previous/'full-report-cache';before=_inventory(old_cache)
 source=previous/'restored/study';cache=out/'full-report-cache'
 write('reused-readers.json',{'source_proof':'490998982c59367f39e7f3daa65a8028ee6069ea','elder_proof':'2f9885d77b1e4a92c59b96875bc0b7cbea3f005d','tests_per_worker':12,'same_production_selector_auditor_and_diagnostic_reader_bytes':True,'same_selection_test_class_ast':True,'native_rerun':False})
 def tests(label,names):
  suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
  with (out/(label+'.log')).open('x') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
  summary={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)};write(label+'.json',summary);assert result.wasSuccessful() and not result.skipped,summary
 from Scripts.StructTrain.TimeLearner.__main__ import main as cli
 with (out/'production-cli.log').open('x') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  rc=cli(['stock-threshold-study','failure-report',str(source),'--output',str(cache)])
 assert rc==0,rc
 os.environ['TIMELEARNER_STOCK_FAILURE_REPORT']=str(cache)
 tests('report-readers',['Scripts.StructTrain.TimeLearner.tests.test_stock_failure_reports.StockFailureReportTest'])
 m=json.loads((cache/'manifest.json').read_text());selected=[];(out/'selected').mkdir()
 for row in m['reports']:
  name=row['name'];folder=cache/name;entries=json.loads((folder/'manifest.json').read_text())['reports']
  for entry,record in zip(entries,row['selection']['probes']):
   probe=folder/entry['folder'];pm=json.loads((probe/'manifest.json').read_text());channel=record['input_index'] if row['topology']=='Classic' else 0
   figure=next(f for f in pm['figures'] if f['channel']==channel);view=next(v for v in figure['views'] if v['time_view']=='overview')
   original=probe/view['files'][0];destination=out/'selected'/(name+'-'+record['role']+'.png');shutil.copyfile(original,destination)
   selected.append({'name':name,'role':record['role'],'channel':channel,'original_cache_file':str(original),'selected':destination.name,'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'manual_review_complete':False})
 # Preserve every previously selected overview byte and add one meaningful
 # measured peak neighbourhood for each terminal condition.
 old_selected=json.loads((previous/'selected.json').read_text())
 for item in selected:
  original=next(x for x in old_selected if x['selected']==item['selected']);assert original['sha256']==item['sha256']
 for row in m['reports']:
  name=row['name'];folder=cache/name;entry=json.loads((folder/'manifest.json').read_text())['reports'][-1];record=row['selection']['probes'][-1];probe=folder/entry['folder'];pm=json.loads((probe/'manifest.json').read_text());channel=record['input_index'] if row['topology']=='Classic' else 0
  figure=next(f for f in pm['figures'] if f['channel']==channel);assignment=next(a for a in record['burst_assignments'] if a['channel']==channel)
  wave_index=2 if row['initial_threshold']==.0117 else 0;wave=assignment['waves'][wave_index]
  from Scripts.StructTrain.TimeLearner.native_evidence import equal
  view=next(v for v in figure['views'] if 'peak_detail' in v and equal(v['peak_detail']['peak_sample_time'],wave['time']))
  original=probe/view['files'][0];destination=out/'selected'/(name+'-terminal-invalid-peak-detail.png');shutil.copyfile(original,destination)
  selected.append({'name':name,'role':'terminal-invalid-peak-detail','channel':channel,'source_wave_index':wave_index,'view':view,'original_cache_file':str(original),'selected':destination.name,'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'manual_review_complete':False})
 after=_inventory(old_cache);assert after==before
 write('old-cache-unchanged.json',{'files':len(before),'before_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'after_sha256':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),'same':True})
 write('selected.json',selected);passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','native_rerun':False,'manual_review_complete':False,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
