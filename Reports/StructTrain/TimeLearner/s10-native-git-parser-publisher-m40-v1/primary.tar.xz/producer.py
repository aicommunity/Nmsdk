HOST='m40'
BASE='/media/user/Data/TimeLearnerRefactor'
DONOR='source-legacy-completed-replay-asan-a1'
METHODS=['test_children_first_and_idempotent', 'test_gitmodules_uneven_indentation_uses_native_committed_git_parser', 'test_sparse_selected_ignored_artifact_is_staged_and_published', 'test_ignored_uncommitted_image_blocks_every_push', 'test_changed_committed_image_cannot_keep_previous_inventory', 'test_explicit_same_repository_push_target_does_not_change_remote_config', 'test_wrong_explicit_push_repository_is_rejected_before_push', 'test_duplicate_and_traversal_manifest_entries_are_rejected', 'test_working_symlink_is_rejected_without_staging', 'test_artifact_verification_uses_original_objects_not_local_replacements', 'test_child_push_failure_prevents_root_push', 'test_root_rejection_is_not_published_success', 'test_missing_or_wrong_child_commit_is_preflight_failure', 'test_dirty_source_is_rejected', 'test_wrong_child_remote_does_not_claim_checkout_reproducibility', 'test_real_cli_receipt_and_existing_receipt_guard', 'test_existing_lock_requires_explicit_recovery']
from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,traceback
ROOT='2adb18ce430b0080f837913ee5aab4569f7e21ba'
base=Path(BASE);name='native-git-parser-publisher-'+HOST+'-v1';repo=base/('git-'+name);source=base/('code-'+name)
out=base/'readbacks'/('s10-'+name);out.mkdir(parents=True,exist_ok=False)
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
(out/'producer.py').write_bytes(Path(__file__).read_bytes());passed=False
try:
 subprocess.run(['git','clone','--shared','--no-checkout',str(base/DONOR),str(repo)],check=True,capture_output=True)
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],check=True,capture_output=True)
 source.mkdir(exist_ok=False)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','-C',str(repo),'archive',ROOT,'Scripts/StructTrain/TimeLearner']))) as archive:archive.extractall(source)
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.validation import run_suite,package_fingerprint
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'native-git-parser-publisher17',
       'package_fingerprint':package_fingerprint(),'modules':['Scripts.StructTrain.TimeLearner.tests.test_publisher'],
       'expected_test_ids':['Scripts.StructTrain.TimeLearner.tests.test_publisher.PublisherTest.'+n for n in METHODS],'fixtures':{}}
 result=run_suite(spec,{},out/'reader-result')
 assert result['executed_tests']==17 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 passed=True;write('terminal.json',{'reader_tests':17,'model_executions':0,'actual_git_fixture_publication':True,
       'scope':'mixed-indentation committed gitmodules, child push rejection, root push rejection, artifact integrity, CLI and lock controls on real local Git repositories',
       'scientific_verdict':None})
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'native_git_parser_publisher_regression','schema_version':1,'root':ROOT,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),
       'native_rerun':False,'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 pg('config','user.name','TimeLearner Evidence');pg('config','user.email','timelearner@localhost')
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s10-native-git-parser-publisher-m40-v1'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: real Git publisher17 with mixed-indentation Git parser regression\n')
 branch='refs/heads/codex/evidence-s10-native-git-parser-publisher-m40-v1'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
