from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,traceback,unittest,shutil,time
base=Path('/home/user/timelearner-refactor');label='native-runtime-interface-a1';out=base/('readbacks/s02-'+label);out.mkdir(exist_ok=False)
source=base/'source-native-runtime-interface-a1';bootstrap=base/'source-closed-worker-recovery-a3';root='8c9ee9f6b319a06224d6ebdcdd537b88e993fc4a';container=Path(str(out)+'-container')
predecessor=base/'readbacks/s10-managed-live-routing-normal-a1-container';primary=base/'readbacks/s10-managed-pipeline-coordinator-normal-a1'
stop=threading.Event();thread=None;errors=[];passed=False;token=None
capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'source':str(source),'root':root,'contained_supervisor':str(container)})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 dependency_source=base/'source-worker-dependency-normal-a2'
 sys.path.insert(0,str(dependency_source))
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 dependency_registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 state=inspect_worker_dependency(base/'readbacks/s10-managed-live-routing-normal-a3-container',dependency_registry,'s10-managed-live-routing-normal-a3',reservation_optional=True)
 assert state['state']=='ready',state
 write('invalid-live-closed.json',state)
 primary=base/'readbacks/s10-managed-pipeline-coordinator-normal-a2'
 baseline=base/'readbacks/s06-live-cold-fixture-baseline-normal-a1'
 assert shutil.disk_usage(base).free>=1024**3
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity)
 reserved=registry.reserve('s10-'+label,[{'path':str(out),'access':'write'},{'path':str(source),'access':'read'},{'path':str(bootstrap),'access':'read'},{'path':str(dependency_source),'access':'read'},{'path':str(primary),'access':'read'},{'path':str(baseline),'access':'read'},{'path':str(base/'source-live-cold-fixture-baseline-normal-a1'),'access':'read'},{'path':str(base/'runtime-live-cold-fixture-baseline-normal-a1'),'access':'read'},{'path':str(base/'build-live-cold-fixture-baseline-normal-a1'),'access':'read'}],demands={'slots':1,'memory_bytes':512*1024**2,'disk_bytes':256*1024**2},ttl_seconds=120)
 token=reserved['token'];write('reservation.json',reserved)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==root
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip()
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 console_runtime=snapshot(base/'source-live-cold-fixture-baseline-normal-a1',base/'runtime-live-cold-fixture-baseline-normal-a1/NeuroModelerConsole',base/'runtime-live-cold-fixture-baseline-normal-a1/NeuroModelerConsole.ini',base/'build-live-cold-fixture-baseline-normal-a1/CMakeCache.txt')
 assert console_runtime['source_closure']['root']['head']=='33fc48278cff860d20c570cb703198847f028065'
 write('console-runtime.json',console_runtime);test_runtime=json.loads((baseline/'native-runtime.json').read_text());verify_runtime(test_runtime)
 assert console_runtime['executable']['sha256']!=test_runtime['executable']['sha256']
 write('test-runtime.json',test_runtime)
 case=primary/'actual-controls/Classic-v1';job=case/'runs/pipeline/phases/train/input/job.json'
 fixtures={'console_runtime':str(out/'console-runtime.json'),'test_runtime':str(out/'test-runtime.json'),'train_job':str(job),'pipeline_job':str(case/'pipeline-job.json'),'pipeline_policy':str(case/'policy.json')}
 write('fixtures.json',fixtures);os.environ['TIMELEARNER_NATIVE_CLI_FIXTURES']=str(out/'fixtures.json')

 os.environ['TMPDIR']=str(out/'temporary');(out/'temporary').mkdir()
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_cli');assert suite.countTestCases()==7
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected':7})
 assert result.testsRun==7 and result.wasSuccessful() and not result.skipped and not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'tests_passed':passed,'new_native_units':0,'source_commit':root,'actual_primary':str(primary),'full_pipeline_and_live_regressions_pending':True,'scientific_verdict':None,'whole_plan_complete':False})
  write('source-hashes.json',{p.relative_to(source).as_posix():sha(p) for p in (source/'Scripts/StructTrain/TimeLearner').rglob('*.py') if '__pycache__' not in p.parts})
  files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,v in files.items():
    entry=tarfile.TarInfo(name);entry.size=v['bytes']
    with (out/name).open('rb') as f:archive.addfile(entry,f)
  write('bundle.json',{'kind':'managed_actual_downstream_declaration_checks','source_commit':root,'passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'new_native_units':0})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
