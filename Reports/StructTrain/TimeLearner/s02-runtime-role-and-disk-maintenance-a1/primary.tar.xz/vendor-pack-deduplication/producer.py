from pathlib import Path
import os,sys,json,hashlib,subprocess,stat,shutil,traceback,time
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s02-obsolete-vendor-pack-dedup-a1';out.mkdir(exist_ok=False);api=base/'source-worker-dependency-normal-a2';token=None

def write(n,v):(out/n).write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(p,*a):return subprocess.check_output(['git','-C',str(p),*a],text=True).strip()
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(api))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 registry=Reservations(base/'resource-reservations.sqlite3',capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3})
 preceding=inspect_worker_dependency(base/'readbacks/s10-managed-live-routing-normal-a3-container',registry,'s10-managed-live-routing-normal-a3',reservation_optional=True);assert preceding['state']=='ready';write('preceding-live-closure.json',preceding)
 builds=[base/'build-test-switch-off-b3',base/'build-test-switch-on-b3'];roots=[p/'_deps/llama_cpp-src' for p in builds]
 for b,r in zip(builds,roots):assert b.resolve().parent==base.resolve() and r.resolve().is_relative_to(b.resolve()) and not b.is_symlink() and not r.is_symlink()
 ledger=registry.inspect()
 for lease in ledger['leases']:
  if lease['state']=='held':
   for resource in lease['resources']:
    p=Path(resource['canonical_path']).resolve()
    assert all(not(p==b.resolve() or p.is_relative_to(b.resolve()) or b.resolve().is_relative_to(p)) for b in builds)
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   if proc.stat().st_uid!=os.getuid():continue
   content=(proc/'cmdline').read_bytes()+(proc/'maps').read_bytes()
   for leaf in ['cwd','exe']:
    try:content+=os.readlink(proc/leaf).encode()
    except OSError:pass
   assert not any(str(b).encode() in content for b in builds),('active_process_uses_old_build',proc.name)
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 for r in roots:
  assert git(r,'rev-parse','HEAD')=='1971adf55e3ebbfab83771d6174d37b77c352c71'
  assert not git(r,'status','--porcelain','--untracked-files=all') and not git(r,'stash','list')
 maintenance=Reservations(base/'maintenance-reservations.sqlite3');reservation=maintenance.reserve('obsolete-vendor-pack-dedup-a1',[{'path':str(out),'access':'write'}]+[{'path':str(r),'access':'write'} for r in roots],ttl_seconds=3600);token=reservation['token'];write('reservation.json',reservation)
 before=shutil.disk_usage(base).free;pairs=[]
 for source in sorted((roots[0]/'.git').rglob('pack-*.pack')):
  relative=source.relative_to(roots[0]);target=roots[1]/relative
  if not target.is_file():continue
  assert source.resolve().is_relative_to((roots[0]/'.git').resolve()) and target.resolve().is_relative_to((roots[1]/'.git').resolve())
  assert not source.is_symlink() and not target.is_symlink() and source.stat().st_dev==target.stat().st_dev
  if source.stat().st_ino==target.stat().st_ino:continue
  assert source.stat().st_size==target.stat().st_size and stat.S_IMODE(source.stat().st_mode)==stat.S_IMODE(target.stat().st_mode)
  assert not (source.stat().st_mode & (stat.S_IWUSR|stat.S_IWGRP|stat.S_IWOTH)),str(source)
  digest=sha(source);assert digest==sha(target)
  pairs.append({'source':str(source),'target':str(target),'bytes':source.stat().st_size,'sha256':digest,'old_source_inode':source.stat().st_ino,'old_target_inode':target.stat().st_ino})
 assert pairs and sum(x['bytes'] for x in pairs)>=256*1024**2
 write('deduplication-plan.json',{'pairs':pairs,'only_immutable_git_pack_bytes':True,'tracked_files_and_refs_unchanged':True,'no_runtime_files_changed':True,'head_commit':'1971adf55e3ebbfab83771d6174d37b77c352c71'})
 for pair in pairs:
  source=Path(pair['source']);target=Path(pair['target']);maintenance.validate_paths(token);assert sha(source)==sha(target)==pair['sha256']
  temp=target.with_name(target.name+'.timelearner-dedup-link');assert not temp.exists();os.link(source,temp);assert temp.stat().st_ino==source.stat().st_ino;os.replace(temp,target)
  assert target.stat().st_ino==source.stat().st_ino and sha(target)==pair['sha256']
 for r in roots:assert git(r,'rev-parse','HEAD')=='1971adf55e3ebbfab83771d6174d37b77c352c71' and not git(r,'status','--porcelain','--untracked-files=all') and not git(r,'stash','list')
 write('terminal.json',{'deduplication_completed':True,'duplicate_pack_copies_replaced':len(pairs),'duplicate_bytes_unallocated':sum(x['bytes'] for x in pairs),'disk_free_before':before,'disk_free_after':shutil.disk_usage(base).free,'all_files_content_preserved':True,'git_refs_stash_working_tree_preserved':True,'runtime_or_sources_content_modified':False,'native_models_executed':False,'whole_plan_complete':False})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()});write('terminal.json',{'deduplication_completed':False,'native_models_executed':False,'whole_plan_complete':False})
finally:
 if token:maintenance.release(token,note='Synchronous immutable duplicate Git-pack dedup ended, no process children or model execution.');write('reservation-final.json',maintenance.inspect())
