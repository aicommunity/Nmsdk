from pathlib import Path
import os,sys,json,hashlib,time,traceback,subprocess,shutil
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s02-obsolete-object-cleanup-a1';out.mkdir(exist_ok=False);api=base/'source-worker-dependency-normal-a2';token=None

def write(n,v):(out/n).write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'role':'obsolete compiled objects only; no models/builds launched'});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(api))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 global_registry=Reservations(base/'resource-reservations.sqlite3',capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3})
 predecessor=inspect_worker_dependency(base/'readbacks/s10-managed-live-routing-normal-a3-container',global_registry,'s10-managed-live-routing-normal-a3',reservation_optional=True);assert predecessor['state']=='ready',predecessor;write('preceding-live-resource-state.json',predecessor)
 targets=[base/'build-test-switch-off-b3',base/'build-test-switch-on-b3'];runtimes=[base/'runtime-test-switch-off-b3',base/'runtime-test-switch-on-b3'];resolved=[p.resolve(strict=True) for p in targets]
 assert all(p.parent==base.resolve() and not target.is_symlink() and p.name in ['build-test-switch-off-b3','build-test-switch-on-b3'] for target,p in zip(targets,resolved))
 # Maintenance has no model slot and never changes global worker capacity.
 # A separate path-only lease protects its own declared filesystem operation;
 # disjointness against every held production lease is checked before unlink.
 maintenance=Reservations(base/'maintenance-reservations.sqlite3')
 reservation=maintenance.reserve('obsolete-object-cleanup-a1',[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'write'} for p in targets]+[{'path':str(p),'access':'read'} for p in runtimes],ttl_seconds=3600);token=reservation['token'];write('maintenance-reservation.json',reservation)
 def overlaps(a,b):return a==b or a.is_relative_to(b) or b.is_relative_to(a)
 ledger=global_registry.inspect()
 for lease in ledger['leases']:
  if lease['state']=='held':
   for resource in lease['resources']:
    q=Path(resource['canonical_path']).resolve()
    assert not any(overlaps(p,q) for p in resolved),('active_global_resource',lease['job_id'],str(q))
 write('global-disjointness.json',{'checked_held_leases':[v['job_id'] for v in ledger['leases'] if v['state']=='held'],'global_registry_changed':False,'global_capacity_changed':False,'maintenance_scope':'filesystem-only; no model execution/compiler; separate namespace,512MiB bounded unit','predecessor_training_success_not_required_for_independent_cache_cleanup':True})
 # Detect current process cwd/executable/command/mappings using old build paths.
 process_count=0
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   if proc.stat().st_uid!=os.getuid():continue
   data=(proc/'cmdline').read_bytes()+b'\n'+(proc/'maps').read_bytes()
   for leaf in ['cwd','exe']:
    try:data+=b'\n'+os.readlink(proc/leaf).encode()
    except OSError:pass
   assert not any(str(p).encode() in data for p in resolved),('active_process_uses_old_build',proc.name)
   process_count+=1
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 write('active-process-check.json',{'processes_checked':process_count,'matched_target_paths':0})
 candidates=[];protected={};preserved_runtime={}
 for target,runtime in zip(targets,runtimes):
  assert not any(p.name=='.git' for p in target.rglob('.git'))
  cache=(target/'CMakeCache.txt').read_text();assert 'CMAKE_BUILD_TYPE:STRING=Release' in cache and 'NMSDK_DEPLOY_ROOT:PATH='+str(runtime) in cache;assert runtime.is_dir() and not runtime.resolve().is_relative_to(target.resolve())
  write(target.name+'-cache.json',{'path':str(target/'CMakeCache.txt'),'sha256':sha(target/'CMakeCache.txt'),'content':cache})
  for q in target.rglob('*'):
   assert not q.is_symlink(),('unexpected_build_symlink',str(q))
   if not q.is_file():continue
   absolute=q.resolve(strict=True);assert absolute.is_relative_to(target.resolve())
   entry={'path':str(q),'bytes':q.stat().st_size,'sha256':sha(q)}
   if q.suffix in ['.o','.a','.obj','.pch']:candidates.append(entry)
   else:protected[str(q)]=entry
  for q in runtime.rglob('*'):
   if q.is_file() and not q.is_symlink():preserved_runtime[str(q)]={'bytes':q.stat().st_size,'sha256':sha(q)}
 assert candidates and sum(v['bytes'] for v in candidates)>=512*1024**2
 write('deletion-inventory.json',{'targets':[str(p) for p in resolved],'files':candidates,'bytes':sum(x['bytes'] for x in candidates),'suffixes':['.o','.a','.obj','.pch'],'reason':'superseded accepted test-switch build products, fully reproducible from retained source/cache; no primary experiment artifacts','accepted_gate_evidence':'57383f8d93ebf660bd2f80d08ac315a67abe2896','runtime_artifacts_deleted':False})
 write('preserved-build-files.json',protected);write('preserved-runtime-files.json',preserved_runtime);before=shutil.disk_usage(base).free
 for entry in candidates:
  maintenance.validate_paths(token);q=Path(entry['path']);assert q.is_file() and not q.is_symlink() and q.suffix in ['.o','.a','.obj','.pch'] and any(q.resolve().is_relative_to(p) for p in resolved)
  assert q.stat().st_size==entry['bytes'] and sha(q)==entry['sha256'];q.unlink()
 for name,entry in protected.items():q=Path(name);assert q.is_file() and q.stat().st_size==entry['bytes'] and sha(q)==entry['sha256']
 for name,entry in preserved_runtime.items():q=Path(name);assert q.is_file() and q.stat().st_size==entry['bytes'] and sha(q)==entry['sha256']
 assert all(not Path(x['path']).exists() for x in candidates)
 write('terminal.json',{'cleanup_completed':True,'files_deleted':len(candidates),'compiled_bytes_deleted':sum(v['bytes'] for v in candidates),'free_disk_bytes_before':before,'free_disk_bytes_after':shutil.disk_usage(base).free,'runtime_files_preserved':len(preserved_runtime),'other_build_files_preserved':len(protected),'source_or_model_changed':False,'native_models_executed':False,'whole_plan_complete':False})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()});write('terminal.json',{'cleanup_completed':False,'native_models_executed':False,'whole_plan_complete':False})
finally:
 if token:maintenance.release(token,note='Synchronous filesystem-only maintenance ended; no child process launched. Compiled product deletion outcome separately recorded.');write('maintenance-reservation-final.json',maintenance.inspect())
