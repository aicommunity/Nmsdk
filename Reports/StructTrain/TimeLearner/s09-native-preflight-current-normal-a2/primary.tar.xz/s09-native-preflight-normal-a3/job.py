transport_ancestors={'3024538': '312541508', '3024493': '312541426', '1048': '537'}
import pathlib,subprocess,json,os,time,sys,traceback,xml.etree.ElementTree as ET
base=pathlib.Path("/home/user/timelearner-refactor");worker="normal"
source=base/"source-n1-measured-refinement-normal-a1";build=base/"build-n1-measured-refinement-normal-a1"
out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/"readbacks").resolve() and out.name=="s09-native-preflight-normal-a3"
assert {p.name for p in out.iterdir()} <= {"job.py","pid.json","supervisor.log"}
runtime=base/("runtime-"+out.name)
assert not runtime.exists()
def write(name,value):
 with (out/name).open("x",encoding="utf-8") as file:json.dump(value,file,indent=2);file.write("\n")
def run(args,name,timeout=300):
 with (out/name).open('xb') as f:r=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:raise RuntimeError(name+':'+str(r.returncode))
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
try:
 roots=[source.resolve(),build.resolve()];users=[];excluded=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   paths=[(p/'cwd').resolve(strict=True),(p/'exe').resolve(strict=True)]
   paths.extend(pathlib.Path(l.split()[-1]) for l in (p/'maps').read_text().splitlines() if '/' in l)
   for f in (p/'fd').iterdir():
    try:paths.append(f.resolve(strict=True))
    except FileNotFoundError:pass
   if any(any(q==r or r in q.parents for r in roots) for q in paths):users.append(p.name)
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').strip()
   if ((comm=='(sd-pam)' and cmd==b'(sd-pam)') or
       (comm=='ssh-agent' and (cmd.startswith(b'/usr/bin/ssh-agent ') or cmd==b'ssh-agent -s')) or
       (comm=='sshd' and p.name in transport_ancestors and (p/'stat').read_text().rsplit(') ',1)[1].split()[19]==transport_ancestors[p.name])):
    excluded.append({'pid':p.name,'comm':comm,'reason':'verified_noncomputing_service_or_launch_transport'});continue
   raise RuntimeError('unknown_same_uid_process_access:'+p.name+':'+comm)
 write('process-guard.json',{'scope':'same-user cwd/exe/maps/fd under reused source/build','users':users,'excluded_noncomputing':excluded})
 assert not users,users
 assert pathlib.Path(git(source,'rev-parse','--show-toplevel')).resolve()==source.resolve()
 assert not git(source,'status','--porcelain','--untracked-files=no')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git','d2bf789f2a6e744fedcd29aefc3ed405eaea0fc8'],'fetch-root.log')
 root=git(source,'rev-parse','FETCH_HEAD');assert root=='d2bf789f2a6e744fedcd29aefc3ed405eaea0fc8'
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 for child,url in [('Libraries/Nmsdk-PulseLib','Nmsdk-PulseLib'),('Bin','Nmsdk-Bin'),('Rdk','Rdk')]:
  repo=source/child;assert not git(repo,'status','--porcelain','--untracked-files=no')
  wanted=git(source,'rev-parse','HEAD:'+child)
  run(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/'+url+'.git',wanted],'fetch-'+url+'.log')
  assert git(repo,'rev-parse','FETCH_HEAD')==wanted,'fetch_did_not_resolve_exact_gitlink'
  run(['git','-C',repo,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+url+'.log')
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure,snapshot
 from Scripts.StructTrain.TimeLearner.process_runner import execute,verify_runtime
 closure=source_closure(source);write('source.json',closure)
 assert not runtime.exists()
 run(['cmake','-S',source,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 run(['cmake','--build',build,'--target','NeuroModelerConsole','--parallel','2'] ,'build.log',7200)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 manifest=snapshot(source,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt')
 write('runtime.json',manifest)
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 corpus=out/'corpus';corpus.mkdir();(corpus/'inputs').mkdir();(corpus/'runs').mkdir()
 originals={}
 pipeline=base/'readbacks/s09-native-pipeline-cli-normal-a2'
 live=base/'readbacks/s09-native-live-training-worker-normal-a2/corpus/runs'
 for topology in ['Classic','Branch']:
  for norm in ['0','1']:
   originals['pipeline-'+topology+'-N'+norm]=pipeline/(topology+'-N'+norm+'-train/input/job.json')
  for mode in ['budget','fixed','grid','legacy-budget','stopped']:
   originals['live-'+topology+'-'+mode]=live/(topology+'-'+mode)/'input/job.json'
 record={'kind':'native_preflight_corpus','schema_version':2,'cooperative_capture':True,'positive':list(originals),'negative':{},'train_controls':{},'sources':{},'scientific_verdict':None}
 for name,path in originals.items():
  raw=path.read_bytes();target=corpus/'inputs'/(name+'.json');target.write_bytes(raw)
  import hashlib
  record['sources'][name]={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
  r=run_job('preflight',target,None,out/'runtime.json',corpus/'runs'/name,120)
  assert r['execution']=='completed' and r['validity']=='valid' and r['analysis']['training_started'] is False
  assert audit_run_manifest(corpus/'runs'/name/'run-manifest.json')['run_evidence_consistent']
  print('preflight '+name+' completed',flush=True)
 for topology in ['Classic','Branch']:
  name='live-'+topology+'-legacy-budget';train='train-'+topology+'-legacy-budget'
  r=run_job('train',corpus/'inputs'/(name+'.json'),None,out/'runtime.json',corpus/'runs'/train,120)
  assert r['execution']=='process_error' and r['validity']=='unverified_execution' and r['analysis'] is None
  e=json.loads((corpus/'runs'/train/'native/execution.json').read_text())
  assert e['execution']=='model_tick_budget_exhausted' and e['model_ticks']==1
  record['train_controls'][topology]={'run':train,'execution':'model_tick_budget_exhausted','scientific_verdict':None}
 import copy
 source_job=json.loads((corpus/'inputs/pipeline-Classic-N1.json').read_text())
 negatives=[('legacy-factor','native',lambda d:d['configuration'].update(SyncTolerance=.02)),
  ('empty-windows','native',lambda d:d['configuration'].update(windows=[])),
  ('frequency-mismatch','native',lambda d:d['configuration']['stimulus_profile'].update(frequency_hz=4000)),
  ('zero-measurement-budget','native',lambda d:d['configuration'].update(maximum_samples=0)),
  ('unsupported-ctrim','descriptor',lambda d:d['optional_modes'].update(sync_capacitance_trim=1)),
  ('wrong-owner','descriptor',lambda d:d.update(owner_class='NNeuronTimeLearnerBogus'))]
 for case,stage,edit in negatives:
  name='invalid-'+case;job=copy.deepcopy(source_job);edit(job);job=_signed({k:v for k,v in job.items() if k!='sha256'})
  path=corpus/'inputs'/(name+'.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
  try:r=run_job('preflight',path,None,out/'runtime.json',corpus/'runs'/name,120)
  except EvidenceError as error:
   assert stage=='descriptor' and not (corpus/'runs'/name).exists()
   record['negative'][name]={'stage':stage,'reason':str(error),'scientific_verdict':None}
  else:
   assert stage=='native' and r['execution']=='process_error' and r['validity']=='unverified_execution' and r['analysis'] is None
   assert not (corpus/'runs'/name/'native/execution.json').exists()
   result=json.loads((corpus/'runs'/name/'process/result.json').read_text());assert result['returncode']==2
   record['negative'][name]={'stage':stage,'reason':'native_configuration_rejected','scientific_verdict':None}
  print('preflight '+name+' rejected',flush=True)
 (corpus/'corpus.json').write_text(json.dumps(record,indent=2)+'\n')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TIMELEARNER_NATIVE_PREFLIGHT_DIR=str(corpus))
 with (out/'reader-tests.log').open('xb') as log:
  checks=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_native_preflight','Scripts.StructTrain.TimeLearner.tests.test_prepare_native_matrix'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 write('reader-validation.json',{'returncode':checks.returncode,'expected_tests':20,'scientific_verdict':None})
 assert checks.returncode==0 and 'Ran 20 tests' in (out/'reader-tests.log').read_text()
 assert source_closure(source)==closure
 verify_runtime(manifest)
 write('terminal.json',{'execution':'completed','positive_preflights':14,'negative_preflights':6,'one_tick_train_controls':2,'scientific_verdict':None})
 print('preflight corpus completed',flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
