import pathlib,subprocess,json,os,time,sys,traceback,hashlib,tarfile,io
base=pathlib.Path('/home/user/timelearner-refactor');out=pathlib.Path(__file__).resolve().parent
assert out.parent==(base/'readbacks').resolve() and out.name=='s09-native-preflight-normal-a4'
assert {p.name for p in out.iterdir()} <= {'job.py','pid.json','supervisor.log'}
binary_source=base/'source-n1-measured-refinement-normal-a1';repo=base/'source-august-replay-proof-elder-a1'
source=base/'source-native-preflight-reader-a1';revision='f198767189494d7ffb5096afebc14edf858aad55'
def write(name,value):
 with (out/name).open('x',encoding='utf-8') as file:json.dump(value,file,indent=2);file.write('\n')
try:
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',revision],check=True,capture_output=True)
 archive=subprocess.check_output(['git','-C',str(repo),'archive',revision,'Scripts/StructTrain/TimeLearner'])
 source.mkdir(exist_ok=False);code_records=[]
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
  for member in tar.getmembers():
   rel=pathlib.PurePosixPath(member.name);assert not rel.is_absolute() and '..' not in rel.parts
   path=source/member.name;assert path.resolve().is_relative_to(source.resolve())
   if member.isdir():path.mkdir(parents=True,exist_ok=True);continue
   assert member.isfile();raw=tar.extractfile(member).read();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
   code_records.append({'path':member.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 write('code-manifest.json',{'root':revision,'files':code_records})
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 manifest=json.loads((base/'readbacks/s09-native-preflight-normal-a3/runtime.json').read_text());closure=source_closure(binary_source)
 assert closure==manifest['source_closure']
 binary_revision=closure['root']['head']
 def tree(commit):return subprocess.check_output(['git','-C',str(repo),'rev-parse',commit+':App/NeuroModelerConsole'],text=True).strip()
 assert tree(revision)==tree(binary_revision)
 os.environ.update(manifest['loader_environment']);os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['PYTHONDONTWRITEBYTECODE']='1'
 verify_runtime(manifest);write('runtime.json',manifest);write('source.json',{'binary':closure,'analysis_root':revision,'cpp_app_tree':tree(revision)})
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
 from Scripts.StructTrain.TimeLearner.native_evidence import EvidenceError
 corpus=out/'corpus';corpus.mkdir();(corpus/'inputs').mkdir();(corpus/'runs').mkdir()
 originals={}
 pipeline=base/'readbacks/s09-native-pipeline-cli-normal-a2'
 live=base/'readbacks/s09-native-live-training-worker-normal-a2/corpus/runs'
 for topology in ['Classic','Branch']:
  for norm in ['0','1']:
   originals['pipeline-'+topology+'-N'+norm]=pipeline/(topology+'-N'+norm+'-train/input/job.json')
  for mode in ['budget','fixed','grid','legacy-budget','stopped']:
   originals['live-'+topology+'-'+mode]=live/(topology+'-'+mode)/'input/job.json'
 record={'kind':'native_preflight_corpus','schema_version':2,'cooperative_capture':True,'positive':list(originals),'negative':{},'train_controls':{},'sources':{},'scientific_verdict':None}
 for name,path in originals.items():
  raw=path.read_bytes();target=corpus/'inputs'/(name+'.json');target.write_bytes(raw)
  import hashlib
  record['sources'][name]={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest()}
  r=run_job('preflight',target,None,out/'runtime.json',corpus/'runs'/name,120)
  assert r['execution']=='completed' and r['validity']=='valid' and r['analysis']['training_started'] is False
  assert audit_run_manifest(corpus/'runs'/name/'run-manifest.json')['run_evidence_consistent']
  print('preflight '+name+' completed',flush=True)
 for topology in ['Classic','Branch']:
  name='live-'+topology+'-legacy-budget';train='train-'+topology+'-legacy-budget'
  r=run_job('train',corpus/'inputs'/(name+'.json'),None,out/'runtime.json',corpus/'runs'/train,120)
  assert r['execution']=='process_error' and r['validity']=='unverified_execution' and r['analysis'] is None
  e=json.loads((corpus/'runs'/train/'native/execution.json').read_text())
  assert e['execution']=='model_tick_budget_exhausted' and e['model_ticks']==1
  record['train_controls'][topology]={'run':train,'execution':'model_tick_budget_exhausted','scientific_verdict':None}
 import copy
 source_job=json.loads((corpus/'inputs/pipeline-Classic-N1.json').read_text())
 negatives=[('legacy-factor','native',lambda d:d['configuration'].update(SyncTolerance=.02)),
  ('empty-windows','native',lambda d:d['configuration'].update(windows=[])),
  ('frequency-mismatch','native',lambda d:d['configuration']['stimulus_profile'].update(frequency_hz=4000)),
  ('zero-measurement-budget','native',lambda d:d['configuration'].update(maximum_samples=0)),
  ('unsupported-ctrim','descriptor',lambda d:d['optional_modes'].update(sync_capacitance_trim=1)),
  ('wrong-owner','descriptor',lambda d:d.update(owner_class='NNeuronTimeLearnerBogus'))]
 for case,stage,edit in negatives:
  name='invalid-'+case;job=copy.deepcopy(source_job);edit(job);job=_signed({k:v for k,v in job.items() if k!='sha256'})
  path=corpus/'inputs'/(name+'.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
  try:r=run_job('preflight',path,None,out/'runtime.json',corpus/'runs'/name,120)
  except EvidenceError as error:
   assert stage=='descriptor' and not (corpus/'runs'/name).exists()
   record['negative'][name]={'stage':stage,'reason':str(error),'scientific_verdict':None}
  else:
   assert stage=='native' and r['execution']=='process_error' and r['validity']=='unverified_execution' and r['analysis'] is None
   assert not (corpus/'runs'/name/'native/execution.json').exists()
   result=json.loads((corpus/'runs'/name/'process/result.json').read_text());assert result['returncode']==2
   record['negative'][name]={'stage':stage,'reason':'native_configuration_rejected','scientific_verdict':None}
  print('preflight '+name+' rejected',flush=True)
 (corpus/'corpus.json').write_text(json.dumps(record,indent=2)+'\n')
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TIMELEARNER_NATIVE_PREFLIGHT_DIR=str(corpus))
 with (out/'reader-tests.log').open('xb') as log:
  checks=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_native_preflight','Scripts.StructTrain.TimeLearner.tests.test_prepare_native_matrix'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 write('reader-validation.json',{'returncode':checks.returncode,'expected_tests':20,'scientific_verdict':None})
 assert checks.returncode==0 and 'Ran 20 tests' in (out/'reader-tests.log').read_text()
 assert source_closure(binary_source)==closure
 verify_runtime(manifest)
 assert all(hashlib.sha256((source/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in code_records)
 write('terminal.json',{'execution':'completed','positive_preflights':14,'negative_preflights':6,'one_tick_train_controls':2,'scientific_verdict':None})
 print('preflight corpus completed',flush=True)
except BaseException as error:
 write('exception.json',{'error':str(error),'traceback':traceback.format_exc()});raise
