from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,io,shutil,threading,traceback,time
base=Path('/home/user/timelearner-refactor');label='shared-lifecycle-candidate-normal-a1';out=base/('readbacks/s06-'+label);out.mkdir(exist_ok=False);source=base/'source-shared-lifecycle-normal-a1';build=base/'build-shared-lifecycle-normal-a1';runtime=base/'runtime-shared-lifecycle-normal-a1';candidate=base/'source-shared-lifecycle-normal-a1';bootstrap=base/'source-closed-worker-recovery-a3';stop=threading.Event();thread=None;registry=None;token=None;errors=[];passed=False
root='ce52898823e7ab855c313f9d0c1cb43081461517';candidate_root='ce52898823e7ab855c313f9d0c1cb43081461517';capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3}
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'root':root,'candidate_root':candidate_root,'contained_supervisor':str(Path(str(out)+'-container'))});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.contained_process import inspect as inspect_contained
 predecessor=base/'readbacks/s06-shared-lifecycle-baseline-normal-a1';started=time.monotonic()
 while True:
  state=inspect_contained(Path(str(predecessor)+'-container'))
  if state['all_processes_closed']:
   terminal=json.loads((predecessor/'terminal.json').read_text());assert terminal['baseline133_passed'],terminal
   release=Path(str(predecessor)+'-container')/'recovery-event.json';assert release.is_file(), 'baseline operational lease recovery pending'
   write('baseline-prerequisite.json',{'terminal':terminal,'closure':state,'recovery':json.loads(release.read_text())});break
  assert time.monotonic()-started<21600, 'baseline wait budget exhausted'
  write('queue.json',{'reason':'wait_for_exact_baseline133_kernel_closure_and_success','waited_seconds':time.monotonic()-started,'candidate_cpp_executed':False})
  time.sleep(15)
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;assert memory>=10*1024**3 and shutil.disk_usage(base).free>=12*1024**3
 write('resource-preflight.json',{'memory_available_bytes':memory,'disk_free_bytes':shutil.disk_usage(base).free,'worker_memory_max_bytes':8*1024**3,'tasks_max':128,'compilation_disabled':False,'baseline_source_build_runtime_immutable':True,'candidate_cpp_executed':None})
 sys.path.insert(0,str(bootstrap))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=capacity);reservation=registry.reserve('s06-'+label,[{'path':str(v),'access':'write'} for v in [out,source,build,runtime]]+[{'path':str(v),'access':'read'} for v in [bootstrap,base/'source-csearch-threshold-joint-normal-a2',base/'framework-initial-threshold-normal-a4',base/'build-initial-threshold-normal-a4/_deps/llama_cpp-src']],demands={'slots':1,'memory_bytes':8*1024**3,'disk_bytes':8*1024**3},ttl_seconds=120);token=reservation['token'];write('reservation.json',reservation)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert git(source,'rev-parse','HEAD')==root and git(candidate,'rev-parse','HEAD')==candidate_root
 donor=base/'source-csearch-threshold-joint-normal-a2';assert git(donor,'rev-parse','HEAD')=='8021301e894368aefd045f9d77274fcce9f60245'
 children={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  key,path=line.split(None,1);wanted=git(source,'rev-parse','HEAD:'+path);destination=source/path
  assert destination.resolve().is_relative_to(source.resolve()) and not destination.is_symlink()
  if path!='Libraries/Nmsdk-PulseLib':
   origin=donor/path;assert git(origin,'rev-parse','HEAD')==wanted and not git(origin,'status','--porcelain','--untracked-files=no')
   assert not destination.exists() or not any(destination.iterdir()), str(destination)
   destination.mkdir(parents=True,exist_ok=True);subprocess.run(['git','init','--quiet',str(destination)],check=True)
   objects={wanted,git(origin,'rev-parse',wanted+'^{tree}')}
   for entry in subprocess.check_output(['git','-C',str(origin),'ls-tree','-r','-t','-z',wanted]).split(b'\0'):
    if not entry:continue
    meta,name=entry.split(b'\t',1);mode,kind,oid=meta.split()
    if kind==b'tree' or (kind==b'blob' and name.split(b'/',1)[0] not in [b'Docs',b'Reports']):objects.add(oid.decode())
   packet=subprocess.check_output(['git','-C',str(origin),'pack-objects','--stdout'],input=('\n'.join(sorted(objects))+'\n').encode())
   subprocess.run(['git','-C',str(destination),'index-pack','--stdin','--promisor'],input=packet,stdout=subprocess.DEVNULL,check=True)
   (destination/'.git/shallow').write_text(wanted+'\n')
   for setting,value in [('core.repositoryformatversion','1'),('extensions.partialClone','origin'),('remote.origin.promisor','true')]:subprocess.run(['git','-C',str(destination),'config',setting,value],check=True)
   subprocess.run(['git','-C',str(destination),'sparse-checkout','init','--no-cone'],check=True)
   subprocess.run(['git','-C',str(destination),'sparse-checkout','set','--no-cone','/*','!/Docs/','!/Reports/'],check=True)
   subprocess.run(['git','-C',str(destination),'-c','submodule.recurse=false','checkout','--detach',wanted],stdout=subprocess.DEVNULL,check=True)
  assert git(destination,'rev-parse','HEAD')==wanted and not git(destination,'status','--porcelain','--untracked-files=no') and not (destination/'.git/objects/info/alternates').exists()
  children[path]=wanted
 subprocess.run(['git','-C',str(source),'submodule','init'],check=True)
 assert git(source,'ls-tree','-r','HEAD','--','Tests','App','CMakeLists.txt')==git(donor,'ls-tree','-r','HEAD','--','Tests','App','CMakeLists.txt'), 'production tests/App/CMake differ from baseline'
 assert len(children)==7 and not git(source,'status','--porcelain','--untracked-files=no')
 write('source-closure.json',{'root':root,'children':children,'clean':True,'alternates':False,'baseline_sdk_unchanged':True})
 assert not build.exists() and not runtime.exists()
 framework=base/'framework-initial-threshold-normal-a4';vendor=base/'build-initial-threshold-normal-a4/_deps/llama_cpp-src'
 assert git(framework,'rev-parse','HEAD')=='58d77fa8070e8cec2dc1ed015d66b454c8d78850' and git(vendor,'rev-parse','HEAD')=='1971adf55e3ebbfab83771d6174d37b77c352c71'
 def run(arguments,name):
  assert not errors;registry.validate_paths(token)
  with (out/name).open('xb') as log:
   process=subprocess.Popen(list(map(str,arguments)),stdout=log,stderr=subprocess.STDOUT)
   write('owned-'+name+'.json',{'pid':process.pid,'start_ticks':Path('/proc',str(process.pid),'stat').read_text().rsplit(') ',1)[1].split()[19],'arguments':list(map(str,arguments))});status=process.wait()
  assert status==0,(name,status)
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON','-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DRDK_LLM_LLAMA_CPP_DIR='+str(vendor),'-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':list(map(str,args))});run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes());write('build-terminal.json',{'execution':'completed','root':root})
 pulse=candidate/'Libraries/Nmsdk-PulseLib';assert git(pulse,'rev-parse','HEAD')=='8644c50984c45a2211de13a75fe05cffc5bb3154' and not git(pulse,'status','--porcelain','--untracked-files=no')
 specfile=candidate/'Scripts/StructTrain/TimeLearner/specs/native-shared-lifecycle-regression-v1.json';spec=json.loads(specfile.read_text());assert len(spec['expected_test_ids'])==133;write('declaration-source.json',{'root':candidate_root,'spec_sha256':sha(specfile),'candidate_materialized_sdk':True,'candidate_cpp_root':root})
 prefix='Reports/StructTrain/TimeLearner/s08-native-phase-lifecycle-interrupt-normal-a1/';manifest=json.loads(subprocess.check_output(['git','-C',str(candidate),'show',candidate_root+':'+prefix+'manifest.json']));data=subprocess.check_output(['git','-C',str(candidate),'show',candidate_root+':'+prefix+'primary.tar.xz']);assert hashlib.sha256(data).hexdigest()==manifest['archive_sha256']=='490c8c74240efb8d661dc14cd4bb5de653255b0e8513a5a7a3c7a71e71fafe42';records={r['path']:r for r in manifest['files']};seen=set();restored={}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as archive:
  for m in archive:
   assert m.isfile() and m.name not in seen and m.name in records;seen.add(m.name);content=archive.extractfile(m).read();record=records[m.name];assert len(content)==record['bytes'] and hashlib.sha256(content).hexdigest()==record['sha256'];relative=Path(m.name);assert not relative.is_absolute() and '..' not in relative.parts
   if m.name.startswith('fixtures/'):
    path=out/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(content);restored[m.name]={'bytes':len(content),'sha256':record['sha256']}
 assert seen==set(records) and (out/'fixtures/Classic-auto_metric/input/job.json').is_file() and (out/'fixtures/Branch-synthetic/input/job.json').is_file();write('fixture-restoration.json',{'archive_sha256':manifest['archive_sha256'],'origin_root':manifest['source_root'],'all_archive_members_verified':len(seen),'restored':restored})
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 current=snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('native-runtime.json',current)
 os.environ['TIMELEARNER_POSTTUNE_FIXED_SOURCE']=str(out/'fixtures');spec.update(source_root=str(source),runtime_manifest=str(out/'native-runtime.json'),asan_options='');write('native-specification.json',spec)
 result=run_native_gate(out/'native-specification.json',out/'native-result');write('native-verdict.json',result);assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed' and result['inventory']['observed']==result['inventory']['expected']==133;assert not errors;passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 try:
  write('terminal.json',{'candidate133_passed':passed,'candidate_cpp_executed':(out/'native-result').is_dir(),'candidate_build_pending':not (out/'build-terminal.json').is_file(),'whole_plan_complete':False,'scientific_verdict':None})
  hashes={}
  for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Libraries/Nmsdk-PulseLib/Core']:
   for path in (source/prefix).rglob('*'):
    if path.is_file() and path.suffix in ['.cpp','.h','.c']:hashes[path.relative_to(source).as_posix()]=sha(path)
  write('source-hashes.json',hashes);files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.rglob('*') if p.is_file()}
  with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
   for name,record in files.items():
    entry=tarfile.TarInfo(name);entry.size=record['bytes']
    with (out/name).open('rb') as stream:archive.addfile(entry,stream)
  write('bundle.json',{'kind':'shared_lifecycle_actual_candidate_controls','root':root,'candidate_root':candidate_root,'candidate133_passed':passed,'members':files,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'candidate_cpp_executed':None,'scientific_verdict':None})
 finally:
  stop.set()
  if thread:thread.join(timeout=30)
 print('CLOSED',passed,flush=True)
