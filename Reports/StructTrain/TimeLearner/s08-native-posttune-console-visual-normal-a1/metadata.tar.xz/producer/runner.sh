set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-console-report-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1"
src="$out/source"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 4c497f41dae4c9dd3a2c52367ec4384c0d8dfad7 > "$out/checkout.log" 2>&1
mkdir "$src"
git -C "$repo" archive 4c497f41dae4c9dd3a2c52367ec4384c0d8dfad7 Scripts | tar -x -C "$src"
cd "$src"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$base/readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/runs"
export TIMELEARNER_POSTTUNE_RUN_REPORT_DIR="$out/reports"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.__main__ import main
root=Path(os.environ["TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR"])
output=Path(os.environ["TIMELEARNER_POSTTUNE_RUN_REPORT_DIR"])
controls=load(root/"controls.json")["records"]
assert len(controls)==18
rows=[]
for control in controls:
 name=control["name"]
 print("BEGIN",name,flush=True)
 target=output/name
 status=main(["report",str(root/name/"run-manifest.json"),"--format","posttune-run","--output",str(target)])
 assert status==0,(name,status)
 m=load(target/"manifest.json")
 rows.append({"name":name,"trial_soma_pairs":m["trial_soma_pairs"],"weight_matrices":len(m["weight_matrices"]),"run_manifest_sha256":m["run_manifest_sha256"]})
 print("DONE",rows[-1],flush=True)
(Path(os.environ["OUT"])/"validation.json").write_text(json.dumps({"source_root":"4c497f41dae4c9dd3a2c52367ec4384c0d8dfad7","reports":len(rows),"rows":rows,"visual_acceptance_complete":False,"evaluation_verdict":None},indent=2)+"\n")
PY
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_posttune_run_reports Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1
