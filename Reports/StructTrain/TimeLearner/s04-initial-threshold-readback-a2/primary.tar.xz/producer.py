from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,time,traceback
ROOT='1635cc369b0a18a538bb0a3fa6d72d156eb3f578'
base=Path('/home/user/timelearner-refactor')
prior=base/'readbacks/s04-initial-threshold-normal-a1'
out=base/'readbacks/s04-initial-threshold-readback-a2';out.mkdir(parents=True,exist_ok=False)
source=base/'source-initial-threshold-normal-a1';runtime=base/'runtime-initial-threshold-normal-a1'
build=base/'build-initial-threshold-normal-a1'
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(record):
 try:return ticks(record['pid'])==record['start_ticks']
 except FileNotFoundError:return False
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT,'build_reused_without_mutation':True})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 owner=json.loads((prior/'owned-supervisor.json').read_text())
 deadline=time.monotonic()+14400
 while live(owner):
  assert time.monotonic()<deadline,'original build owner still live after wait budget'
  write('wait.json',{'execution':'waiting','pid':owner['pid'],'start_ticks':owner['start_ticks'],'reason':'do not disturb original build or publication'})
  time.sleep(15)
 assert (prior/'build-terminal.json').exists(),'original build did not finish; inspect its preserved failure'
 original=json.loads((prior/'exception.json').read_text())
 assert "cannot import name 'run'" in original['reason'],'unexpected original failure; no automatic retry'
 assert not (prior/'native-result').exists(),'original numerical state is not the declared pre-import failure'
 write('prerequisite.json',{'root':ROOT,'original_build_completed':True,'original_numerical_tests':0,
       'original_exception':original,'native_rerun':False,'source_runtime_mutated':False})
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.runtime import snapshot,source_closure
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 from Scripts.StructTrain.TimeLearner.stock_phasea_preflight import run_stock_preflight
 assert source_closure(source)['root']['head']==ROOT
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ('LD_LIBRARY_PATH','QT_PLUGIN_PATH'):os.environ.pop(key,None)
 write('native-runtime.json',snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 write('console-runtime.json',snapshot(source,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 spec=json.loads((source/'Scripts/StructTrain/TimeLearner/specs/native-initial-threshold-v1.json').read_text())
 assert len(spec['expected_test_ids'])==14
 spec.update(runtime_manifest=str(out/'native-runtime.json'),source_root=str(source),asan_options='')
 write('native-specification.json',spec)
 args=['python3','-m','Scripts.StructTrain.TimeLearner','native-gate',str(out/'native-specification.json'),'--output',str(out/'native-result')]
 with (out/'native-stdout.log').open('xb') as so,(out/'native-stderr.log').open('xb') as se:
  child=subprocess.Popen(args,cwd=source,stdout=so,stderr=se)
  write('owned-native-cli.json',{'pid':child.pid,'start_ticks':ticks(child.pid),'arguments':args});rc=child.wait()
 native=json.loads((out/'native-result/result.json').read_text())
 assert rc==0 and native['execution']=='completed' and native['validity']=='valid' and native['assertion_status']=='passed'
 bundle=out/'source-calibration';bundle.mkdir()
 prefix='Reports/StructTrain/TimeLearner/s08-positive-n1-calibration-normal-a1/'
 for name in ['README.md','manifest.json','SHA256SUMS.json','primary.tar.xz']:
  (bundle/name).write_bytes(subprocess.check_output(['git','-C',str(source),'show',ROOT+':'+prefix+name]))
 run_stock_preflight(bundle,out/'console-runtime.json',out/'preflight100',initial_threshold=100.)
 # All four stock/feedback checks and three schema2/readback checks use real data.
 count,fingerprint=fixture_fingerprint(out/'preflight100','**/*.*')
 tests={'test_stock_phasea_preflight.StockPhaseAPreflightTest':[
       'test_both_actual_native_graphs_have_the_declared_original_physics_without_calculation',
       'test_modified_integration_fixture_cannot_claim_the_stock_scientific_profile',
       'test_rehashed_channel_and_synapse_drift_are_rejected','test_rehashed_changed_spike_feedback_path_is_rejected'],
       'test_native_model_spec.NativeModelSpecTest':[
       'test_both_actual_native_construction_values_and_full_physics_are_bound',
       'test_schema_downgrade_unknown_factor_and_invalid_scalar_cannot_be_ignored',
       'test_rehashed_effective_threshold_mismatch_is_rejected']}
 prefix='Scripts.StructTrain.TimeLearner.tests.'
 bindings={key:str(out/'preflight100') for key in ['TIMELEARNER_INITIAL_THRESHOLD_PREFLIGHT','TIMELEARNER_STOCK_PHASEA_PREFLIGHT']}
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'native-initial-threshold-stock7',
       'package_fingerprint':package_fingerprint(),'modules':[prefix+k.rsplit('.',1)[0] for k in tests],
       'expected_test_ids':[prefix+k+'.'+n for k,methods in tests.items() for n in methods],
       'fixtures':{key:{'pattern':'**/*.*','files':count,'fingerprint':fingerprint} for key in bindings}}
 write('reader-specification.json',spec)
 reader=run_suite(spec,bindings,out/'reader-result')
 assert reader['assertion_status']=='passed' and reader['executed_tests']==7 and not any(reader[k] for k in ['errors','failures','skipped'])
 write('source-after.json',source_closure(source))
 passed=True;write('terminal.json',{'execution':'completed','acceptance_status':'passed','native_tests':14,'native_preflights':2,
       'readers':7,'training_performed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'native_initial_threshold_readback','schema_version':1,'root':ROOT,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),
       'build_reused_without_mutation':True,'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(source),*a],input=raw,env=env).decode().strip()
 pg('config','user.name','TimeLearner Evidence');pg('config','user.email','timelearner@localhost')
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s04-initial-threshold-readback-a2'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: initial threshold native14 stock preflight and strict reader7\n')
 branch='refs/heads/codex/evidence-s04-initial-threshold-readback-a2'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
