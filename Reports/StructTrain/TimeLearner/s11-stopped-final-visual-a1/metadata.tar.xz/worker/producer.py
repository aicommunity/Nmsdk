from pathlib import Path
import os,sys,json,subprocess,hashlib,shutil,traceback,time
venv='/media/user/Data/TimeLearnerRefactor/plot-venv-a1'
if sys.prefix!=venv:os.execv(venv+'/bin/python',[venv+'/bin/python',str(Path(__file__))])
base=Path('/media/user/Data/TimeLearnerRefactor');source=base/'source-stopped-final-diagnostics-a2';raw=base/'ReportsCache/stopped-final-native-elder-a1-reader-a2/source';out=base/'readbacks/s11-stopped-final-visual-a1';out.mkdir(exist_ok=False);cache=base/'ReportsCache/stopped-final-visual-a1';cache.mkdir(exist_ok=False);inputs=cache/'inputs';inputs.mkdir();reports=cache/'reports';reports.mkdir()
sys.dont_write_bytecode=True;sys.path.insert(0,str(source));os.nice(19)
os.environ.update(MPLCONFIGDIR=str(cache/'matplotlib'),MPLBACKEND='Agg',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
from Scripts.StructTrain.TimeLearner.probe_reports import render_probe_set
from Scripts.StructTrain.TimeLearner.native_evidence import load
from PIL import Image
r=Reservations(base/'report-reservations.sqlite3');token=None;passed=False;selected=[];rows=[];views=0;pairs=0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'native_models_executed':0});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='297bcbb42105396d83c3eecf52ad98613afaef0f'
 lease=r.reserve(out.name,[{'path':str(out),'access':'write'},{'path':str(cache),'access':'write'},{'path':str(source),'access':'read'},{'path':str(raw),'access':'read'}],ttl_seconds=18000);token=lease['token'];write('reservation.json',lease)
 before={p.relative_to(raw).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in raw.rglob('*') if p.is_file()};assert len(before)==116;write('source-inventory.json',before)
 descriptors=sorted((raw/'native-result').glob('*.inputs.json'));assert len(descriptors)==4
 for descriptor in descriptors:
  case=descriptor.name.removesuffix('.inputs.json');dest=inputs/case;dest.mkdir();trials=[]
  for index,trial in enumerate(load(descriptor)['trials']):
   paths={}
   for key in ['packet','trace']:
    original=descriptor.parent/trial[key];assert original.resolve().is_relative_to(raw.resolve());copy=dest/original.name;shutil.copyfile(original,copy);assert sha(copy)==sha(original);paths[key]=copy.name
   packet=load(dest/paths['packet']);paths['trial_id']=packet['observation']['specification']['trial_id'];trials.append(paths)
  spec={'kind':'timelearner_probe_report_spec','schema_version':1,'trials':trials};(dest/'report-spec.json').write_text(json.dumps(spec,indent=2)+'\n');target=reports/case;print('RENDER',case,flush=True)
  result=render_probe_set(dest/'report-spec.json',target);assert result['trials']==8;pairs+=result['trial_soma_pairs'];manifest=load(target/'manifest.json');assert len(manifest['reports'])==8
  sums=load(target/'SHA256SUMS.json');assert set(sums)=={p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'}|{p.relative_to(target).as_posix() for p in target.rglob('SHA256SUMS.json') if p.parent!=target}
  for name,h in sums.items():assert sha(target/name)==h
  for index,entry in enumerate(manifest['reports']):
   assert entry['trial_id']==trials[index]['trial_id'];folder=target/entry['folder'];pm=load(folder/'manifest.json');assert (folder/'primary/probe.json').read_bytes()==(dest/trials[index]['packet']).read_bytes();assert (folder/'primary/trace.csv').read_bytes()==(dest/trials[index]['trace']).read_bytes()
   for fig in pm['figures']:
    assert any(v['time_view']!='overview' for v in fig['views'])
    for view in fig['views']:
     assert view['downsampling'] is False
     if view['time_view']!='overview':assert view['minimum_native_tick_pixels_on_zoom']>=8
     png,svg,pdf=[folder/n for n in view['files']]
     with Image.open(png) as im:assert im.size==(1920,960)
     assert 'Actual shared input' in svg.read_text() and pdf.read_bytes().startswith(b'%PDF-');views+=1
    if index>=6:
     chosen=[next(v for v in fig['views'] if v['time_view']=='overview'),next(v for v in fig['views'] if v['time_view']!='overview')]
     for view in chosen:selected.append({'case':case,'trial_id':entry['trial_id'],'channel':fig['channel'],'time_view':view['time_view'],'png':(folder/view['files'][0]).relative_to(cache).as_posix(),'sha256':sha(folder/view['files'][0]),'manual_review_complete':False})
  rows.append({'case':case,'result':result,'common_y_limits':manifest['common_y_limits']});write('progress.json',rows);r.heartbeat(token,ttl_seconds=18000)
 assert pairs==48 and len(selected)==24
 after={p.relative_to(raw).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in raw.rglob('*') if p.is_file()};assert before==after
 # Negative production controls: duplicate IDs and absent trace must refuse before output creation.
 specpath=inputs/rows[0]['case']/'report-spec.json';original=load(specpath)
 for label,mutation in [('duplicate',lambda s:s['trials'].append(dict(s['trials'][0]))),('missing',lambda s:s['trials'][0].update(trace='absent.csv'))]:
  spec=json.loads(json.dumps(original));mutation(spec);bad=specpath.parent/(label+'.json');bad.write_text(json.dumps(spec));badout=cache/('negative-'+label)
  try:render_probe_set(bad,badout)
  except (ValueError,FileNotFoundError):pass
  else:raise AssertionError('negative accepted '+label)
  assert not badout.exists()
 write('selection.json',{'images':selected,'manual_review_complete':False});write('coverage.json',{'cases':4,'trials':32,'trial_soma_pairs':pairs,'views':views,'source_members_unchanged':116,'selected_images':len(selected),'native_models_executed':0,'scientific_verdict':None,'engineering_two_input_LTMembrane':True,'spike_capture':'unknown_not_recorded','checks':['source_identity_and_immutability','all_trial_soma_coverage','lossless_primary_copies','checksums_and_readable_scale_actual_input','duplicate_and_missing_negative_controls']});passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 if token:r.release(token,note='Read-only plotting worker ended, native models not executed.');write('reservation-final.json',r.inspect())
 write('terminal.json',{'report_and_checks_passed':passed,'native_models_executed':0,'source_commit':'297bcbb42105396d83c3eecf52ad98613afaef0f','primary_evidence_commit':'d080310f241c994bca1231cbb38a3cb290ca2f36','cache':str(cache),'manual_visual_review_complete':False,'scientific_verdict':None});print('CLOSED',passed,flush=True)
