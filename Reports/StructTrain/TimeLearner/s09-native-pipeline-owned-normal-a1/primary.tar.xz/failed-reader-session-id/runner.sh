set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s09-native-pipeline-cli-normal-a1
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd /home/user/timelearner-refactor/source-native-pipeline-cli-normal-a1
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
python3 - <<'PY' > "$out/validation.log" 2>&1
import copy,json,subprocess,sys
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load,EvidenceError
from Scripts.StructTrain.TimeLearner.model_identity import canonical_model_sha256 as sha
from Scripts.StructTrain.TimeLearner.native_pipeline_worker import audit_run_manifest
base=Path('/home/user/timelearner-refactor/readbacks')
native=base/'s09-native-pipeline-normal-a1';out=base/'s09-native-pipeline-cli-normal-a1'
assert (native/'process-exit-status.txt').read_text().strip()=='0'
runtime=native/'runtime-before.json'
def run(mode,job,folder,source=None):
 job.pop('sha256',None);job['sha256']=sha(job);path=out/(folder.name+'-job.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
 command=[sys.executable,'-m','Scripts.StructTrain.TimeLearner',mode,str(path),'--runtime-manifest',str(runtime),
          '--wall-seconds','600','--output',str(folder)]
 if source:command.extend(('--source-solo',str(source)))
 with (out/(folder.name+'.stdout.log')).open('wb') as stdout,(out/(folder.name+'.stderr.log')).open('wb') as stderr:
  result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=660)
 assert result.returncode==0,(folder.name,result.returncode)
 audit=audit_run_manifest(folder/'run-manifest.json');assert audit['run_evidence_consistent'] is True
 return load(folder/'run-manifest.json')
results=[]
for case in ('Classic-N0','Classic-N1','Branch-N0','Branch-N1'):
 train=out/(case+'-train');t=run('train',load(native/(case+'-train-job.json')),train)
 source=train/'native/train_learned_state.json'
 ej=load(native/(case+'-export-job.json'));ej['source_solo']=load(source)
 export=out/(case+'-export');e=run('export',ej,export,source)
 vj=load(native/(case+'-evaluate-job.json'));vj['source_recognition']=load(export/'native/model.json')
 evaluate=out/(case+'-evaluate');v=run('evaluate',vj,evaluate,source)
 results.append({'case':case,'training_outcome':t['analysis']['training_outcome'],'frozen_metrics':v['analysis']['metrics']})
 print(case,'owned train/export/evaluate and portable audit passed',flush=True)
(out/'validation.json').write_text(json.dumps({'reader_root':'27fc5e3d6eef5ea33f10556d22fd921476b41067','native_cases':4,
 'owned_native_phases':12,'portable_audits':12,'results':results,'scientific_verdict':None},indent=2)+'\n')
PY
