set -euo pipefail
out=/home/user/timelearner-refactor/readbacks/s02-runtime-duplicate-cleanup-a2
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
OUT="$out" python3 - <<'PY' > "$out/cleanup.log" 2>&1
import hashlib,json,os,shlex,shutil
from pathlib import Path
base=Path('/home/user/timelearner-refactor').resolve();out=Path(os.environ['OUT'])
def active():
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if p.stat().st_uid!=os.getuid():continue
   args=(p/'cmdline').read_bytes().split(b'\0');exe=(p/'exe').resolve(strict=True)
   if (str(exe).startswith(str(base)+'/runtime-') and ('Console' in exe.name or exe.name.startswith('Test_'))) or (
      exe.name in ('cmake','make','gmake','ninja','ar','ranlib','c++','g++','cc1plus') and
      (p/'cwd').resolve(strict=True).is_relative_to(base)):
    found.append({'pid':int(p.name),'executable':str(exe),'arguments':[a.decode(errors='replace') for a in args if a]})
  except (FileNotFoundError,ProcessLookupError):pass
 return found
live=active();assert not live,live
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as stream:
  for raw in iter(lambda:stream.read(1024*1024),b''):h.update(raw)
 return h.hexdigest()
by_inode={};candidates=[]
for runtime in sorted(base.glob('runtime-*')):
 if not runtime.is_dir() or runtime.is_symlink():continue
 library=runtime/'Lib.CMake'
 if not library.is_dir():continue
 for p in sorted(library.glob('*.a')):
  assert not p.is_symlink() and p.resolve().is_relative_to(base)
  st=p.stat();key=(st.st_dev,st.st_ino)
  if key not in by_inode:by_inode[key]=digest(p)
  candidates.append({'path':str(p),'bytes':st.st_size,'device':st.st_dev,'inode':st.st_ino,'links':st.st_nlink,'sha256':by_inode[key]})
(out/'inventory.json').write_text(json.dumps({'root':str(base),'files':candidates,'active_owned_processes':live},indent=2)+'\n')
groups={}
for record in candidates:groups.setdefault((record['bytes'],record['sha256']),[]).append(record)
before=shutil.disk_usage(base).free;changed=[]
for group in groups.values():
 canonical=max(group,key=lambda r:r['links']);source=Path(canonical['path'])
 for record in group:
  p=Path(record['path']);s=source.stat();st=p.stat()
  if (st.st_dev,st.st_ino)==(s.st_dev,s.st_ino):continue
  assert st.st_dev==s.st_dev
  assert not active(),'owned native process or build started; no further edits'
  assert p.resolve().is_relative_to(base) and source.resolve().is_relative_to(base)
  assert digest(p)==digest(source)==record['sha256']
  temporary=p.with_name(p.name+'.verified-duplicate-link-a2');assert not temporary.exists()
  os.link(source,temporary)
  current=p.stat();assert (current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns)==(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
  os.replace(temporary,p)
  assert p.stat().st_ino==source.stat().st_ino
  changed.append({'path':str(p),'canonical':str(source),'bytes':st.st_size,'old_links':st.st_nlink,'sha256':record['sha256']})
  print(str(p),'verified duplicate hardlinked',flush=True)
receipt={'kind':'timelearner_verified_inactive_static_runtime_deduplication','schema_version':1,
 'inventory_files':len(candidates),'unique_inodes_before':len(by_inode),'changed':changed,
 'free_bytes_before':before,'free_bytes_after':shutil.disk_usage(base).free,
 'source_and_result_files_deleted':False,'native_executables_changed':False}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='changed'}),flush=True)
PY
