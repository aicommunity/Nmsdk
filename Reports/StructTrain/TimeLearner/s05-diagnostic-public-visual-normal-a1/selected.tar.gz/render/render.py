
import pathlib,json,hashlib,tarfile,io,subprocess,os,sys,time,unittest,traceback
base=pathlib.Path('/media/user/Data/TimeLearnerRefactor');repo=base/'source-legacy-completed-replay-asan-a1';out=base/'readbacks/s05-diagnostic-public-visual-m40-a1'
start=time.monotonic()
try:
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit() or p.name==str(os.getpid()):continue
  try:
   if p.stat().st_uid==os.getuid():
    cwd=(p/'cwd').resolve();assert cwd!=repo and repo not in cwd.parents,('active_python_checkout_user',p.name)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--untracked-files=no'],text=True).strip()
 sha='4c42d90ee61a4b0a9583f36744972ef58f0c5531'
 with (out/'setup.log').open('x') as log:
  for args in [['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',sha],['git','-C',str(repo),'-c','submodule.recurse=false','checkout','--detach','FETCH_HEAD']]:subprocess.run(args,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 prefix='Reports/StructTrain/TimeLearner/s05-diagnostic-public-normal-a1/'
 def blob(n):return subprocess.check_output(['git','-C',str(repo),'show',sha+':'+prefix+n])
 b=json.loads(blob('bundle.json'));archive=blob('primary.tar.gz');assert hashlib.sha256(archive).hexdigest()==b['archive_sha256']
 inputs=base/'report-inputs/s05-diagnostic-public-normal-a1';inputs.mkdir(exist_ok=False)
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  assert set(tar.getnames())==set(b['members'])
  for n,h in b['members'].items():
   member=tar.getmember(n);assert member.isfile()
   target=inputs/n;assert target.resolve().is_relative_to(inputs.resolve())
   raw=tar.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==h
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 source=inputs/'public6/result';cache=base/'report-cache/s05-diagnostic-public-normal-a1';cache.mkdir(exist_ok=False)
 sys.path.insert(0,str(repo));from Scripts.StructTrain.TimeLearner.live_pipeline_reports import render_pipeline_run
 results={}
 for topology in ('Classic','Branch'):
  for status in ('completed','interrupted'):
   name=topology+'-'+status
   results[name]=render_pipeline_run(source/'runs'/name/'run-manifest.json',cache/name)
 os.environ['TIMELEARNER_DIAGNOSTIC_PIPELINE_DIR']=str(source)
 os.environ['TIMELEARNER_DIAGNOSTIC_PIPELINE_REPORTS']=str(cache)
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in ('test_diagnostic_pipeline','test_diagnostic_pipeline_reports'))
 with (out/'unittest.log').open('x') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 result={'execution':'completed','reader':sha,'numeric_root':b['numeric_root'],'source_evidence':'480c7683fb91c237d420f441693cd80a2190f3b2','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'successful':r.wasSuccessful(),'reports':4,'observed_trial_soma_pairs':sum(v['recognition_trial_soma_pairs'] for v in results.values()),'png_files':len(list(cache.rglob('*.png'))),'elapsed_wall_seconds':time.monotonic()-start,'visual_acceptance_complete':False,'scientific_verdict':None}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 (out/'error.log').write_text(traceback.format_exc());raise
