from pathlib import Path
import json,os,sys,time,hashlib,traceback,tarfile,contextlib
base=Path('/home/user/timelearner-refactor');sdk=base/'source-initial-threshold-normal-a4'
out=base/'readbacks/s02-native-event-calibration-normal-a1';out.mkdir(exist_ok=False)
prior=base/'readbacks/s05-model-spec-production-normal-a4';gate=base/'readbacks/s02-native-event-log-normal-a3'
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def inv(root):return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid())})
passed=False;before=None
try:
 owner=json.loads((gate/'owned-supervisor.json').read_text());write('waiting-for.json',owner)
 while live(owner):time.sleep(10)
 assert json.loads((gate/'terminal.json').read_text())['status']=='passed'
 sys.path.insert(0,str(sdk));os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.__main__ import main as cli
 from Scripts.StructTrain.TimeLearner.native_calibration_worker import audit_run_manifest
 manifest=json.loads((gate/'runtime.json').read_text());runtime=Path(manifest['executable']['path']).parent
 before=inv(runtime);write('runtime-before.json',before);rows=[]
 for name in ['Classic-v1','Classic-v2','Branch-v1','Branch-v2']:
  job=prior/'corpus/jobs'/(name+'-calibrate.json');source=prior/'corpus/runs'/(name+'-train')/'native/train_learned_state.json';folder=out/name
  with (out/(name+'.log')).open('x') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
   rc=cli(['calibrate','run',str(job),'--source-solo',str(source),'--runtime-manifest',str(gate/'runtime.json'),'--wall-seconds','1800','--output',str(folder)])
  assert rc==0,(name,rc)
  audit=audit_run_manifest(folder/'run-manifest.json');assert audit['run_evidence_consistent']
  original=prior/'corpus/runs'/(name+'-calibrate')/'native'
  for n in ['job.json','model.json','transaction.json']:
   assert json.loads((folder/'native'/n).read_text())==json.loads((original/n).read_text()),(name,n)
  rows.append({'name':name,'model_and_full_transaction_equal_original':True,'audit':audit});write('completed-'+name+'.json',rows[-1])
 write('calibration-cases.json',rows);passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 if before is not None:
  after=inv(runtime);write('runtime-after.json',after);passed=passed and after==before
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','scientific_verdict':None})
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()}
 records={n:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 write('bundle.json',{'kind':'native_event_log_calibration_validation','root':'b3bfe86e913bc1f7aeb5a340a72698eacb060f00','rdk':'0e70cf07ddc52f6af81ac0b291e299434925319c','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
