from pathlib import Path
import os,sys,json,subprocess,hashlib,shutil,time,traceback,stat
base=Path('/home/user/timelearner-refactor');out=base/'readbacks/s02-obsolete-schema4-j3-build-cache-a1';out.mkdir(exist_ok=False);sys.path.insert(0,str(base/'source-worker-dependency-normal-a2'));os.nice(15)
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'maintenance-reservations.sqlite3');global_registry=Reservations(base/'resource-reservations.sqlite3',capacity={'slots':1,'memory_bytes':24*1024**3,'disk_bytes':14*1024**3});token=None;deleted=[];passed=False
roots=[base/'build-capacitance-schema4-normal-j3']
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.PIPE).decode().strip()
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'role':'only obsolete generated build/vendor cache, no experiment runtime/source/result deletion'});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 launch=json.loads(os.environ.get('TIMELEARNER_OWNED_LAUNCH_ANCESTORS','{}'));launch[str(os.getpid())]=Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]
 for d in roots:
  assert d.parent.resolve()==base.resolve() and d.resolve()==d and not d.is_symlink() and d.name in ['build-capacitance-schema4-normal-j3']
 held=[r for l in global_registry.inspect()['leases'] if l['state']=='held' for r in l['resources']]
 for d in roots:
  for r in held:
   q=Path(r['canonical_path']);assert not d.is_relative_to(q) and not q.is_relative_to(d),r
 write('global-resource-disjointness.json',{'held_resources':held,'old_builds_overlap':False,'global_capacity_or_slots_changed':False})
 lease=registry.reserve(out.name,[{'path':str(p),'access':'write'} for p in roots]+[{'path':str(out),'access':'write'}],ttl_seconds=3600);token=lease['token'];write('reservation.json',lease)
 plans=[];preserved={}
 canonical=base/'build-initial-threshold-normal-a4/_deps/llama_cpp-src';canonical_head=git(canonical,'rev-parse','HEAD');assert canonical_head=='1971adf55e3ebbfab83771d6174d37b77c352c71'
 for d in roots:
  cache=d/'CMakeCache.txt';values={l.split('=',1)[0].split(':',1)[0]:l.split('=',1)[1] for l in cache.read_text().splitlines() if not l.startswith(('#','//')) and '=' in l}
  deploy=Path(values['NMSDK_DEPLOY_ROOT']).resolve();resources=Path(values['NMSDK_RESOURCE_ROOT']).resolve();source=Path(values['CMAKE_HOME_DIRECTORY']).resolve()
  assert all(p.exists() and not p.is_relative_to(d) and not d.is_relative_to(p) for p in [deploy,resources,source])
  for name in ['CMakeCache.txt','compile_commands.json']:
   p=d/name
   if p.exists():(out/(d.name+'-'+name)).write_bytes(p.read_bytes())
  vendor=d/'_deps/llama_cpp-src';assert git(vendor,'rev-parse','HEAD')==canonical_head
  assert not git(vendor,'status','--porcelain','--untracked-files=all','--ignore-submodules=none') and not git(vendor,'stash','list')
  refs=git(vendor,'show-ref');gits=[]
  for cur,dirs,files in os.walk(d,followlinks=False):
   for name in list(dirs):
    p=Path(cur,name)
    if name=='.git':gits.append(str(p));dirs.remove(name)
   # Exclude only Git internals here; these will be present in the full cache inventory below.
  assert all(Path(p).is_relative_to(d/'_deps') for p in gits),gits
  for g in [vendor/'.git']+(list((vendor/'.git/modules').rglob('HEAD')) if (vendor/'.git/modules').exists() else []):
   gd=g.parent if g.name=='HEAD' else g
   if not (gd/'objects').is_dir() or not (gd/'config').is_file():continue
   result=subprocess.run(['git','--git-dir',str(gd),'show-ref','--verify','--quiet','refs/stash']);assert result.returncode==1,('stash_or_invalid_git_dir',str(gd))
  possible=[];inventory=[];bytes_total=0
  for cur,dirs,files in os.walk(d,followlinks=False):
   for n in files:
    p=Path(cur,n);rel=p.relative_to(d);s=p.lstat()
    if stat.S_ISLNK(s.st_mode):inventory.append({'path':str(rel),'symlink':os.readlink(p)});continue
    assert stat.S_ISREG(s.st_mode)
    if '_deps' not in rel.parts and 'CMakeFiles' not in rel.parts and p.suffix in ['.csv','.json','.xml','.ini','.xz','.gz'] and n!='compile_commands.json':possible.append(str(rel))
    inventory.append({'path':str(rel),'bytes':s.st_size,'sha256':sha(p)});bytes_total+=s.st_size
  assert not possible,('potential_primary_data_outside_build_metadata',possible)
  # Save only metadata identity; complete runtime/resource bytes remain in their existing directories.
  runtime_hashes={str(p.relative_to(deploy)):sha(p) for p in deploy.rglob('*') if p.is_file() and not p.is_symlink()};preserved[str(deploy)]=runtime_hashes
  plans.append({'build':str(d),'source_retained':str(source),'resources_retained':str(resources),'runtime_retained':str(deploy),'bytes_in_cache':bytes_total,'vendor_head':canonical_head,'same_vendor_tree_as_retained_build':str(canonical),'vendor_refs':refs,'vendor_stash_empty':True,'potential_experiment_data_outside_vendor_or_CMake':possible,'file_inventory':inventory})
 write('deletion-plan.json',{'roots':plans,'scope':'reproducible obsolete build products and clean third-party fetch cache; no source SDK/runtime/results','all_files_hashed_before_deletion':True})
 write('runtime-before.json',preserved)
 nonce=__import__('uuid').uuid4().hex
 write('ready-for-readonly-process-audit.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'nonce':nonce,'targets':[str(p) for p in roots]})
 started=time.monotonic();audit=out/'readonly-process-audit.json'
 while not audit.exists():
  assert time.monotonic()-started<180,'read-only process audit not delivered'
  time.sleep(1)
 def verify_audit():
  v=json.loads(audit.read_text());assert audit.stat().st_uid==0
  assert v['nonce']==nonce and v['worker_pid']==os.getpid() and v['worker_start_ticks']==Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]
  assert v['targets']==[str(p) for p in roots] and v['safe'] and not v['references'] and not v['read_errors']
  assert 0<=time.time()-v['completed_unix_seconds']<=60
  held=[r for l in global_registry.inspect()['leases'] if l['state']=='held' for r in l['resources']]
  for d in roots:
   for r in held:
    q=Path(r['canonical_path']);assert not d.is_relative_to(q) and not q.is_relative_to(d)
  registry.validate_paths(token)
 verify_audit()
 before=shutil.disk_usage(base).free
 for d in roots:
  assert d.resolve()==d and d.parent==base and (d/'CMakeCache.txt').exists();verify_audit();shutil.rmtree(d);deleted.append(str(d));write('deleted-builds.json',deleted)
 for runtime,expected in preserved.items():
  d=Path(runtime);actual={str(p.relative_to(d)):sha(p) for p in d.rglob('*') if p.is_file() and not p.is_symlink()};assert actual==expected,runtime
 passed=True;write('result.json',{'free_before':before,'free_after':shutil.disk_usage(base).free,'deleted_builds':deleted,'runtime_content_unchanged':True,'source_sdk_or_resources_deleted':False,'primary_models_logs_results_deleted':False,'new_native_models_executed':0})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 if token:registry.release(token,note='Synchronous obsolete build-cache cleanup ended; no model, compiler or child process remains. Source SDK/runtime/results retained.');write('reservation-final.json',registry.inspect())
 write('terminal.json',{'cleanup_passed':passed,'deleted_builds':deleted,'whole_plan_complete':False,'scientific_verdict':None});print('CLOSED',passed,flush=True)
