set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-owned-posttune-worker-visual-asan-a1"
repo="$base/source-training-intent-binding-reader-asan-a1"
work="$base/source-owned-posttune-worker-visual-asan-a1"
producer="$base/readbacks/s08-native-owned-posttune-worker-asan-a1"
reader="$base/readbacks/s08-native-owned-posttune-worker-reader-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$reader/process-exit-status.txt")" = 0
git -C "$repo" -c fetch.recurseSubmodules=false fetch origin 504d6fac3be225102079541dc94a5a8f37fa9381 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" 504d6fac3be225102079541dc94a5a8f37fa9381 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_OWNED_WORKER_CORPUS="$producer/corpus"
export TIMELEARNER_OWNED_WORKER_REPORTS="$base/cache/s08-native-owned-posttune-worker-asan-a1"
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$producer/corpus/runs"
export TIMELEARNER_POSTTUNE_RUN_REPORT_DIR="$TIMELEARNER_OWNED_WORKER_REPORTS/posttune"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import hashlib,json,os,time,unittest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.posttune_transaction_reports import render_posttune_run
from Scripts.StructTrain.TimeLearner.calibration_transaction_reports import render_calibration_transaction
corpus=Path(os.environ['TIMELEARNER_OWNED_WORKER_CORPUS']);cache=Path(os.environ['TIMELEARNER_OWNED_WORKER_REPORTS'])
assert not cache.exists();cache.mkdir(parents=True)
def inventory():return {p.relative_to(corpus).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(corpus.rglob('*')) if p.is_file()}
before=inventory();start=time.monotonic();reports=[]
for control in load(corpus/'runs/controls.json')['records']:
 name=control['name'];source=corpus/'runs'/name/'run-manifest.json';output=cache/'posttune'/name
 result=render_posttune_run(source,output)
 reports.append({'kind':'posttune_run','source':source.relative_to(corpus).as_posix(),'source_file_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output':output.relative_to(cache).as_posix(),'result':result})
 print('RENDERED',name,flush=True)
for top in ('Classic','Branch'):
 name=top+'-fixed';source=corpus/'fixed-runs'/name/'run-manifest.json';output=cache/'fixed'/name
 result=render_posttune_run(source,output)
 reports.append({'kind':'posttune_run','source':source.relative_to(corpus).as_posix(),'source_file_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output':output.relative_to(cache).as_posix(),'result':result})
 print('RENDERED',name,flush=True)
 for case in ('success','nonseparable','budget'):
  name=top+'-'+case;source=corpus/'calibration-regressions'/name/'transaction.json';output=cache/'calibration'/name
  result=render_calibration_transaction(source,output)
  reports.append({'kind':'calibration_transaction','source':source.relative_to(corpus).as_posix(),'source_file_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output':output.relative_to(cache).as_posix(),'result':result})
  print('RENDERED',name,flush=True)
index={'kind':'owned_console_temporal_report_index','schema_version':1,'reports':reports,'visual_acceptance_complete':False,'scientific_verdict':None}
(cache/'render-index.json').write_text(json.dumps(index,indent=2)+'\n')
rows=[]
for module,count in [('test_posttune_run_reports',3),('test_owned_posttune_worker_reports',2)]:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+module))
 rows.append({'module':module,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
 assert result.wasSuccessful() and result.testsRun==count and not result.skipped,rows[-1]
assert inventory()==before
summary={'kind':'owned_console_temporal_report_gate','schema_version':1,'modules':rows,'seconds':time.monotonic()-start,'reports':reports,'source_files_unchanged':len(before),'cache':str(cache),'cache_files':sum(p.is_file() for p in cache.rglob('*')),'cache_bytes':sum(p.stat().st_size for p in cache.rglob('*') if p.is_file()),'visual_acceptance_complete':False,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'modules':rows,'seconds':summary['seconds'],'cache_files':summary['cache_files'],'cache_bytes':summary['cache_bytes']}),flush=True)
PY
