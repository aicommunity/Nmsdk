from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,time,traceback
ROOT='74369ef343ec577e301c63f4c9ad6b0dabd2b935'
base=Path('/home/user/timelearner-refactor')
repo=base/'source-initial-threshold-normal-a1'
prior=base/'readbacks/s04-initial-threshold-normal-a3'
out=base/'readbacks/s07-stock-threshold-pair-normal-a1';out.mkdir(parents=True,exist_ok=False)
source=base/'code-stock-threshold-pair-normal-a1';source.mkdir(exist_ok=False)
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False
try:
 subprocess.run(['git','-C',str(repo),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],check=True)
 raw=subprocess.check_output(['git','-C',str(repo),'archive',ROOT,'Scripts/StructTrain/TimeLearner'])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(source)
 owner=json.loads((prior/'owned-supervisor.json').read_text());assert owner['pid']==994687
 deadline=time.monotonic()+15000
 while live(owner):
  assert time.monotonic()<deadline,'precondition owner still live after wait budget'
  write('wait.json',{'execution':'waiting','pid':owner['pid'],'start_ticks':owner['start_ticks'],'reason':'exact native14 and stock preflight acceptance required'})
  time.sleep(15)
 assert not (prior/'exception.json').exists(),'native construction acceptance failed; no cold Train started'
 terminal=json.loads((prior/'terminal.json').read_text());proof=json.loads((prior/'publication.json').read_text())
 assert terminal['acceptance_status']=='passed' and terminal['native_tests']==14 and terminal['native_preflights']==2 and proof['acceptance_status']=='passed'
 write('prerequisite.json',{'native_root':'7ffec7acbf7f1f9884c713aaf22e6d852f6d4ce5','native_evidence':proof,'terminal':terminal,'runtime_mutated':False})
 sdk=base/'source-initial-threshold-normal-a3'
 pulse=subprocess.check_output(['git','-C',str(sdk/'Libraries/Nmsdk-PulseLib'),'rev-parse','HEAD:Core'],text=True).strip()
 rdk=subprocess.check_output(['git','-C',str(sdk/'Rdk'),'rev-parse','HEAD:Core'],text=True).strip()
 code_id={'pulse_core':pulse,'rdk_core':rdk,'console_driver':hashlib.sha256(json.dumps({p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((sdk/'App/NeuroModelerConsole').rglob('*.cpp'))},sort_keys=True).encode()).hexdigest()}
 sys.path.insert(0,str(source))
 from Scripts.StructTrain.TimeLearner.stock_threshold_study import run
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ.pop('ASAN_OPTIONS',None)
 for key in ('LD_LIBRARY_PATH','QT_PLUGIN_PATH'):os.environ.pop(key,None)
 write('code-identity.json',code_id)
 result=run(prior/'preflight100',prior/'console-runtime.json',code_id,out/'study');write('analysis.json',result)
 count,fingerprint=fixture_fingerprint(out/'study','**/*.*')
 name='Scripts.StructTrain.TimeLearner.tests.test_stock_threshold_study.StockThresholdStudyTest'
 methods=['test_actual_complete_matrix_is_audited_without_requiring_scientific_success','test_attempt_and_binary_path_do_not_change_the_condition',
          'test_rehashed_missing_condition_cannot_keep_a_complete_matrix']
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'stock-threshold-pair3',
       'package_fingerprint':package_fingerprint(),'modules':[name],'expected_test_ids':[name+'.'+n for n in methods],
       'fixtures':{'TIMELEARNER_STOCK_THRESHOLD_STUDY':{'pattern':'**/*.*','files':count,'fingerprint':fingerprint}}}
 reader=run_suite(spec,{'TIMELEARNER_STOCK_THRESHOLD_STUDY':str(out/'study')},out/'reader-result')
 assert reader['executed_tests']==3 and reader['assertion_status']=='passed' and not any(reader[k] for k in ['errors','failures','skipped'])
 passed=True;write('terminal.json',{'cold_training_runs':4,'native_preflights':4,'reader_tests':3,'classification_assessed':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 hashes={}
 for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Scripts/StructTrain/TimeLearner','Libraries/Nmsdk-PulseLib/Core/TimeLearner']:
  folder=source/prefix
  if folder.exists():
   for p in folder.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:hashes[p.relative_to(source).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file()}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'stock_threshold_pair_cold','schema_version':1,'root':ROOT,
       'acceptance_status':'passed' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),
       'native_rerun':False,'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 pg('config','user.name','TimeLearner Evidence');pg('config','user.email','timelearner@localhost')
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s07-stock-threshold-pair-normal-a1'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: paired stock four-input cold training at fixed low and high thresholds\n')
 branch='refs/heads/codex/evidence-s07-stock-threshold-pair-normal-a1'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
