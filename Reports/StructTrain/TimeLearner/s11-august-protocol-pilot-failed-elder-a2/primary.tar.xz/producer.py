from pathlib import Path
import os,sys,json,hashlib,sqlite3,threading,traceback,tarfile,io,unittest,subprocess,shutil
base=Path('/home/user/timelearner-refactor');tool=base/'source-august-protocol-controls-a2';source=base/'source-august-phasea-de02-a1'
out=base/'readbacks/s11-august-protocol-pilot-elder-a2';out.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(tool));os.environ['TL_HISTORICAL_BIN']=str(source/'Bin')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
from Scripts.StructTrain.TimeLearner.historical_protocol_robustness import run_case
from Scripts.StructTrain.TimeLearner.runtime import source_closure
runtime_path=base/'readbacks/s11-august-phasea-runtime-elder-a1/runtime.json';runtime=load(runtime_path)
c=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True);metadata=dict(c.execute('select key,value from metadata'));c.close()
registry=Reservations(base/'resource-reservations.sqlite3',capacity=json.loads(metadata['capacity']))
token=None;thread=None;stop=threading.Event();errors=[];passed=False;rows=[]
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def checksum(f):return hashlib.sha256(f.read_bytes()).hexdigest()
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert metadata['schema_version']=='2'
 assert subprocess.check_output(['git','-C',str(tool),'rev-parse','HEAD'],text=True).strip()=='8753e3172a1a4566ef4271453a3ec2b74c4b1fc2'
 available_memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 free=shutil.disk_usage(base).free;write('resource-preflight.json',{'available_memory_bytes':available_memory,'disk_free_bytes':free,'minimum_disk_bytes':2*1024**3,'memory_max_bytes':2*1024**3,'reserved_disk_bytes':512*1024**2,'tasks_max':128})
 assert available_memory>=4*1024**3 and free>=2*1024**3
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 prior=inspect_worker_dependency(base/'readbacks/s11-august-protocol-pilot-elder-a1-container',registry,'s11-august-protocol-pilot-elder-a1')
 assert prior['state']=='ready' and prior['reservation_state']=='released';write('failed-prerequisite-closed.json',prior)
 lease=registry.reserve(out.name,[{'path':str(out),'access':'write'}]+[{'path':str(x),'access':'read'} for x in [tool,source,runtime_path.parent]],ttl_seconds=120,demands={'slots':1,'memory_bytes':2*1024**3,'disk_bytes':512*1024**2})
 token=lease['token'];write('reservation.json',lease)
 def beat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=beat,daemon=True);thread.start()
 verify_runtime(runtime);before=source_closure(source);write('historical-runtime.json',runtime);write('source-before.json',before)
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']=''
 for key in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(key,None)
 suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_historical_protocol_robustness.HistoricalProtocolPreparation');assert suite.countTestCases()==11
 with (out/'preparation-tests.txt').open('w') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('preparation-tests.json',{'tests_run':r.testsRun,'successful':r.wasSuccessful(),'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped)})
 assert r.wasSuccessful() and r.testsRun==11 and not r.skipped
 from Scripts.StructTrain.TimeLearner import historical_phasea_native as shared
 from Scripts.StructTrain.TimeLearner.tests import historical_phasea_replay as replay,historical_phasea_coldtest as cold
 assert replay.prepare_case is shared.prepare_case and cold.parameter_export is shared.parameter_export and cold.recognition_identity is shared.recognition_identity
 write('shared-helper-wiring.json',{'original_replay_uses_shared_helpers':True,'original_coldtest_uses_shared_helpers':True,'copied_function_implementation_in_tests':False})
 design=[{'id':'original-order-gap1.5','rotation':0,'iti':1.5},{'id':'original-order-gap3','rotation':0,'iti':3.},{'id':'rotated-order-gap1.5','rotation':1,'iti':1.5},{'id':'rotated-order-gap3','rotation':1,'iti':3.}]
 write('design.json',{'kind':'historical_frozen_protocol_2x2_pilot','cases':design,'training':False,'threshold':.0135,'declared_native_operations':8,'original_control_must_pass_first':True,'whole16_condition_matrix':False})
 for case in design:
  order=[(i+case['rotation'])%8 for i in range(8)];print('CASE',case['id'],flush=True)
  observation=run_case(source,runtime,out/case['id'],order,case['iti'])
  rows.append({'case':case['id'],'native_counts':observation['native_counts'],'native_correct':observation['native_correct'],'actual_inter_burst_gaps':observation['actual_inter_burst_gaps'],'frozen_neuron_sha256':observation['frozen_neuron_sha256'],'all_recorded_windows_complete':observation['all_recorded_windows_complete']})
  write('progress.json',rows);assert not errors;registry.validate_paths(token)
 verify_runtime(runtime);assert source_closure(source)==before;write('source-after.json',source_closure(source));passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()});print('FAILED',str(e),flush=True)
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 if token:write('lease-before-worker-exit.json',next(x for x in registry.inspect()['leases'] if x['token']==token))
 c=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True);after=dict(c.execute('select key,value from metadata'));c.close()
 write('ledger-metadata.json',{'before':metadata,'after':after,'unchanged':metadata==after})
 write('terminal.json',{'pilot_passed':passed,'preparation_tests_declared':11,'completed_cases':len(rows),'rows':rows,'heartbeat_errors':errors,'ledger_metadata_unchanged':metadata==after,'training_started':False,'whole16_condition_matrix_complete':False,'temporal_report_complete':False,'scientific_verdict':None,'whole_plan_complete':False})
 write('tool-source-hashes.json',{f.relative_to(tool).as_posix():checksum(f) for f in (tool/'Scripts/StructTrain/TimeLearner').rglob('*.py')})
 members={}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for f in sorted(out.rglob('*')):
   if f.is_file() and f.name not in ('primary.tar.xz','bundle.json'):
    n=f.relative_to(out).as_posix();members[n]={'bytes':f.stat().st_size,'sha256':checksum(f)};info=tarfile.TarInfo(n);info.size=f.stat().st_size
    with f.open('rb') as stream:archive.addfile(info,stream)
 write('bundle.json',{'members':members,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':checksum(out/'primary.tar.xz'),'tool_root':'8753e3172a1a4566ef4271453a3ec2b74c4b1fc2','pilot_passed':passed})
 print('FINISHED',passed,flush=True)
