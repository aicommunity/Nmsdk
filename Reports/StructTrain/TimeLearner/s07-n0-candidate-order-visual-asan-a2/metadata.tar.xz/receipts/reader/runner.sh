set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-visual-reader-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-n0-candidate-order-visual-asan-a2"
export BASE="$base" OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_N0_CANDIDATE_REPORT_DIR="$base/readbacks/s07-n0-candidate-order-visual-asan-a2/data"
export TIMELEARNER_N0_CANDIDATE_VISUAL_DIR="$base/cache/s07-n0-candidate-order-asan-a1"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,hashlib,unittest,subprocess
start=time.monotonic();out=Path(os.environ['OUT']);base=Path(os.environ['BASE'])
root=Path(os.environ['TIMELEARNER_N0_CANDIDATE_REPORT_DIR']);cache=Path(os.environ['TIMELEARNER_N0_CANDIDATE_VISUAL_DIR'])
def snapshot():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
before=snapshot()
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_test_visual_evidence.N0CandidateVisualEvidenceTest'))
assert r.wasSuccessful() and r.testsRun==3 and not r.skipped
assert snapshot()==before
prefix='Reports/StructTrain/TimeLearner/s07-n0-candidate-order-visual-normal-a1/'
normal=json.loads(subprocess.check_output(['git','show','077334d7fb76bc6d05983a892570f5178ce9b21d:'+prefix+'manifest.json']))
qa=json.loads(subprocess.check_output(['git','show','fd90e862d4f817cc2269ad9c46ba9c8c52aeb5a8:'+prefix+'SELECTED_VISUAL_REVIEW.json']))
reviewed={x['path']:x['sha256'] for x in qa['reviewed']};assert len(reviewed)==8
comparison=[]
for row in normal['selected']:
 assert reviewed[row['path']]==row['sha256']
 path=cache/row['cache_path'];sha=hashlib.sha256(path.read_bytes()).hexdigest()
 comparison.append({'normal_selected':row['path'],'cache_path':row['cache_path'],'normal_sha256':row['sha256'],'asan_sha256':sha,'identical':sha==row['sha256'],'normal_review_commit':'fd90e862d4f817cc2269ad9c46ba9c8c52aeb5a8'})
v={'kind':'n0_asan_native_visual_readback','schema_version':1,'reader_root':'9b2b5990c60154ffad9806f97a50c6a724313cc0','tests':3,'trials':56,'trial_soma_pairs':84,'source_files_unchanged':len(before),'seconds':time.monotonic()-start,'selected_comparison':comparison,'all_selected_identical':all(x['identical'] for x in comparison),'new_direct_manual_review':False,'full_cache_manual_acceptance':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
