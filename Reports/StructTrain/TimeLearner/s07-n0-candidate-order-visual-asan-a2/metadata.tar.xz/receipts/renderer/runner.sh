set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s07-n0-candidate-order-visual-asan-a2"
job="$base/readbacks/s07-n0-candidate-order-fixed-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while test ! -f "$job/process-exit-status.txt";do
 kill -0 "$(cat "$job/supervisor.pid")";sleep 10
done
test "$(cat "$job/process-exit-status.txt")" = 0
cd "$base/source-n0-candidate-order-visual-asan-a2"
export BASE="$base" OUT="$out" JOB="$job" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
import os,shutil,json,hashlib,time
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_test_reports import inventory_native_test_run
from Scripts.StructTrain.TimeLearner.__main__ import main as cli
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);job=Path(os.environ['JOB']);start=time.monotonic()
spec=Path('Scripts/StructTrain/TimeLearner/specs/n0-candidate-order-native-v1.json').resolve()
declared=json.loads(spec.read_text());root=out/'data';(root/'native').mkdir(parents=True)
shutil.copyfile(job/'native.xml',root/'native.xml')
for phase in declared['phases']:
 stem=phase['summary'];summary=job/'native-evidence'/stem
 shutil.copyfile(summary,root/'native'/stem)
 count=json.loads(summary.read_text());total=count['reference_probes']+count.get('search_probes',0);assert total>0
 for i in range(1,total+1):
  for ext in ('.json','.csv'):
   name=phase['probe_prefix']+str(i)+ext
   shutil.copyfile(job/'native-evidence'/name,root/'native'/name)
def hashes():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
before=hashes();inventory=inventory_native_test_run(spec,root)
cache=base/'cache/s07-n0-candidate-order-asan-a1'
assert cli(['report',str(spec),'--format','native-test-run','--artifacts',str(root),'--output',str(cache)])==0
assert hashes()==before
report=json.loads((cache/'manifest.json').read_text());assert report['rendered_trial_soma_pairs']==inventory['plottable_trial_soma_pairs']
v={'kind':'n0_native_training_visual','schema_version':1,'seconds':time.monotonic()-start,'tests':inventory['tests'],'phases':len(inventory['groups']),'trials':inventory['trials'],'rendered_trial_soma_pairs':report['rendered_trial_soma_pairs'],'source_files_unchanged':len(before),'report_scope':'four actual native N0 training phases; editor-only probes excluded explicitly','scientific_verdict':None,'visual_acceptance_complete':False}
(out/'validation.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
PY
