set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-owned-posttune-worker-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1";build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-training-threshold-reference-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-owned-posttune-asan-a3/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s08-native-owned-posttune-reader-asan-a3/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 750000000
test -z "$(git -C "$src" status --porcelain)"
export BASE="$base" OUT="$out" SRC="$src" BUILD="$build"
python3 - <<'PY' > "$out/live-source-check.json"
from pathlib import Path
import os,json
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'exe':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch origin 08ae95430014a6a6c8b92ebc040181372fd0f912 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
cd "$src";export PYTHONDONTWRITEBYTECODE=1
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
unset QT_QPA_PLATFORM
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 - <<'PY' > "$out/historical-controls.log" 2>&1
from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
out=Path(os.environ['OUT']);src=Path(os.environ['SRC'])
prefix='Reports/StructTrain/TimeLearner/s08-native-posttune-console-normal-a2/'
def blob(name):return subprocess.check_output(['git','-C',str(src),'show','HEAD:'+prefix+name])
manifest=json.loads(blob('manifest.json'));raw=blob('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==manifest['archive_sha256']
key='native-production/runs/controls.json';expected=next(r for r in manifest['files'] if r['path']==key)
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:contents=tar.extractfile(key).read()
assert hashlib.sha256(contents).hexdigest()==expected['sha256'] and len(contents)==expected['bytes']
assert len(json.loads(contents)['records'])==18
(out/'historical-controls.json').write_bytes(contents)
(out/'historical-controls-provenance.json').write_text(json.dumps({'git_root':'08ae95430014a6a6c8b92ebc040181372fd0f912','report':prefix,'archive_sha256':manifest['archive_sha256'],'member':key,'member_sha256':expected['sha256']},indent=2)+'\n')
PY
export TIMELEARNER_OWNED_POSTTUNE_NATIVE="$base/readbacks/s08-native-owned-posttune-asan-a3/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
python3 -u - <<'PY' > "$out/owner-reader-regression.log" 2>&1
from pathlib import Path
import json,os,time,unittest
begin=time.monotonic()
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_owned_posttune_evidence'))
report={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-begin}
(Path(os.environ['OUT'])/'owner-reader-regression.json').write_text(json.dumps(report,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==2 and not result.skipped
PY
python3 - <<'PY' > "$out/source-input.log" 2>&1
from pathlib import Path
import shutil,os
out=Path(os.environ['OUT']);base=Path(os.environ['BASE'])
root=base/'readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/runs'
target=out/'input-source';target.mkdir()
for topology in ('Classic','Branch'):
 source=root/(topology+'-keep')/'input/source'
 assert source.is_dir()
 shutil.copytree(source,target/topology)
PY
python3 -u -m Scripts.StructTrain.TimeLearner.tests.owned_posttune_worker_corpus --jobs "$base/readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/jobs" --controls "$out/historical-controls.json" --fixtures "$out/input-source" --runtime "$out/runtime-before.json" --output "$out/corpus" --wall-seconds 900 > "$out/corpus.log" 2>&1
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$out/corpus/runs"
export TIMELEARNER_OWNED_POSTTUNE_WORKER_DIR="$out/corpus/runs"
export TIMELEARNER_NATIVE_CALIBRATION_WORKER_DIR="$out/corpus/calibration-regressions"
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$out/corpus/source-fixtures"
export TIMELEARNER_NATIVE_CALIBRATION_CLI_OUTPUT="$out/calibration-cli-regressions"
python3 -u - <<'PY' > "$out/worker-tests.log" 2>&1
from pathlib import Path
import json,os,time,unittest
start=time.monotonic();rows=[]
for module,count in [('test_native_posttune_controller_worker',4),('test_owned_posttune_worker',3),('test_native_calibration_worker',12)]:
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+module))
 rows.append({'module':module,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
 assert result.wasSuccessful() and result.testsRun==count and not result.skipped,rows[-1]
summary={'kind':'native_owned_post_tune_console_gate','schema_version':1,'source_root':'08ae95430014a6a6c8b92ebc040181372fd0f912','modules':rows,'seconds':time.monotonic()-start,'corpus':json.loads((Path(os.environ['OUT'])/'corpus/corpus-summary.json').read_text()),'scientific_verdict':None,'full_stage_8_accepted':False}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/NeuroModelerConsole" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
df -h "$base" > "$out/disk-after.txt"
