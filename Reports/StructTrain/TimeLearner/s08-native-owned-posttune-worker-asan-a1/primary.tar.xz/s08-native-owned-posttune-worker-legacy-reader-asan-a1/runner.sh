set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-owned-posttune-worker-legacy-reader-asan-a1"
repo="$base/source-training-intent-binding-reader-asan-a1"
work="$base/source-owned-posttune-worker-legacy-reader-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
git -C "$repo" -c fetch.recurseSubmodules=false fetch origin 08ae95430014a6a6c8b92ebc040181372fd0f912 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" 08ae95430014a6a6c8b92ebc040181372fd0f912 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_POSTTUNE_CONTROLLER_WORKER_DIR="$base/readbacks/s08-native-posttune-console-offload-normal-a2/data/native-production/runs"
python3 -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import json,os,time,unittest
start=time.monotonic()
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_native_posttune_controller_worker'))
report={'kind':'owned_worker_schema1_compatibility','schema_version':1,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'seconds':time.monotonic()-start,'historical_runs':18,'source_primary_modified':False,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
assert result.wasSuccessful() and result.testsRun==4 and not result.skipped
print(json.dumps(report),flush=True)
PY
