from pathlib import Path,PurePosixPath
import os,sys,subprocess,json,hashlib,tarfile,io,time,traceback
base=Path('/media/user/Data/TimeLearnerRefactor');venv=base/'plot-venv-a1/bin/python'
assert venv.is_file()
if sys.prefix!=str(venv.parent.parent):os.execv(str(venv),[str(venv),'-u',str(Path(__file__).resolve())])
ROOT='ddfe1f39d40373daab1d4e2894a9c822c90a288f';DATA='c8381cfc3ecbf446ae1f59175c794ef547dcc93d'
out=base/'readbacks/s11-stock-stopped-phasea-visual-a1';out.mkdir(exist_ok=False)
repo=base/'code-stock-stopped-phasea-visual-a1.git';source=base/'code-stock-stopped-phasea-visual-a1';source.mkdir(exist_ok=False)
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def command(args,timeout=1800):return subprocess.check_output([str(a) for a in args],stderr=subprocess.STDOUT,timeout=timeout)
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT,'numerical_model_rerun':False})
passed=False
try:
 command(['git','clone','--shared','--bare',base/'source-configured-probe-ownership-asan-h14',repo])
 command(['git','-C',repo,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT])
 raw=command(['git','-C',repo,'archive',ROOT,'Scripts/StructTrain/TimeLearner'])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(source,filter='data')
 write('git-object-dependency.json',{'read_only_donor':str(base/'source-configured-probe-ownership-asan-h14'),'preserve_donor_until_dissociated':True,'runtime_mutated':False})
 prior=base/'readbacks/s07-configured-probe-ownership-asan-h21';owner=json.loads((prior/'owned-supervisor.json').read_text());deadline=time.monotonic()+46800
 while live(owner):
  assert time.monotonic()<deadline,'exact H21 owner still live after report wait budget'
  write('waiting-native-owner.json',{'pid':owner['pid'],'start_ticks':owner['start_ticks'],'reason':'avoid competing with original120s fresh-import budget','execution':'waiting'})
  time.sleep(15)
 write('native-owner-closed.json',{'owner':owner,'same_process_live':False,'source_and_runtime_mutated':False,'passed_native_is_not_a_report_requirement':True})
 memory=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 assert memory>=16*1024**3,'insufficient free memory for complete report cache'
 prefix='Reports/StructTrain/TimeLearner/s11-stock-stopped-phasea-normal-a3/'
 def get(n):return command(['git','-C',repo,'show',DATA+':'+prefix+n])
 manifest=json.loads(get('manifest.json'));assert manifest['acceptance_status']=='passed'
 for n,d in json.loads(get('SHA256SUMS.json')).items():assert hashlib.sha256(get(n)).hexdigest()==d
 raw=get('primary.tar.xz');assert len(raw)==manifest['archive_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['archive_sha256']
 primary=out/'source-primary';primary.mkdir()
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:
  members=t.getmembers();assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
  assert {m.name for m in members}==set(manifest['members'])
  for m in members:
   data=t.extractfile(m).read();r=manifest['members'][m.name];assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  t.extractall(primary,filter='data')
 write('source-primary-proof.json',{'commit':DATA,'members_verified':len(manifest['members']),'archive_bytes':len(raw),'archive_sha256':manifest['archive_sha256'],'new_numerical_runs':0})
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 from Scripts.StructTrain.TimeLearner.plotting import plotting_runtime
 write('plotting-runtime.json',plotting_runtime())
 cache=out/'full-report-cache';args=[sys.executable,'-m','Scripts.StructTrain.TimeLearner','stock-stopped-evaluation','report',str(primary/'evaluation'),'--output',str(cache)]
 write('cli-request.json',{'arguments':args,'cwd':'/tmp','PYTHONPATH':str(source)})
 with (out/'cli-stdout.log').open('xb') as so,(out/'cli-stderr.log').open('xb') as se:
  q=subprocess.Popen(args,cwd='/tmp',env=dict(os.environ,PYTHONPATH=str(source)),stdout=so,stderr=se)
  write('owned-renderer.json',{'pid':q.pid,'start_ticks':ticks(q.pid),'arguments':args});rc=q.wait(timeout=43200)
 assert rc==0,'production temporal report CLI failed'
 bindings={'TIMELEARNER_STOCK_STOPPED_EVALUATION':primary/'evaluation','TIMELEARNER_STOCK_STOPPED_REPORTS':cache};declarations={}
 for k,p in bindings.items():
  count,digest=fixture_fingerprint(p,'**/*.*');declarations[k]={'pattern':'**/*.*','files':count,'fingerprint':digest}
 module='Scripts.StructTrain.TimeLearner.tests.test_stock_stopped_reports.StockStoppedReportsTest'
 names=['test_all_original_samples_and_eighty_trial_soma_pairs_are_preserved','test_all_figure_files_have_full_overviews_and_readable_native_zoom','test_complete_cache_hashes_no_lt_scope_and_no_training_or_manual_acceptance_claim']
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'stock-stopped80-pair-reports3','package_fingerprint':package_fingerprint(),'modules':[module],'expected_test_ids':[module+'.'+n for n in names],'fixtures':declarations}
 result=run_suite(spec,{k:str(p) for k,p in bindings.items()},out/'reader-result')
 assert result['executed_tests']==3 and result['assertion_status']=='passed' and not any(result[k] for k in ['errors','failures','skipped'])
 write('cache-location.json',{'path':str(cache),'source_root':ROOT,'data_commit':DATA,'trial_soma_pairs':80,'full_images_in_git':False,'selected_manual_review_pending':True})
 passed=True;write('terminal.json',{'execution':'completed','trial_soma_pairs':80,'reader_tests':3,'numerical_rerun':False,'visual_acceptance_complete':False,'scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 sys.path.insert(0,str(source));from Scripts.StructTrain.TimeLearner.publisher import _module_urls
 probe=out/'child-reachability.git';command(['git','init','--bare',probe]);reachable=[]
 for path,url in _module_urls(repo,ROOT).items():
  sha=command(['git','-C',repo,'rev-parse',ROOT+':'+path]).decode().strip()
  command(['git','-C',probe,'fetch','--no-recurse-submodules','--filter=tree:0','--depth=1',url,sha])
  command(['git','-C',probe,'cat-file','-e',sha+'^{commit}']);reachable.append({'path':path,'url':url,'commit':sha,'remote_fetch_verified':True})
 write('child-remote-reachability.json',reachable)
 hashes={p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*.py') if '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 selected={}
 for p in out.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if rel.parts[0] in ['source-primary','child-reachability.git']:continue
  if rel.parts[0]=='full-report-cache':
   if 'primary' in rel.parts or p.name not in ['manifest.json','analysis.json','SHA256SUMS.json','index.html','series_timeline.json']:continue
  selected[rel.as_posix()]=p
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in selected.items()}
 archive=out/'metadata.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as t:
  for n,p in selected.items():t.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes();bundle={'kind':'stock_stopped_phasea_temporal_metadata','schema_version':1,'root':ROOT,'data_commit':DATA,'acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None}
 payload={'metadata.tar.xz':raw,'manifest.json':(json.dumps(bundle,indent=2)+'\n').encode()};payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def git(*a,raw=None):return subprocess.check_output(['git','-C',str(repo),*a],input=raw,env=env).decode().strip()
 git('config','user.name','TimeLearner Evidence');git('config','user.email','timelearner@localhost');git('read-tree',ROOT)
 report='Reports/StructTrain/TimeLearner/s11-stock-stopped-phasea-visual-a1'
 for n,b in payload.items():git('update-index','--add','--cacheinfo','100644',git('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=git('commit-tree',git('write-tree'),'-p',ROOT,raw=b'evidence: complete stock stopped-model80-pair temporal cache metadata without full image payload\n')
 branch='refs/heads/codex/evidence-s11-stock-stopped-phasea-visual-a1';remote='git@github.com:aicommunity/Nmsdk.git'
 git('update-ref',branch,commit,'0'*40);git('push','--recurse-submodules=no',remote,branch+':'+branch)
 assert git('ls-remote',remote,branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':bundle['acceptance_status'],'archive_bytes':len(raw),'members':len(records),'full_images_in_git':False})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
