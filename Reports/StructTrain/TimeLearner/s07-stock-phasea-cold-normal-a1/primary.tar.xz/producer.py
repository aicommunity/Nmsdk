from pathlib import Path
import subprocess,json,os,sys,io,tarfile,hashlib,time,traceback,shutil
ROOT='15bae9cbee8a59e699d7efa0a788c6bb729cb1ab'
SOURCE='99e0291bd71d99857335f3c31e7719c8bce79812'
out=Path('/home/user/timelearner-refactor/readbacks/s07-stock-phasea-cold-normal-a1');out.mkdir(parents=True,exist_ok=False)
repo=out/'root-objects.git'
baseline=Path('/home/user/timelearner-refactor/readbacks/s04-stock-phasea-preflight-normal-a1')
def write(n,v):p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(*a,raw=None):return subprocess.check_output(['git','--git-dir',str(repo),*a],input=raw)
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'producer_root':ROOT,'no_build':True,'source_preflight':SOURCE})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 free=shutil.disk_usage(out).free
 write('resource-preflight.json',{'disk_free_bytes':free,'minimum_free_bytes':16*1024**3,'logical_cpus':os.cpu_count(),'concurrent_owned_consoles':1})
 assert free>=16*1024**3,'not enough disk for bounded four-input primary data'
 subprocess.run(['git','clone','--bare','--shared',str(baseline/'root-objects.git'),str(repo)],check=True,capture_output=True)
 git('config','user.name','TimeLearner Evidence');git('config','user.email','timelearner@localhost')
 git('fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT)
 # Exact source proof, not the presence of a stale status file.
 data=json.loads(git('show',SOURCE+':Reports/StructTrain/TimeLearner/s04-stock-phasea-preflight-normal-a1/manifest.json'))
 assert data['acceptance_status']=='passed' and data['root']=='472219ab9041e7a5be134c37ea306c21437fa8dd'
 for name,r in data['members'].items():
  p=baseline/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],name
 code=out/'code';code.mkdir()
 with tarfile.open(fileobj=io.BytesIO(git('archive',ROOT,'Scripts')),mode='r:') as a:
  for m in a:
   if m.isdir():continue
   assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
   p=code/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(a.extractfile(m).read())
 sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.validation import run_suite,fixture_fingerprint,package_fingerprint
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest,audit_execution,validate_job
 from Scripts.StructTrain.TimeLearner.stock_phasea_preflight import audit_stock_profile
 from Scripts.StructTrain.TimeLearner.native_evidence import load
 runtime=load(baseline/'native-runtime.json')
 for k in ('LD_LIBRARY_PATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM'):
  if k in runtime['loader_environment']:os.environ[k]=runtime['loader_environment'][k]
  else:os.environ.pop(k,None)
 write('runtime.json',runtime)
 count,fingerprint=fixture_fingerprint(baseline/'preflight','**/*.*')
 prefix='Scripts.StructTrain.TimeLearner.tests.test_stock_phasea_preflight.StockPhaseAPreflightTest.'
 spec={'kind':'timelearner_python_validation_suite','schema_version':1,'suite_id':'stock-phasea-full-profile-and-feedback-4',
  'package_fingerprint':package_fingerprint(),'modules':['Scripts.StructTrain.TimeLearner.tests.test_stock_phasea_preflight'],
  'expected_test_ids':[prefix+n for n in ['test_both_actual_native_graphs_have_the_declared_original_physics_without_calculation',
  'test_modified_integration_fixture_cannot_claim_the_stock_scientific_profile','test_rehashed_channel_and_synapse_drift_are_rejected',
  'test_rehashed_changed_spike_feedback_path_is_rejected']],
  'fixtures':{'TIMELEARNER_STOCK_PHASEA_PREFLIGHT':{'pattern':'**/*.*','files':count,'fingerprint':fingerprint}}}
 write('reader-specification.json',spec)
 reader=run_suite(spec,{'TIMELEARNER_STOCK_PHASEA_PREFLIGHT':str(baseline/'preflight')},out/'preflight-readers')
 assert reader['assertion_status']=='passed' and reader['executed_tests']==4 and not any(reader[k] for k in ['errors','failures','skipped'])
 write('source-hashes.json',{p.relative_to(code).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in sorted((code/'Scripts').rglob('*')) if p.is_file() and '__pycache__' not in p.parts})
 jobs=out/'jobs';jobs.mkdir();(out/'runs').mkdir()
 prepared=[]
 for top in ('Classic','Branch'):
  name=top+'-stock-nspneurongen-inputs4'
  original=baseline/'preflight/runs'/name
  audit_run_manifest(original/'run-manifest.json')
  job=load(original/'input/job.json');validate_job('train',job)
  initial=load(original/'native/initial-state.json')
  audit_stock_profile(initial['identity'],branch=top=='Branch')
  assert job['profile_archives']==[] and job['configuration']['model']['neuron_class']=='NSPNeuronGen'
  write('jobs/'+name+'.json',job)
  write('preflight/'+name+'-initial.json',initial)
  prepared.append((name,job,initial))
 write('design.json',{'kind':'stock_phasea_four_input_cold_training','schema_version':1,'producer_root':ROOT,
       'source_preflight':SOURCE,'native_root':runtime['source_closure']['root']['head'],
       'job_sha256':{n:j['sha256'] for n,j,_ in prepared},'cold_models':2,'lt_membrane':False,
       'all_jobs_frozen_before_train':True,'calibration_performed':False,'scientific_verdict':None})
 rows=[]
 for name,job,expected in prepared:
  print('TRAIN',name,flush=True)
  folder=out/'runs'/name
  started=time.monotonic()
  result=run_job('train',jobs/(name+'.json'),None,out/'runtime.json',folder,7200.)
  row={'name':name,'execution':result['execution'],'validity':result['validity'],'wall_seconds':time.monotonic()-started,
       'scientific_verdict':None}
  rows.append(row);write('progress.json',rows)
  if result['execution']!='completed' or result['validity']!='valid':
   raise RuntimeError('native training execution invalid; no template Test or automatic retry')
  audit=audit_run_manifest(folder/'run-manifest.json')
  actual=load(folder/'native/initial-state.json')
  assert actual['identity']==expected['identity'] and actual['parameters']==expected['parameters'],'cold state differs from verified stock graph'
  profile=audit_stock_profile(actual['identity'],branch=job['configuration']['model']['branch'])
  e=load(folder/'native/execution.json')
  package=load(folder/'native'/e['package_path'])
  summary=load(folder/'native'/('train_learned_summary.json' if e['completed_boundary'] else 'train_stopped_summary.json'))
  assert package['neuron']['graph']['identity']['model']['nodes'][0]['path']=='$'
  assert not any(n['path']=='$.LTMembrane' or n['path'].startswith('$.LTMembrane.') for n in package['neuron']['graph']['identity']['model']['nodes'])
  row.update(run_audit=audit,training_outcome=e['training_outcome'],completed_boundary=e['completed_boundary'],
       initial_profile=profile,initial_model_revision=actual['identity']['sha256'],
       final_model_revision=package['model_revision'],model_ticks=e['model_ticks'],
       candidates=summary['candidates'],certificate=summary['certificate'])
  write('progress.json',rows)
  print('END',name,e['training_outcome'],e['completed_boundary'],flush=True)
 passed=len(rows)==2 and all(r['execution']=='completed' and r['validity']=='valid' for r in rows)
 write('index.json',{'kind':'stock_phasea_four_input_cold_training_result','schema_version':1,
       'records':rows,'lt_membrane':False,'training_runs':2,'calibration_performed':False,
       'acceptance_status':'execution_valid' if passed else 'not_accepted','scientific_verdict':None})
 write('terminal.json',{'execution':'completed','acceptance_status':'execution_valid' if passed else 'not_accepted','scientific_verdict':None})
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
try:
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and p.relative_to(out).parts[0] not in {'root-objects.git','code'}}
 records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3) as a:
  for n,p in files.items():a.add(p,arcname=n,recursive=False)
 raw=archive.read_bytes()
 manifest={'kind':'stock_phasea_cold_training_primary','schema_version':1,'root':ROOT,'source_preflight':SOURCE,
       'acceptance_status':'execution_valid' if passed else 'not_accepted','members':records,
       'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'scientific_verdict':None}
 payload={'primary.tar.xz':raw,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
 payload['SHA256SUMS.json']=(json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in payload.items()},indent=2)+'\n').encode()
 env=dict(os.environ,GIT_INDEX_FILE=str(out/'publish.index'))
 def pg(*a,raw=None):return subprocess.check_output(['git','--git-dir',str(repo),*a],input=raw,env=env).decode().strip()
 pg('read-tree',ROOT);report='Reports/StructTrain/TimeLearner/s07-stock-phasea-cold-normal-a1'
 for n,b in payload.items():pg('update-index','--add','--cacheinfo','100644',pg('hash-object','-w','--stdin',raw=b),report+'/'+n)
 commit=pg('commit-tree',pg('write-tree'),'-p',ROOT,raw=b'evidence: cold stock no-LT four-input native training and explicit outcomes\n')
 branch='refs/heads/codex/evidence-s07-stock-phasea-cold-normal-a1'
 pg('update-ref',branch,commit,'0'*40);pg('push','--recurse-submodules=no','git@github.com:aicommunity/Nmsdk.git',branch+':'+branch)
 assert pg('ls-remote','git@github.com:aicommunity/Nmsdk.git',branch).split()[0]==commit
 write('publication.json',{'commit':commit,'report':report,'acceptance_status':manifest['acceptance_status'],'members':len(files),'archive_bytes':len(raw)})
except BaseException as e:write('publication-exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
