set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s04-uninitialized-bool-fixed-normal-a2"
src="$base/source-order-fixed-a1"
build="$base/build-order-fixed-normal-a1"
runtime="$base/runtime-s04-uninitialized-bool-fixed-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-phase-lifecycle-interrupt-normal-a1/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1300000000
test ! -e "$runtime"
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 0fca58516 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
unset ASAN_OPTIONS
unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
filter='RdkLifecycleBoolean.*:TimeLearnerNativeLifecycle.*:NativePhaseLifecycle.ClassicWeightDefault:NativePhaseLifecycle.BranchWeightDestroy:NativeFixedPostTune.ClassicBudget:NativeFixedPostTune.BranchBudget'
result=execute(runtime,['--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'native.xml')],
 Path(runtime['executable']['path']).parent,out/'process',300)
x=ET.parse(out/'native.xml').getroot()
assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
assert result['returncode']==0 and result['execution']=='completed' and result['runtime_provenance']=='loaded_files_captured'
names={(s.attrib['name'],t.attrib['name']) for s in x.findall('testsuite') for t in s.findall('testcase')}
assert ('RdkLifecycleBoolean','UninitializedContainerSkipsWithoutBooleanError') in names
for pair in [('NativePhaseLifecycle','ClassicWeightDefault'),('NativePhaseLifecycle','BranchWeightDestroy'),
             ('NativeFixedPostTune','ClassicBudget'),('NativeFixedPostTune','BranchBudget')]:assert pair in names
assert len(names)==int(x.attrib['tests']) and len(names)>5
r=load(out/'native/uninitialized-container.json')
assert r['uninitialized_return'] is True and r['inactive_return'] is True and r['uninitialized_children_skipped'] is True
assert r['initialized_return'] is True and r['parent_calculate_calls']==r['child_calculate_calls']==1 and r['global_clock_unchanged'] is True
report={'kind':'rdk_uninitialized_boolean_fixed','schema_version':1,'native_tests':int(x.attrib['tests']),
 'native_seconds':float(x.attrib['time']),'test_names':[list(n) for n in sorted(names)],'control':r,
 'runtime_provenance':result['runtime_provenance'],'native_execution_attested':False,'scientific_verdict':None}
(out/'fixed-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
