set -euo pipefail
data=/media/user/Data/TimeLearnerRefactor
out="$data/readbacks/s08-calibration-ownership-fixed-asan-a1"
src="$data/source-threshold-contract-asan-isolated-a1"
build="$data/build-threshold-contract-asan-isolated-a1"
runtime="$data/runtime-calibration-ownership-fixed-asan-a1"
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
python3 - <<'PY' > "$out/resource-preflight.json"
import json,os,shutil
from pathlib import Path
m={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines()}
free=shutil.disk_usage('/media/user/Data').free
assert m['MemAvailable']>8*1024**3 and free>12*1024**3
print(json.dumps({'cpu_count':os.cpu_count(),'memory_available_bytes':m['MemAvailable'],'data_disk_free_bytes':free,'build_jobs':2,'scientific_verdict':None},indent=2))
PY
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
export TMPDIR="$data/tmp-calibration-ownership-fixed-asan-a1"
mkdir "$TMPDIR"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 0b89622a25785cbe1055721832da55933cb4988c > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach 0b89622a25785cbe1055721832da55933cb4988c >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive --jobs 2 >> "$out/checkout.log" 2>&1
test "$(git -C "$src/Libraries/Nmsdk-PulseLib" rev-parse HEAD)" = fad7aed8c6ae9e32dea79001eec55c49904ff4d7
test "$(git -C "$src/Bin" rev-parse HEAD)" = 9af8a5c7cbcd94c76930b2b9928f2c307a98143b
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0
OLD_RUNTIME=/media/user/Data/TimeLearnerRefactor/readbacks/s08-threshold-potential-asan-a2/runtime-before.json python3 - <<'PY' > "$out/coexisting-runtime-before.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['OLD_RUNTIME']).read_text())))}))
PY
cmake -S "$src" -B "$build" -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DNMSDK_BUILD_PARALLEL_JOBS=2 -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" '-DCMAKE_CXX_FLAGS_RELEASE=-O1 -g1 -fno-omit-frame-pointer -fsanitize=address' '-DCMAKE_C_FLAGS_RELEASE=-O1 -g1 -fno-omit-frame-pointer -fsanitize=address' '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address' '-DCMAKE_SHARED_LINKER_FLAGS=-fsanitize=address' '-DCMAKE_MODULE_LINKER_FLAGS=-fsanitize=address' -DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF -DRDK_LLM_BUILD_EMBEDDED=OFF -DRDK_USE_CUDA=OFF -DRDK_USE_DARKNET=OFF -DRDK_USE_MATLAB=OFF -DRDK_USE_ODESOLVER=OFF -DRDK_USE_OPENCV=OFF -DRDK_USE_PYTHON=OFF -DRDK_USE_SQL=OFF -DRDK_USE_TENSORFLOW=OFF > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 2 > "$out/build.log" 2>&1
BUILD="$build" python3 - <<'PY' > "$out/asan-compile-flags.json"
import json,os,shlex
from pathlib import Path
commands=json.loads(Path(os.environ['BUILD'],'compile_commands.json').read_text())
found=[]
for name in ('NNeuronTimeLearner.cpp','NNeuronTimeLearnerBranch.cpp','NativeThresholdCandidate.cpp','Test_PulseLib_CalibrationOwnership.cpp'):
 matches=[r for r in commands if Path(r['file']).name==name]
 assert len(matches)==1,(name,len(matches))
 args=shlex.split(matches[0]['command'])
 assert '-fsanitize=address' in args and '-fno-omit-frame-pointer' in args
 assert [a for a in args if a.startswith('-O')][-1]=='-O1'
 found.append(matches[0])
print(json.dumps(found,indent=2))
PY
OLD_RUNTIME=/media/user/Data/TimeLearnerRefactor/readbacks/s08-threshold-potential-asan-a2/runtime-before.json python3 - <<'PY' > "$out/coexisting-runtime-after-build.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['OLD_RUNTIME']).read_text())))}))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native"
cd "$runtime"
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE="$data/readbacks/s08-calibration-grid-report-normal-a2/extracted/native-v2/native"
set +e
./Test_PulseLib_StorageComponents --gtest_filter='NativeCalibrationOwnership.*' --gtest_output="xml:$out/native.xml" > "$out/native.log" 2>&1
status=$?
set -e
echo "$status" > "$out/native-exit-status.txt"
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import os,json
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_text()))),'scientific_verdict':None}))
PY
test "$status" = 0
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import os,json,xml.etree.ElementTree as E
from pathlib import Path
out=Path(os.environ['OUT']);r=E.parse(out/'native.xml').getroot()
cases={(c.attrib['classname'],c.attrib['name']) for c in r.iter('testcase')}
expected={('NativeCalibrationOwnership',top+case) for top in ('Classic','Branch') for case in ('ForeignResult','ConsumedResult','SamePackageImport','NormalFlow')}
assert cases==expected and len(list(r.iter('testcase')))==8
assert not list(r.iter('failure')) and not list(r.iter('error')) and not list(r.iter('skipped'))
(out/'validation.json').write_text(json.dumps({'native_cases':8,'root':'0b89622a25785cbe1055721832da55933cb4988c','scope':'ASan real saved model ownership and normal grid flow; no fresh Train','scientific_verdict':None},indent=2)+'\n')
PY
