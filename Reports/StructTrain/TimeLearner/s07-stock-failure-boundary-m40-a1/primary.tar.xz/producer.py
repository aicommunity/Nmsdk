from pathlib import Path,PurePosixPath
import json,sys,os,subprocess,tarfile,io,hashlib,traceback,contextlib,unittest,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');venv=base/'plot-venv-a1/bin/python'
if sys.executable!=str(venv):os.execv(str(venv),[str(venv),'-u',__file__])
root='2b9f13a6c868e428e975252882067c9ee692d1fc';donor=base/'source-initial-threshold-asan-a2';sdk=base/'analysis-stock-failure-reports-a1';out=base/'readbacks/s07-stock-failure-production-visual-a1';out.mkdir(exist_ok=False)
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],stderr=subprocess.STDOUT)
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 assert shutil.disk_usage(base).free>=4*1024**3
 subprocess.run(['git','clone','--shared','--no-checkout',str(donor),str(sdk)],check=True)
 git(sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root)
 git(sdk,'sparse-checkout','set','--no-cone','/Scripts/','/Docs/');git(sdk,'checkout','--detach',root)
 sys.path.insert(0,str(sdk));os.environ['PYTHONPATH']=str(sdk);os.environ['MPLCONFIGDIR']=str(out/'matplotlib-cache')
 proof='e5fa71d745119af0d818059f497dd226f4c7c25d';prefix='Reports/StructTrain/TimeLearner/s07-stock-threshold-pair-normal-a3'
 raw=git(sdk,'show',proof+':'+prefix+'/primary.tar.xz');manifest=json.loads(git(sdk,'show',proof+':'+prefix+'/manifest.json'))
 assert len(raw)==manifest['archive_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['archive_sha256']
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  members=t.getmembers();assert len(members)==len(manifest['members']) and len({m.name for m in members})==len(members)
  for m in members:
   assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
   data=t.extractfile(m).read();assert manifest['members'][m.name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
   if m.name.startswith('study/'):
    p=out/'restored'/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 write('source-verification.json',{'proof_commit':proof,'archive_sha256':manifest['archive_sha256'],'members_verified':len(members),'native_rerun':False})
 for label in ['a1','a2']:
  previous=base/('readbacks/s07-stock-wave-loss-visual-'+label);dest=out/'prior-attempts'/label;dest.mkdir(parents=True)
  assert json.loads((previous/'terminal.json').read_text())['status']=='not_accepted'
  for name in ['producer.py','exception.json','terminal.json']:(dest/name).write_bytes((previous/name).read_bytes())
 source=out/'restored/study';cache=out/'full-report-cache';os.environ['TIMELEARNER_STOCK_THRESHOLD_STUDY']=str(source)
 def tests(label,names):
  suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
  with (out/(label+'.log')).open('x') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
  summary={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)};write(label+'.json',summary);assert result.wasSuccessful() and not result.skipped,summary
 tests('selection-readers',['Scripts.StructTrain.TimeLearner.tests.test_stock_failure_reports.StockFailureBoundaryTest','Scripts.StructTrain.TimeLearner.tests.test_stock_threshold_study.StockThresholdStudyTest'])
 from Scripts.StructTrain.TimeLearner.__main__ import main as cli
 with (out/'production-cli.log').open('x') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  rc=cli(['stock-threshold-study','failure-report',str(source),'--output',str(cache)])
 assert rc==0,rc
 os.environ['TIMELEARNER_STOCK_FAILURE_REPORT']=str(cache)
 tests('report-readers',['Scripts.StructTrain.TimeLearner.tests.test_stock_failure_reports.StockFailureReportTest'])
 m=json.loads((cache/'manifest.json').read_text());selected=[];(out/'selected').mkdir()
 for row in m['reports']:
  name=row['name'];folder=cache/name;entries=json.loads((folder/'manifest.json').read_text())['reports']
  for entry,record in zip(entries,row['selection']['probes']):
   probe=folder/entry['folder'];pm=json.loads((probe/'manifest.json').read_text());channel=record['input_index'] if row['topology']=='Classic' else 0
   figure=next(f for f in pm['figures'] if f['channel']==channel);view=next(v for v in figure['views'] if v['time_view']=='overview')
   original=probe/view['files'][0];destination=out/'selected'/(name+'-'+record['role']+'.png');shutil.copyfile(original,destination)
   selected.append({'name':name,'role':record['role'],'channel':channel,'original_cache_file':str(original),'selected':destination.name,'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'manual_review_complete':False})
 write('selected.json',selected);passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','native_rerun':False,'manual_review_complete':False,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
