from pathlib import Path,PurePosixPath
import json,os,sys,subprocess,tarfile,io,hashlib,traceback,shutil
base=Path('/media/user/Data/TimeLearnerRefactor');sdk=base/'source-initial-threshold-asan-a2'
venv=base/'plot-venv-a1/bin/python'
if sys.executable!=str(venv):os.execv(str(venv),[str(venv),'-u',__file__])
out=base/'readbacks/s07-stock-wave-loss-visual-a2';out.mkdir(exist_ok=False)
previous=base/'readbacks/s07-stock-wave-loss-visual-a1';assert json.loads((previous/'terminal.json').read_text())['status']=='not_accepted'
(out/'prior-attempt').mkdir()
for n in ['producer.py','exception.json','terminal.json']:(out/'prior-attempt'/n).write_bytes((previous/n).read_bytes())
source='b3bfe86e913bc1f7aeb5a340a72698eacb060f00';proof='e5fa71d745119af0d818059f497dd226f4c7c25d';prefix='Reports/StructTrain/TimeLearner/s07-stock-threshold-pair-normal-a3'
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(sdk),*args])
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc',str(os.getpid()),'stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
passed=False
try:
 assert shutil.disk_usage(base).free>=2*1024**3
 assert git('rev-parse','HEAD').decode().strip()==source
 raw=git('show',proof+':'+prefix+'/primary.tar.xz');manifest=json.loads(git('show',proof+':'+prefix+'/manifest.json'))
 assert len(raw)==manifest['archive_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['archive_sha256'] and manifest['acceptance_status']=='passed'
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  ms=t.getmembers();assert len(ms)==len(manifest['members']) and len({m.name for m in ms})==len(ms)
  for m in ms:
   assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
   data=t.extractfile(m).read();assert manifest['members'][m.name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  write('source-verification.json',{'proof_commit':proof,'archive_path':prefix+'/primary.tar.xz','archive_sha256':manifest['archive_sha256'],'members_verified':len(ms),'native_rerun':False})
  sys.path.insert(0,str(sdk));os.environ['MPLCONFIGDIR']=str(out/'matplotlib-cache')
  from Scripts.StructTrain.TimeLearner.native_evidence import audit_probe
  from Scripts.StructTrain.TimeLearner.probe_reports import render_probe_set
  comparisons=[]
  for top,index in [('Classic',0),('Branch',2)]:
   stem='study/runs/'+top+'-threshold-training100/native/';summary=json.load(t.extractfile(stem+'train_stopped_summary.json'))
   packets={m.name:json.load(t.extractfile(m)) for m in ms if m.name.startswith(stem+'train_stopped_trial_') and m.name.endswith('.json')}
   last=max(packets,key=lambda n:int(n.rsplit('_',1)[1].split('.')[0]));terminal=packets[last]
   assert terminal['observation']['valid'] is False and terminal['observation']['complete'] is True
   previous=[e for e in summary['candidates'] if e['input_index']==index][-1]
   valid=next(n for n,p in packets.items() if p['observation']['specification']['trial_id']==previous['trial_id'])
   selected=[('last-valid',valid),('first-invalid',last)];folder=out/'primary'/top;folder.mkdir(parents=True)
   trials=[];rows=[]
   for label,name in selected:
    packet=packets[name];observation=packet['observation'];spec=observation['specification'];packet_name=label+'.json';trace_name=label+'.csv'
    (folder/packet_name).write_bytes(t.extractfile(name).read());(folder/trace_name).write_bytes(t.extractfile(name[:-5]+'.csv').read())
    audit=audit_probe(packet,folder/trace_name);assert audit['valid_observation']==(label=='last-valid')
    trials.append({'trial_id':spec['trial_id'],'packet':packet_name,'trace':trace_name})
    waves=next(a['waves'] for a in observation['burst_assignments'] if a['channel']==(0 if top=='Branch' else index))
    rows.append({'role':label,'original_member':name,'trial_id':spec['trial_id'],'complete':observation['complete'],'valid':observation['valid'],'reasons':observation['reasons'],'samples':observation['sample_count'],'stimuli':observation['stimuli'],'waves':waves,'base_revision':packet['prepared']['base_model_revision'],'effective_revision':spec['effective_model_revision'],'audit':audit})
   specification={'kind':'timelearner_probe_report_spec','schema_version':2,'observation_policy':'complete_or_partial','trials':trials}
   (folder/'specification.json').write_text(json.dumps(specification,indent=2)+'\n')
   report=render_probe_set(folder/'specification.json',out/'full-report-cache'/top)
   comparisons.append({'topology':top,'active_input_index':index,'previous_candidate':previous,'actual_terminal_parameters':summary['actual_parameters'],'invalid_budget':summary['configuration']['maximum_invalid_observations'],'probes':rows,'report':report,'scientific_verdict':None});write('comparison-'+top+'.json',comparisons[-1])
  write('comparison.json',{'kind':'stock_wave_assignment_boundary','source_root':source,'source_proof':proof,'comparisons':comparisons,'native_rerun':False,'visual_acceptance_complete':False,'scientific_verdict':None})
  passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','native_rerun':False,'visual_acceptance_complete':False,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
