import subprocess
from pathlib import Path
p=subprocess.Popen(["/bin/sleep","20"],start_new_session=True)
Path('/tmp/timelearner-contained-q840_no1/child').write_text(str(p.pid))
