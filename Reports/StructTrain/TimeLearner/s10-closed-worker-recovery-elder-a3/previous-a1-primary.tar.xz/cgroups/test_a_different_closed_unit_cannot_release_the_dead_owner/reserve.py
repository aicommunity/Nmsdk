from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,'/home/user/timelearner-refactor/source-closed-worker-recovery-a1')
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
r=Reservations('/tmp/timelearner-contained-x24_w7e2/leases.sqlite3',capacity=None)
lease=r.reserve("crashed-worker",[{"path":'/tmp/timelearner-contained-x24_w7e2/scratch',"access":"write"}],ttl_seconds=.001,demands=None)
Path('/tmp/timelearner-contained-x24_w7e2/lease.json').write_text(json.dumps(lease))
