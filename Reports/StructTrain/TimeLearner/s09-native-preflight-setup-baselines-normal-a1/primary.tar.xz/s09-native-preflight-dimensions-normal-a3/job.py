import pathlib,json,os,sys,subprocess,tarfile,io,hashlib,traceback
base=pathlib.Path('/home/user/timelearner-refactor');out=base/'readbacks/s09-native-preflight-dimensions-normal-a3'
source=base/'source-n1-measured-refinement-normal-a1';parent=base/'readbacks/s09-native-preflight-normal-a1'
code=base/'source-native-preflight-prepare-analysis-a1';revision='6896144a3851a2f1950b20e5bd1511d82e070ec9'
try:
 subprocess.run(['git','-C',str(source),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',revision],check=True,capture_output=True)
 archive=subprocess.check_output(['git','-C',str(source),'archive',revision,'Scripts/StructTrain/TimeLearner'])
 code.mkdir(exist_ok=False);code_records=[]
 with tarfile.open(fileobj=io.BytesIO(archive)) as t:
  for member in t.getmembers():
   relative=pathlib.PurePosixPath(member.name);assert not relative.is_absolute() and '..' not in relative.parts
   path=code/member.name;assert path.resolve().is_relative_to(code.resolve())
   if member.isdir():path.mkdir(parents=True,exist_ok=True);continue
   assert member.isfile();raw=t.extractfile(member).read();path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
   code_records.append({'path':member.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 (out/'code-manifest.json').write_text(json.dumps({'root':revision,'files':code_records},indent=2)+'\n')
 sys.path.insert(0,str(code))
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
 from Scripts.StructTrain.TimeLearner.runtime import source_closure
 from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
 runtime=json.loads((parent/'runtime.json').read_text());closure=source_closure(source);assert closure==runtime['source_closure']
 os.environ.update(runtime['loader_environment']);os.environ['ASAN_OPTIONS']='detect_leaks=0';os.environ['PYTHONDONTWRITEBYTECODE']='1'
 verify_runtime(runtime)
 spec={'kind':'timelearner_native_matrix_preparation','schema_version':1,
  'templates':{t+'-N'+n:json.loads((parent/'corpus/inputs'/('pipeline-'+t+'-N'+n+'.json')).read_text()) for t in ['Classic','Branch'] for n in ['0','1']},
  'input_counts':[1,2,4,6],'frequencies_hz':[2000,20000],'isi_seconds':.02,'probe_duration':.3,'window_width':.015,'n0_candidate_repeats':2,'run_prefix':'native-preflight-dimension'}
 (out/'specification.json').write_text(json.dumps(spec,allow_nan=False)+'\n')
 env=dict(os.environ,TIMELEARNER_NATIVE_PREFLIGHT_DIR=str(parent/'corpus'))
 with (out/'reader-tests.log').open('wb') as log:
  tests=subprocess.run(['python3','-m','unittest','-v','Scripts.StructTrain.TimeLearner.tests.test_native_preflight','Scripts.StructTrain.TimeLearner.tests.test_prepare_native_matrix'],cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/'reader-validation.json').write_text(json.dumps({'returncode':tests.returncode,'expected_tests':18,'scientific_verdict':None})+'\n')
 assert tests.returncode==0 and 'Ran 18 tests' in (out/'reader-tests.log').read_text()
 with (out/'prepare.log').open('wb') as log:
  p=subprocess.run(['python3','-m','Scripts.StructTrain.TimeLearner','prepare',str(out/'specification.json'),'--output',str(out/'prepared')],cwd=code,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0
 prepared=json.loads((out/'prepared/manifest.json').read_text());assert len(prepared['job_sha256'])==32 and prepared['training_started'] is False
 (out/'runs').mkdir();record={'kind':'native_preflight_dimension_corpus','schema_version':1,'preparation_code':revision,'binary_source':closure['root']['head'],'cases':{},'scientific_verdict':None}
 for name in sorted(prepared['job_sha256']):
  path=out/'prepared/jobs'/(name+'.json');job=json.loads(path.read_text());c=job['configuration'];model=c['model'];count=len(model['inputs']);frequency=model['frequency_hz']
  r=run_job('preflight',path,None,parent/'runtime.json',out/'runs'/name,120)
  if r['execution']!='completed' or r['validity']!='valid':
   stderr=(out/'runs'/name/'process/stderr.log').read_text();raise RuntimeError(name+':'+json.dumps(r)+':'+stderr)
  assert audit_run_manifest(out/'runs'/name/'run-manifest.json')['run_evidence_consistent']
  initial=json.loads((out/'runs'/name/'native/initial-state.json').read_text())
  assert len(initial['parameters'])==count and all(n['frequency_hz']==str(frequency) for n in initial['identity']['model']['nodes'])
  record['cases'][name]={'inputs':count,'frequency_hz':frequency,'normalization':model['normalization'],'topology':'Branch' if model['branch'] else 'Classic','model_revision':r['analysis']['model_revision'],'model_ticks':0}
  (out/'corpus.json').write_text(json.dumps(record,indent=2)+'\n')
  print(name+' completed',flush=True)
 assert len(record['cases'])==32
 assert source_closure(source)==closure;verify_runtime(runtime)
 assert all(hashlib.sha256((code/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in code_records)
 (out/'terminal.json').write_text(json.dumps({'execution':'completed','cases':32,'reader_tests':18,'preparation_source':revision,'scientific_verdict':None})+'\n')
except BaseException as error:
 (out/'exception.json').write_text(json.dumps({'error':str(error),'traceback':traceback.format_exc()})+'\n');raise
