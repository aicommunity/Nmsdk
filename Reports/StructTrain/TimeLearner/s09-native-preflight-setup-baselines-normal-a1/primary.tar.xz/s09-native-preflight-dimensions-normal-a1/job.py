import pathlib,json,os,subprocess,sys,copy,traceback
base=pathlib.Path('/home/user/timelearner-refactor');out=base/'readbacks/s09-native-preflight-dimensions-normal-a1'
source=base/'source-n1-measured-refinement-normal-a1';parent=base/'readbacks/s09-native-preflight-normal-a1'
sys.path.insert(0,str(source))
from Scripts.StructTrain.TimeLearner.native_pipeline_worker import run_job,audit_run_manifest
from Scripts.StructTrain.TimeLearner.native_calibration_worker import _signed
from Scripts.StructTrain.TimeLearner.runtime import source_closure,verify_runtime
try:
 closure=source_closure(source);runtime=json.loads((parent/'runtime.json').read_text());verify_runtime(runtime)
 assert closure==runtime['source_closure']
 (out/'inputs').mkdir();(out/'runs').mkdir()
 record={'kind':'native_preflight_dimension_corpus','schema_version':1,'cases':{},'scientific_verdict':None}
 for topology in ['Classic','Branch']:
  for norm in ['0','1']:
   original=json.loads((parent/'corpus/inputs'/('pipeline-'+topology+'-N'+norm+'.json')).read_text())
   for count in [1,2,4,6]:
    for frequency in [2000,20000]:
     name=topology+'-N'+norm+'-inputs'+str(count)+'-f'+str(frequency)
     job=copy.deepcopy(original);c=job['configuration'];m=c['model']
     m['frequency_hz']=frequency;m['inputs']=[copy.deepcopy(m['inputs'][0]) for _ in range(count)]
     m['initial_isi']=[.02]*count;m['allocated_cable_lengths']=[m['inputs'][0]['attachment']]*(1 if m['branch'] else count)
     c['stimulus_profile']['frequency_hz']=frequency;c['duration']=.3;c['maximum_sample_gap']=1./frequency;c['maximum_samples']=frequency+1
     c['windows']=[[(i+1)*.02,(i+1)*.02+.015] for i in range(count)]
     c['maximum_reference_probes']=max(c['maximum_reference_probes'],count*2)
     c['search']['bounds']=[copy.deepcopy(c['search']['bounds'][0]) for _ in range(count)]
     c['run_id']='preflight-dimension-'+name
     if norm=='0':c['schema_version']=2;c['search']['n0_candidate_repeats']=2
     job=_signed({k:v for k,v in job.items() if k!='sha256'})
     path=out/'inputs'/(name+'.json');path.write_text(json.dumps(job,allow_nan=False)+'\n')
     r=run_job('preflight',path,None,parent/'runtime.json',out/'runs'/name,120)
     assert r['execution']=='completed' and r['validity']=='valid',name
     audit=audit_run_manifest(out/'runs'/name/'run-manifest.json');assert audit['run_evidence_consistent']
     initial=json.loads((out/'runs'/name/'native/initial-state.json').read_text())
     assert len(initial['parameters'])==count
     assert all(n['frequency_hz']==str(frequency) for n in initial['identity']['model']['nodes'])
     record['cases'][name]={'inputs':count,'frequency_hz':frequency,'normalization':'N'+norm,'topology':topology,'model_revision':r['analysis']['model_revision'],'model_ticks':0}
     (out/'corpus.json').write_text(json.dumps(record,indent=2)+'\n')
     print(name+' completed',flush=True)
 assert len(record['cases'])==32
 assert source_closure(source)==closure;verify_runtime(runtime)
 (out/'terminal.json').write_text(json.dumps({'execution':'completed','cases':32,'scientific_verdict':None})+'\n')
except BaseException as error:
 (out/'exception.json').write_text(json.dumps({'error':str(error),'traceback':traceback.format_exc()})+'\n');raise
