import unittest,json,pathlib,sys
suite=unittest.defaultTestLoader.discover('Scripts/StructTrain/TimeLearner/tests',top_level_dir='.')
with open(sys.argv[1]+'/unittest.log','w') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
v={'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':[(str(t),s) for t,s in r.skipped],'successful':r.wasSuccessful()}
pathlib.Path(sys.argv[1]+'/result.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({**v,'skipped':len(v['skipped'])}))
