import unittest,json,pathlib,sys
sys.path.insert(0,str(pathlib.Path.cwd()))
names=json.loads(sys.argv[2])
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+n) for n in names)
with open(sys.argv[1]+'/unittest.log','w') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
v={'modules':names,'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':[(str(t),s) for t,s in r.skipped],'successful':r.wasSuccessful()}
pathlib.Path(sys.argv[1]+'/result.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({**v,'modules':len(names),'skipped':len(v['skipped'])}))
