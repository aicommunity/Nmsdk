set -euo pipefail
base=/home/user/timelearner-refactor
out="$base/readbacks/s08-native-owned-posttune-reader-normal-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
repo="$base/source-training-intent-binding-reader-normal-a1"
work="$base/source-owned-posttune-reader-normal-a2"
git -C "$repo" -c fetch.recurseSubmodules=false fetch origin 007eae21cdaeb7ff2336d77913bcf3eff6c36886 > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" 007eae21cdaeb7ff2336d77913bcf3eff6c36886 >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone
git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
gate="$base/readbacks/s08-native-owned-posttune-normal-a2"
while test ! -f "$gate/process-exit-status.txt"; do kill -0 2073217; sleep 10; done
test "$(cat "$gate/process-exit-status.txt")" = 0
cd "$work"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_OWNED_POSTTUNE_NATIVE="$gate/native"
export TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES="$base/readbacks/s08-native-posttune-fixed-normal-a2/baseline-source"
python3 -u - <<'PY' > "$out/test.log" 2>&1
import json,os,time,unittest
from pathlib import Path
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.owned_posttune_evidence import audit_owned_posttune
start=time.monotonic()
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_owned_posttune_evidence'))
cases={}
if result.wasSuccessful():
 for p in sorted(Path(os.environ['TIMELEARNER_OWNED_POSTTUNE_NATIVE']).glob('*_managed_finalization_*_owned_*.json')):
  topology=p.name.split('_')[0]
  source=Path(os.environ['TIMELEARNER_FINALIZATION_ORIGINAL_FIXTURES'])/('Classic-auto_metric' if topology=='Classic' else 'Branch-synthetic')/'input/source'
  cases[p.name]=audit_owned_posttune(load(p),load_case(next(source.glob('*_learned_state.json'))))
summary={'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'seconds':time.monotonic()-start,'cases':cases,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
assert result.wasSuccessful() and result.testsRun==2 and not result.skipped and len(cases)==10
PY
