from pathlib import Path
import sys,os,json,time,threading,hashlib,unittest,traceback,tarfile,io
base=Path('/media/user/Data/TimeLearnerRefactor')
source=base/'source-feedback-profile-readers-a1-delivery'
framework=base/'source-worker-dependency-normal-a2'
study=base/'readbacks/s07-feedback-console-normal-a2'
out=base/'readbacks/s07-feedback-profile-readers-a1'
out.mkdir(exist_ok=False)
sys.dont_write_bytecode=True
sys.path.insert(0,str(framework))
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
registry=Reservations(base/'resource-reservations.sqlite3')
stop_event=threading.Event();errors=[];token=None;thread=None

def write(name,value):
 (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
try:
 reservation=registry.reserve('s07-feedback-profile-readers-a1',[{'path':str(out),'access':'write'}]+[{'path':str(p),'access':'read'} for p in [source,framework,study]],ttl_seconds=120)
 token=reservation['token'];write('reservation.json',reservation)
 def beat():
  while not stop_event.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=beat,daemon=True);thread.start()
 import subprocess
 from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
 prior=inspect_worker_dependency(Path(str(study)+'-container'),registry,study.name)
 assert prior['state']=='ready' and prior['reservation_state']=='released',prior
 raw=(study/'primary.tar.xz').read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='8f7a7f741763ae1547b7ed8a0817c4a0ea133afc45a7ae81d272de6218fa26b4'
 def original_files():
  return {f.relative_to(study).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in (study/'feedback-study').rglob('*') if f.is_file()}
 original=original_files();write('input-file-hashes.json',original)
 write('source-primary-binding.json',{'native_primary_archive_sha256':hashlib.sha256(raw).hexdigest(),'compiled_root':'844b2789ea0c087c1a0f676d9584ce7b8a7a4d36','corrected_reader_root':'3b3642feb92b2bb17481b79a776be69351db0375','native_reexecuted':False,'prior':prior})
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()=='3b3642feb92b2bb17481b79a776be69351db0375'
 write('owned-process.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]})
 write('source-hashes.json',{p.relative_to(source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'Scripts').rglob('*.py')})
 # The framework ledger instance remains bound; tests use the exact candidate tree.
 for name in list(sys.modules):
  if name=='Scripts' or name.startswith('Scripts.'):del sys.modules[name]
 sys.path.insert(0,str(source));os.chdir(source)
 os.environ['TIMELEARNER_FEEDBACK_PROFILE_CORPUS']=str(study/'feedback-study')
 suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.'+name) for name in ['test_feedback_profile_execution.FeedbackProfileExecutionTest'])
 assert suite.countTestCases()==2
 with (out/'tests.log').open('w') as log:result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 write('tests.json',{'tests_run':result.testsRun,'successful':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped)})
 assert result.wasSuccessful() and result.testsRun==2 and not result.skipped and not errors
 assert original_files()==original
 write('terminal.json',{'actual_execution_reader_controls_passed':True,'native_compilation_verified':False,'waveform_equivalence_verified':False,'scientific_verdict':None})
except BaseException as e:
 write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
 write('terminal.json',{'actual_execution_reader_controls_passed':False,'native_compilation_verified':False,'scientific_verdict':None})
finally:
 stop_event.set()
 if thread:thread.join(timeout=30)
 payloads={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
 payloads['producer.py']=Path(__file__).read_bytes()
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w:xz') as archive:
  for name,raw in sorted(payloads.items()):
   entry=tarfile.TarInfo(name);entry.size=len(raw);archive.addfile(entry,io.BytesIO(raw))
 raw=buffer.getvalue();(out/'primary.tar.xz').write_bytes(raw)
 write('bundle.json',{'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payloads.items()},'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'root':'3b3642feb92b2bb17481b79a776be69351db0375'})
