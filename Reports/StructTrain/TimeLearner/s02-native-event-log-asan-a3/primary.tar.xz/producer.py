from pathlib import Path
import subprocess,json,os,sys,hashlib,traceback,signal,tarfile,contextlib,concurrent.futures
base=Path('/media/user/Data/TimeLearnerRefactor');ROOT='b3bfe86e913bc1f7aeb5a340a72698eacb060f00';OLD='5949d850cc41e51e5d94d8fb812e7509d5fa6380'
out=base/('readbacks/s02-native-event-log-'+'asan'+'-a3');out.mkdir(exist_ok=False)
sdk=base/'source-initial-threshold-asan-a2';build=base/'build-initial-threshold-asan-a2';runtime=base/('runtime-native-event-log-'+'asan'+'-a3');old_runtime=base/('runtime-native-event-log-'+'asan'+'-a2')
prior=base/('readbacks/s05-model-spec-production-'+'asan'+'-a4')
def write(n,v):
 p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def live(r):
 try:return ticks(r['pid'])==r['start_ticks']
 except FileNotFoundError:return False
def inventory(folder):return {p.relative_to(folder).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'realpath':str(p.resolve()),'bytes':p.stat().st_size} for p in folder.rglob('*') if p.is_file()}
def git(*a):return subprocess.check_output(['git','-C',str(sdk),*a],text=True).strip()
def run(args,name,timeout=3600):
 with (out/name).open('xb') as log:
  p=subprocess.Popen([str(a) for a in args],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);owned={'pid':p.pid,'start_ticks':ticks(p.pid),'arguments':[str(a) for a in args]};write('owned-'+name+'.json',owned)
  try:rc=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   if live(owned) and os.getpgid(p.pid)==p.pid:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:
     if live(owned) and os.getpgid(p.pid)==p.pid:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
   raise
  assert rc==0,(name,rc)
(out/'producer.py').write_bytes(Path(__file__).read_bytes());write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':ROOT})
passed=False;before=None;new_before=None
try:
 assert not live(json.loads((prior/'owned-supervisor.json').read_text()))
 assert json.loads((prior/'final-readers.json').read_text())=={'tests':5,'failures':0,'errors':0,'skipped':0}
 assert json.loads((prior/'corpus/index.json').read_text())['all_calibrated_transfers_completed']
 previous=base/'readbacks/s02-native-event-log-asan-a2'
 assert not live(json.loads((previous/'owned-supervisor.json').read_text()))
 (out/'prior-attempt').mkdir()
 for name in ['primary.tar.xz','bundle.json']:(out/'prior-attempt'/name).write_bytes((previous/name).read_bytes())
 assert git('rev-parse','HEAD')==OLD and not git('status','--porcelain','--untracked-files=no') and not runtime.exists()
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:assert not str((p/'exe').resolve()).startswith(str(old_runtime)+'/'),'old runtime still live'
  except (FileNotFoundError,PermissionError):pass
 before=inventory(old_runtime);write('old-runtime-before.json',before)
 run(['git','-C',sdk,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',ROOT],'fetch-source.log')
 changed=git('diff','--name-only',OLD,ROOT,'--','App','Tests','CMakeLists.txt','cmake').splitlines()
 assert changed==[],changed
 assert not git('diff','--name-only',OLD,ROOT,'--','Libraries','Bin')
 assert not git('diff','--name-only',OLD,ROOT,'--','Rdk')
 write('closed-build-reuse.json',{'old_root':OLD,'new_root':ROOT,'source_changes':changed,'build_target':'NeuroModelerConsole','test_cpp_not_built':True,'rdk_application_work_directory_changed':False,'neural_component_sources_unchanged':True,'old_runtime_preserved':True})
 run(['git','-C',sdk/'Rdk','fetch','--no-recurse-submodules','https://github.com/aicommunity/Rdk.git','0e70cf07ddc52f6af81ac0b291e299434925319c'],'fetch-rdk.log')
 run(['git','-C',sdk,'checkout','--detach',ROOT],'checkout-source.log')
 run(['git','-C',sdk/'Rdk','checkout','--detach','0e70cf07ddc52f6af81ac0b291e299434925319c'],'checkout-rdk.log')
 assert not git('status','--porcelain','--untracked-files=no')
 run(['cmake','-S',sdk,'-B',build,'-DNMSDK_DEPLOY_ROOT='+str(runtime)],'configure.log')
 run(['cmake','--build',build,'--target','NeuroModelerConsole','--parallel','1'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 sys.path.insert(0,str(sdk));os.chdir('/tmp')
 os.environ['PYTHONPATH']=str(sdk);os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 for k in ['LD_LIBRARY_PATH','QT_PLUGIN_PATH']:os.environ.pop(k,None)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.__main__ import main as cli
 from Scripts.StructTrain.TimeLearner.native_pipeline_worker import audit_run_manifest
 from Scripts.StructTrain.TimeLearner.process_runner import execute
 from Scripts.StructTrain.TimeLearner.recognition_metrics import load_evaluation
 run([sys.executable,'-m','unittest','Scripts.StructTrain.TimeLearner.tests.test_native_event_log_artifacts','-v'],'artifact-reader-tests.log')
 new_before=inventory(runtime);write('new-runtime-before.json',new_before)
 manifest=snapshot(sdk,runtime/'NeuroModelerConsole',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt');write('runtime.json',manifest)
 (out/'preflights').mkdir();(out/'frozen').mkdir();records=[]
 plan=json.loads((prior/'prepared/plan.json').read_text())
 for row in plan['conditions']:
  name=row['name'];source=prior/'prepared/jobs'/(name+'-train.json');folder=out/'preflights'/name
  with (out/(name+'-preflight.log')).open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):code=cli(['preflight',str(source),'--runtime-manifest',str(out/'runtime.json'),'--wall-seconds','120','--output',str(folder)])
  assert code==0;assert audit_run_manifest(folder/'run-manifest.json')['run_evidence_consistent']
  initial=json.loads((folder/'native/initial-state.json').read_text());expected=json.loads((prior/'corpus/runs'/(name+'-train')/'native/initial-state.json').read_text());assert initial['identity']==expected['identity'] and initial['parameters']==expected['parameters'] and not initial['training_started']
  assert (folder/'native.events-log').is_dir()
  source=prior/'corpus/jobs'/(name+'-frozen.json');solo=prior/'corpus/runs'/(name+'-train')/'native/train_learned_state.json';folder=out/'frozen'/name
  with (out/(name+'-frozen.log')).open('w') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):code=cli(['evaluate',str(source),'--source-solo',str(solo),'--runtime-manifest',str(out/'runtime.json'),'--wall-seconds','300','--output',str(folder)])
  assert code==0;assert audit_run_manifest(folder/'run-manifest.json')['run_evidence_consistent']
  old=prior/'corpus/runs'/(name+'-frozen')/'native';_,a=load_evaluation(old/'evaluation.json');_,b=load_evaluation(folder/'native/evaluation.json');assert a==b
  for n in ['model.json','model-after.json']:assert json.loads((folder/'native'/n).read_text())==json.loads((old/n).read_text())
  expected_dir=out/'expected'/name;expected_dir.mkdir(parents=True)
  for n in ['evaluation.json','trial-0.json','trial-1.json','trial-2.json','trial-3.json']:(expected_dir/n).write_bytes((old/n).read_bytes())
  assert (folder/'native.events-log').is_dir();records.append({'name':name,'preflight_matches_original':True,'all_four_frozen_observations_equal':True,'complete_calibrated_package_equal':True})
 write('positive-cases.json',records)
 template=prior/'prepared/jobs/Classic-v1-train.json';(out/'negatives').mkdir();negative=[]
 def refusal(label,destination,expected_reason,appini=None):
  root=out/'negatives'/label;root.mkdir();ini=appini or runtime/'NeuroModelerConsole.ini'
  m=manifest if appini is None else snapshot(sdk,runtime/'NeuroModelerConsole',ini,build/'CMakeCache.txt')
  result=execute(m,['--app-ini',str(ini),'--timelearner-preflight',str(template),'--timelearner-output',str(destination)],runtime,root/'process',120)
  assert result['returncode']==2
  text=(root/'process/stderr.log').read_text();errors=[json.loads(s) for s in text.splitlines() if s.startswith('{')];assert any(d.get('kind')=='timelearner_native_configuration_error' and d.get('reason')==expected_reason and d.get('validity')=='invalid_config' and d.get('execution')=='not_started' for d in errors)
  negative.append({'name':label,'returncode':2,'reason':expected_reason,'diagnostic':errors})
 refusal('runtime-output',runtime/'forbidden-native-result','invalid_native_output_or_event_log_path')
 previous=out/'preflights/Classic-v1';saved=inventory(previous);refusal('existing-output',previous/'native','invalid_native_output_or_event_log_path');assert saved==inventory(previous)
 bad=out/'bad-log.ini';text=(runtime/'NeuroModelerConsole.ini').read_text();assert text.count('[Log]')==1;bad.write_text(text.replace('[Log]','[Log]\nDir='+str(out/'forbidden-common-log'),1));(out/'bad-ini-output').mkdir();refusal('ini-override',out/'bad-ini-output/native','native_event_log_ini_override_not_allowed',bad)
 write('negative-cases.json',negative)
 (out/'duplicate-output').mkdir();destination=out/'duplicate-output/native'
 def duplicate(label):
  return execute(manifest,['--app-ini',str(runtime/'NeuroModelerConsole.ini'),'--timelearner-preflight',str(template),'--timelearner-output',str(destination)],runtime,out/'duplicate-processes'/label,120,cooperative_capture=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(duplicate,['a','b']))
 assert sorted(r['returncode'] for r in results)==[0,2];winner=next(i for i,r in enumerate(results) if r['returncode']==0);winner_pid=json.loads((out/'duplicate-processes'/['a','b'][winner]/'owned-process.json').read_text())['pid']
 logs=[p for p in (out/'duplicate-output/native.events-log/EventsLog').rglob('*') if p.is_file() and not p.is_symlink()];assert logs and all(int(p.name.rsplit('.',1)[1])==winner_pid for p in logs)
 write('concurrent-duplicate.json',{'returncodes':[r['returncode'] for r in results],'winner_pid':winner_pid,'only_winner_has_log_files':True})
 after=inventory(runtime);write('new-runtime-after.json',after);assert after==new_before
 passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'scientific_verdict':None})
finally:
 if before is not None:
  after=inventory(old_runtime);write('old-runtime-after.json',after)
  if after!=before:passed=False;write('old-runtime-guard-failed.json',{'same':False})
 if new_before is not None:
  after=inventory(runtime);write('new-runtime-final.json',after)
  if after!=new_before:passed=False;write('new-runtime-guard-failed.json',{'same':False})
 write('terminal.json',{'status':'passed' if passed else 'not_accepted','positive_preflights_declared':4,'frozen_imports_declared':4,'negative_cases_declared':3,'concurrent_duplicate_declared':2,'scientific_verdict':None})
 hashes={p.relative_to(sdk).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['App/NeuroModelerConsole','Scripts/StructTrain/TimeLearner'] for p in (sdk/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts};write('source-hashes.json',hashes)
 files={p.relative_to(out).as_posix():p for p in out.rglob('*') if p.is_file() and not p.is_symlink()};records={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for n,p in files.items()}
 archive=out/'primary.tar.xz'
 with tarfile.open(archive,'w:xz',preset=3,dereference=True) as t:
  for n,p in files.items():t.add(p,arcname=n,recursive=False)
 write('bundle.json',{'kind':'native_console_event_log_isolation_validation','root':ROOT,'pulselib':'541bf89b9966f63ca5131fa57a31a9ae3f5820ea','rdk':'0e70cf07ddc52f6af81ac0b291e299434925319c','acceptance_status':'passed' if passed else 'not_accepted','members':records,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'scientific_verdict':None})
 print('CLOSED',passed,flush=True)
