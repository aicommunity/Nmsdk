set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-solo-threshold-trace-asan-a1"
src="$base/source-threshold-contract-asan-isolated-a1"
build="$base/build-threshold-contract-asan-isolated-a1"
runtime="$base/runtime-s08-native-solo-threshold-trace-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3911421 2>/dev/null && test ! -f "$base/readbacks/s08-native-finalization-ownership-asan-a1/process-exit-status.txt"; do sleep 10; done
test "$(cat "$base/readbacks/s08-native-finalization-ownership-asan-a1/process-exit-status.txt")" = 0
test "$(cat "$base/readbacks/s04-uninitialized-bool-baseline-asan-a1/process-exit-status.txt")" = 0
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
test ! -e "$runtime"
test -z "$(git -C "$src" status --porcelain)"
export SRC="$src" BUILD="$build" BASE="$base" OUT="$out"
python3 - <<'PY' > "$out/live-source-check.json"
import json,os
from pathlib import Path
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:exe=(p/'exe').resolve(strict=True);cwd=(p/'cwd').resolve(strict=True)
 except (OSError,RuntimeError):continue
 if str(exe).startswith(os.environ['BASE']+'/runtime-') or str(cwd).startswith(os.environ['SRC']) or (str(cwd).startswith(os.environ['BUILD']) and exe.name in {'cmake','make','gmake','cc1plus'}):
  active.append({'pid':int(p.name),'executable':str(exe),'cwd':str(cwd)})
print(json.dumps({'active_owned_jobs':active}));assert not active
PY
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git a87bb8fc16d5ad0a48b5b337efb11c72c6d26724 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" rev-parse HEAD > "$out/source-closure.txt"
git -C "$src" submodule status --recursive >> "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents NeuroModelerConsole -j 1 > "$out/build.log" 2>&1
test "$(df -B1 --output=avail "$base" | tail -n 1)" -gt 1073741824
cd "$src"
export PYTHONDONTWRITEBYTECODE=1
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
unset QT_QPA_PLATFORM
export TIMELEARNER_EXECUTION_OUTPUT="$out/native"
export TIMELEARNER_POSTTUNE_FIXED_SOURCE="$base/readbacks/s08-native-posttune-fixed-asan-a1/baseline-source"
export TIMELEARNER_POSTTUNE_CONFIG_SOURCE="$TIMELEARNER_POSTTUNE_FIXED_SOURCE"
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
python3 -u - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as ET
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.process_runner import execute
out=Path(os.environ['OUT']);runtime=load(out/'runtime-before.json')
filter='NativeSoloThresholdTrace.*:NativeFinalizationBoundary.*:TimeLearnerNativeLifecycle.*:NativePostTuneConfiguration.*'
result=execute(runtime,['--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'native.xml')],
 Path(runtime['executable']['path']).parent,out/'process',1800)
x=ET.parse(out/'native.xml').getroot()
assert all(int(x.attrib.get(k,'0'))==0 for k in ['failures','errors','disabled']) and not x.findall('.//skipped')
assert result['returncode']==0 and result['execution']=='completed' and result['runtime_provenance']=='loaded_files_captured'
names={(s.attrib['name'],t.attrib['name']) for s in x.findall('testsuite') for t in s.findall('testcase')}
assert len(names)==int(x.attrib['tests'])==33
assert sum(a=='NativeFinalizationBoundary' for a,b in names)==9
assert sum(a=='NativeSoloThresholdTrace' for a,b in names)==8
report={'kind':'native_solo_threshold_trace_gate','schema_version':1,'native_tests':33,
 'native_seconds':float(x.attrib['time']),'test_names':[list(n) for n in sorted(names)],
 'runtime_provenance':result['runtime_provenance'],'native_execution_attested':False,'scientific_verdict':None}
(out/'native-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
PY
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-after.json"
cmp "$out/runtime-before.json" "$out/runtime-after.json"
