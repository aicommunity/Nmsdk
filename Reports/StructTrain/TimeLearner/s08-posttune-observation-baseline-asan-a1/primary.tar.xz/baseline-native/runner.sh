set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
src="$base/source-threshold-contract-asan-isolated-a1";build="$base/build-threshold-contract-asan-isolated-a1"
out="$base/readbacks/s08-posttune-observation-baseline-asan-a1";runtime="$base/runtime-s08-posttune-observation-baseline-asan-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s09-native-pipeline-asan-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git d8e2ad16d79d1309aef88887b5e9c388539542a4 > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach d8e2ad16d79d1309aef88887b5e9c388539542a4 >> "$out/checkout.log" 2>&1
git -C "$src" submodule update --init --recursive >> "$out/checkout.log" 2>&1
git -C "$src" submodule status --recursive > "$out/source-closure.txt"
cmake -S "$src" -B "$build" -DNMSDK_DEPLOY_ROOT="$runtime" -DNMSDK_RESOURCE_ROOT="$src/Bin" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCMAKE_CXX_FLAGS_RELWITHDEBINFO="-O1 -g1 -fsanitize=address -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address" -DCMAKE_SHARED_LINKER_FLAGS="-fsanitize=address" > "$out/configure.log" 2>&1
cmake --build "$build" --target Test_PulseLib_StorageComponents -j 1 > "$out/build.log" 2>&1
cd "$src"
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1
python3 -m Scripts.StructTrain.TimeLearner.runtime --root "$src" --executable "$runtime/Test_PulseLib_StorageComponents" --app-ini "$runtime/NeuroModelerConsole.ini" --cache "$build/CMakeCache.txt" --output "$out/runtime-before.json"
mkdir "$out/native"
set +e
(cd "$runtime" && TIMELEARNER_EXECUTION_OUTPUT="$out/native" ./Test_PulseLib_StorageComponents --gtest_filter='LegacyPostTuneInferenceObservation.*' --gtest_output="xml:$out/native.xml") > "$out/native.log" 2>&1
native_rc=$?
set -e
echo "$native_rc" > "$out/native-exit-status.txt"
OUT="$out" python3 - <<'PY' > "$out/validation.log" 2>&1
import json,os,xml.etree.ElementTree as E
from pathlib import Path
p=Path(os.environ['OUT']);xml=E.parse(p/'native.xml').getroot();cases=list(xml.iter('testcase'))
v={'root':'d8e2ad16d79d1309aef88887b5e9c388539542a4','pulse':'ded4b558af46bb2caa07587d1dce81cba2da7c11','tests':len(cases),'failed':[q.attrib['name'] for q in cases if q.find('failure') is not None],'native_returncode':int((p/'native-exit-status.txt').read_text()),'scientific_verdict':None}
(p/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
assert len(cases)==8 and len(v['failed'])==6 and v['native_returncode']==1,v
assert not list(xml.iter('error')) and not list(xml.iter('skipped'))
print(json.dumps(v))
PY
cd "$src"
RUNTIME_MANIFEST="$out/runtime-before.json" python3 - <<'PY' > "$out/runtime-after.json"
import json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.process_runner import verify_runtime
print(json.dumps({'verified':True,'executable':str(verify_runtime(json.loads(Path(os.environ['RUNTIME_MANIFEST']).read_bytes())))}))
PY
