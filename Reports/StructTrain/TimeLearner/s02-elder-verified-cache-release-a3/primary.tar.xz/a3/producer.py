from pathlib import Path
import os,sys,json,hashlib,tarfile,stat,sqlite3,threading,traceback,shutil,time
base=Path('/home/user/timelearner-refactor');tool=base/'source-publication-lock-recovery-a2';out=base/'readbacks/s02-elder-verified-cache-release-a3';out.mkdir(exist_ok=False);old=base/'readbacks/s07-csearch-threshold-joint-full-normal-a1';rawdir=old/'native-result/native';builds=[base/n for n in ['build-august-phasea-de02-a1','build-initial-threshold-normal-a4','build-n1-measured-refinement-normal-a1']];protected=base/'runtime-integrated-acceptance-normal-a1'
sys.dont_write_bytecode=True;os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.path.insert(0,str(tool));os.nice(19)
from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
from Scripts.StructTrain.TimeLearner.worker_dependency import inspect_worker_dependency
registry=None;token=None;stop=threading.Event();thread=None;errors=[];passed=False;deleted=[]
def write(n,v):(out/n).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def own_users_of_targets():
 users=[];excluded=[];targets=[rawdir,*builds]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   if entry.stat().st_uid!=os.getuid():continue
   cwd=(entry/'cwd').resolve(strict=True);cmd=(entry/'cmdline').read_bytes()
   used=any(cwd.is_relative_to(t) or str(t).encode() in cmd for t in targets)
   for fd in (entry/'fd').iterdir():
    try:target=os.readlink(fd)
    except FileNotFoundError:continue
    if any(target==str(t) or target.startswith(str(t)+'/') for t in targets):used=True
   if used:users.append(int(entry.name))
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:
   name=(entry/'comm').read_text().strip();cgroup=(entry/'cgroup').read_text().strip();status=(entry/'status').read_text();parent=int(next(l.split()[1] for l in status.splitlines() if l.startswith('PPid:')))
   argv0=(entry/'cmdline').read_bytes().split(b'\0')[0].decode(errors='strict')
   pam=name=='(sd-pam)' and argv0=='(sd-pam)' and Path('/proc',str(parent),'comm').read_text().strip()=='systemd' and cgroup=='0::/user.slice/user-1000.slice/user@1000.service/init.scope'
   session=cgroup.startswith('0::/user.slice/user-1000.slice/session-') and cgroup.endswith('.scope')
   transport=session and ((name=='ssh-agent' and argv0=='/usr/bin/ssh-agent') or (name=='sshd' and argv0.startswith('sshd: user@')))
   assert pam or transport,(entry.name,name,cgroup)
   excluded.append({'pid':int(entry.name),'comm':name,'parent_pid':parent,'argv0':argv0,'cgroup':cgroup,'scope':'identified PAM/SSH transport helper; protected proc cwd/fd not inspected; child processes scanned individually'})
 write('process-scan-exclusions.json',excluded)
 return users
write('owner.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert base.resolve()==base and rawdir.resolve()==rawdir and all(p.resolve()==p and p.is_relative_to(base) for p in builds)
 c=sqlite3.connect('file:'+str(base/'resource-reservations.sqlite3')+'?mode=ro',uri=True)
 try:metadata=dict(c.execute('SELECT key,value FROM metadata'))
 finally:c.close()
 registry=Reservations(base/'resource-reservations.sqlite3',capacity=json.loads(metadata['capacity']))
 prior2=inspect_worker_dependency(base/'readbacks/s02-elder-verified-cache-release-a2-container',registry,'s02-elder-verified-cache-release-a2');assert prior2['state']=='ready';write('prior-cleanup-a2-closure.json',prior2)
 prior=inspect_worker_dependency(base/'readbacks/s02-elder-verified-cache-release-a1-container',registry,'s02-elder-verified-cache-release-a1');assert prior['state']=='ready';write('prior-cleanup-closure.json',prior)
 previous=inspect_worker_dependency(Path(str(old)+'-container'),registry,old.name);assert previous['state']=='ready';write('previous-native-closure.json',previous)
 lease=registry.reserve(out.name,[{'path':str(out),'access':'write'},{'path':str(rawdir),'access':'write'}]+[{'path':str(p),'access':'write'} for p in builds]+[{'path':str(protected),'access':'read'},{'path':str(tool),'access':'read'}],ttl_seconds=120,demands={'slots':1,'memory_bytes':512*1024**2,'disk_bytes':16*1024**2});token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 assert sha(old/'bundle.json')=='8ad75229c4af2bccabef1afbd414198c7fe969a581e53591dd0c2460390f7c50'
 bundle=json.loads((old/'bundle.json').read_text());assert bundle['archive_sha256']=='e0b4dbc2ba7f34f1f0579b19309240842c7d31c0a1624656f61010d1fae2f94c' and sha(old/'primary.tar.xz')==bundle['archive_sha256'];seen=set()
 with tarfile.open(old/'primary.tar.xz','r:xz') as archive:
  for member in archive:
   assert member.isfile() and member.name not in seen;seen.add(member.name);h=hashlib.sha256();size=0
   stream=archive.extractfile(member)
   for block in iter(lambda:stream.read(1024**2),b''):h.update(block);size+=len(block)
   assert bundle['members'][member.name]=={'bytes':size,'sha256':h.hexdigest()}
 assert seen==set(bundle['members']) and len(seen)==3932
 protected_before={p.relative_to(protected).as_posix():sha(p) for p in protected.rglob('*') if p.is_file()};assert protected_before
 plan=[]
 for name,record in bundle['members'].items():
  if not name.startswith('native-result/native/'):continue
  path=old/name;assert path.resolve()==path and path.is_relative_to(rawdir) and not path.is_symlink();info=path.stat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==record['bytes'] and sha(path)==record['sha256'];plan.append({'path':str(path),'bytes':info.st_size,'sha256':record['sha256'],'inode':info.st_ino,'mtime_ns':info.st_mtime_ns,'category':'published_archive_duplicate'})
 assert len(plan)==3907 and sum(r['bytes'] for r in plan)==1489206406
 assert {p for p in rawdir.rglob('*') if p.is_file()}=={Path(r['path']) for r in plan}
 for folder in builds:
  for parent,dirs,files in os.walk(folder,followlinks=False):
   dirs[:]=[d for d in dirs if not Path(parent,d).is_symlink()]
   for name in files:
    path=Path(parent,name)
    if not name.endswith(('.cpp.o','.c.o','.cc.o','.cxx.o','.S.o')) or 'CMakeFiles' not in path.parts:continue
    info=path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:continue
    assert path.resolve()==path and path.is_relative_to(folder);plan.append({'path':str(path),'bytes':info.st_size,'sha256':sha(path),'inode':info.st_ino,'mtime_ns':info.st_mtime_ns,'category':'obsolete_compilation_object'})
 assert sum(r['bytes'] for r in plan if r['category']=='obsolete_compilation_object')==299451536
 users=own_users_of_targets();assert not users,users;write('plan.json',{'published_data_commit':'25bbda5529caea24e8847973cd603d50b1b45826','origin_root_verified_locally':'55bb4d559a0586e04f148d6d50b26c6fae569ccf','archive_members_verified':3932,'archive_preserved':str(old/'primary.tar.xz'),'archive_sha256':bundle['archive_sha256'],'matched_user_processes':users,'files':plan,'protected_runtime_hashes':protected_before});before=shutil.disk_usage(base).free
 for row in plan:
  registry.validate_paths(token);assert not errors;path=Path(row['path']);info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_ino==row['inode'] and info.st_mtime_ns==row['mtime_ns'] and info.st_size==row['bytes'] and sha(path)==row['sha256'];assert path.resolve()==path;path.unlink();deleted.append(row['path'])
  with (out/'deleted.jsonl').open('a') as stream:stream.write(json.dumps({'path':str(path),'bytes':row['bytes'],'sha256':row['sha256']})+'\n')
 assert sha(old/'primary.tar.xz')==bundle['archive_sha256']
 assert protected_before=={p.relative_to(protected).as_posix():sha(p) for p in protected.rglob('*') if p.is_file()}
 (rawdir/'CACHE_RESTORATION.md').write_text('Only expanded duplicate native cache files were removed after verification. Original primary.tar.xz and bundle.json remain in the parent readback; full original data also in Git commit25bbda5529caea24e8847973cd603d50b1b45826, Reports/StructTrain/TimeLearner/s10-elder-completed-gates-20261104/s07-csearch-threshold-joint-full-normal-a1. Restore the native-result/native members before reusing an old expanded-fixture path. No scientific measurement is discarded.\n')
 write('result.json',{'deleted_files':len(deleted),'published_duplicate_files':3907,'duplicate_bytes':1489206406,'generated_object_bytes':299451536,'logical_bytes_removed':sum(r['bytes'] for r in plan),'disk_free_before':before,'disk_free_after':shutil.disk_usage(base).free,'archive_preserved':True,'all_current_runtime_hashes_unchanged':len(protected_before),'scientific_verdict':None});passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc(),'already_deleted':len(deleted)})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 write('terminal.json',{'verified_cache_release_passed':passed,'already_deleted':len(deleted),'native_models_executed':0,'scientific_verdict':None});print('CLOSED',passed,flush=True)
