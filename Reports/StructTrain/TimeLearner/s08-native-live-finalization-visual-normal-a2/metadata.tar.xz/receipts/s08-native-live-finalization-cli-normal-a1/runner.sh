set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-live-finalization-cli-normal-a1"
plot="$base/readbacks/s08-native-live-finalization-visual-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-live-finalization-cli-normal-a1"
export OUT="$out" PYTHONDONTWRITEBYTECODE=1
export TIMELEARNER_LIVE_FINALIZATION_NATIVE="$plot/data/composed-native"
export TIMELEARNER_LIVE_PRIMARY_INVENTORY="$plot/data/s08-native-live-finalization-reader-normal-a3/composition.json"
test -f "$TIMELEARNER_LIVE_PRIMARY_INVENTORY"
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import os,json,time,unittest,hashlib
inputs=[Path(os.environ['TIMELEARNER_LIVE_PRIMARY_INVENTORY']),Path(os.environ['TIMELEARNER_LIVE_FINALIZATION_NATIVE'])/'Classic_live_finalization_0_local_6.json']
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
start=time.monotonic()
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_finalization_cli'))
assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}==before
value={'kind':'native_live_finalization_cli_gate','schema_version':1,'source_root':'10032be3c420ec16401db1f903dc9c984b776379','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,'source_inputs_unchanged':before,'new_numerical_runs':0,'scientific_verdict':None}
(Path(os.environ['OUT'])/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
assert r.wasSuccessful() and r.testsRun==2 and not r.skipped,value
print(json.dumps(value),flush=True)
PY
