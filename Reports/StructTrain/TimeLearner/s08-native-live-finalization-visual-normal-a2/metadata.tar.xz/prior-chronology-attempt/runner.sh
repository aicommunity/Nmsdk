set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-live-finalization-visual-normal-a1"
work="$base/source-live-finalization-visual-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$work"
export OUT="$out" BASE="$base" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/test.log" 2>&1
from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile,time,unittest
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.live_finalization_reports import render_live_finalization
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);start=time.monotonic()
prefix='Reports/StructTrain/TimeLearner/s08-native-live-finalization-normal-a1/'
manifest=json.loads(subprocess.check_output(['git','show','HEAD:'+prefix+'manifest.json']))
archive=subprocess.check_output(['git','show','HEAD:'+prefix+'primary.tar.xz'])
assert hashlib.sha256(archive).hexdigest()==manifest['archive_sha256']
assert sum(row['bytes'] for row in manifest['files'])<2*1024**3
data=out/'data';data.mkdir();expected={row['path']:row for row in manifest['files']}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  row=expected.pop(member.name);raw=tar.extractfile(member).read()
  assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
  p=data/member.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert not expected
inventory=data/'s08-native-live-finalization-reader-normal-a3/composition.json'
composition=load(inventory);native=data/'composed-native';native.mkdir()
for row in composition['files']:
 source=data/row['source_run']/row['source_path']
 assert source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest()==row['sha256']
 os.link(source,native/row['path'])
def snapshot():
 return {p.relative_to(data).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(data.rglob('*')) if p.is_file()}
before=snapshot()
cache=base/'cache/s08-native-live-finalization-normal-a1';assert not cache.exists();cache.mkdir()
declaration=load(Path('Scripts/StructTrain/TimeLearner/Specifications/native-live-finalization-addressed.json'))
names=sorted(name for name,kind in declaration['expected_controls'].items() if kind=='native_live_finalization_control')
assert len(names)==16
reports=[]
for name in names:
 source=native/name;target=cache/Path(name).stem
 result=render_live_finalization(source,inventory,target)
 reports.append({'source':name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                 'output':target.name,'result':result})
 print('RENDERED',name,'training_pairs',result['training_trial_soma_pairs'],
       'recognition_pairs',result['recognition_trial_soma_pairs'],flush=True)
(cache/'render-index.json').write_text(json.dumps({'kind':'native_live_finalization_report_index','schema_version':1,
 'reports':reports,'source_proof_commit':'a7ef72e14f8a43fff916a460d126cc6bf25db03b',
 'renderer_root':'3d679ec7f4245239b7dd86f081db045dab4ea468','scientific_verdict':None},indent=2)+'\n')
os.environ['TIMELEARNER_LIVE_REPORTS']=str(cache)
os.environ['TIMELEARNER_LIVE_FINALIZATION_NATIVE']=str(native)
os.environ['TIMELEARNER_LIVE_PRIMARY_INVENTORY']=str(inventory)
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_live_finalization_reports'))
assert r.wasSuccessful() and r.testsRun==3 and not r.skipped
assert snapshot()==before
value={'kind':'native_live_temporal_report_gate','schema_version':1,'reports':reports,'tests':r.testsRun,
 'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'seconds':time.monotonic()-start,
 'source_files_unchanged':len(before),'cache':str(cache),'cache_files':sum(p.is_file() for p in cache.rglob('*')),
 'cache_bytes':sum(p.stat().st_size for p in cache.rglob('*') if p.is_file()),
 'training_trial_soma_pairs':sum(row['result']['training_trial_soma_pairs'] for row in reports),
 'recognition_trial_soma_pairs':sum(row['result']['recognition_trial_soma_pairs'] for row in reports),
 'selected_visual_review_complete':False,'scientific_verdict':None}
(out/'validation.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k!='reports'}),flush=True)
PY
