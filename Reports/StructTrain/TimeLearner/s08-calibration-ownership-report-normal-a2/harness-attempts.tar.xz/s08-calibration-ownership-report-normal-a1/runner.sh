set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-calibration-ownership-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
cd "$base/source-calibration-ownership-report-normal-a1"
export PYTHONDONTWRITEBYTECODE=1
OUT="$out" python3 - <<'PY' > "$out/reports.log" 2>&1
import os,json,hashlib,tarfile,io,unittest,sys
from pathlib import Path
from PIL import Image
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.calibration_transaction_reports import render_calibration_transaction
from Scripts.StructTrain.TimeLearner.recognition_trial_evidence import audit_recognition_trial
from Scripts.StructTrain.TimeLearner.plotting import render_soma,padded_limits
out=Path(os.environ['OUT'])
bundle=Path('Reports/StructTrain/TimeLearner/s08-calibration-ownership-normal-a1')
manifest=load(bundle/'manifest.json');archive=bundle/'primary.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
extracted=out/'extracted';extracted.mkdir()
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest['files'])
 expected={r['path']:r for r in manifest['files']}
 for member in members:
  assert member.isfile() and member.name in expected and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  data=tar.extractfile(member).read();r=expected[member.name]
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  target=extracted/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
os.environ['TIMELEARNER_CALIBRATION_OWNERSHIP_DIR']=str(extracted/'fixed-native/native')
os.environ['TIMELEARNER_CALIBRATION_OWNERSHIP_SOURCE']=str(extracted/'source-primary')
suite=unittest.defaultTestLoader.loadTestsFromNames(['Scripts.StructTrain.TimeLearner.tests.test_calibration_ownership_evidence','Scripts.StructTrain.TimeLearner.tests.test_plotting'])
assert suite.countTestCases()==9
result=unittest.TextTestRunner(verbosity=2).run(suite)
assert result.wasSuccessful() and result.testsRun==9 and not result.skipped
reports=out/'reports';reports.mkdir();records=[];pairs=0;selected={}
encode=lambda v:(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
for path in sorted((extracted/'fixed-native/native').glob('*_ownership_*.json')):
 record=load(path);top=record['topology'];scenario=record['scenario']
 transaction=out/(path.stem+'-transaction.json');transaction.write_bytes(encode(record['transaction']))
 folder=reports/path.stem
 info=render_calibration_transaction(transaction,folder);pairs+=info['trial_soma_pairs']
 assert info['completed_matrices']==(3 if scenario==3 else 0)
 records.append({'record':path.name,'report':str(folder),'manifest':info})
 if scenario==3:
  for trial in range(2):
   png=folder/'fresh-confirmation'/f'trial-{trial:04d}-soma-001'/'overview.png'
   assert Image.open(png).size==(1920,960)
   selected[f'{top}-confirmation-'+('target' if trial==0 else 'foil')+'.png']=png.read_bytes()
 if scenario==1:
  o=record['external_observation'];audit_recognition_trial(o,record['candidate_before'])
  count=len(o['samples'][0]['soma'])
  for channel in range(count):
   folder=reports/(path.stem+f'-consumed-complete-soma-{channel+1}')
   folder.mkdir()
   views=render_soma(o,channel,f'$.Soma{channel+1}.SumPotential (SI units unverified)',padded_limits([r['soma'][channel] for r in o['samples']]),folder)
   assert all(v['downsampling'] is False and v['png_width']==1920 and v['png_height']==960 for v in views)
   assert all(v['minimum_native_tick_pixels_on_zoom']>=8 for v in views if v['time_view']!='overview')
   (folder/'manifest.json').write_bytes(encode({'kind':'single_complete_consumed_probe_diagnostic','views':views,'source_record':path.name,'trial_id':o['trial_id'],'model_revision':o['model_before'],'calibration_claim':False,'visual_acceptance_complete':False,'evaluation_verdict':None}))
assert len(records)==8 and pairs==18
validation={'tests':9,'failures':0,'errors':0,'skips':0,'complete_transaction_matrices':6,'trial_soma_pairs':pairs,'consumed_probe_soma_pairs':3,'source_bundle':'56b6471311f8d85cfd2671ddb10f5c269952aa6a','renderer_root':'56b6471311f8d85cfd2671ddb10f5c269952aa6a','visual_acceptance_complete':False,'evaluation_verdict':None}
(out/'validation.json').write_bytes(encode(validation))
dest=Path('Reports/StructTrain/TimeLearner/s08-calibration-ownership-report-normal-a1');dest.mkdir()
metadata={}
for p in reports.rglob('*.json'):
 if 'primary' not in p.relative_to(reports).parts:
  metadata[p.relative_to(reports).as_posix()]=p.read_bytes()
metadata['validation.json']=encode(validation)
metadata['report-records.json']=encode(records)
meta=dest/'report-metadata.tar.xz'
with tarfile.open(meta,'w:xz',preset=6) as tar:
 for name,data in sorted(metadata.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
picked=dest/'selected';picked.mkdir()
for name,data in selected.items():(picked/name).write_bytes(data)
(dest/'manifest.json').write_bytes(encode({'kind':'ownership_visual_cache_receipt','schema_version':1,**validation,'cache':str(reports),'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'metadata_files':[{'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(metadata.items())],'selected':[{'path':'selected/'+n,'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(selected.items())]}))
(dest/'README.md').write_bytes(('# Ownership controls: native soma/input reports\n\nM40 verified and losslessly extracted the published normal primary bundle. Nine checks passed (four ownership evidence checks and five plotting regressions). Full calibrated transaction reports cover all six complete candidate/confirmation matrices, both patterns and every soma: 18 trial/soma pairs. Three additional complete externally consumed probe/soma pairs have diagnostic plots. Six interrupted/context-replaced transactions retain their raw diagnostic evidence and do not invent complete matrices.\n\nEvery plot uses actual soma samples and overlaid native input samples/events. PNG is 1920 by 960; 100-tick zoom tiles provide at least 14.208 horizontal pixels per native tick without decimation. Full PNG/SVG/PDF reports remain reproducible M40 cache. Git stores metadata and four selected confirmation overviews. SI units are unverified; manual visual acceptance and the full original experiment matrix remain open. Scientific verdict is null.\n').encode())
(dest/'SHA256SUMS.json').write_bytes(encode({p.relative_to(dest).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}))
print(json.dumps(validation))
PY
git add Reports/StructTrain/TimeLearner/s08-calibration-ownership-report-normal-a1
git commit -m 'Preserve readable soma input report metadata and selected ownership confirmation plots'
git -c push.recurseSubmodules=no push origin HEAD
test "$(git ls-remote origin refs/heads/codex/timelearner-ownership-visual-evidence-a1 | cut -f1)" = "$(git rev-parse HEAD)"
git rev-parse HEAD
