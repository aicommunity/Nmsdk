set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-fixed-report-normal-a3"
repo="$base/source-posttune-observation-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-native-posttune-fixed-report-normal-a1/process-exit-status.txt")" = 1
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git b7cab7348aea1fc29038b991d5298693d10ed87e > "$out/checkout.log" 2>&1
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 655af8a4ee7e132ef7754181398bd6b709cd9392 >> "$out/checkout.log" 2>&1
mkdir "$out/source"
git -C "$repo" archive b7cab7348aea1fc29038b991d5298693d10ed87e Scripts | tar -x -C "$out/source"
cd "$out/source"
export OUT="$out" REPO="$repo" PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/extract.log" 2>&1
import hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
out=Path(os.environ['OUT']);repo=Path(os.environ['REPO'])
commit='655af8a4ee7e132ef7754181398bd6b709cd9392'
prefix='Reports/StructTrain/TimeLearner/s08-native-posttune-fixed-normal-a2/'
blob=lambda name:subprocess.check_output(['git','-C',str(repo),'show',commit+':'+prefix+name])
m=json.loads(blob('manifest.json'));raw=blob('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
(out/'git-primary-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
expected={r['path']:r for r in m['files']};assert len(expected)==134
data=out/'data';data.mkdir()
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
 for member in tar:
  assert member.isfile() and member.name in expected
  relative=Path(member.name);assert not relative.is_absolute() and '..' not in relative.parts
  raw=tar.extractfile(member).read();r=expected.pop(member.name)
  assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256']
  p=data/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
assert not expected
for r in m['files']:
 p=data/r['path'];assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
print('all 134 Git primary members extracted and checked twice')
PY
export TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS="$out/data/native-fixed-a2/native"
export TIMELEARNER_FIXED_POSTTUNE_SOURCE="$out/data/native-fixed-a2/runs"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_fixed_posttune_evidence Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/report.log" 2>&1
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.learned_evidence import load_case
from Scripts.StructTrain.TimeLearner.posttune_transaction_evidence import audit_posttune_transaction
from Scripts.StructTrain.TimeLearner.calibration_transaction_evidence import audit_native_calibration_transaction
from Scripts.StructTrain.TimeLearner.calibration_transaction_reports import _spec,render_calibration_transaction
from Scripts.StructTrain.TimeLearner.recognition_metrics import score_recognition_evaluation
from Scripts.StructTrain.TimeLearner.reports import render_evaluation
from Scripts.StructTrain.TimeLearner.__main__ import main
out=Path(os.environ['OUT']);root=Path(os.environ['TIMELEARNER_FIXED_POSTTUNE_ARTIFACTS'])
sources={}
for folder in Path(os.environ['TIMELEARNER_FIXED_POSTTUNE_SOURCE']).iterdir():
 run=load(folder/'run-manifest.json');p=folder/run['source_package_path'];sources[load(p)['sha256']]=p
assert len(sources)==2
reports=out/'reports';reports.mkdir();rows=[];pairs=0
records=sorted(root.glob('*_fixed_*_transaction.json'));assert len(records)==8
for path in records:
 r=load(path);source=sources[r['source_recognition']['source_solo']['sha256']]
 print('BEGIN weight report',path.name,flush=True)
 target=reports/path.stem
 assert main(['report',str(path),'--format','posttune-transaction','--source-solo',str(source),'--output',str(target)])==0
 m=load(target/'manifest.json');pairs+=m['trial_soma_pairs']
 assert m['calibration_status']==('unverified' if r['status']=='recovery_required' else 'fixed')
 rows.append({'phase':'fixed_weights','name':target.name,'trial_soma_pairs':m['trial_soma_pairs'],'status':r['status']})
for path in sorted(root.glob('*_fixed_*_roundtrip.json')):
 wrapper=load(path);name=path.stem.removesuffix('_roundtrip')
 parent=load(root/(name+'_transaction.json'));chosen=wrapper['selected_package']
 assert parent['status']=='weights_selected' and parent['selected_package']==chosen
 source=load_case(sources[chosen['source_solo']['sha256']])
 child=wrapper['subsequent_calibration']
 proof=audit_native_calibration_transaction(child,source);assert child['source_recognition']==chosen
 primary=out/'render-inputs'/name;primary.mkdir(parents=True)
 write=lambda p,v:p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
 write(primary/'calibration.json',child)
 target=reports/(name+'_later-calibration')
 print('BEGIN later calibration',name,flush=True)
 result=render_calibration_transaction(primary/'calibration.json',target);pairs+=result['trial_soma_pairs']
 write(target/'source-binding.json',{'source_solo_sha256':chosen['source_solo']['sha256'],'source_audit':proof,
  'fixed_parent_transaction_sha256':parent['sha256'],'primary_bundle_commit':'655af8a4ee7e132ef7754181398bd6b709cd9392',
  'native_execution_verified':False,'evaluation_verdict':None})
 # Expected requests come from the declared fixture protocol, not measured end
 # times: actor <top>_fixed_0 changes only run_id to <actor>/roundtrip.
 requests=[{**q,'run_id':name+'/roundtrip'} for q in parent['trials']]
 matrix={'requests':requests,'observations':wrapper['observations']}
 spec=_spec(matrix,chosen,parent['confirmation_specification']['criterion'])
 metrics=score_recognition_evaluation(spec,wrapper['observations'],chosen)
 assert metrics['validity']=='valid' and metrics['pooled_counts']['FN']==1
 write(primary/'model.json',chosen)
 observations={o['trial_id']:o for o in wrapper['observations']}
 assert len(observations)==len(wrapper['observations'])==len(spec['trials'])
 for q in spec['trials']:
  # The input adapter uses ordinary JSON; render_evaluation creates its own
  # correctly compressed lossless primary snapshot.
  q['observation']=q['observation'].removesuffix('.gz')
  write(primary/q['observation'],observations[q['trial_id']])
 write(primary/'evaluation.json',spec)
 target2=reports/(name+'_roundtrip')
 print('BEGIN roundtrip',name,flush=True)
 result2=render_evaluation(primary/'evaluation.json',primary/'model.json',target2);pairs+=result2['trial_soma_pairs']
 rows.extend([{'phase':'later_calibration','name':target.name,'trial_soma_pairs':result['trial_soma_pairs'],'status':child['status']},
  {'phase':'roundtrip','name':target2.name,'trial_soma_pairs':result2['trial_soma_pairs'],'status':'fixed_negative_evaluation'}])
# Include the added source-binding in the actual cache checksum closure.
for folder in reports.iterdir():
 sums={p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
  for p in sorted(folder.rglob('*')) if p.is_file() and p!=folder/'SHA256SUMS.json'}
 write(folder/'SHA256SUMS.json',sums)
assert len(rows)==12 and pairs==32,(len(rows),pairs)
write(out/'validation.json',{'renderer_root':'b7cab7348aea1fc29038b991d5298693d10ed87e','source_bundle':'655af8a4ee7e132ef7754181398bd6b709cd9392',
 'reports':len(rows),'trial_soma_pairs':pairs,'rows':rows,'full_visual_acceptance':False,'evaluation_verdict':None})
print(json.dumps({'reports':len(rows),'trial_soma_pairs':pairs}))
PY

