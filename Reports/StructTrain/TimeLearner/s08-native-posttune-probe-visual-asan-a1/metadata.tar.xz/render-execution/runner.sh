set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-probe-report-asan-a2"
repo="$base/source-rdk-bool-evidence-asan-a2";work="$base/source-probe-threshold-report-asan-a2"
cache="$base/cache/s08-native-posttune-probe-threshold-asan-a2"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
while kill -0 3812820 2>/dev/null; do sleep 10; done
test "$(cat "$base/readbacks/s08-native-posttune-probe-threshold-asan-a1/process-exit-status.txt")" = 0
test ! -e "$cache"
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 8c64d5d2c8204ef14f38d59df0c7a3d576f6a57b > "$out/checkout.log" 2>&1
git -C "$repo" worktree add --no-checkout --detach "$work" FETCH_HEAD >> "$out/checkout.log" 2>&1
git -C "$work" sparse-checkout init --cone;git -C "$work" sparse-checkout set Scripts
git -C "$work" -c submodule.recurse=false checkout >> "$out/checkout.log" 2>&1
cd "$work";export BASE="$base" OUT="$out" CACHE="$cache" PYTHONDONTWRITEBYTECODE=1
"$base/plot-venv-a1/bin/python" -u - <<'PY' > "$out/render.log" 2>&1
import hashlib,json,os,unittest,time,shutil
from pathlib import Path
from Scripts.StructTrain.TimeLearner.native_evidence import load
from Scripts.StructTrain.TimeLearner.posttune_transaction_reports import render_posttune_transaction
base=Path(os.environ['BASE']);out=Path(os.environ['OUT']);cache=Path(os.environ['CACHE'])
original=base/'readbacks/s08-native-posttune-fixed-console-asan-a1/runs';sources={}
for name in ['Classic-auto_metric','Branch-synthetic']:
 folder=original/(name+'-legacy');run=load(folder/'run-manifest.json');path=folder/run['source_package_path']
 sources[load(path)['sha256']]=path
native=base/'readbacks/s08-native-posttune-probe-threshold-asan-a1/native';records=[]
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
for p in sorted(native.glob('*_probe_threshold_*.json')):
 r=load(p);source=sources[r['source_recognition']['source_solo']['sha256']]
 result=render_posttune_transaction(p,source,cache/p.stem)
 records.append({'case':p.stem,'source_report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_solo_sha256':load(source)['sha256'],'result':result})
 print(json.dumps(records[-1]),flush=True)
assert len(records)==8
os.environ['TIMELEARNER_PROBE_THRESHOLD_REPORTS']=str(cache)
suite=unittest.defaultTestLoader.loadTestsFromName('Scripts.StructTrain.TimeLearner.tests.test_posttune_probe_threshold_reports')
begin=time.monotonic();tests=unittest.TextTestRunner(verbosity=2).run(suite)
assert tests.wasSuccessful() and tests.testsRun==2 and not tests.skipped
selected=[];(out/'selected').mkdir()
for top in ['Classic','Branch']:
 folder=cache/(top+'_probe_threshold_0');outer=load(folder/'manifest.json')
 for item in outer['weight_matrices']+outer['final_model_matrices']:
  group=folder/item['name'];spec=load(group/'primary/evaluation.json')
  target=next(q['trial_id'] for q in spec['trials'] if q['label']=='target')
  figure=next(f for f in load(group/'manifest.json')['figures'] if f['trial_id']==target and f['descriptor']['index']==0)
  views=[next(v for v in figure['views'] if v['time_view']=='overview'),next(v for v in figure['views'] if v['time_view']!='overview')]
  for index,v in enumerate(views):
   source=group/v['files'][0];name=top+'_'+item['name']+('_overview.png' if index==0 else '_detail.png')
   shutil.copyfile(source,out/'selected'/name)
   selected.append({'path':'selected/'+name,'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'cache_path':str(source),'source_transaction_sha256':outer['source_transaction_sha256'],'model_revision':item['model_revision'],'role':item['role']})
write(out/'selected-sources.json',{'records':selected,'visual_acceptance_complete':False,'scientific_verdict':None})
inventory=[{'path':p.relative_to(cache).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(cache.rglob('*')) if p.is_file()]
write(out/'cache-inventory.json',{'cache_root':str(cache),'files':inventory})
write(out/'render-validation.json',{'kind':'native_post_tune_probe_threshold_visual_gate','schema_version':1,
 'renderer_root':'8c64d5d2c8204ef14f38d59df0c7a3d576f6a57b','records':records,'tests':tests.testsRun,'test_seconds':time.monotonic()-begin,
 'cache_files':len(inventory),'cache_bytes':sum(r['bytes'] for r in inventory),'selected_figures':len(selected),
 'trial_soma_pairs':sum(r['result']['trial_soma_pairs'] for r in records),'visual_acceptance_complete':False,'scientific_verdict':None})
PY
