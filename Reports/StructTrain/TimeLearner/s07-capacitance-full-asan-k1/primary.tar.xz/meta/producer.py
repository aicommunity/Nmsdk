from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,threading,time,traceback,shutil,xml.etree.ElementTree as ET
base=Path('/media/user/Data/TimeLearnerRefactor');label='capacitance-full-asan-k1-evidence-a1';out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False);original=base/'readbacks/s07-capacitance-full-asan-k1';source=base/'source-capacitance-full-asan-k1';api=base/'source-audit-probe-retirement-a1';token=None;thread=None;stop=threading.Event();errors=[];passed=False
root='69789b8cb93dbc2ce44fe7a8d90aed758cf93f76'
def write(n,v):(out/n).write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
def sha(q):
 h=hashlib.sha256()
 with q.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def alive(v):
 q=Path('/proc')/str(v['pid'])/'stat'
 try:
  fields=q.read_text().rsplit(') ',1)[1].split();return fields[19]==str(v['start_ticks']) and fields[0] not in ['Z','X']
 except (FileNotFoundError,ProcessLookupError):return False
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19],'original':str(original),'root':root,'purpose':'archive completed ASan primary, no models or compilation'});(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 terminal=json.loads((original/'terminal.json').read_text());assert terminal['acceptance_status']=='passed' and terminal['root']==root
 for stem,count in [('targeted',34),('native',262)]:
  verdict=json.loads((original/(stem+'-verdict.json')).read_text());assert verdict['execution']=='completed' and verdict['validity']=='valid' and verdict['assertion_status']=='passed' and verdict['inventory']['observed']==verdict['inventory']['expected']==count
  cases=list(ET.parse(original/(stem+'-result/native.xml')).getroot().iter('testcase'));assert len(cases)==count and not any(list(x.iter('failure')) or list(x.iter('error')) or list(x.iter('skipped')) for x in cases)
  stderr=(original/(stem+'-result/process/stderr.log')).read_text(errors='replace');assert not any(s in stderr for s in ['ERROR: AddressSanitizer','SUMMARY: AddressSanitizer','AddressSanitizer:DEADLYSIGNAL'])
 readers=json.loads((original/'structured-readers/result.json').read_text());assert readers['executed_tests']==119 and readers['assertion_status']=='passed' and not any(readers[k] for k in ['failures','errors','skipped'])
 records={}
 for q in [*(original.glob('owned-*.json')),*(original.rglob('owned-process.json'))]:
  value=json.loads(q.read_text());assert 'pid' in value and 'start_ticks' in value;state={'pid':value['pid'],'start_ticks':value['start_ticks'],'same_handle_live':alive(value)};assert not state['same_handle_live'];records[str(q.relative_to(original))]=state
 write('original-handles-fresh.json',{'handles':records,'all_recorded_handles_closed':True,'ownership_scope':'recorded handles from legacy launcher; not a whole-descendant cgroup attestation'})
 assert shutil.disk_usage(base).free>=5*1024**3
 sys.path.insert(0,str(api))
 from Scripts.StructTrain.TimeLearner.resource_reservations import Reservations
 registry=Reservations(base/'resource-reservations.sqlite3');prior=json.loads((original/'reservation.json').read_text());ledger=registry.inspect();assert next(x for x in ledger['leases'] if x['token']==prior['token'])['state']=='released';write('original-reservation-state.json',{'token':prior['token'],'state':'released','automatic_recovery_performed':False})
 lease=registry.reserve('s07-'+label,[{'path':str(out),'access':'write'}]+[{'path':str(q),'access':'read'} for q in [original,source,api]],ttl_seconds=120);token=lease['token'];write('reservation.json',lease)
 def heartbeat():
  while not stop.wait(20):
   try:registry.heartbeat(token,ttl_seconds=120);registry.validate_paths(token)
   except BaseException as e:errors.append(str(e));return
 thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
 def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
 closure=json.loads((original/'source-closure.json').read_text());assert git(source,'rev-parse','HEAD')==root and closure['root']==root
 assert not git(source,'status','--porcelain','--untracked-files=no')
 for name,head in closure['children'].items():assert git(source/name,'rev-parse','HEAD')==head and not git(source/name,'status','--porcelain','--untracked-files=no')
 write('source-hashes.json',{q.relative_to(source).as_posix():sha(q) for prefix in ['App/NeuroModelerConsole','Tests/Integration/Libraries','Libraries/Nmsdk-PulseLib/Core'] for q in sorted((source/prefix).rglob('*')) if q.is_file() and q.suffix in ['.cpp','.h','.c']})
 write('scope.json',{'targeted_tests':34,'full_tests':262,'readers':119,'source_closure':closure,'asan_options':'detect_leaks=0','leak_absence_attested':False,'legacy_source_uses_shared_object_handles':True,'final_native_peak_memory_bytes':None,'memory_measurement_limit':'legacy launcher did not retain native rusage or final cgroup peak; historical RSS observations are only lower bounds','scientific_verdict':None,'whole_plan_complete':False})
 files={};symlinks={}
 for folder,prefix in [(original,'raw'),(out,'meta')]:
  for q in sorted(folder.rglob('*')):
   name=prefix+'/'+q.relative_to(folder).as_posix()
   if q.is_symlink():symlinks[name]=os.readlink(q);continue
   if q.is_file():files[name]={'path':q,'bytes':q.stat().st_size,'sha256':sha(q)}
 with tarfile.open(out/'primary.tar.xz','w:xz',preset=3) as archive:
  for name,record in files.items():
   q=record['path'];assert q.stat().st_size==record['bytes']
   info=tarfile.TarInfo(name);info.size=record['bytes']
   with q.open('rb') as f:archive.addfile(info,f)
 assert not errors
 for name,record in files.items():assert record['path'].stat().st_size==record['bytes'] and sha(record['path'])==record['sha256']
 write('bundle.json',{'kind':'completed_capacitance_full_asan_primary','root':root,'members':{n:{k:v for k,v in r.items() if k!='path'} for n,r in files.items()},'symlinks':symlinks,'archive_bytes':(out/'primary.tar.xz').stat().st_size,'archive_sha256':sha(out/'primary.tar.xz'),'original_regular_files':sum(n.startswith('raw/') for n in files),'targeted':34,'full':262,'readers':119,'scientific_verdict':None});passed=True
except BaseException as e:write('exception.json',{'reason':str(e),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if thread:thread.join(timeout=30)
 write('terminal.json',{'archive_complete':passed,'native_models_executed_by_archiver':False,'whole_plan_complete':False,'scientific_verdict':None});print('CLOSED',passed,flush=True)
