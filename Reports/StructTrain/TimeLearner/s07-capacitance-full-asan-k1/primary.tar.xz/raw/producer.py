
from pathlib import Path
import os,sys,json,subprocess,hashlib,tarfile,io,shutil,threading,time,traceback,importlib.util
base=Path('/media/user/Data/TimeLearnerRefactor')
root='69789b8cb93dbc2ce44fe7a8d90aed758cf93f76'
lease_root='ea8345c334738cc9aea34c2010dd0d380cf474dd'
label='capacitance-full-asan-k1'
out=base/('readbacks/s07-'+label);out.mkdir(exist_ok=False)
source=base/('source-'+label);build=base/('build-'+label);runtime=base/('runtime-'+label)
donor=base/'source-legacy-completed-replay-asan-a1';oldsource=base/'source-finite-ranking-asan-a1'
framework=base/'framework-configured-probe-ownership-asan-h14'
stop=threading.Event();heartbeat=None;lease=None;token=None;heartbeat_errors=[];passed=False;children=[]
def write(name,value):
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def ticks(pid):return Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()[19]
def git(directory,*args):return subprocess.check_output(['git','-C',str(directory),*args],text=True).strip()
def check_lease():
 if token:lease.validate_paths(token)
 assert not heartbeat_errors,heartbeat_errors
def run(args,name):
 check_lease()
 with (out/name).open('xb') as log:
  p=subprocess.Popen(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
  record={'pid':p.pid,'start_ticks':ticks(p.pid),'arguments':list(map(str,args))};children.append(record);write('owned-'+name+'.json',record)
  status=p.wait()
 if status:raise RuntimeError(name+':'+str(status))
 check_lease()
def available():return int(next(r.split()[1] for r in Path('/proc/meminfo').read_text().splitlines() if r.startswith('MemAvailable:')))*1024
write('owned-supervisor.json',{'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'root':root,'source':str(source),'build':str(build),'runtime':str(runtime)})
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
try:
 assert not any(p.exists() for p in [source,build,runtime])
 disk=shutil.disk_usage(base);memory=available()
 assert disk.free>=60*1024**3 and memory>=32*1024**3
 write('resource-preflight.json',{'disk_free_bytes':disk.free,'memory_available_bytes':memory,'compiler_parallelism':2,'minimum_memory_bytes':32*1024**3,'minimum_disk_bytes':60*1024**3,'native_child_timeout_unchanged':True})
 subprocess.run(['git','-C',str(donor),'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',lease_root],check=True)
 raw=subprocess.check_output(['git','-C',str(donor),'show',lease_root+':Scripts/StructTrain/TimeLearner/resource_reservations.py'])
 (out/'resource_reservations.py').write_bytes(raw)
 spec=importlib.util.spec_from_file_location('tl_worker_reservations',out/'resource_reservations.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 lease=module.Reservations(base/'resource-reservations.sqlite3')
 resources=[{'path':str(p),'access':'write'} for p in [source,build,runtime,out]]+[{'path':str(p),'access':'read'} for p in [donor,oldsource,framework]]
 reserved=lease.reserve('s07-'+label,resources,ttl_seconds=120);token=reserved['token'];write('reservation.json',dict(reserved,implementation_root=lease_root,implementation_sha256=hashlib.sha256(raw).hexdigest()))
 def keep_alive():
  while not stop.wait(20):
   try:lease.heartbeat(token,ttl_seconds=120);lease.validate_paths(token)
   except BaseException as error:heartbeat_errors.append(str(error));write('heartbeat-error.json',{'reason':str(error)});return
 heartbeat=threading.Thread(target=keep_alive,daemon=True);heartbeat.start()
 run(['git','clone','--shared','--no-checkout','--no-recurse-submodules',donor,source],'clone-root.log')
 run(['git','-C',source,'sparse-checkout','init','--no-cone'],'sparse-init.log')
 run(['git','-C',source,'sparse-checkout','set','--no-cone','/*','!/Reports/','!/Docs/'],'sparse-set.log')
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',root],'fetch-root.log')
 run(['git','-C',source,'-c','submodule.recurse=false','checkout','--detach',root],'checkout-root.log')
 closure={}
 for line in git(source,'config','-f','.gitmodules','--get-regexp','^submodule.*.path$').splitlines():
  key,path=line.split(None,1);url=git(source,'config','-f','.gitmodules','--get',key[:-5]+'.url').replace('git@github.com:','https://github.com/')
  destination=source/path;destination.parent.mkdir(parents=True,exist_ok=True)
  assert not destination.exists() or not any(destination.iterdir())
  run(['git','clone','--shared','--no-checkout',oldsource/path,destination],'clone-'+path.replace('/','_')+'.log')
  wanted=git(source,'rev-parse','HEAD:'+path)
  if subprocess.run(['git','-C',str(destination),'cat-file','-e',wanted+'^{commit}'],capture_output=True).returncode:
   run(['git','-C',destination,'fetch','--no-recurse-submodules',url,wanted],'fetch-'+path.replace('/','_')+'.log')
  run(['git','-C',destination,'-c','submodule.recurse=false','checkout','--detach',wanted],'checkout-'+path.replace('/','_')+'.log')
  assert git(destination,'rev-parse','HEAD')==wanted and not git(destination,'status','--porcelain','--untracked-files=no')
  closure[path]=wanted
 assert len(closure)==7 and closure['Libraries/Nmsdk-PulseLib']=='84e456d6fb551021e0222ebaf51fa313df2623b4'
 run(['git','-C',source,'submodule','init'],'init-submodules.log');assert not git(source,'status','--porcelain','--untracked-files=no')
 write('source-closure.json',{'root':root,'children':closure,'clean':True})
 assert git(framework,'rev-parse','HEAD')=='58d77fa8070e8cec2dc1ed015d66b454c8d78850' and not git(framework,'status','--porcelain','--untracked-files=no')
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DCMAKE_CXX_FLAGS_RELWITHDEBINFO=-O1 -g1 -fsanitize=address -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address','-DBUILD_TESTING=ON','-DCMAKE_DISABLE_FIND_PACKAGE_GTest=ON','-DRDK_BUILD_LEGACY_ENGINE_UNIT_TESTS=OFF','-DFETCHCONTENT_SOURCE_DIR_GOOGLETEST='+str(framework),'-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DNMSDK_DEPLOY_ROOT='+str(runtime)]
 write('configure-arguments.json',{'arguments':list(map(str,args))});run(args,'configure.log')
 run(['cmake','--build',build,'--target','Test_PulseLib_StorageComponents','NeuroModelerConsole','--parallel','2'],'build.log')
 (out/'CMakeCache.txt').write_bytes((build/'CMakeCache.txt').read_bytes())
 write('build-terminal.json',{'execution':'completed','root':root})
 sys.path.insert(0,str(source));os.chdir(source)
 from Scripts.StructTrain.TimeLearner.runtime import snapshot
 from Scripts.StructTrain.TimeLearner.native_gate import run_native_gate
 from Scripts.StructTrain.TimeLearner.validation import package_fingerprint,fixture_fingerprint
 os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['ASAN_OPTIONS']='detect_leaks=0'
 write('native-runtime.json',snapshot(source,runtime/'Test_PulseLib_StorageComponents',runtime/'NeuroModelerConsole.ini',build/'CMakeCache.txt'))
 for stage,filename,count,budget in [('targeted','native-capacitance-search-v4.json',34,21600),('native','native-capacitance-search-regression-v4.json',262,86400)]:
  check_lease();assert available()>=32*1024**3
  specification=json.loads((source/'Scripts/StructTrain/TimeLearner/specs'/filename).read_text());assert len(specification['expected_test_ids'])==count
  specification.update(source_root=str(source),runtime_manifest=str(out/'native-runtime.json'),maximum_wall_seconds=budget,asan_options='detect_leaks=0')
  write(stage+'-specification.json',specification)
  result=run_native_gate(out/(stage+'-specification.json'),out/(stage+'-result'));write(stage+'-verdict.json',result)
  assert result['execution']=='completed' and result['validity']=='valid' and result['assertion_status']=='passed'
  assert result['inventory']['expected']==result['inventory']['observed']==count and not result['inventory']['failed_test_ids']
  maps=json.loads((out/(stage+'-result/process/loaded-files.json')).read_text());assert any(Path(r['path']).name.startswith('libasan.so') for r in maps)
 check_lease()
 # Reuse the exact119 production reader declaration accepted with the normal262 run.
 proof='cfde22838e9c6eef7edd5dfbd20936b3bda97899';prefix='Reports/StructTrain/TimeLearner/s07-capacitance-full-normal-j5/'
 run(['git','-C',source,'fetch','--no-recurse-submodules','https://github.com/aicommunity/Nmsdk.git',proof],'fetch-normal-proof.log')
 archive=subprocess.check_output(['git','-C',str(source),'show',proof+':'+prefix+'primary.tar.gz'])
 bundle=json.loads(subprocess.check_output(['git','-C',str(source),'show',proof+':'+prefix+'bundle.json']))
 assert bundle['acceptance_status']=='passed' and hashlib.sha256(archive).hexdigest()==bundle['archive_sha256']
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  raw=tar.extractfile('reader-suite.json').read();assert hashlib.sha256(raw).hexdigest()==bundle['members']['reader-suite.json'];template=json.loads(raw)
 assert len(template['expected_test_ids'])==119
 fixtures={n:(out/'native-result' if n=='TIMELEARNER_NATIVE_GATE_DIR' else out/'native-result/native') for n in template['fixtures']}
 declarations={}
 for name,path in fixtures.items():
  count,fingerprint=fixture_fingerprint(path,'*.json');declarations[name]={'pattern':'*.json','files':count,'fingerprint':fingerprint}
 template.update(suite_id='capacitance-full-asan-k1-readers119',package_fingerprint=package_fingerprint(),fixtures=declarations);write('reader-suite.json',template)
 args=['python3','-m','Scripts.StructTrain.TimeLearner.validation',str(out/'reader-suite.json'),'--output',str(out/'structured-readers')]
 for name,path in fixtures.items():args+=['--fixture',name+'='+str(path)]
 run(args,'reader-cli.log')
 checked=json.loads((out/'structured-readers/result.json').read_text())
 assert checked['executed_tests']==119 and checked['assertion_status']=='passed' and not any(checked[k] for k in ['failures','errors','skipped'])
 passed=True
except BaseException as error:write('exception.json',{'reason':str(error),'traceback':traceback.format_exc()})
finally:
 stop.set()
 if heartbeat:heartbeat.join(timeout=30)
 if token:
  # Release only after the supervisor has no remaining direct child. On a crash
  # the durable held reservation remains for explicit recovery.
  remaining=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    if int((p/'stat').read_text().rsplit(') ',1)[1].split()[1])==os.getpid():remaining.append(int(p.name))
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  if not remaining and not heartbeat_errors:
   lease.release(token,note='Supervisor work ended and all direct children are closed; result separately recorded.')
  write('reservation-final.json',dict(lease.inspect(),remaining_direct_children=remaining,heartbeat_errors=heartbeat_errors))
 write('terminal.json',{'execution':'completed','acceptance_status':'passed' if passed else 'not_accepted','root':root,'targeted_tests':34,'declared_full_tests':262,'declared_readers':119,'asan_options':'detect_leaks=0','scientific_verdict':None})
 print('CLOSED',passed,flush=True)
