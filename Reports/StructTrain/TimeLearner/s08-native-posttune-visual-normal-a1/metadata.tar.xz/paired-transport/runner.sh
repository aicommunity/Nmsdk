set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-candidates-report-normal-a1"
src="$base/source-posttune-observation-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test "$(cat "$base/readbacks/s08-posttune-observation-report-publish-normal-a1/process-exit-status.txt")" = 0
test -z "$(git -C "$src" status --porcelain --untracked-files=no --ignore-submodules=all)"
git -C "$src" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 2d304c2aa250a2f2643863f6eac13da2b8b8e06e > "$out/checkout.log" 2>&1
git -C "$src" -c submodule.recurse=false checkout --detach 2d304c2aa250a2f2643863f6eac13da2b8b8e06e >> "$out/checkout.log" 2>&1
cd "$src"
OUT="$out" python3 - <<'PY' > "$out/extract.log" 2>&1
import hashlib,json,os,subprocess,tarfile,io
from pathlib import Path,PurePosixPath
p=Path(os.environ['OUT']);d='Reports/StructTrain/TimeLearner/s08-native-posttune-candidates-normal-a2/'
read=lambda n:subprocess.check_output(['git','show','HEAD:'+d+n])
m=json.loads(read('manifest.json'));raw=read('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
expected={r['path']:r for r in m['files']}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as tar:
 members=tar.getmembers();assert {v.name for v in members}==set(expected)
 for v in members:
  path=PurePosixPath(v.name);assert v.isfile() and not path.is_absolute() and '..' not in path.parts
  data=tar.extractfile(v).read();r=expected[v.name]
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  target=p/'data'/v.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(p/'git-primary-manifest.json').write_bytes(read('manifest.json'))
print(len(expected))
PY
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_POSTTUNE_CANDIDATES_DIR="$out/data/accepted-a2/native"
export TIMELEARNER_POSTTUNE_TRANSPORT_REPORT_CACHE="$out/reports"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_candidates -v > "$out/reader.log" 2>&1
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_recognition_transport_reports Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/report.log" 2>&1
OUT="$out" "$base/plot-venv-a1/bin/python" - <<'PY' > "$out/validation.log" 2>&1
import hashlib,json,os
from pathlib import Path
p=Path(os.environ['OUT']);manifests=sorted((p/'reports').glob('*/manifest.json'));assert len(manifests)==4
total=0;files=0
for path in manifests:
 m=json.loads(path.read_bytes());assert m['paired_model_waveform_values_exact'] is True and m['visual_acceptance_complete'] is False
 total+=m['soma_channels']
 sums=json.loads((path.parent/'SHA256SUMS.json').read_bytes())
 for n,h in sums.items():assert hashlib.sha256((path.parent/n).read_bytes()).hexdigest()==h
 files+=len(sums)
assert total==6
(p/'validation.json').write_text(json.dumps({'reader_root':'2d304c2aa250a2f2643863f6eac13da2b8b8e06e','reader_checks':8,
 'report_and_plot_checks':6,'reports':4,'pattern_soma_pairs':6,'hashed_report_files':files,
 'visual_acceptance_complete':False,'scientific_verdict':None},indent=2)+'\n')
PY
