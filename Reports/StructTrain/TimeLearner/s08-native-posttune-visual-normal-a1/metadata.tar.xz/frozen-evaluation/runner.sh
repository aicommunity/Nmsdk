set -euo pipefail
base=/media/user/Data/TimeLearnerRefactor
out="$base/readbacks/s08-native-posttune-worker-report-normal-a1"
repo="$base/source-posttune-observation-report-normal-a1";src="$base/source-native-posttune-worker-report-normal-a1"
trap 'echo $? > "$out/process-exit-status.txt"' EXIT
test ! -e "$src"
git -C "$repo" -c fetch.recurseSubmodules=false fetch https://github.com/aicommunity/Nmsdk.git 6870d987ac83ab21b84387277259c2c4c6e3da5f > "$out/checkout.log" 2>&1
git -C "$repo" -c submodule.recurse=false worktree add --detach "$src" 6870d987ac83ab21b84387277259c2c4c6e3da5f >> "$out/checkout.log" 2>&1
cd "$src"
OUT="$out" python3 - <<'PY' > "$out/extract.log" 2>&1
import hashlib,json,os,subprocess,tarfile,io
from pathlib import Path,PurePosixPath
p=Path(os.environ['OUT']);d='Reports/StructTrain/TimeLearner/s08-native-posttune-worker-normal-a1/'
read=lambda n:subprocess.check_output(['git','show','HEAD:'+d+n])
m=json.loads(read('manifest.json'));raw=read('primary.tar.xz')
assert hashlib.sha256(raw).hexdigest()==m['archive_sha256']
expected={r['path']:r for r in m['files']}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as tar:
 members=tar.getmembers();assert {v.name for v in members}==set(expected)
 for v in members:
  path=PurePosixPath(v.name);assert v.isfile() and not path.is_absolute() and '..' not in path.parts
  data=tar.extractfile(v).read();r=expected[v.name]
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  target=p/'data'/v.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(p/'git-primary-manifest.json').write_bytes(read('manifest.json'))
print(len(expected))
PY
export PYTHONDONTWRITEBYTECODE=1 QT_QPA_PLATFORM=offscreen
export TIMELEARNER_NATIVE_POSTTUNE_WORKER_DIR="$out/data/runs"
"$base/plot-venv-a1/bin/python" -m unittest Scripts.StructTrain.TimeLearner.tests.test_native_posttune_worker Scripts.StructTrain.TimeLearner.tests.test_plotting -v > "$out/reader.log" 2>&1
OUT="$out" "$base/plot-venv-a1/bin/python" - <<'PY' > "$out/report.log" 2>&1
import hashlib,json,os
from pathlib import Path
from Scripts.StructTrain.TimeLearner.reports import render_evaluation
from Scripts.StructTrain.TimeLearner.native_pipeline_worker import audit_run_manifest
p=Path(os.environ['OUT']);root=p/'data/runs';reports=p/'reports';reports.mkdir()
records=json.loads((root/'controls.json').read_bytes())['records'];assert len(records)==20
rows=[]
for r in records:
 d=root/(r['name']+'-evaluate');audit_run_manifest(d/'run-manifest.json')
 target=reports/r['name'];render_evaluation(d/'native/evaluation.json',d/'native/model.json',target)
 m=json.loads((target/'manifest.json').read_bytes())
 for name,h in json.loads((target/'SHA256SUMS.json').read_bytes()).items():
  assert hashlib.sha256((target/name).read_bytes()).hexdigest()==h
 rows.append({'case':r['name'],'mode':r['mode'],'path':target.name,'source_run_manifest_sha256':hashlib.sha256((d/'run-manifest.json').read_bytes()).hexdigest(),
  'report_manifest_sha256':hashlib.sha256((target/'manifest.json').read_bytes()).hexdigest(),
  'source_counts':json.loads((d/'run-manifest.json').read_bytes())['analysis']['metrics']['pooled_counts']})
 print(r['name'],flush=True)
(p/'validation.json').write_text(json.dumps({'source_root':'6870d987ac83ab21b84387277259c2c4c6e3da5f',
 'primary_bundle_members':1814,'portable_worker_and_plot_checks':9,'evaluation_reports':20,
 'expected_patterns_per_report':2,'expected_pattern_soma_pairs':60,'rows':rows,
 'visual_acceptance_complete':False,'scientific_verdict':None},indent=2)+'\n')
PY
